#!/bin/bash

###############################################################################
# TestRun Manager v1.0 - Automatyczny skrypt instalacyjny dla Linux
# Autor: ITM Marek Dacz
# Data: 2026
###############################################################################

set -e

echo "=================================="
echo "TestRun Manager v1.0 - Instalacja"
echo "Autor: ITM Marek Dacz"
echo "=================================="
echo ""

# Kolory dla outputu
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Funkcje pomocnicze
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

# Sprawdź czy skrypt jest uruchomiony jako root
if [ "$EUID" -eq 0 ]; then 
    print_error "Nie uruchamiaj tego skryptu jako root. Użyj sudo tylko gdy będzie potrzebne."
    exit 1
fi

# Sprawdź system operacyjny
if [[ "$OSTYPE" != "linux-gnu"* ]]; then
    print_error "Ten skrypt działa tylko na systemach Linux"
    exit 1
fi

echo "Krok 1: Sprawdzanie wymagań systemowych..."

# Sprawdź Node.js
if ! command -v node &> /dev/null; then
    print_error "Node.js nie jest zainstalowany"
    print_info "Instaluję Node.js 18.x..."
    
    curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
    sudo apt install -y nodejs
    
    print_success "Node.js zainstalowany"
else
    NODE_VERSION=$(node -v | cut -d'v' -f2 | cut -d'.' -f1)
    if [ "$NODE_VERSION" -lt 18 ]; then
        print_error "Node.js w wersji 18+ jest wymagany. Aktualna wersja: $(node -v)"
        exit 1
    fi
    print_success "Node.js $(node -v) - OK"
fi

# Sprawdź npm
if ! command -v npm &> /dev/null; then
    print_info "npm nie jest zainstalowany - instaluję..."
    sudo apt install -y npm
    
    if ! command -v npm &> /dev/null; then
        print_error "Nie udało się zainstalować npm"
        print_info "Zainstaluj ręcznie: sudo apt install npm"
        exit 1
    fi
    print_success "npm zainstalowany"
else
    print_success "npm $(npm -v) - OK"
fi

echo ""
echo "Krok 2: Konfiguracja instalacji..."

# Zapytaj o katalog instalacji
read -p "Katalog instalacji [/opt/testrun-manager]: " INSTALL_DIR
INSTALL_DIR=${INSTALL_DIR:-/opt/testrun-manager}

# Zapytaj o port backendu
read -p "Port backendu [3000]: " BACKEND_PORT
BACKEND_PORT=${BACKEND_PORT:-3000}

# Zapytaj o domenę
read -p "Domena (przyklad: testrun.example.com) [localhost]: " DOMAIN
DOMAIN=${DOMAIN:-localhost}

# Zapytaj czy zainstalować Nginx
read -p "Czy zainstalować i skonfigurować Nginx? (y/n) [y]: " INSTALL_NGINX
INSTALL_NGINX=${INSTALL_NGINX:-y}

# Zapytaj czy zainstalować PM2
read -p "Czy zainstalować PM2 (Process Manager)? (y/n) [y]: " INSTALL_PM2
INSTALL_PM2=${INSTALL_PM2:-y}

# Zapytaj o dane administratora
echo ""
echo "Konfiguracja konta administratora:"
read -p "Email administratora [admin@example.com]: " ADMIN_EMAIL
ADMIN_EMAIL=${ADMIN_EMAIL:-admin@example.com}

read -sp "Hasło administratora (min. 6 znaków): " ADMIN_PASSWORD
echo ""
if [ -z "$ADMIN_PASSWORD" ] || [ ${#ADMIN_PASSWORD} -lt 6 ]; then
    ADMIN_PASSWORD="Admin123!"
    print_info "Użyto domyślnego hasła: Admin123!"
fi

read -p "Imię i nazwisko administratora [Administrator]: " ADMIN_NAME
ADMIN_NAME=${ADMIN_NAME:-Administrator}

echo ""
echo "Krok 3: Tworzenie katalogów..."

# Utwórz katalog instalacji
if [ ! -d "$INSTALL_DIR" ]; then
    sudo mkdir -p "$INSTALL_DIR"
    sudo chown $USER:$USER "$INSTALL_DIR"
    print_success "Utworzono katalog: $INSTALL_DIR"
else
    print_info "Katalog już istnieje: $INSTALL_DIR"
fi

# Skopiuj pliki
echo ""
echo "Krok 4: Kopiowanie plików..."

SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"

if [ "$SCRIPT_DIR" != "$INSTALL_DIR" ]; then
    # Kopiuj pliki z wykluczeniem ukrytych plików i node_modules
    sudo mkdir -p "$INSTALL_DIR"
    sudo chown $USER:$USER "$INSTALL_DIR"
    
    # Kopiuj tylko niezbędne katalogi i pliki
    for item in backend frontend install.sh install.ps1 README.md INSTALLATION.md LICENSE; do
        if [ -e "$SCRIPT_DIR/$item" ]; then
            cp -r "$SCRIPT_DIR/$item" "$INSTALL_DIR/" 2>/dev/null || true
        fi
    done
    
    print_success "Pliki skopiowane do $INSTALL_DIR"
else
    print_info "Instalacja w bieżącym katalogu"
fi

cd "$INSTALL_DIR"

echo ""
echo "Krok 5: Instalacja zależności backendu..."

cd "$INSTALL_DIR/backend"
npm install
print_success "Zależności backendu zainstalowane"

echo ""
echo "Krok 6: Budowanie backendu..."

cd "$INSTALL_DIR/backend"
npm run build
print_success "Backend zbudowany"

echo ""
echo "Krok 7: Budowanie frontendu..."

cd "$INSTALL_DIR/frontend"
npm install
npm run build
print_success "Frontend zbudowany"

echo ""
echo "Krok 8: Konfiguracja środowiska..."

# Generuj losowy JWT secret
JWT_SECRET=$(openssl rand -base64 32)

# Utwórz plik .env
cat > "$INSTALL_DIR/backend/.env" << EOF
# TestRun Manager - Konfiguracja środowiska
# Wygenerowano automatycznie: $(date)

# Port backendu
PORT=$BACKEND_PORT

# JWT Secret (wygenerowany automatycznie)
JWT_SECRET=$JWT_SECRET

# CORS Origin
CORS_ORIGIN=http://$DOMAIN

# Database path
DB_PATH=./database.db

# Environment
NODE_ENV=production
EOF

print_success "Plik .env utworzony"

# Instalacja PM2
if [ "$INSTALL_PM2" = "y" ]; then
    echo ""
    echo "Krok 9: Instalacja PM2..."
    
    if ! command -v pm2 &> /dev/null; then
        sudo npm install -g pm2
        print_success "PM2 zainstalowany"
    else
        print_info "PM2 już zainstalowany"
    fi
    
    # Uruchom backend przez PM2
    cd "$INSTALL_DIR/backend"
    pm2 delete testrun-backend 2>/dev/null || true
    pm2 start dist/server.js --name testrun-backend
    pm2 save
    
    # Konfiguruj autostart
    sudo env PATH=$PATH:/usr/bin pm2 startup systemd -u $USER --hp /home/$USER
    
    print_success "Backend uruchomiony przez PM2"
    
    # Poczekaj aż backend się uruchomi
    sleep 3
    
    # Utwórz użytkownika administratora
    echo ""
    echo "Tworzenie konta administratora..."
    cd "$INSTALL_DIR/backend"
    node scripts/create-admin.js "$ADMIN_EMAIL" "$ADMIN_PASSWORD" "$ADMIN_NAME"
    
    if [ $? -eq 0 ]; then
        print_success "Konto administratora utworzone"
    else
        print_info "Nie udało się utworzyć konta administratora automatycznie"
        print_info "Możesz je utworzyć ręcznie po instalacji przez interfejs rejestracji"
    fi
fi

# Instalacja Nginx
if [ "$INSTALL_NGINX" = "y" ]; then
    echo ""
    echo "Krok 10: Instalacja i konfiguracja Nginx..."
    
    if ! command -v nginx &> /dev/null; then
        sudo apt update
        sudo apt install -y nginx
        print_success "Nginx zainstalowany"
    else
        print_info "Nginx już zainstalowany"
    fi
    
    # Utwórz konfigurację Nginx
    sudo tee /etc/nginx/sites-available/testrun-manager > /dev/null << EOF
server {
    listen 80;
    server_name $DOMAIN;

    # Frontend (pliki statyczne)
    location / {
        root $INSTALL_DIR/frontend/dist;
        try_files \$uri \$uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:$BACKEND_PORT;
        proxy_http_version 1.1;
        proxy_set_header Upgrade \$http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host \$host;
        proxy_cache_bypass \$http_upgrade;
        proxy_set_header X-Real-IP \$remote_addr;
        proxy_set_header X-Forwarded-For \$proxy_add_x_forwarded_for;
    }

    # Uploads
    location /uploads {
        alias $INSTALL_DIR/backend/uploads;
    }
}
EOF
    
    # Aktywuj konfigurację
    sudo ln -sf /etc/nginx/sites-available/testrun-manager /etc/nginx/sites-enabled/
    
    # Usuń domyślną konfigurację
    sudo rm -f /etc/nginx/sites-enabled/default
    
    # Testuj konfigurację
    sudo nginx -t
    
    # Restart Nginx
    sudo systemctl restart nginx
    sudo systemctl enable nginx
    
    print_success "Nginx skonfigurowany i uruchomiony"
fi

# Konfiguracja firewall
echo ""
echo "Krok 11: Konfiguracja firewall..."

if command -v ufw &> /dev/null; then
    sudo ufw allow 'Nginx Full' 2>/dev/null || true
    sudo ufw allow $BACKEND_PORT 2>/dev/null || true
    print_success "Firewall skonfigurowany"
else
    print_info "UFW nie jest zainstalowany - pomiń konfigurację firewall"
fi

# Podsumowanie
echo ""
echo "=================================="
echo "✓ Instalacja zakończona pomyślnie!"
echo "=================================="
echo ""
echo "Szczegóły instalacji:"
echo "  - Katalog: $INSTALL_DIR"
echo "  - Backend port: $BACKEND_PORT"
echo "  - Domena: $DOMAIN"
echo "  - Frontend: http://$DOMAIN"
echo "  - Backend API: http://$DOMAIN/api"
echo ""
echo "Konto administratora:"
echo "  - Email: $ADMIN_EMAIL"
echo "  - Hasło: $ADMIN_PASSWORD"
echo "  - Rola: Administrator"
echo ""
echo "Następne kroki:"
echo "  1. Otwórz przeglądarkę: http://$DOMAIN"
echo "  2. Zaloguj się używając powyższych danych"
echo "  3. Zmień hasło administratora w Panelu Administracyjnym"
echo "  4. Zacznij korzystać z TestRun Manager!"
echo ""
echo "Przydatne komendy:"
if [ "$INSTALL_PM2" = "y" ]; then
    echo "  - Status backendu: pm2 status"
    echo "  - Logi backendu: pm2 logs testrun-backend"
    echo "  - Restart backendu: pm2 restart testrun-backend"
fi
if [ "$INSTALL_NGINX" = "y" ]; then
    echo "  - Status Nginx: sudo systemctl status nginx"
    echo "  - Restart Nginx: sudo systemctl restart nginx"
fi
echo ""
echo "Dokumentacja: $INSTALL_DIR/INSTALLATION.md"
echo ""
echo "Autor: ITM Marek Dacz"
echo "Wersja: 1.0"
echo "=================================="
