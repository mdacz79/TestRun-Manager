#!/bin/bash

###############################################################################
# TestRun Manager v1.0 - Skrypt tworzenia paczki instalacyjnej
# Autor: ITM Marek Dacz
###############################################################################

set -e

VERSION="1.0.1"
RELEASE_NAME="testrun-manager-v${VERSION}"
RELEASE_DIR="releases"

echo "=================================="
echo "TestRun Manager - Tworzenie Release"
echo "Wersja: $VERSION"
echo "=================================="
echo ""

# Kolory
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m'

print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_info() {
    echo -e "${YELLOW}ℹ $1${NC}"
}

# Utwórz katalog releases
mkdir -p "$RELEASE_DIR"

# Utwórz tymczasowy katalog
TEMP_DIR=$(mktemp -d)
PACKAGE_DIR="$TEMP_DIR/$RELEASE_NAME"

print_info "Kopiowanie plików..."

# Utwórz strukturę katalogów
mkdir -p "$PACKAGE_DIR"

# Kopiuj pliki projektu (bez node_modules i build artifacts)
rsync -av --progress \
  --exclude 'node_modules' \
  --exclude 'dist' \
  --exclude '.git' \
  --exclude 'database.db' \
  --exclude 'uploads' \
  --exclude 'releases' \
  --exclude '.env' \
  --exclude '*.log' \
  ./ "$PACKAGE_DIR/"

print_success "Pliki skopiowane"

# Utwórz plik VERSION
echo "$VERSION" > "$PACKAGE_DIR/VERSION"

# Utwórz plik z checksumami
print_info "Generowanie checksumów..."
cd "$PACKAGE_DIR"
find . -type f -not -path "*/node_modules/*" -exec sha256sum {} \; > CHECKSUMS.txt
cd -

print_success "Checksumy wygenerowane"

# Utwórz archiwum tar.gz
print_info "Tworzenie archiwum tar.gz..."
cd "$TEMP_DIR"
tar -czf "$RELEASE_NAME.tar.gz" "$RELEASE_NAME"
cd -

# Przenieś archiwum do katalogu releases
mv "$TEMP_DIR/$RELEASE_NAME.tar.gz" "$RELEASE_DIR/"

print_success "Archiwum utworzone: $RELEASE_DIR/$RELEASE_NAME.tar.gz"

# Utwórz archiwum zip (dla Windows)
print_info "Tworzenie archiwum zip..."
cd "$TEMP_DIR"
zip -r "$RELEASE_NAME.zip" "$RELEASE_NAME" -q
cd -

mv "$TEMP_DIR/$RELEASE_NAME.zip" "$RELEASE_DIR/"

print_success "Archiwum utworzone: $RELEASE_DIR/$RELEASE_NAME.zip"

# Oblicz rozmiary
TAR_SIZE=$(du -h "$RELEASE_DIR/$RELEASE_NAME.tar.gz" | cut -f1)
ZIP_SIZE=$(du -h "$RELEASE_DIR/$RELEASE_NAME.zip" | cut -f1)

# Oblicz checksumy archiwów
TAR_SHA=$(sha256sum "$RELEASE_DIR/$RELEASE_NAME.tar.gz" | cut -d' ' -f1)
ZIP_SHA=$(sha256sum "$RELEASE_DIR/$RELEASE_NAME.zip" | cut -d' ' -f1)

# Utwórz plik z informacjami o release (tylko jeśli nie istnieje)
if [ ! -f "$RELEASE_DIR/RELEASE_NOTES_v${VERSION}.md" ]; then
cat > "$RELEASE_DIR/RELEASE_NOTES_v${VERSION}.md" << EOF
# TestRun Manager v${VERSION} - Release Notes

**Data wydania**: $(date +%Y-%m-%d)  
**Autor**: ITM Marek Dacz

## Pliki do pobrania

### Linux/Mac
- **Plik**: \`$RELEASE_NAME.tar.gz\`
- **Rozmiar**: $TAR_SIZE
- **SHA-256**: \`$TAR_SHA\`

### Windows
- **Plik**: \`$RELEASE_NAME.zip\`
- **Rozmiar**: $ZIP_SIZE
- **SHA-256**: \`$ZIP_SHA\`

## Instalacja

### Automatyczna instalacja

**Linux/Mac:**
\`\`\`bash
tar -xzf $RELEASE_NAME.tar.gz
cd $RELEASE_NAME
chmod +x install.sh
./install.sh
\`\`\`

**Windows:**
\`\`\`powershell
Expand-Archive $RELEASE_NAME.zip
cd $RELEASE_NAME
.\install.ps1
\`\`\`

### Ręczna instalacja

Zobacz plik \`INSTALLATION.md\` w archiwum.

## Wymagania systemowe

- **Node.js**: v18.0 lub nowszy
- **RAM**: 2 GB (zalecane 4 GB)
- **Dysk**: 1 GB wolnego miejsca
- **System**: Linux (Ubuntu 20.04+), Windows Server 2019+, macOS

## Funkcjonalności

- ✅ Zarządzanie projektami testowymi
- ✅ Specyfikacja testowa z edytorem Rich Text
- ✅ Plany testowe i wykonywanie testów
- ✅ Zarządzanie defektami
- ✅ Raporty i wykresy burndown
- ✅ Macierz pokrycia wymagań testami
- ✅ System ról i uprawnień
- ✅ Panel administracyjny

## Znane problemy

Brak znanych problemów w tej wersji.

## Wsparcie

- **Email**: support@testrun-manager.com
- **Dokumentacja**: Zobacz plik INSTALLATION.md
- **Autor**: ITM Marek Dacz

---

© 2026 ITM Marek Dacz. All rights reserved.
EOF
    print_success "Release notes utworzone: $RELEASE_DIR/RELEASE_NOTES_v${VERSION}.md"
else
    print_info "Release notes już istnieją: $RELEASE_DIR/RELEASE_NOTES_v${VERSION}.md"
fi

# Wyczyść tymczasowy katalog
rm -rf "$TEMP_DIR"

# Podsumowanie
echo ""
echo "=================================="
echo "✓ Release utworzony pomyślnie!"
echo "=================================="
echo ""
echo "Pliki:"
echo "  - $RELEASE_DIR/$RELEASE_NAME.tar.gz ($TAR_SIZE)"
echo "  - $RELEASE_DIR/$RELEASE_NAME.zip ($ZIP_SIZE)"
echo "  - $RELEASE_DIR/RELEASE_NOTES_v${VERSION}.md"
echo ""
echo "Checksums:"
echo "  - tar.gz: $TAR_SHA"
echo "  - zip: $ZIP_SHA"
echo ""
echo "Gotowe do dystrybucji!"
echo "=================================="
