#!/usr/bin/env node

/**
 * Skrypt do tworzenia użytkownika administratora
 * Użycie: node create-admin.js <email> <password> <name>
 */

const bcrypt = require('bcryptjs');
const Database = require('better-sqlite3');
const path = require('path');

// Argumenty z linii komend
const [,, email, password, name] = process.argv;

if (!email || !password || !name) {
  console.error('❌ Błąd: Wymagane wszystkie parametry');
  console.log('Użycie: node create-admin.js <email> <password> <name>');
  console.log('Przykład: node create-admin.js admin@example.com Admin123! "Administrator"');
  process.exit(1);
}

// Ścieżka do bazy danych
const dbPath = path.join(__dirname, '..', 'database.db');

try {
  const db = new Database(dbPath);
  
  // Sprawdź czy użytkownik już istnieje
  const existingUser = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (existingUser) {
    console.error(`❌ Użytkownik z emailem ${email} już istnieje`);
    process.exit(1);
  }
  
  // Sprawdź liczbę użytkowników
  const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get();
  const isFirstUser = userCount.count === 0;
  
  // Hashuj hasło
  const hashedPassword = bcrypt.hashSync(password, 10);
  
  // Utwórz użytkownika z rolą Administrator (role_id: 1)
  const result = db.prepare(
    'INSERT INTO users (email, password, name, role_id, is_active) VALUES (?, ?, ?, ?, ?)'
  ).run(email, hashedPassword, name, 1, 1);
  
  console.log('✓ Użytkownik administratora został utworzony pomyślnie!');
  console.log(`  - ID: ${result.lastInsertRowid}`);
  console.log(`  - Email: ${email}`);
  console.log(`  - Imię: ${name}`);
  console.log(`  - Rola: Administrator`);
  
  if (!isFirstUser) {
    console.log('\n⚠️  Uwaga: To nie jest pierwszy użytkownik w systemie.');
    console.log('   Został utworzony z rolą Administrator na podstawie tego skryptu.');
  }
  
  db.close();
  process.exit(0);
  
} catch (error) {
  console.error('❌ Błąd podczas tworzenia użytkownika:', error.message);
  process.exit(1);
}
