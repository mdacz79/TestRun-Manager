# Feature - Moduł Wykonywania Testów

## Opis
Kompletny moduł do zarządzania wykonywaniem testów z planami testów, przypisywaniem użytkowników, wykonywaniem testów ze statusami, zgłaszaniem błędów i historią wykonań.

## Funkcjonalności

### 1. Plany Testów
- ✅ Tworzenie planów testów
- ✅ Dodawanie przypadków testowych do planu
- ✅ Usuwanie przypadków z planu
- ✅ Przypisywanie użytkowników do przypadków
- ✅ Wyświetlanie liczby testów w planie

### 2. Wykonywanie Testów
- ✅ Rozpoczynanie testu (status → IN_PROGRESS)
- ✅ Wybór wyniku: PASSED, FAILED, SKIPPED, BLOCKED
- ✅ Domyślny status: NOT_RUN
- ✅ Wymuszenie zgłoszenia błędu przy FAILED
- ✅ Dodawanie notatek do wykonania

### 3. Błędy (Bugs)
- ✅ Automatyczne generowanie ID błędu (BUG-0001)
- ✅ Powiązanie błędu z wykonaniem testu
- ✅ Wyświetlanie błędów powiązanych z testem
- ✅ Zarządzanie błędami (CRUD)

### 4. Historia Wykonań
- ✅ Pełna historia wszystkich wykonań testu
- ✅ Informacje: kto, kiedy, status, błąd, plan
- ✅ Modal z historią po kliknięciu ikony
- ✅ Chronologiczne sortowanie

## Struktura Bazy Danych

### Tabela: test_plans
```sql
CREATE TABLE test_plans (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  description TEXT,
  project_id INTEGER NOT NULL,
  created_by INTEGER NOT NULL,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id)
);
```

### Tabela: test_plan_cases
```sql
CREATE TABLE test_plan_cases (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  test_plan_id INTEGER NOT NULL,
  test_specification_id INTEGER NOT NULL,
  assigned_to INTEGER,
  status TEXT DEFAULT 'NOT_RUN',
  order_index INTEGER DEFAULT 0,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (test_plan_id) REFERENCES test_plans(id) ON DELETE CASCADE,
  FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id),
  FOREIGN KEY (assigned_to) REFERENCES users(id)
);
```

**Statusy:**
- `NOT_RUN` - Domyślny, nie wykonano
- `IN_PROGRESS` - W trakcie wykonywania
- `PASSED` - Zaliczony
- `FAILED` - Niezaliczony
- `SKIPPED` - Pominięty
- `BLOCKED` - Zablokowany

### Tabela: bugs
```sql
CREATE TABLE bugs (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  bug_id TEXT UNIQUE,
  title TEXT NOT NULL,
  description TEXT,
  severity TEXT DEFAULT 'medium',
  status TEXT DEFAULT 'open',
  project_id INTEGER NOT NULL,
  reported_by INTEGER NOT NULL,
  assigned_to INTEGER,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
  FOREIGN KEY (reported_by) REFERENCES users(id),
  FOREIGN KEY (assigned_to) REFERENCES users(id)
);
```

### Tabela: test_executions
```sql
CREATE TABLE test_executions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  test_plan_case_id INTEGER NOT NULL,
  executed_by INTEGER NOT NULL,
  status TEXT NOT NULL,
  bug_id INTEGER,
  notes TEXT,
  started_at DATETIME,
  completed_at DATETIME,
  created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (test_plan_case_id) REFERENCES test_plan_cases(id),
  FOREIGN KEY (executed_by) REFERENCES users(id),
  FOREIGN KEY (bug_id) REFERENCES bugs(id)
);
```

## API Endpoints

### Test Plans
- `GET /api/test-plans?project_id={id}` - Lista planów
- `GET /api/test-plans/:id` - Szczegóły planu
- `POST /api/test-plans` - Utwórz plan
- `PUT /api/test-plans/:id` - Aktualizuj plan
- `DELETE /api/test-plans/:id` - Usuń plan
- `POST /api/test-plans/:id/cases` - Dodaj przypadek do planu
- `DELETE /api/test-plans/:planId/cases/:caseId` - Usuń przypadek
- `PUT /api/test-plans/:planId/cases/:caseId/assign` - Przypisz użytkownika

### Test Executions
- `POST /api/test-executions/start` - Rozpocznij test
- `POST /api/test-executions/complete` - Zakończ test
- `GET /api/test-executions/history/:testPlanCaseId` - Historia wykonań
- `GET /api/test-executions/plan/:planId` - Wykonania dla planu

### Bugs
- `GET /api/bugs?project_id={id}` - Lista błędów
- `GET /api/bugs/:id` - Szczegóły błędu
- `POST /api/bugs` - Utwórz błąd
- `PUT /api/bugs/:id` - Aktualizuj błąd
- `DELETE /api/bugs/:id` - Usuń błąd

## Przepływ Wykonywania Testu

### 1. Rozpoczęcie testu
```
Użytkownik klika "Wykonaj"
↓
POST /api/test-executions/start
{
  test_plan_case_id: 123
}
↓
Zmiana statusu test_plan_cases.status → IN_PROGRESS
Utworzenie rekordu test_executions z started_at
↓
Otwarcie modalu wykonywania testu
```

### 2. Wykonywanie testu
```
Modal pokazuje:
- Tytuł i ID przypadku testowego
- Kroki testowe z akcjami i oczekiwanymi rezultatami
- Przyciski wyboru statusu:
  [PASSED] [FAILED] [SKIPPED] [BLOCKED]
- Pole notatek
```

### 3. Zakończenie testu - PASSED/SKIPPED/BLOCKED
```
Użytkownik wybiera status
Opcjonalnie dodaje notatki
Klika "Zakończ"
↓
POST /api/test-executions/complete
{
  execution_id: 456,
  status: "PASSED",
  notes: "Test przeszedł pomyślnie"
}
↓
Aktualizacja test_executions: status, notes, completed_at
Aktualizacja test_plan_cases.status → PASSED
↓
Modal się zamyka
Lista odświeża się
```

### 4. Zakończenie testu - FAILED
```
Użytkownik wybiera FAILED
↓
System wymusza utworzenie błędu
Modal zgłoszenia błędu się otwiera
↓
Użytkownik wypełnia:
- Tytuł błędu
- Opis
- Severity (low/medium/high/critical)
- Przypisanie (opcjonalne)
↓
POST /api/bugs
{
  title: "Błąd logowania",
  description: "...",
  severity: "high",
  project_id: 1
}
↓
Otrzymanie bug_id
↓
POST /api/test-executions/complete
{
  execution_id: 456,
  status: "FAILED",
  bug_id: 789,
  notes: "..."
}
↓
Powiązanie błędu z wykonaniem
Aktualizacja statusów
Modal się zamyka
```

## Komponenty Frontend

### 1. TestExecution.tsx (główny)
**Funkcje:**
- Lista planów testów (lewa kolumna)
- Szczegóły planu i lista przypadków (prawa kolumna)
- Przyciski akcji (Nowy plan, Dodaj testy, Wykonaj)
- Przypisywanie użytkowników (dropdown)
- Ikony statusów z kolorami

**Statusy wizualne:**
- ✅ PASSED - zielony
- ❌ FAILED - czerwony
- ⊖ SKIPPED - szary
- 🚫 BLOCKED - pomarańczowy
- ⏱️ IN_PROGRESS - niebieski
- 📋 NOT_RUN - szary jasny

### 2. CreateTestPlanModal.tsx
**Pola:**
- Nazwa planu (wymagane)
- Opis (opcjonalne)

**Przyciski:**
- Anuluj
- Utwórz

### 3. AddTestCasesModal.tsx
**Funkcje:**
- Lista wszystkich przypadków testowych projektu
- Checkboxy do wyboru
- Filtrowanie (opcjonalne)
- Wykluczenie już dodanych przypadków

**Przyciski:**
- Anuluj
- Dodaj wybrane

### 4. ExecuteTestModal.tsx
**Sekcje:**
- **Nagłówek:** ID i tytuł przypadku
- **Kroki:** Lista kroków z akcjami i rezultatami
- **Status:** Przyciski wyboru (PASSED/FAILED/SKIPPED/BLOCKED)
- **Notatki:** Pole tekstowe
- **Błąd:** Automatyczne otwarcie przy FAILED

**Logika:**
- Jeśli FAILED → wymusza utworzenie błędu
- Przycisk "Zakończ" aktywny tylko po wyborze statusu
- Automatyczne zamknięcie po zakończeniu

### 5. TestHistoryModal.tsx
**Wyświetla:**
```
┌─────────────────────────────────────────────────────────┐
│ Historia wykonań: PT1-001                               │
├─────────────────────────────────────────────────────────┤
│ 📅 14 maja 2026, 15:30                                  │
│ 👤 Jan Kowalski                                         │
│ ✅ Status: PASSED                                       │
│ 📋 Plan: Sprint 1 - Testy funkcjonalne                 │
│ 📝 Notatki: Test przeszedł pomyślnie                   │
├─────────────────────────────────────────────────────────┤
│ 📅 13 maja 2026, 10:15                                  │
│ 👤 Anna Nowak                                           │
│ ❌ Status: FAILED                                       │
│ 🐛 Błąd: BUG-0042 - Błąd logowania                     │
│ 📋 Plan: Sprint 1 - Testy funkcjonalne                 │
│ 📝 Notatki: Nie można zalogować się                    │
└─────────────────────────────────────────────────────────┘
```

**Sortowanie:** Od najnowszych do najstarszych

### 6. CreateBugModal.tsx
**Pola:**
- Tytuł (wymagane)
- Opis (opcjonalne)
- Severity: low/medium/high/critical
- Przypisz do (dropdown użytkowników)

**Przyciski:**
- Anuluj
- Zgłoś błąd

**Auto-generowanie ID:**
```javascript
const count = await bugs.getAll(projectId);
const bugId = `BUG-${String(count.length + 1).padStart(4, '0')}`;
// BUG-0001, BUG-0002, ...
```

## Przykład Użycia

### Scenariusz 1: Utworzenie planu testów

**Akcje:**
1. Kliknij "Nowy plan testów"
2. Wpisz nazwę: "Sprint 1 - Testy funkcjonalne"
3. Wpisz opis: "Testy funkcjonalności logowania i rejestracji"
4. Kliknij "Utwórz"

**Rezultat:**
```
Plan utworzony
Lista planów odświeżona
Nowy plan widoczny w lewej kolumnie
```

### Scenariusz 2: Dodanie przypadków do planu

**Akcje:**
1. Wybierz plan "Sprint 1 - Testy funkcjonalne"
2. Kliknij "Dodaj testy"
3. Zaznacz przypadki:
   - PT1-001: Test logowania
   - PT1-002: Test rejestracji
   - PT1-003: Test resetowania hasła
4. Kliknij "Dodaj wybrane"

**Rezultat:**
```
3 przypadki dodane do planu
Lista przypadków odświeżona
Wszystkie w statusie NOT_RUN
```

### Scenariusz 3: Przypisanie użytkowników

**Akcje:**
1. Dla PT1-001: Wybierz "Jan Kowalski" z dropdown
2. Dla PT1-002: Wybierz "Anna Nowak"
3. PT1-003: Pozostaw "Nie przypisano"

**Rezultat:**
```
Użytkownicy przypisani
Widoczne pod tytułem przypadku
👤 Jan Kowalski
👤 Anna Nowak
```

### Scenariusz 4: Wykonanie testu - PASSED

**Akcje:**
1. Kliknij "Wykonaj" przy PT1-001
2. Status zmienia się na IN_PROGRESS
3. Modal pokazuje kroki testu
4. Przejrzyj kroki
5. Kliknij przycisk "PASSED"
6. Dodaj notatki: "Test przeszedł pomyślnie"
7. Kliknij "Zakończ"

**Rezultat:**
```
Status → PASSED (zielony)
Ikona ✅
Wykonanie zapisane w historii
Modal zamknięty
```

### Scenariusz 5: Wykonanie testu - FAILED z błędem

**Akcje:**
1. Kliknij "Wykonaj" przy PT1-002
2. Status → IN_PROGRESS
3. Modal pokazuje kroki
4. Kliknij przycisk "FAILED"
5. System otwiera modal zgłoszenia błędu
6. Wypełnij:
   - Tytuł: "Błąd walidacji email"
   - Opis: "System nie waliduje poprawności adresu email"
   - Severity: "high"
   - Przypisz do: "Jan Kowalski"
7. Kliknij "Zgłoś błąd"
8. Wróć do modalu wykonania
9. Dodaj notatki: "Email 'test@' został zaakceptowany"
10. Kliknij "Zakończ"

**Rezultat:**
```
Błąd utworzony: BUG-0001
Status → FAILED (czerwony)
Ikona ❌
Błąd powiązany z wykonaniem
Historia zawiera link do błędu
```

### Scenariusz 6: Przeglądanie historii

**Akcje:**
1. Kliknij ikonę 📜 (Historia) przy PT1-001
2. Modal pokazuje wszystkie wykonania

**Historia:**
```
┌─────────────────────────────────────────────┐
│ Historia wykonań: PT1-001                   │
├─────────────────────────────────────────────┤
│ 📅 14 maja 2026, 15:30                      │
│ 👤 Jan Kowalski                             │
│ ✅ PASSED                                   │
│ 📋 Sprint 1 - Testy funkcjonalne           │
│ 📝 Test przeszedł pomyślnie                │
├─────────────────────────────────────────────┤
│ 📅 13 maja 2026, 10:00                      │
│ 👤 Jan Kowalski                             │
│ ❌ FAILED                                   │
│ 🐛 BUG-0015 - Błąd timeout                 │
│ 📋 Sprint 1 - Testy funkcjonalne           │
│ 📝 Timeout po 30 sekundach                 │
└─────────────────────────────────────────────┘
```

## Pliki Utworzone

### Backend:
1. `/backend/src/database.ts` - Dodane tabele:
   - `test_plans`
   - `test_plan_cases`
   - `bugs`
   - `test_executions`

2. `/backend/src/routes/test-plans.ts` - API planów testów
3. `/backend/src/routes/test-executions.ts` - API wykonań
4. `/backend/src/routes/bugs.ts` - API błędów
5. `/backend/src/server.ts` - Rejestracja routes

### Frontend:
1. `/frontend/src/lib/api.ts` - API clients:
   - `testPlans`
   - `testExecutions`
   - `bugs`

2. `/frontend/src/pages/TestExecution.tsx` - Główny komponent

### Komponenty do utworzenia:
3. `/frontend/src/components/CreateTestPlanModal.tsx`
4. `/frontend/src/components/AddTestCasesModal.tsx`
5. `/frontend/src/components/ExecuteTestModal.tsx`
6. `/frontend/src/components/TestHistoryModal.tsx`
7. `/frontend/src/components/CreateBugModal.tsx`

## Routing

Dodaj do `/frontend/src/App.tsx`:
```tsx
import TestExecution from './pages/TestExecution';

// W routingu:
<Route path="/test-execution" element={<TestExecution />} />
```

Dodaj do menu nawigacji:
```tsx
<NavLink to="/test-execution">
  <Play className="h-5 w-5" />
  <span>Wykonywanie testów</span>
</NavLink>
```

## Statusy i Kolory

| Status | Ikona | Kolor | Label |
|--------|-------|-------|-------|
| NOT_RUN | 📋 | Szary | Nie wykonano |
| IN_PROGRESS | ⏱️ | Niebieski | W trakcie |
| PASSED | ✅ | Zielony | Zaliczony |
| FAILED | ❌ | Czerwony | Niezaliczony |
| SKIPPED | ⊖ | Szary | Pominięty |
| BLOCKED | 🚫 | Pomarańczowy | Zablokowany |

## Walidacja

### Rozpoczęcie testu:
- ✅ test_plan_case_id wymagany
- ✅ Użytkownik musi być zalogowany

### Zakończenie testu:
- ✅ execution_id wymagany
- ✅ status wymagany
- ✅ Jeśli FAILED → bug_id wymagany
- ✅ notes opcjonalne

### Utworzenie błędu:
- ✅ title wymagany
- ✅ project_id wymagany
- ✅ Auto-generowanie bug_id
- ✅ reported_by = zalogowany użytkownik

## Data implementacji
2026-05-17

## Status
🚧 W trakcie implementacji - Backend gotowy, Frontend wymaga utworzenia komponentów modali
