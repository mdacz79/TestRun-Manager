# Feature - Rozwijany panel metadanych w podglądzie TC

## Opis
Przeniesiono informacje o autorze i datach (utworzenie, modyfikacja) na sam dół modalu podglądu TC jako **rozwijany panel** z ikoną. Panel jest domyślnie zwinięty i rozwija się po kliknięciu.

## Problem
Informacje o autorze zajmowały dużo miejsca w środku modalu, między tagami a priorytetem/statusem. Przeszkadzały w przeglądaniu głównych informacji o TC.

## Rozwiązanie
- ✅ Przeniesiono metadane na sam dół (po krokach testowych, przed przyciskami)
- ✅ Panel jest domyślnie **zwinięty**
- ✅ Ikona ℹ️ i przycisk "Informacje o utworzeniu i modyfikacji"
- ✅ Po kliknięciu rozwija się panel z:
  - 👤 Autor
  - 📅 Data utworzenia
  - 🔄 Ostatnia modyfikacja (jeśli była)

## Implementacja

### 1. Nowy stan

```typescript
const [showMetadata, setShowMetadata] = useState(false);
```

**Domyślnie:** `false` (panel zwinięty)

### 2. Reset stanu przy otwieraniu modalu

```typescript
const handleView = (spec: any) => {
  setViewSpec(spec);
  setShowViewModal(true);
  setShowMetadata(false); // Zwinięty panel przy otwieraniu
};
```

### 3. Przycisk rozwijający

```tsx
<button
  onClick={() => setShowMetadata(!showMetadata)}
  className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
>
  <span className="text-lg">ℹ️</span>
  <span className="font-medium">Informacje o utworzeniu i modyfikacji</span>
  <span className="text-xs">
    {showMetadata ? '▼' : '▶'}
  </span>
</button>
```

**Elementy:**
- ℹ️ Ikona informacji
- Tekst: "Informacje o utworzeniu i modyfikacji"
- Strzałka: ▶ (zwinięty) / ▼ (rozwinięty)

### 4. Panel z metadanymi

```tsx
{showMetadata && (
  <div className="mt-3 bg-gray-50 rounded-lg p-4 space-y-3">
    <div className="grid grid-cols-2 gap-4">
      {/* Autor */}
      <div>
        <div className="text-xs font-medium text-gray-500 mb-1">👤 Autor</div>
        <div className="text-sm font-semibold text-gray-900">
          {viewSpec.created_by_name || 'Nieznany autor'}
        </div>
      </div>
      
      {/* Data utworzenia */}
      <div>
        <div className="text-xs font-medium text-gray-500 mb-1">📅 Data utworzenia</div>
        <div className="text-sm text-gray-900">
          {viewSpec.created_at ? new Date(viewSpec.created_at).toLocaleDateString('pl-PL', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          }) : 'Brak danych'}
        </div>
      </div>
    </div>
    
    {/* Ostatnia modyfikacja (jeśli była) */}
    {viewSpec.updated_at && viewSpec.updated_at !== viewSpec.created_at && (
      <div>
        <div className="text-xs font-medium text-gray-500 mb-1">🔄 Ostatnia modyfikacja</div>
        <div className="text-sm text-gray-900">
          {new Date(viewSpec.updated_at).toLocaleDateString('pl-PL', { 
            year: 'numeric', 
            month: 'long', 
            day: 'numeric',
            hour: '2-digit',
            minute: '2-digit'
          })}
        </div>
      </div>
    )}
  </div>
)}
```

## Wygląd UI

### Panel zwinięty (domyślnie):
```
┌─────────────────────────────────────────────────────────┐
│ Kroki testowe                                           │
│ 1. Akcja → Rezultat                                     │
│ 2. Akcja → Rezultat                                     │
├─────────────────────────────────────────────────────────┤
│ ℹ️ Informacje o utworzeniu i modyfikacji ▶             │
├─────────────────────────────────────────────────────────┤
│                                      [Zamknij] [Edytuj] │
└─────────────────────────────────────────────────────────┘
```

### Panel rozwinięty (po kliknięciu):
```
┌─────────────────────────────────────────────────────────┐
│ Kroki testowe                                           │
│ 1. Akcja → Rezultat                                     │
│ 2. Akcja → Rezultat                                     │
├─────────────────────────────────────────────────────────┤
│ ℹ️ Informacje o utworzeniu i modyfikacji ▼             │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ 👤 Autor              │ 📅 Data utworzenia          │ │
│ │ Jan Kowalski          │ 14 maja 2026, 19:20         │ │
│ │                                                     │ │
│ │ 🔄 Ostatnia modyfikacja                             │ │
│ │ 14 maja 2026, 21:45                                 │ │
│ └─────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────┤
│                                      [Zamknij] [Edytuj] │
└─────────────────────────────────────────────────────────┘
```

## Lokalizacja w modalu

### Przed (stara lokalizacja):
```
1. ID TC
2. Tytuł
3. Opis
4. Warunki wstępne
5. Zestaw testowy
6. Powiązane wymagania
7. Tagi
8. 👤 AUTOR (tutaj było) ← USUNIĘTE
9. Priorytet | Status
10. Kroki testowe
11. [Zamknij] [Edytuj]
```

### Po (nowa lokalizacja):
```
1. ID TC
2. Tytuł
3. Opis
4. Warunki wstępne
5. Zestaw testowy
6. Powiązane wymagania
7. Tagi
8. Priorytet | Status
9. Kroki testowe
10. ℹ️ METADANE (tutaj jest teraz) ← NOWE
11. [Zamknij] [Edytuj]
```

## Przykłady użycia

### Scenariusz 1: Podgląd TC bez rozwijania metadanych

**Akcja:** Kliknij ikonę oka przy TC

**Modal:**
```
┌─────────────────────────────────────────┐
│ Podgląd przypadku testowego        [X] │
├─────────────────────────────────────────┤
│ PT1-001: Test logowania                 │
│ ...                                     │
│ Kroki testowe: ...                      │
├─────────────────────────────────────────┤
│ ℹ️ Informacje o utworzeniu... ▶        │
├─────────────────────────────────────────┤
│                  [Zamknij] [Edytuj]     │
└─────────────────────────────────────────┘
```

**Rezultat:** Szybki podgląd TC bez zbędnych informacji.

### Scenariusz 2: Sprawdzenie autora i dat

**Akcja:** 
1. Kliknij ikonę oka przy TC
2. Kliknij "ℹ️ Informacje o utworzeniu i modyfikacji"

**Modal:**
```
┌─────────────────────────────────────────┐
│ Podgląd przypadku testowego        [X] │
├─────────────────────────────────────────┤
│ PT1-001: Test logowania                 │
│ ...                                     │
│ Kroki testowe: ...                      │
├─────────────────────────────────────────┤
│ ℹ️ Informacje o utworzeniu... ▼        │
│ ┌─────────────────────────────────────┐ │
│ │ 👤 Autor: Jan Kowalski              │ │
│ │ 📅 Utworzono: 14 maja 2026, 19:20   │ │
│ │ 🔄 Modyfikacja: 14 maja 2026, 21:45 │ │
│ └─────────────────────────────────────┘ │
├─────────────────────────────────────────┤
│                  [Zamknij] [Edytuj]     │
└─────────────────────────────────────────┘
```

**Rezultat:** Widoczne wszystkie metadane.

### Scenariusz 3: Zwijanie panelu

**Akcja:** Kliknij ponownie "ℹ️ Informacje..." (gdy panel jest rozwinięty)

**Rezultat:** Panel się zwija, strzałka zmienia się z ▼ na ▶

### Scenariusz 4: Otwarcie kolejnego TC

**Akcja:**
1. Otwórz TC #1, rozwiń metadane
2. Zamknij modal
3. Otwórz TC #2

**Rezultat:** Panel metadanych w TC #2 jest **zwinięty** (reset stanu)

## Metadane wyświetlane

### 1. Autor (👤)
- **Zawsze wyświetlany**
- Wartość: `viewSpec.created_by_name`
- Fallback: "Nieznany autor"

### 2. Data utworzenia (📅)
- **Zawsze wyświetlana**
- Wartość: `viewSpec.created_at`
- Format: "14 maja 2026, 19:20"
- Fallback: "Brak danych"

### 3. Ostatnia modyfikacja (🔄)
- **Warunkowo wyświetlana**
- Warunek: `updated_at` istnieje i różni się od `created_at`
- Wartość: `viewSpec.updated_at`
- Format: "14 maja 2026, 21:45"

**Dlaczego warunkowo?**
- Jeśli TC nigdy nie był modyfikowany: `updated_at === created_at`
- Wtedy nie ma sensu pokazywać "Ostatnia modyfikacja" (byłaby taka sama jak utworzenie)

## Stylowanie

### Przycisk rozwijający:
- **Domyślny:** `text-gray-600`
- **Hover:** `text-gray-900`
- **Transition:** Płynna zmiana koloru
- **Gap:** Odstęp między ikoną, tekstem i strzałką

### Panel metadanych:
- **Tło:** `bg-gray-50` (jasne szare)
- **Zaokrąglenie:** `rounded-lg`
- **Padding:** `p-4`
- **Odstępy:** `space-y-3` (między sekcjami)

### Etykiety:
- **Rozmiar:** `text-xs`
- **Waga:** `font-medium`
- **Kolor:** `text-gray-500`

### Wartości:
- **Rozmiar:** `text-sm`
- **Kolor:** `text-gray-900`
- **Autor:** Dodatkowo `font-semibold` (pogrubiony)

## Porównanie

| Aspekt | Przed | Po |
|--------|-------|-----|
| **Lokalizacja** | Między tagami a priorytetem | Na dole, przed przyciskami |
| **Widoczność** | Zawsze widoczne | Zwinięte domyślnie |
| **Miejsce** | Zajmowało dużo miejsca | Kompaktowy przycisk |
| **Interakcja** | Brak | Kliknięcie rozwija/zwija |
| **Data modyfikacji** | Brak | Tak (jeśli była) |
| **Ikony** | 👤 | ℹ️ 👤 📅 🔄 |

## Korzyści

### ✅ Czytelność:
- Główne informacje (tytuł, opis, kroki) są bardziej widoczne
- Metadane nie rozpraszają uwagi

### ✅ Oszczędność miejsca:
- Panel zwinięty zajmuje tylko 1 linię
- Więcej miejsca na kroki testowe

### ✅ Opcjonalność:
- Użytkownik sam decyduje czy chce zobaczyć metadane
- Większość czasu nie są potrzebne

### ✅ Dodatkowe informacje:
- Data ostatniej modyfikacji (wcześniej nie było)
- Kontekst historii TC

### ✅ UX:
- Intuicyjna ikona ℹ️
- Płynna animacja rozwijania
- Strzałka wskazuje stan (▶/▼)

## Zachowanie

### Otwieranie modalu:
```
handleView(spec)
↓
setShowMetadata(false)
↓
Panel zwinięty
```

### Kliknięcie przycisku:
```
Zwinięty (▶) → Kliknięcie → Rozwinięty (▼)
Rozwinięty (▼) → Kliknięcie → Zwinięty (▶)
```

### Zamknięcie i ponowne otwarcie:
```
Modal #1: Rozwinięty
↓
Zamknij modal
↓
Otwórz Modal #2
↓
Panel zwinięty (reset)
```

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Dodanie stanu `showMetadata` (linia 22)
  - Reset stanu w `handleView` (linia 218)
  - Usunięcie pola autora z poprzedniej lokalizacji
  - Dodanie rozwijanego panelu metadanych na dole (linia 1462-1513)

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
