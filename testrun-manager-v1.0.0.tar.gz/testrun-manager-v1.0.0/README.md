# TestRun Manager v1.0

<div align="center">
  <img src="frontend/public/logo.svg" alt="TestRun Manager Logo" width="120" height="120">
  <p><strong>Professional Test Management System</strong></p>
  <p>Nowoczesny system do zarządzania testami z pełnym interfejsem użytkownika</p>
  <p><em>Autor: ITM Marek Dacz</em></p>
</div>

---

## 🚀 Szybka Instalacja

### Automatyczna instalacja (zalecane)

**Linux/Mac:**
```bash
chmod +x install.sh
./install.sh
```

**Windows (PowerShell jako Administrator):**
```powershell
.\install.ps1
```

### Ręczna instalacja

Zobacz szczegółową instrukcję: [INSTALLATION.md](INSTALLATION.md)

---

## Funkcjonalności

### Zarządzanie Projektami
- 📁 Wybór projektu z dashboardu
- 📊 Organizacja testów w kontekście projektu
- 🔄 Przypisywanie użytkowników do projektów

### Zarządzanie Testami
- 📝 Tworzenie i edycja przypadków testowych
- ✅ Wykonywanie testów i raportowanie wyników
- 🎯 Priorytety testów (wysoki, średni, niski)
- 📈 Historia wykonań testów
- 🔍 Filtrowanie testów po projekcie

### Panel Administracyjny (tylko dla Administratorów)
- � **Zarządzanie użytkownikami:**
  - Dodawanie, edycja i usuwanie użytkowników
  - Resetowanie haseł użytkowników
  - Aktywacja/deaktywacja kont
  - Przypisywanie użytkowników do projektów
- �️ **Zarządzanie rolami:**
  - 4 domyślne role: Administrator, Test Manager, Analityk, Tester
  - Tworzenie niestandardowych ról
  - Edycja i usuwanie ról niestandardowych
  - Definiowanie uprawnień dla ról

### Dashboard
- 📊 Wybór projektu do pracy
- 📈 Statystyki i metryki

## Stack Technologiczny

### Backend
- Node.js + Express
- TypeScript
- SQLite (sql.js - baza danych)
- JWT (autentykacja)
- bcryptjs (hashowanie haseł)

### Frontend
- React 18
- TypeScript
- Vite
- TailwindCSS
- Lucide Icons
- React Router
- Axios
- Context API (zarządzanie stanem projektu)

## Instalacja

### Backend

```bash
cd backend
cp .env.example .env  # Skopiuj plik konfiguracyjny
npm install
npm run dev
```

Backend uruchomi się na `http://localhost:3000`

**Uwaga:** Przy pierwszym uruchomieniu zostaną utworzone:
- Domyślne role (Administrator, Test Manager, Analityk, Tester)
- Domyślny administrator (admin@test.com)

### Frontend

```bash
cd frontend
npm install
npm run dev
```

Frontend uruchomi się na `http://localhost:5173`

## Struktura Projektu

```
├── backend/          # Serwer API
│   ├── src/
│   │   ├── routes/   # Endpointy API
│   │   │   ├── auth.ts        # Autentykacja
│   │   │   ├── projects.ts    # Projekty
│   │   │   ├── tests.ts       # Testy
│   │   │   ├── test-runs.ts   # Wykonania testów
│   │   │   ├── users.ts       # Użytkownicy (admin)
│   │   │   ├── roles.ts       # Role (admin)
│   │   │   └── statistics.ts  # Statystyki
│   │   ├── middleware/
│   │   │   └── auth.ts        # JWT middleware
│   │   ├── database.ts        # Konfiguracja bazy danych
│   │   └── server.ts          # Główny plik serwera
│   └── package.json
│
└── frontend/         # Aplikacja React
    ├── src/
    │   ├── components/
    │   │   ├── Layout.tsx           # Główny layout
    │   │   └── admin/               # Komponenty admin
    │   │       ├── UserManagement.tsx
    │   │       └── RoleManagement.tsx
    │   ├── pages/
    │   │   ├── Login.tsx            # Logowanie/Rejestracja
    │   │   ├── Dashboard.tsx        # Wybór projektu
    │   │   ├── Projects.tsx         # Lista projektów
    │   │   ├── Tests.tsx            # Lista testów
    │   │   ├── TestDetail.tsx       # Szczegóły testu
    │   │   └── AdminPanel.tsx       # Panel administracyjny
    │   ├── context/
    │   │   └── ProjectContext.tsx   # Kontekst wybranego projektu
    │   ├── lib/
    │   │   ├── api.ts               # Klient API
    │   │   └── auth.ts              # Utilities autentykacji
    │   └── App.tsx
    └── package.json
```

## API Endpoints

### Autentykacja
- `POST /api/auth/register` - Rejestracja użytkownika
- `POST /api/auth/login` - Logowanie

### Projekty
- `GET /api/projects` - Lista projektów
- `POST /api/projects` - Tworzenie projektu
- `PUT /api/projects/:id` - Aktualizacja projektu
- `DELETE /api/projects/:id` - Usuwanie projektu

### Testy
- `GET /api/tests` - Lista testów (z filtrowaniem po projekcie)
- `GET /api/tests/:id` - Szczegóły testu
- `POST /api/tests` - Tworzenie testu
- `PUT /api/tests/:id` - Aktualizacja testu
- `DELETE /api/tests/:id` - Usuwanie testu

### Wykonania Testów
- `GET /api/test-runs` - Lista wykonań (z filtrowaniem)
- `POST /api/test-runs` - Wykonanie testu

### Statystyki
- `GET /api/statistics` - Statystyki systemu

### Użytkownicy (tylko Administrator)
- `GET /api/users` - Lista użytkowników
- `POST /api/users` - Dodanie użytkownika
- `PUT /api/users/:id` - Edycja użytkownika
- `DELETE /api/users/:id` - Usunięcie użytkownika
- `POST /api/users/:id/reset-password` - Resetowanie hasła
- `GET /api/users/:id/projects` - Projekty użytkownika
- `POST /api/users/:id/projects` - Przypisanie projektu
- `DELETE /api/users/:id/projects/:projectId` - Usunięcie przypisania

### Role (tylko Administrator)
- `GET /api/roles` - Lista ról
- `POST /api/roles` - Dodanie roli
- `PUT /api/roles/:id` - Edycja roli
- `DELETE /api/roles/:id` - Usunięcie roli

## Domyślne Konto Administratora

- Email: `admin@test.com`
- Hasło: `admin123`
- Rola: Administrator

## System Ról i Uprawnień

### Domyślne Role

1. **Administrator**
   - Pełny dostęp do systemu
   - Zarządzanie użytkownikami i rolami
   - Dostęp do panelu administracyjnego
   - Uprawnienia: `all`

2. **Test Manager**
   - Zarządzanie projektami i testami
   - Wykonywanie testów
   - Uprawnienia: `manage_projects`, `manage_tests`, `execute_tests`

3. **Analityk**
   - Tworzenie i edycja testów
   - Wykonywanie testów
   - Uprawnienia: `create_tests`, `edit_tests`, `execute_tests`

4. **Tester**
   - Wykonywanie testów
   - Przeglądanie testów
   - Uprawnienia: `execute_tests`, `view_tests`

### Dostępne Uprawnienia

- `all` - pełny dostęp do systemu
- `manage_projects` - zarządzanie projektami
- `manage_tests` - zarządzanie testami
- `create_tests` - tworzenie testów
- `edit_tests` - edycja testów
- `execute_tests` - wykonywanie testów
- `view_tests` - przeglądanie testów

## Przepływ Pracy

1. **Logowanie** - Użytkownik loguje się do systemu
2. **Wybór Projektu** - Na dashboardzie wybiera projekt do pracy
3. **Zarządzanie Testami** - W kontekście projektu tworzy i zarządza testami
4. **Wykonywanie Testów** - Wykonuje testy i zapisuje wyniki
5. **Panel Admin** (tylko Administrator) - Zarządza użytkownikami i rolami

## Baza Danych

System używa SQLite (sql.js) z następującymi tabelami:

- `roles` - Role w systemie
- `users` - Użytkownicy
- `projects` - Projekty
- `test_cases` - Przypadki testowe
- `test_runs` - Wykonania testów
- `user_projects` - Przypisania użytkowników do projektów

## Bezpieczeństwo

- Hasła są hashowane przy użyciu bcryptjs
- Autentykacja oparta na JWT tokens
- Middleware sprawdza uprawnienia użytkownika
- Panel administracyjny dostępny tylko dla administratorów
- Domyślne role są chronione przed modyfikacją/usunięciem
