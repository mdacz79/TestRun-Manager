# Bugfix - Widoczność autora w podglądzie TC

## Problem
Pole autora w modalu podglądu przypadku testowego było mało widoczne - wyglądało jak zwykłe pole formularza i łatwo było je przeoczyć.

## Rozwiązanie
Zmieniono styl pola autora na wyróżniony panel z:
- Niebieskim tłem i ramką
- Ikoną użytkownika (👤)
- Większą czcionką dla imienia autora
- Dodatkowo datą utworzenia TC

## Implementacja

### Przed:
```tsx
<div>
  <label className="block text-sm font-medium text-gray-700 mb-1">
    Autor
  </label>
  <div className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
    {viewSpec.created_by_name || 'Nieznany'}
  </div>
</div>
```

**Wygląd:**
```
┌─────────────────────────────────┐
│ Autor                           │
│ Jan Kowalski                    │
└─────────────────────────────────┘
```
❌ Mało widoczne, wygląda jak zwykłe pole

### Po:
```tsx
<div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
  <label className="block text-sm font-medium text-blue-900 mb-2">
    👤 Autor przypadku testowego
  </label>
  <div className="text-base font-semibold text-blue-800">
    {viewSpec.created_by_name || 'Nieznany autor'}
  </div>
  {viewSpec.created_at && (
    <div className="text-xs text-blue-600 mt-1">
      Utworzono: {new Date(viewSpec.created_at).toLocaleDateString('pl-PL', { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })}
    </div>
  )}
</div>
```

**Wygląd:**
```
┌─────────────────────────────────────────────┐
│ 👤 Autor przypadku testowego               │
│ Jan Kowalski                                │
│ Utworzono: 14 maja 2026, 19:20             │
└─────────────────────────────────────────────┘
```
✅ Wyróżnione, łatwe do zauważenia

## Szczegóły zmian

### 1. Kontener
**Przed:** Zwykły `<div>`
**Po:** `<div className="bg-blue-50 border border-blue-200 rounded-lg p-3">`

**Zmiany:**
- ✅ Niebieskie tło (`bg-blue-50`)
- ✅ Niebieska ramka (`border border-blue-200`)
- ✅ Zaokrąglone rogi (`rounded-lg`)
- ✅ Padding (`p-3`)

### 2. Etykieta
**Przed:** `Autor` (szary tekst)
**Po:** `👤 Autor przypadku testowego` (niebieski tekst z ikoną)

**Zmiany:**
- ✅ Ikona użytkownika (👤)
- ✅ Pełniejszy opis ("Autor przypadku testowego")
- ✅ Niebieski kolor (`text-blue-900`)
- ✅ Większy margines dolny (`mb-2`)

### 3. Wartość (imię autora)
**Przed:** `text-sm text-gray-900` (mały, szary)
**Po:** `text-base font-semibold text-blue-800` (większy, pogrubiony, niebieski)

**Zmiany:**
- ✅ Większa czcionka (`text-base` zamiast `text-sm`)
- ✅ Pogrubienie (`font-semibold`)
- ✅ Niebieski kolor (`text-blue-800`)

### 4. Data utworzenia (NOWE)
**Przed:** Brak
**Po:** Wyświetlanie daty utworzenia TC

```tsx
{viewSpec.created_at && (
  <div className="text-xs text-blue-600 mt-1">
    Utworzono: {new Date(viewSpec.created_at).toLocaleDateString('pl-PL', { 
      year: 'numeric', 
      month: 'long', 
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })}
  </div>
)}
```

**Format daty:** "14 maja 2026, 19:20"

## Przykład użycia

### Podgląd TC:

**Akcja:** Kliknij ikonę oka przy TC

**Modal:**
```
┌─────────────────────────────────────────────────────────┐
│ Podgląd przypadku testowego                       [X]  │
├─────────────────────────────────────────────────────────┤
│ ID TC: PT1-001                                          │
│ Tytuł: Test logowania                                   │
│ Opis: Sprawdzenie procesu logowania                     │
│ Warunki wstępne: Użytkownik niezalogowany              │
│ Zestaw testowy: Logowanie                              │
│ Powiązane wymagania: WYM-001                            │
│ Tagi: [Backend] [API]                                  │
│                                                         │
│ ┌─────────────────────────────────────────────────────┐ │
│ │ 👤 Autor przypadku testowego                        │ │
│ │ Jan Kowalski                                        │ │
│ │ Utworzono: 14 maja 2026, 19:20                      │ │
│ └─────────────────────────────────────────────────────┘ │
│                                                         │
│ Priorytet: Wysoki    │ Status: Zatwierdzony            │
│                                                         │
│ Kroki testowe:                                          │
│ 1. Wejdź na stronę logowania → Formularz widoczny      │
│ 2. Wprowadź dane → Dane zaakceptowane                  │
└─────────────────────────────────────────────────────────┘
```

## Porównanie

| Aspekt | Przed | Po |
|--------|-------|-----|
| **Tło** | Szare (`bg-gray-50`) | Niebieskie (`bg-blue-50`) |
| **Ramka** | Brak | Niebieska (`border-blue-200`) |
| **Ikona** | Brak | 👤 |
| **Etykieta** | "Autor" | "👤 Autor przypadku testowego" |
| **Rozmiar czcionki** | Mały (`text-sm`) | Normalny (`text-base`) |
| **Waga czcionki** | Normalna | Pogrubiona (`font-semibold`) |
| **Kolor tekstu** | Szary | Niebieski |
| **Data utworzenia** | Brak | Tak (format polski) |
| **Widoczność** | ❌ Niska | ✅ Wysoka |

## Korzyści

### ✅ Widoczność:
- Pole autora jest teraz wyraźnie widoczne
- Niebieskie tło przyciąga wzrok
- Ikona użytkownika ułatwia identyfikację

### ✅ Informacyjność:
- Dodano datę utworzenia TC
- Pełniejszy opis ("Autor przypadku testowego")
- Format daty w języku polskim

### ✅ Spójność:
- Styl podobny do pola autora w formularzu
- Jednolite niebieskie tło dla informacji o autorze
- Spójny design w całej aplikacji

### ✅ UX:
- Łatwiejsze znalezienie autora
- Więcej kontekstu (data utworzenia)
- Lepsze wrażenia użytkownika

## Format daty

### Funkcja formatowania:
```typescript
new Date(viewSpec.created_at).toLocaleDateString('pl-PL', { 
  year: 'numeric',      // 2026
  month: 'long',        // maja
  day: 'numeric',       // 14
  hour: '2-digit',      // 19
  minute: '2-digit'     // 20
})
```

### Przykłady:
- `2026-05-14T19:20:00` → "14 maja 2026, 19:20"
- `2026-01-01T08:30:00` → "1 stycznia 2026, 08:30"
- `2026-12-31T23:59:00` → "31 grudnia 2026, 23:59"

## Fallback dla brakujących danych

### Brak autora:
```typescript
{viewSpec.created_by_name || 'Nieznany autor'}
```

**Wyświetli:** "Nieznany autor" (zamiast "Nieznany")

### Brak daty:
```typescript
{viewSpec.created_at && (
  // Wyświetl datę
)}
```

**Jeśli brak:** Data nie jest wyświetlana (pole ukryte)

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Zmiana stylu pola autora w modalu podglądu (linia 1414-1432)
  - Dodanie ikony użytkownika
  - Dodanie wyświetlania daty utworzenia
  - Zmiana tekstu "Nieznany" na "Nieznany autor"

## Data implementacji
2026-05-14

## Status
✅ Naprawione i gotowe do użycia
