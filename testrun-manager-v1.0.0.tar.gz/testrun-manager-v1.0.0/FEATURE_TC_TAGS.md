# Feature - Tagowanie przypadków testowych

## Opis
Dodano możliwość przypisywania tagów (słów kluczowych) do przypadków testowych. Przypadki testowe i wymagania korzystają z tego samego słownika tagów w ramach projektu.

## Implementacja

### Frontend (`/frontend/src/pages/TestSpecifications.tsx`)

#### 1. Nowy stan:
```typescript
const [selectedTags, setSelectedTags] = useState<number[]>([]);
```

#### 2. Formularz tworzenia/edycji TC:
- ✅ Dodano komponent `TagSelector` w formularzu
- ✅ Pole "Tagi" umieszczone po polach Priorytet i Status
- ✅ Używa tego samego komponentu co wymagania

#### 3. Zapisywanie tagów:
```typescript
const data = {
  ...formData,
  tag_ids: selectedTags,  // Dodano tag_ids
};
```

#### 4. Ładowanie tagów przy edycji:
```typescript
setSelectedTags(spec.tags ? spec.tags.map((t: any) => t.id) : []);
```

#### 5. Resetowanie formularza:
```typescript
setSelectedTags([]);  // Reset tagów
```

#### 6. Wyświetlanie tagów:

**W liście TC (zestawy i "Bez zestawu"):**
```tsx
{spec.tags && spec.tags.length > 0 && (
  <div className="flex items-center gap-1 mt-1 flex-wrap">
    <span className="text-xs text-gray-500">Tagi:</span>
    {spec.tags.map((tag: any) => (
      <span style={{ backgroundColor, color, border }}>
        {tag.name}
      </span>
    ))}
  </div>
)}
```

**W modalu podglądu:**
- Nowa sekcja "Tagi" po "Powiązane wymagania"
- Wyświetlanie tagów z kolorami
- Komunikat "Brak tagów" gdy brak przypisanych tagów

## Funkcjonalności

### ✅ Tworzenie TC:
1. Otwórz formularz "Nowy przypadek testowy"
2. Wypełnij dane TC
3. W polu "Tagi" wybierz istniejące tagi lub utwórz nowe
4. Zapisz TC - tagi zostaną przypisane

### ✅ Edycja TC:
1. Kliknij "Edytuj" przy TC
2. Pole "Tagi" pokazuje aktualnie przypisane tagi
3. Możesz dodać/usunąć tagi
4. Zapisz zmiany

### ✅ Wyświetlanie tagów:
- **Lista TC** - tagi wyświetlane pod wymaganiami z kolorami
- **Podgląd TC** - sekcja "Tagi" z kolorowymi znacznikami
- **Eksport CSV** - tagi eksportowane jako lista oddzielona przecinkami

## Wspólny słownik tagów

Przypadki testowe i wymagania używają **tego samego słownika tagów**:
- Tagi tworzone w wymaganiach są dostępne dla TC
- Tagi tworzone w TC są dostępne dla wymagań
- Zarządzanie tagami w Admin Panel → Zarządzanie tagami
- Tagi są przypisane do projektu

## Przykład użycia

### Scenariusz 1: Tagowanie TC
1. Utwórz TC "Test logowania"
2. Dodaj tagi: "Backend", "Security", "Critical"
3. TC będzie wyświetlany z kolorowymi tagami w liście

### Scenariusz 2: Filtrowanie (przyszła funkcja)
- Możliwość filtrowania TC po tagach
- Grupowanie TC według tagów
- Wyszukiwanie TC z konkretnym tagiem

### Scenariusz 3: Eksport
- Eksport TC do CSV zawiera kolumnę "Tagi"
- Tagi oddzielone przecinkami: "Backend, Security, Critical"

## Pliki zmienione

### Frontend:
- `/frontend/src/pages/TestSpecifications.tsx`
  - Import TagSelector
  - Stan selectedTags
  - Integracja w formularzu
  - Wyświetlanie w liście i podglądzie
  - Obsługa zapisywania i ładowania tagów

### Backend:
- Backend już obsługiwał tagi dla TC (tabela `test_specification_tags`)
- Endpoint GET zwraca tagi w enrichedSpecs
- Endpoint POST/PUT przyjmuje `tag_ids`

## Korzyści

✅ **Organizacja** - łatwe grupowanie TC według kategorii
✅ **Wyszukiwanie** - szybkie znajdowanie TC z konkretnym tagiem
✅ **Raportowanie** - możliwość tworzenia raportów per tag
✅ **Spójność** - ten sam słownik dla wymagań i TC
✅ **Wizualizacja** - kolorowe tagi ułatwiają identyfikację
✅ **Eksport** - tagi zawarte w eksporcie CSV

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
