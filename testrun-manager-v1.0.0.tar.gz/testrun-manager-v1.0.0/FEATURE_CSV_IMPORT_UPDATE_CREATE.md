# Feature - Import CSV z aktualizacją i tworzeniem TC

## Opis
Zmieniono logikę importu CSV aby obsługiwała trzy scenariusze:
1. **ID istnieje** → aktualizuj istniejący TC
2. **ID nowe** → utwórz nowy TC z podanym ID
3. **Brak ID** → utwórz nowy TC z automatycznie wygenerowanym ID

## Implementacja

### 1. Nowa logika importu (`TestSpecifications.tsx`)

#### Przed:
```typescript
// Sprawdź duplikaty i pomiń
if (existingTC) {
  skipped++;
  continue;
}
// Zawsze twórz nowy TC
await testSpecifications.create(data);
```

#### Po:
```typescript
// Sprawdź czy TC istnieje
const existingTC = tc.test_case_id 
  ? specificationsList.find(s => s.test_case_id === tc.test_case_id)
  : null;

if (existingTC) {
  // Scenariusz 1: ID istnieje -> aktualizuj
  await testSpecifications.update(existingTC.id, tcData);
  updated++;
} else {
  // Scenariusz 2 i 3: Utwórz nowy TC
  await testSpecifications.create(tcData);
  created++;
}
```

### 2. Parser CSV - obsługa braku ID (`csvImport.ts`)

#### Przed:
```typescript
if (!testCaseId || !title) {
  console.warn('Pominięto wiersz bez ID lub tytułu');
  return;
}
```

#### Po:
```typescript
if (!title) {
  console.warn('Pominięto wiersz bez tytułu');
  return;
}

// Użyj ID jako klucza, lub tytułu jeśli brak ID
const mapKey = testCaseId || `__no_id__${title}`;
```

### 3. Nowe komunikaty podsumowania

#### Przed:
```
✅ Zaimportowano: 5
ℹ️ Pominięto: 2 (duplikaty)
❌ Błędy: 0
```

#### Po:
```
✅ Utworzono 3 nowych przypadków testowych
🔄 Zaktualizowano 2 istniejących przypadków testowych
❌ Błędy podczas importu: 0
```

## Scenariusze użycia

### Scenariusz 1: Aktualizacja istniejących TC

**CSV:**
```csv
ID TC,Tytuł,Opis,...
PT1-001,Test 1 (zaktualizowany),Nowy opis,...
PT1-002,Test 2 (zaktualizowany),Nowy opis,...
```

**Rezultat:**
- TC PT1-001 istnieje → **aktualizuj** tytuł, opis, kroki, etc.
- TC PT1-002 istnieje → **aktualizuj** tytuł, opis, kroki, etc.

**Komunikat:**
```
🔄 Zaktualizowano 2 istniejących przypadków testowych
```

### Scenariusz 2: Tworzenie nowych TC z określonym ID

**CSV:**
```csv
ID TC,Tytuł,Opis,...
PT1-999,Nowy test 1,Opis,...
PT1-998,Nowy test 2,Opis,...
```

**Rezultat:**
- TC PT1-999 nie istnieje → **utwórz nowy** z ID PT1-999
- TC PT1-998 nie istnieje → **utwórz nowy** z ID PT1-998

**Komunikat:**
```
✅ Utworzono 2 nowych przypadków testowych
```

**Uwaga:** Backend może odrzucić ID jeśli nie pasuje do formatu projektu (TAG-XXX).

### Scenariusz 3: Tworzenie nowych TC bez ID

**CSV:**
```csv
ID TC,Tytuł,Opis,...
,Nowy test bez ID 1,Opis,...
,Nowy test bez ID 2,Opis,...
```

**Rezultat:**
- Brak ID → **utwórz nowy** z automatycznym ID (np. PT1-010)
- Brak ID → **utwórz nowy** z automatycznym ID (np. PT1-011)

**Komunikat:**
```
✅ Utworzono 2 nowych przypadków testowych
```

### Scenariusz 4: Mix - aktualizacja i tworzenie

**CSV:**
```csv
ID TC,Tytuł,Opis,...
PT1-001,Test 1 (aktualizacja),Opis,...
PT1-999,Nowy test,Opis,...
,Test bez ID,Opis,...
```

**Rezultat:**
- PT1-001 istnieje → **aktualizuj**
- PT1-999 nie istnieje → **utwórz** z ID PT1-999
- Brak ID → **utwórz** z automatycznym ID (PT1-010)

**Komunikat:**
```
✅ Utworzono 2 nowych przypadków testowych
🔄 Zaktualizowano 1 istniejący przypadek testowy
```

## Grupowanie kroków bez ID

Parser grupuje kroki według ID lub tytułu:

**CSV:**
```csv
ID TC,Tytuł,Opis,Warunki,Numer kroku,Akcja,Rezultat,...
,Test bez ID,Opis,Warunki,1,Akcja 1,Rezultat 1,...
,Test bez ID,Opis,Warunki,2,Akcja 2,Rezultat 2,...
```

**Grupowanie:**
```javascript
// Klucz mapy: "__no_id__Test bez ID"
{
  test_case_id: '', // puste
  title: 'Test bez ID',
  steps: [
    { action: 'Akcja 1', expected_result: 'Rezultat 1' },
    { action: 'Akcja 2', expected_result: 'Rezultat 2' }
  ]
}
```

## Aktualizacja TC - co jest zmieniane

Przy aktualizacji istniejącego TC **wszystkie dane są nadpisywane**:
- ✅ Tytuł
- ✅ Opis
- ✅ Warunki wstępne
- ✅ Priorytet
- ✅ Status
- ✅ Zestaw testowy
- ✅ Kroki (stare usuwane, nowe dodawane)
- ✅ Wymagania (stare usuwane, nowe dodawane)
- ✅ Tagi (stare usuwane, nowe dodawane)

**Uwaga:** Aktualizacja jest **pełna** - jeśli coś nie jest w CSV, zostanie usunięte!

## Przykłady CSV

### Przykład 1: Aktualizacja z nowymi krokami
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-001,Test logowania (v2),Nowy opis,Nowe warunki,1,Nowa akcja 1,Nowy rezultat 1,Wysoki,Zatwierdzony,Logowanie,WYM-PT1-001,Backend
PT1-001,Test logowania (v2),Nowy opis,Nowe warunki,2,Nowa akcja 2,Nowy rezultat 2,Wysoki,Zatwierdzony,Logowanie,WYM-PT1-001,Backend
```

### Przykład 2: Nowe TC bez ID
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
,Nowy test API,Test endpointu,API dostępne,1,Wyślij request,Status 200,Wysoki,Szkic,API,WYM-PT1-005,Backend
,Nowy test API,Test endpointu,API dostępne,2,Sprawdź response,Dane poprawne,Wysoki,Szkic,API,WYM-PT1-005,Backend
```

### Przykład 3: Mix
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-001,Aktualizacja,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,Logowanie,WYM-PT1-001,test
PT1-999,Nowy z ID,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,Logowanie,WYM-PT1-002,test
,Nowy bez ID,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,Logowanie,WYM-PT1-003,test
```

**Rezultat:**
- PT1-001 → zaktualizowany
- PT1-999 → utworzony z tym ID
- Bez ID → utworzony z automatycznym ID (np. PT1-010)

## Walidacja

### Wymagane pola:
- ✅ **Tytuł** - musi być wypełniony
- ❌ **ID TC** - opcjonalne

### Opcjonalne pola:
- Opis, warunki wstępne, kroki, wymagania, tagi, etc.

### Pominięte wiersze:
- Wiersze bez tytułu
- Wiersze z mniej niż 12 kolumnami

## Pliki zmienione

### Frontend:
- `/frontend/src/pages/TestSpecifications.tsx`:
  - Zmiana logiki importu (create vs update)
  - Nowe liczniki: `created`, `updated`
  - Nowe komunikaty podsumowania
- `/frontend/src/utils/csvImport.ts`:
  - Walidacja tylko tytułu (ID opcjonalne)
  - Grupowanie kroków po ID lub tytule

## Korzyści

✅ **Aktualizacja masowa** - możliwość edycji TC w Excel i reimport
✅ **Migracja danych** - import TC z innych systemów z zachowaniem ID
✅ **Tworzenie masowe** - szybkie dodawanie wielu TC bez ręcznego wpisywania
✅ **Elastyczność** - obsługa wszystkich scenariuszy w jednym imporcie

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
