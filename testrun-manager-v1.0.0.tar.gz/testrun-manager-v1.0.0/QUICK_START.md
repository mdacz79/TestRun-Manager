# TestRun Manager v1.0 - Quick Start Guide

## Szybki Start (5 minut)

### Krok 1: Pobierz i rozpakuj

**Linux/Mac:**
```bash
tar -xzf testrun-manager-v1.0.tar.gz
cd testrun-manager-v1.0
```

**Windows:**
```powershell
Expand-Archive testrun-manager-v1.0.zip
cd testrun-manager-v1.0
```

### Krok 2: Uruchom instalator

**Linux/Mac:**
```bash
chmod +x install.sh
./install.sh
```

**Windows (PowerShell jako Administrator):**
```powershell
.\install.ps1
```

### Krok 3: Otwórz przeglądarkę

Przejdź do: `http://localhost` lub `http://your-domain.com`

### Krok 4: Zarejestruj się

1. Kliknij "Zarejestruj się"
2. Wprowadź dane:
   - Email: twój@email.com
   - Hasło: (wybierz silne hasło)
   - Imię i nazwisko: Twoje Imię

**Pierwsze konto automatycznie otrzymuje uprawnienia administratora!**

### Krok 5: Utwórz pierwszy projekt

1. Na dashboardzie kliknij "Nowy projekt"
2. Wprowadź nazwę i opis
3. Kliknij "Utwórz"

### Krok 6: Dodaj wymagania i testy

1. Przejdź do modułu "Wymagania"
2. Dodaj wymagania dla projektu
3. Przejdź do "Specyfikacja testowa"
4. Utwórz przypadki testowe

### Krok 7: Wykonaj testy

1. Przejdź do "Wykonywanie testów"
2. Wybierz plan testowy
3. Wykonaj testy i zapisz wyniki

### Krok 8: Zobacz raporty

1. Przejdź do "Raporty"
2. Zobacz:
   - Wykres burndown
   - Statystyki wykonania
   - Macierz pokrycia wymagań

---

## Przydatne Komendy

### Sprawdzenie statusu

**Linux (PM2):**
```bash
pm2 status
pm2 logs testrun-backend
```

**Windows (Usługa):**
```powershell
Get-Service 'TestRun Manager Backend'
```

### Restart systemu

**Linux:**
```bash
pm2 restart testrun-backend
sudo systemctl restart nginx
```

**Windows:**
```powershell
Restart-Service 'TestRun Manager Backend'
```

### Backup bazy danych

**Linux:**
```bash
cp /opt/testrun-manager/backend/database.db ~/backup/database-$(date +%Y%m%d).db
```

**Windows:**
```powershell
Copy-Item C:\testrun-manager\backend\database.db C:\backup\database-$(Get-Date -Format 'yyyyMMdd').db
```

---

## Rozwiązywanie Problemów

### Problem: Nie mogę się zalogować

**Rozwiązanie:**
- Sprawdź czy backend działa: `pm2 status` (Linux) lub `Get-Service` (Windows)
- Sprawdź logi: `pm2 logs testrun-backend`
- Upewnij się że używasz poprawnego hasła

### Problem: Strona się nie ładuje

**Rozwiązanie:**
- Sprawdź czy Nginx działa: `sudo systemctl status nginx`
- Sprawdź konfigurację: `sudo nginx -t`
- Sprawdź firewall: `sudo ufw status`

### Problem: Backend nie startuje

**Rozwiązanie:**
- Sprawdź czy port 3000 jest wolny: `sudo netstat -tulpn | grep 3000`
- Sprawdź plik .env w katalogu backend
- Sprawdź uprawnienia: `sudo chown -R $USER:$USER /opt/testrun-manager`

---

## Następne Kroki

1. **Dodaj użytkowników** - Panel Admin → Użytkownicy
2. **Skonfiguruj role** - Panel Admin → Role
3. **Utwórz projekty** - Dashboard → Nowy projekt
4. **Importuj wymagania** - Moduł Wymagania
5. **Napisz testy** - Specyfikacja testowa
6. **Zaplanuj wykonanie** - Plany testowe
7. **Monitoruj postęp** - Raporty

---

## Wsparcie

**Dokumentacja pełna**: [INSTALLATION.md](INSTALLATION.md)  
**Autor**: ITM Marek Dacz  
**Wersja**: 1.0  
**Email**: support@testrun-manager.com

---

© 2026 ITM Marek Dacz
