# Bugfix - Niemożność Zakończenia Testu

## Problem

Użytkownik nie mógł dokończyć testu, który był rozpoczęty. Przycisk "Zakończ test" był nieaktywny lub test nie mógł być zakończony ze statusem FAILED.

## Przyczyna

1. **Brak przekazywania bugId** - ExecuteTestModal nie otrzymywał informacji o utworzonym błędzie
2. **Brak walidacji** - Nie było sprawdzenia czy przy statusie FAILED został zgłoszony błąd
3. **Brak informacji zwrotnej** - Użytkownik nie widział czy błąd został zgłoszony

## Rozwiązanie

### 1. Dodanie stanu dla bugId w TestExecution.tsx

```typescript
const [createdBugId, setCreatedBugId] = useState<number | undefined>();
```

### 2. Przekazanie bugId do ExecuteTestModal

```typescript
<ExecuteTestModal
  testCase={selectedTestCase}
  execution={currentExecution}
  bugId={createdBugId}  // ← NOWE
  onClose={() => {
    setShowExecuteModal(false);
    setCurrentExecution(null);
    setSelectedTestCase(null);
    setCreatedBugId(undefined);  // ← Reset bugId
  }}
  onComplete={handleCompleteTest}
  onCreateBug={() => setShowBugModal(true)}
/>
```

### 3. Obsługa utworzenia błędu

```typescript
<CreateBugModal
  projectId={selectedProject!.id}
  onClose={() => setShowBugModal(false)}
  onCreate={(bug: any) => {
    setCreatedBugId(bug.id);  // ← Zapisz ID błędu
    setShowBugModal(false);
    toast.success(`✅ Błąd ${bug.bug_id} zgłoszony`);
  }}
/>
```

### 4. Aktualizacja ExecuteTestModal

**Dodanie bugId jako prop:**
```typescript
interface ExecuteTestModalProps {
  testCase: any;
  execution: any;
  bugId?: number;  // ← NOWE
  onClose: () => void;
  onComplete: (data: { status: string; bug_id?: number; notes?: string }) => void;
  onCreateBug: () => void;
}
```

**Walidacja przycisku "Zakończ test":**
```typescript
<button
  onClick={handleComplete}
  disabled={!selectedStatus || (selectedStatus === 'FAILED' && !bugId)}
  className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
>
  Zakończ test
</button>
```

**Przycisk jest disabled gdy:**
- Nie wybrano statusu (`!selectedStatus`)
- LUB wybrano FAILED ale nie zgłoszono błędu (`selectedStatus === 'FAILED' && !bugId`)

### 5. Informacje zwrotne dla użytkownika

**Gdy błąd został zgłoszony (zielony panel):**
```typescript
{selectedStatus === 'FAILED' && bugId && (
  <div className="bg-green-50 border border-green-200 rounded-lg p-3">
    <div className="flex items-center gap-2 text-green-800">
      <span className="text-lg">✅</span>
      <span className="font-medium">Błąd został zgłoszony (ID: {bugId})</span>
    </div>
  </div>
)}
```

**Gdy wybrano FAILED ale nie zgłoszono błędu (czerwony panel):**
```typescript
{selectedStatus === 'FAILED' && !bugId && (
  <div className="bg-red-50 border border-red-200 rounded-lg p-3">
    <div className="flex items-center gap-2 text-red-800">
      <span className="text-lg">⚠️</span>
      <span className="font-medium">Musisz zgłosić błąd przed zakończeniem testu</span>
    </div>
  </div>
)}
```

## Przepływ Użytkownika

### Scenariusz 1: Test PASSED (bez błędu)

```
1. Kliknij "Wykonaj test"
2. Przejrzyj kroki
3. Kliknij przycisk "Zaliczony" (✅)
4. Dodaj notatki (opcjonalne)
5. Kliknij "Zakończ test" ← AKTYWNY
6. Test zakończony ze statusem PASSED
```

### Scenariusz 2: Test FAILED (z błędem)

```
1. Kliknij "Wykonaj test"
2. Przejrzyj kroki
3. Kliknij przycisk "Niezaliczony" (❌)
4. Modal zgłoszenia błędu się otwiera automatycznie
5. Wypełnij formularz błędu:
   - Tytuł: "Błąd walidacji"
   - Opis: "..."
   - Severity: "high"
6. Kliknij "Zgłoś błąd"
7. Toast: "✅ Błąd BUG-0001 zgłoszony"
8. Wróć do modalu wykonania testu
9. Zielony panel: "✅ Błąd został zgłoszony (ID: 1)"
10. Dodaj notatki (opcjonalne)
11. Kliknij "Zakończ test" ← TERAZ AKTYWNY
12. Test zakończony ze statusem FAILED + powiązany błąd
```

### Scenariusz 3: Test FAILED (próba bez błędu)

```
1. Kliknij "Wykonaj test"
2. Przejrzyj kroki
3. Kliknij przycisk "Niezaliczony" (❌)
4. Zamknij modal zgłoszenia błędu (Anuluj)
5. Czerwony panel: "⚠️ Musisz zgłosić błąd przed zakończeniem testu"
6. Przycisk "Zakończ test" jest NIEAKTYWNY (szary)
7. Użytkownik musi kliknąć ponownie "Niezaliczony" aby zgłosić błąd
```

## Wygląd UI

### Panel sukcesu (błąd zgłoszony):
```
┌─────────────────────────────────────────────┐
│ ✅ Błąd został zgłoszony (ID: 1)            │
└─────────────────────────────────────────────┘
```
- Tło: `bg-green-50`
- Ramka: `border-green-200`
- Tekst: `text-green-800`

### Panel ostrzeżenia (brak błędu):
```
┌─────────────────────────────────────────────┐
│ ⚠️ Musisz zgłosić błąd przed zakończeniem   │
│    testu                                    │
└─────────────────────────────────────────────┘
```
- Tło: `bg-red-50`
- Ramka: `border-red-200`
- Tekst: `text-red-800`

## Testowanie

### Test 1: Zakończenie testu PASSED
```
1. Rozpocznij test
2. Wybierz "Zaliczony"
3. Sprawdź czy przycisk "Zakończ test" jest aktywny (niebieski)
4. Kliknij "Zakończ test"
5. Sprawdź czy test ma status PASSED (✅ zielony)
```

### Test 2: Zakończenie testu FAILED z błędem
```
1. Rozpocznij test
2. Wybierz "Niezaliczony"
3. Modal błędu się otwiera
4. Wypełnij i zgłoś błąd
5. Sprawdź toast: "✅ Błąd BUG-XXXX zgłoszony"
6. Sprawdź zielony panel: "✅ Błąd został zgłoszony"
7. Sprawdź czy przycisk "Zakończ test" jest aktywny
8. Kliknij "Zakończ test"
9. Sprawdź czy test ma status FAILED (❌ czerwony)
10. Sprawdź w historii czy błąd jest powiązany
```

### Test 3: Próba zakończenia FAILED bez błędu
```
1. Rozpocznij test
2. Wybierz "Niezaliczony"
3. Zamknij modal błędu (Anuluj)
4. Sprawdź czerwony panel: "⚠️ Musisz zgłosić błąd..."
5. Sprawdź czy przycisk "Zakończ test" jest NIEAKTYWNY (szary)
6. Próba kliknięcia - nic się nie dzieje
7. Wybierz ponownie "Niezaliczony"
8. Zgłoś błąd
9. Teraz przycisk jest aktywny
```

### Test 4: Zakończenie testu SKIPPED/BLOCKED
```
1. Rozpocznij test
2. Wybierz "Pominięty" lub "Zablokowany"
3. Sprawdź czy przycisk "Zakończ test" jest aktywny (bez wymagania błędu)
4. Kliknij "Zakończ test"
5. Sprawdź odpowiedni status
```

## Pliki Zmienione

### 1. TestExecution.tsx
- Dodano stan `createdBugId`
- Przekazywanie `bugId` do ExecuteTestModal
- Reset `bugId` przy zamknięciu modalu
- Obsługa `onCreate` w CreateBugModal z zapisaniem ID

### 2. ExecuteTestModal.tsx
- Dodano prop `bugId?: number`
- Walidacja przycisku: `disabled={!selectedStatus || (selectedStatus === 'FAILED' && !bugId)}`
- Zielony panel gdy błąd zgłoszony
- Czerwony panel gdy brak błędu przy FAILED

## Korzyści

✅ **Jasny przepływ** - Użytkownik wie co musi zrobić
✅ **Walidacja** - Niemożliwe zakończenie FAILED bez błędu
✅ **Informacje zwrotne** - Panele pokazują status zgłoszenia
✅ **UX** - Przycisk nieaktywny gdy nie można zakończyć
✅ **Spójność danych** - Każdy FAILED ma powiązany błąd

## Data naprawy
2026-05-17

## Status
✅ Naprawione - Test można teraz dokończyć poprawnie
