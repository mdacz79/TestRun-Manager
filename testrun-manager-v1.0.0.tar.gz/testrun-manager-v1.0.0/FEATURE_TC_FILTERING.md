# Feature - Filtrowanie przypadków testowych

## Opis
Dodano zaawansowane filtrowanie przypadków testowych po:
1. **Tekście** - ID TC, tytuł, opis
2. **Tagach** - wybór wielu tagów (TC musi mieć wszystkie wybrane)
3. **ID wymagania** - wyszukiwanie po requirement_id

## Implementacja

### 1. Nowe stany filtrów

```typescript
// Filtry
const [filterText, setFilterText] = useState('');
const [filterTags, setFilterTags] = useState<number[]>([]);
const [filterRequirement, setFilterRequirement] = useState('');
const [tagsList, setTagsList] = useState<any[]>([]);
```

### 2. Funkcja filtrowania

```typescript
const filterSpecifications = (specs: any[]): any[] => {
  return specs.filter(spec => {
    // Filtr tekstowy (ID, tytuł, opis)
    if (filterText) {
      const searchText = filterText.toLowerCase();
      const matchesText = 
        spec.test_case_id?.toLowerCase().includes(searchText) ||
        spec.title?.toLowerCase().includes(searchText) ||
        spec.description?.toLowerCase().includes(searchText);
      if (!matchesText) return false;
    }

    // Filtr po tagach (TC musi mieć WSZYSTKIE wybrane tagi)
    if (filterTags.length > 0) {
      const specTagIds = spec.tags?.map((t: any) => t.id) || [];
      const hasAllTags = filterTags.every(tagId => specTagIds.includes(tagId));
      if (!hasAllTags) return false;
    }

    // Filtr po ID wymagania
    if (filterRequirement) {
      const searchReq = filterRequirement.toLowerCase();
      const hasRequirement = spec.requirements?.some((req: any) => 
        req.requirement_id?.toLowerCase().includes(searchReq)
      );
      if (!hasRequirement) return false;
    }

    return true;
  });
};
```

### 3. Integracja z listą TC

```typescript
const getSpecsBySuite = (suiteId: number | null) => {
  const specsInSuite = specificationsList.filter(spec => 
    suiteId === null ? !spec.test_suite_id : spec.test_suite_id === suiteId
  );
  return filterSpecifications(specsInSuite); // Zastosuj filtry
};
```

### 4. UI filtrów

```tsx
<div className="bg-white shadow rounded-lg p-4">
  <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
    {/* Filtr tekstowy */}
    <input
      type="text"
      value={filterText}
      onChange={(e) => setFilterText(e.target.value)}
      placeholder="Wpisz tekst do wyszukania..."
    />

    {/* Filtr po tagach */}
    <select
      multiple
      value={filterTags.map(String)}
      onChange={(e) => {
        const selected = Array.from(e.target.selectedOptions, option => Number(option.value));
        setFilterTags(selected);
      }}
      size={3}
    >
      {tagsList.map(tag => (
        <option key={tag.id} value={tag.id}>{tag.name}</option>
      ))}
    </select>

    {/* Filtr po ID wymagania */}
    <input
      type="text"
      value={filterRequirement}
      onChange={(e) => setFilterRequirement(e.target.value)}
      placeholder="np. WYM-001"
    />
  </div>

  {/* Przycisk czyszczenia */}
  <button onClick={() => {
    setFilterText('');
    setFilterTags([]);
    setFilterRequirement('');
  }}>
    Wyczyść filtry
  </button>
</div>
```

## Przykłady użycia

### Scenariusz 1: Wyszukiwanie po tekście

**Filtr:**
```
Tekst: "login"
```

**Rezultat:**
- TC z ID zawierającym "login" (np. PT1-LOGIN-001)
- TC z tytułem zawierającym "login" (np. "Test logowania")
- TC z opisem zawierającym "login" (np. "Sprawdzenie procesu login")

**Przykład:**
```
✅ PT1-001 "Test logowania" - wyświetlony
✅ PT1-002 "Login użytkownika" - wyświetlony
❌ PT1-003 "Test rejestracji" - ukryty
```

### Scenariusz 2: Filtrowanie po tagach

**Filtr:**
```
Tagi: [Backend, API]
```

**Rezultat:**
- TC musi mieć **oba** tagi: Backend **i** API
- TC z tylko jednym tagiem są ukryte

**Przykład:**
```
✅ TC z tagami: [Backend, API, Database] - wyświetlony (ma oba)
❌ TC z tagami: [Backend] - ukryty (brak API)
❌ TC z tagami: [API] - ukryty (brak Backend)
❌ TC z tagami: [Frontend] - ukryty (brak obu)
```

### Scenariusz 3: Filtrowanie po wymaganiu

**Filtr:**
```
ID wymagania: "WYM-001"
```

**Rezultat:**
- TC powiązane z wymaganiem WYM-001
- TC bez tego wymagania są ukryte

**Przykład:**
```
✅ TC z wymaganiami: [WYM-001, WYM-002] - wyświetlony
✅ TC z wymaganiami: [WYM-001] - wyświetlony
❌ TC z wymaganiami: [WYM-002] - ukryty
❌ TC bez wymagań - ukryty
```

### Scenariusz 4: Kombinacja filtrów (AND)

**Filtry:**
```
Tekst: "test"
Tagi: [Backend]
ID wymagania: "WYM-001"
```

**Rezultat:**
- TC musi spełniać **wszystkie** warunki:
  - Zawiera "test" w ID/tytule/opisie **AND**
  - Ma tag "Backend" **AND**
  - Powiązany z WYM-001

**Przykład:**
```
✅ PT1-001 "Test API" [Backend] [WYM-001] - wyświetlony (spełnia wszystko)
❌ PT1-002 "Test API" [Frontend] [WYM-001] - ukryty (brak tagu Backend)
❌ PT1-003 "Test API" [Backend] [WYM-002] - ukryty (brak WYM-001)
❌ PT1-004 "Login" [Backend] [WYM-001] - ukryty (brak "test" w tekście)
```

## Logika filtrowania

### Filtr tekstowy (OR):
```
ID zawiera "login" OR tytuł zawiera "login" OR opis zawiera "login"
```

### Filtr tagów (AND):
```
TC ma tag1 AND TC ma tag2 AND TC ma tag3
```

### Filtr wymagania (OR):
```
Wymaganie1 zawiera "WYM-001" OR Wymaganie2 zawiera "WYM-001"
```

### Wszystkie filtry (AND):
```
(Filtr tekstowy) AND (Filtr tagów) AND (Filtr wymagania)
```

## UI - Szczegóły

### Filtr tekstowy:
- **Typ:** Input text
- **Placeholder:** "Wpisz tekst do wyszukania..."
- **Wyszukuje w:** ID TC, tytuł, opis
- **Case-insensitive:** Tak (wielkość liter nie ma znaczenia)

### Filtr tagów:
- **Typ:** Select multiple
- **Rozmiar:** 3 wiersze
- **Wybór:** Ctrl+klik (wielokrotny)
- **Logika:** AND (wszystkie wybrane tagi muszą być w TC)
- **Podpowiedź:** "Ctrl+klik aby wybrać wiele"

### Filtr wymagania:
- **Typ:** Input text
- **Placeholder:** "np. WYM-001"
- **Wyszukuje w:** requirement_id
- **Częściowe dopasowanie:** Tak (np. "WYM" znajdzie "WYM-001", "WYM-002")

### Przycisk czyszczenia:
- **Widoczność:** Tylko gdy jakiś filtr jest aktywny
- **Akcja:** Czyści wszystkie filtry jednocześnie
- **Pozycja:** Prawy dolny róg sekcji filtrów

## Responsywność

### Desktop (md i większe):
```
[Filtr tekstowy] [Filtr tagów] [Filtr wymagania]
```

### Mobile (mniejsze niż md):
```
[Filtr tekstowy]
[Filtr tagów]
[Filtr wymagania]
```

## Wydajność

### Optymalizacja:
- Filtrowanie działa na już przefiltrowanej liście (po zestawie)
- Nie ma dodatkowych zapytań do API
- Filtrowanie w czasie rzeczywistym (onChange)

### Liczba operacji:
```
Dla 100 TC i 3 filtrów:
- Maksymalnie 100 iteracji
- Każda iteracja: 3 sprawdzenia (tekst, tagi, wymaganie)
- Szybkie (< 1ms)
```

## Zachowanie zestawów

### Puste zestawy:
- Jeśli wszystkie TC w zestawie są odfiltrowane → zestaw nadal widoczny
- Można rozwinąć zestaw i zobaczyć że jest pusty

### Liczniki:
- Licznik TC w zestawie pokazuje **wszystkie** TC (nie tylko przefiltrowane)
- Można dodać licznik przefiltrowanych TC w przyszłości

## Przykład użycia krok po kroku

### 1. Wyszukaj TC z "login":
```
Wpisz "login" w polu tekstowym
→ Widoczne tylko TC z "login" w ID/tytule/opisie
```

### 2. Dodaj filtr po tagu "Backend":
```
Ctrl+klik na "Backend" w liście tagów
→ Widoczne tylko TC z "login" ORAZ tagiem "Backend"
```

### 3. Dodaj filtr po wymaganiu "WYM-001":
```
Wpisz "WYM-001" w polu wymagania
→ Widoczne tylko TC z "login" ORAZ tagiem "Backend" ORAZ wymaganiem "WYM-001"
```

### 4. Wyczyść filtry:
```
Kliknij "Wyczyść filtry"
→ Wszystkie TC widoczne ponownie
```

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Dodanie stanów filtrów
  - Funkcja `filterSpecifications`
  - Integracja z `getSpecsBySuite`
  - UI filtrów
  - Ładowanie tagsList w `loadData`

## Możliwe rozszerzenia (przyszłość)

1. **Filtr po priorytecie** (Wysoki/Średni/Niski)
2. **Filtr po statusie** (Szkic/Zatwierdzony/...)
3. **Filtr po zestawie** (dropdown z zestawami)
4. **Filtr po dacie utworzenia** (zakres dat)
5. **Zapisywanie filtrów** (localStorage)
6. **Licznik przefiltrowanych TC** ("Wyświetlono 5 z 20 TC")
7. **Filtr tagów OR** (przełącznik AND/OR)

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
