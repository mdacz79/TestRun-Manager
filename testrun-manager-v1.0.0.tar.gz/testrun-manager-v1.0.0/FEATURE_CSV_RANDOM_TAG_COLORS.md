# Feature - Losowe kolory tagów i obsługa pustych wymagań w imporcie CSV

## Opis
Podczas importu przypadków testowych z CSV:
1. **Nowe tagi** są tworzone z **losowym kolorem** z palety 10 kolorów
2. **Brak wymagań** w CSV → TC tworzony z **pustym polem wymagań** (pusta tablica)

## Implementacja

### 1. Losowe kolory dla nowych tagów

#### Przed:
```typescript
// Stały kolor dla wszystkich nowych tagów
const newTagRes = await tagsApi.create({
  name: tagName,
  color: '#3B82F6', // Zawsze niebieski
  project_id: selectedProject!.id
});
```

**Problem:** Wszystkie nowe tagi miały ten sam niebieski kolor.

#### Po:
```typescript
// Paleta 10 kolorów
const colorPalette = [
  '#3B82F6', // Niebieski
  '#10B981', // Zielony
  '#EF4444', // Czerwony
  '#F59E0B', // Pomarańczowy
  '#8B5CF6', // Fioletowy
  '#EC4899', // Różowy
  '#6366F1', // Indygo
  '#F97316', // Pomarańczowy ciemny
  '#14B8A6', // Turkusowy
  '#6B7280'  // Szary
];

// Losowy kolor dla każdego nowego tagu
const randomColor = colorPalette[Math.floor(Math.random() * colorPalette.length)];
const newTagRes = await tagsApi.create({
  name: tagName,
  color: randomColor,
  project_id: selectedProject!.id
});
```

**Rozwiązanie:** Każdy nowy tag otrzymuje losowy kolor z palety.

### 2. Obsługa pustych wymagań

#### Przed:
```typescript
// Zawsze filtruj wymagania
const requirementIds = tc.requirements
  .map(reqId => {
    const req = projectReqs.find(r => r.requirement_id === reqId);
    return req?.id;
  })
  .filter(id => id !== undefined);
```

**Problem:** Kod działał tak samo dla pustych wymagań i nieistniejących.

#### Po:
```typescript
// Jeśli brak wymagań w CSV -> pusta tablica
// Jeśli wymaganie nie istnieje -> pomijane (filtrowane)
const requirementIds = tc.requirements.length > 0
  ? tc.requirements
      .map(reqId => {
        const req = projectReqs.find(r => r.requirement_id === reqId);
        return req?.id;
      })
      .filter(id => id !== undefined)
  : []; // Pusta tablica jeśli brak wymagań w CSV
```

**Rozwiązanie:** Jawne rozróżnienie między brakiem wymagań a nieistniejącymi wymaganiami.

## Paleta kolorów

### 10 kolorów dla tagów:

| Kolor | Hex | Nazwa |
|-------|-----|-------|
| 🔵 | `#3B82F6` | Niebieski |
| 🟢 | `#10B981` | Zielony |
| 🔴 | `#EF4444` | Czerwony |
| 🟠 | `#F59E0B` | Pomarańczowy |
| 🟣 | `#8B5CF6` | Fioletowy |
| 🌸 | `#EC4899` | Różowy |
| 🔷 | `#6366F1` | Indygo |
| 🟧 | `#F97316` | Pomarańczowy ciemny |
| 🔷 | `#14B8A6` | Turkusowy |
| ⚫ | `#6B7280` | Szary |

### Losowanie:
```javascript
Math.floor(Math.random() * 10) // 0-9
colorPalette[randomIndex]
```

## Scenariusze użycia

### Scenariusz 1: Import z nowymi tagami

**CSV:**
```csv
ID TC,Tytuł,...,Tagi
PT1-001,Test 1,...,Backend
PT1-002,Test 2,...,Frontend
PT1-003,Test 3,...,API
```

**Rezultat:**
- Tag "Backend" → utworzony z losowym kolorem (np. 🔵 niebieski)
- Tag "Frontend" → utworzony z losowym kolorem (np. 🟢 zielony)
- Tag "API" → utworzony z losowym kolorem (np. 🔴 czerwony)

**Komunikat:**
```
✅ Utworzono 3 nowych przypadków testowych
```

### Scenariusz 2: Import bez wymagań

**CSV:**
```csv
ID TC,Tytuł,...,Powiązane wymagania,...
PT1-004,Test 4,...,,...  ← puste pole
PT1-005,Test 5,...,,...  ← puste pole
```

**Rezultat:**
- TC PT1-004 → utworzony **bez wymagań** (pusta tablica)
- TC PT1-005 → utworzony **bez wymagań** (pusta tablica)

**Dane w bazie:**
```javascript
{
  test_case_id: 'PT1-004',
  requirements: []  // Pusta tablica
}
```

### Scenariusz 3: Import z nieistniejącymi wymaganiami

**CSV:**
```csv
ID TC,Tytuł,...,Powiązane wymagania,...
PT1-006,Test 6,...,"WYM-001, WYM-999",...
```

**Rezultat:**
- WYM-001 istnieje → dodane do TC
- WYM-999 nie istnieje → **pominięte**
- TC PT1-006 → utworzony z 1 wymaganiem (tylko WYM-001)

**Dane w bazie:**
```javascript
{
  test_case_id: 'PT1-006',
  requirements: [{ id: 1, requirement_id: 'WYM-001', ... }]
}
```

### Scenariusz 4: Mix tagów (istniejące + nowe)

**CSV:**
```csv
ID TC,Tytuł,...,Tagi
PT1-007,Test 7,...,"Backend, Database"
```

**Przed importem:**
- Tag "Backend" istnieje (kolor: 🔵)

**Po imporcie:**
- Tag "Backend" → użyty istniejący (kolor: 🔵)
- Tag "Database" → utworzony nowy (losowy kolor, np. 🟣)

**Rezultat:**
- TC ma 2 tagi: Backend (🔵), Database (🟣)

## Różnice w obsłudze

### Tagi vs Wymagania vs Zestawy:

| Element | Jeśli nie istnieje | Jeśli puste pole w CSV |
|---------|-------------------|------------------------|
| **Tagi** | ✅ Tworzony z losowym kolorem | Pusta tablica |
| **Zestawy** | ✅ Tworzony automatycznie | TC bez zestawu |
| **Wymagania** | ❌ Pomijane | Pusta tablica |

### Podsumowanie automatycznego tworzenia:

| Element | Tworzony automatycznie? | Kolor/Właściwości |
|---------|------------------------|-------------------|
| Tagi | ✅ TAK | **Losowy kolor** z palety 10 kolorów |
| Zestawy | ✅ TAK | Opis: "Automatycznie utworzony..." |
| Wymagania | ❌ NIE | - |

## Przykład importu z wszystkim

**CSV:**
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-010,Test API,Opis,Warunki,1,Akcja,Rezultat,Wysoki,Szkic,API Tests,WYM-001,"Backend, API, Database"
PT1-011,Test UI,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,UI Tests,,"Frontend, UI"
PT1-012,Test bez niczego,Opis,Warunki,1,Akcja,Rezultat,Niski,Szkic,,,
```

**Przed importem:**
- Zestawy: Logowanie
- Tagi: Backend (🔵)
- Wymagania: WYM-001

**Po imporcie:**
- **Zestawy:** Logowanie, API Tests, UI Tests
- **Tagi:** Backend (🔵), API (🟢), Database (🔴), Frontend (🟠), UI (🟣)
- **TC PT1-010:** zestaw "API Tests", wymaganie WYM-001, tagi: Backend, API, Database
- **TC PT1-011:** zestaw "UI Tests", brak wymagań, tagi: Frontend, UI
- **TC PT1-012:** brak zestawu, brak wymagań, brak tagów

**Komunikaty:**
```
✅ Utworzono 3 nowych przypadków testowych
📁 Utworzono 2 nowych zestawów testowych
```

## Wizualizacja kolorów tagów

Po imporcie tagi będą wyglądać różnorodnie:

```
[Backend 🔵] [API 🟢] [Database 🔴] [Frontend 🟠] [UI 🟣]
```

Zamiast monotonnie:

```
[Backend 🔵] [API 🔵] [Database 🔵] [Frontend 🔵] [UI 🔵]
```

## Edycja po imporcie

### Tagi:
- Możesz zmienić kolor tagu w Admin Panel → Zarządzanie tagami
- Zmiana koloru wpłynie na wszystkie TC używające tego tagu

### Wymagania:
- Możesz dodać wymagania ręcznie po imporcie
- Edytuj TC i wybierz wymagania z listy

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Paleta 10 kolorów dla tagów
  - Losowanie koloru dla nowych tagów
  - Jawna obsługa pustych wymagań

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
