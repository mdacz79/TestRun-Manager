# Bugfix - lastID vs lastInsertRowid w Database Wrapper

## Problem

Błąd "Internal server error" przy dodawaniu przypadków testowych do planu testów:
```
POST http://localhost:3000/api/test-plans/2/cases
Response: { "error": "Internal server error" }
```

## Przyczyna

W kodzie używano `result.lastID`, ale funkcja `run()` w `database.ts` zwraca obiekt z polem `lastInsertRowid`:

```typescript
// database.ts - funkcja run()
function run(sql: string, params: any[] = []): any {
  // ...
  return {
    lastInsertRowid: lastId  // ← Zwraca lastInsertRowid
  };
}

// routes - błędne użycie
const result = db.prepare('INSERT ...').run(...);
const newItem = db.prepare('SELECT ...').get(result.lastID); // ← Błąd! Powinno być lastInsertRowid
```

## Rozwiązanie

Zmieniono wszystkie wystąpienia `result.lastID` na `result.lastInsertRowid`.

## Naprawione Pliki

### 1. test-plans.ts (2 miejsca)

**Linia 85 - Tworzenie planu testów:**
```typescript
// PRZED:
const newPlan = db.prepare('SELECT * FROM test_plans WHERE id = ?').get(result.lastID);

// PO:
const newPlan = db.prepare('SELECT * FROM test_plans WHERE id = ?').get(result.lastInsertRowid);
```

**Linia 164 - Dodawanie przypadku do planu:**
```typescript
// PRZED:
const newCase = db.prepare(`
  SELECT tpc.*, ts.test_case_id, ts.title, u.name as assigned_to_name
  FROM test_plan_cases tpc
  JOIN test_specifications ts ON tpc.test_specification_id = ts.id
  LEFT JOIN users u ON tpc.assigned_to = u.id
  WHERE tpc.id = ?
`).get(result.lastID);

// PO:
const newCase = db.prepare(`
  SELECT tpc.*, ts.test_case_id, ts.title, u.name as assigned_to_name
  FROM test_plan_cases tpc
  JOIN test_specifications ts ON tpc.test_specification_id = ts.id
  LEFT JOIN users u ON tpc.assigned_to = u.id
  WHERE tpc.id = ?
`).get(result.lastInsertRowid);
```

### 2. bugs.ts (1 miejsce)

**Linia 96 - Tworzenie błędu:**
```typescript
// PRZED:
const newBug = db.prepare('SELECT * FROM bugs WHERE id = ?').get(result.lastID);

// PO:
const newBug = db.prepare('SELECT * FROM bugs WHERE id = ?').get(result.lastInsertRowid);
```

### 3. test-executions.ts (1 miejsce)

**Linia 32 - Rozpoczynanie wykonania testu:**
```typescript
// PRZED:
const execution = db.prepare('SELECT * FROM test_executions WHERE id = ?').get(result.lastID);

// PO:
const execution = db.prepare('SELECT * FROM test_executions WHERE id = ?').get(result.lastInsertRowid);
```

## Testowanie

### Test 1: Dodawanie przypadku do planu
```bash
POST http://localhost:3000/api/test-plans/2/cases
Body: {
  "test_specification_id": 5,
  "assigned_to": 1
}

Oczekiwany rezultat: 201 Created
{
  "id": 1,
  "test_plan_id": 2,
  "test_specification_id": 5,
  "assigned_to": 1,
  "status": "NOT_RUN",
  "test_case_id": "PT1-001",
  "title": "Test logowania",
  "assigned_to_name": "Jan Kowalski"
}
```

### Test 2: Tworzenie planu testów
```bash
POST http://localhost:3000/api/test-plans
Body: {
  "name": "Sprint 1",
  "description": "Testy funkcjonalne",
  "project_id": 1
}

Oczekiwany rezultat: 201 Created
{
  "id": 3,
  "name": "Sprint 1",
  "description": "Testy funkcjonalne",
  "project_id": 1,
  "created_by": 1,
  "created_at": "2026-05-17T14:25:00.000Z"
}
```

### Test 3: Zgłaszanie błędu
```bash
POST http://localhost:3000/api/bugs
Body: {
  "title": "Błąd walidacji",
  "description": "Email nie jest walidowany",
  "severity": "high",
  "project_id": 1
}

Oczekiwany rezultat: 201 Created
{
  "id": 1,
  "bug_id": "BUG-0001",
  "title": "Błąd walidacji",
  "description": "Email nie jest walidowany",
  "severity": "high",
  "status": "open",
  "project_id": 1,
  "reported_by": 1
}
```

### Test 4: Rozpoczynanie testu
```bash
POST http://localhost:3000/api/test-executions/start
Body: {
  "test_plan_case_id": 1
}

Oczekiwany rezultat: 201 Created
{
  "id": 1,
  "test_plan_case_id": 1,
  "executed_by": 1,
  "status": "IN_PROGRESS",
  "started_at": "2026-05-17T14:30:00.000Z"
}
```

## Dlaczego to się stało?

Database wrapper w `database.ts` używa biblioteki `sql.js`, która ma inną konwencję nazewnictwa niż standardowy SQLite:

- **SQLite (natywny):** `lastID`
- **sql.js:** `lastInsertRowid`

Wrapper został napisany z użyciem `lastInsertRowid`, ale w routes używano `lastID` (prawdopodobnie z przyzwyczajenia do natywnego SQLite).

## Zapobieganie w przyszłości

### 1. Dokumentacja w database.ts
Dodaj komentarz w funkcji `run()`:
```typescript
function run(sql: string, params: any[] = []): any {
  // ...
  return {
    lastInsertRowid: lastId  // UWAGA: Używaj lastInsertRowid, NIE lastID!
  };
}
```

### 2. TypeScript Interface
Zdefiniuj interface dla wyniku:
```typescript
interface RunResult {
  lastInsertRowid: number;
}

function run(sql: string, params: any[] = []): RunResult {
  // ...
}
```

### 3. Grep Check
Przed commitem sprawdź:
```bash
grep -r "\.lastID" backend/src/routes/
# Powinno zwrócić 0 wyników
```

## Pliki zmienione
- `/backend/src/routes/test-plans.ts` (2 zmiany)
- `/backend/src/routes/bugs.ts` (1 zmiana)
- `/backend/src/routes/test-executions.ts` (1 zmiana)

## Data naprawy
2026-05-17

## Status
✅ Naprawione - Wszystkie wystąpienia lastID zmienione na lastInsertRowid
