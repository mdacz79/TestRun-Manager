# Eksport i Import CSV

## Funkcjonalności

### Import przypadków testowych z CSV
- Przycisk **"Importuj CSV"** w prawym górnym rogu strony Specyfikacja testowa
- Importuje przypadki testowe z pliku CSV (kompatybilny z eksportem)
- Automatycznie grupuje kroki testowe według ID TC
- Automatycznie tworzy nowe tagi jeśli nie istnieją
- Pomija duplikaty (TC o tym samym ID)
- Wyświetla podsumowanie importu (zaimportowane, pominięte, błędy)

### Wymagania

#### 1. Eksport wszystkich wymagań
- Przycisk **"Eksportuj CSV"** w prawym górnym rogu strony Wymagania
- Eksportuje wszystkie wymagania z projektu do jednego pliku CSV
- Nazwa pliku: `wymagania_[nazwa_projektu]_[data].csv`

#### 2. Eksport pojedynczego wymagania
- Przycisk **Download** (zielona ikona) w kolumnie Akcje dla każdego wymagania
- Eksportuje tylko wybrane wymaganie
- Nazwa pliku: `wymaganie_[ID_wymagania].csv`

### Przypadki testowe

#### 1. Eksport wszystkich przypadków testowych
- Przycisk **"Eksportuj CSV"** w prawym górnym rogu strony Specyfikacja testowa
- Eksportuje wszystkie przypadki testowe z projektu do jednego pliku CSV
- Uwzględnia zestawy testowe w kolumnie "Zestaw testowy"
- Nazwa pliku: `tc_[nazwa_projektu]_[data].csv`

#### 2. Eksport pojedynczego przypadku testowego
- Przycisk **Download** (zielona ikona) w kolumnie Akcje dla każdego przypadku testowego
- Eksportuje tylko wybrany przypadek testowy
- Nazwa pliku: `tc_[ID_TC].csv`

## Format CSV

### Format dla wymagań:
1. **ID Wymagania** - unikalny identyfikator wymagania
2. **Tytuł** - nazwa wymagania
3. **Opis** - pełny opis (HTML zostaje usunięty)
4. **Priorytet** - Wysoki/Średni/Niski
5. **Status** - Szkic/Zatwierdzony/Odrzucony
6. **Zestaw** - nazwa zestawu wymagań lub "Bez zestawu"
7. **Tagi** - lista tagów oddzielonych przecinkami
8. **Liczba TC** - liczba powiązanych przypadków testowych
9. **Data utworzenia** - data utworzenia wymagania

### Format dla przypadków testowych:
**UWAGA:** Każdy przypadek testowy jest powielany dla każdego kroku - każdy krok w osobnym wierszu CSV!

1. **ID TC** - unikalny identyfikator przypadku testowego (powtarzany dla każdego kroku)
2. **Tytuł** - nazwa przypadku testowego (powtarzany dla każdego kroku)
3. **Opis** - pełny opis (HTML zostaje usunięty, powtarzany dla każdego kroku)
4. **Warunki wstępne** - preconditions (HTML zostaje usunięty, powtarzany dla każdego kroku)
5. **Numer kroku** - numer kroku (1, 2, 3, ...)
6. **Akcja** - akcja do wykonania w danym kroku
7. **Oczekiwany rezultat** - oczekiwany rezultat dla danego kroku
8. **Priorytet** - Wysoki/Średni/Niski (powtarzany dla każdego kroku)
9. **Status** - Szkic/Zatwierdzony/Odrzucony/Zaliczony/Niezaliczony/Zablokowany/Niewykonany (powtarzany dla każdego kroku)
10. **Zestaw testowy** - nazwa zestawu testowego lub "Bez zestawu" (powtarzany dla każdego kroku)
11. **Powiązane wymagania** - lista ID wymagań oddzielonych przecinkami (powtarzany dla każdego kroku)
12. **Tagi** - lista tagów oddzielonych przecinkami (powtarzany dla każdego kroku)
13. **Data utworzenia** - data utworzenia przypadku testowego (powtarzany dla każdego kroku)

## Kompatybilność

- Plik CSV zawiera BOM (Byte Order Mark) dla poprawnego wyświetlania polskich znaków w Microsoft Excel
- Format zgodny z Excel, Google Sheets, LibreOffice Calc
- Kodowanie: UTF-8 z BOM
- Separator: przecinek (,)
- Wartości zawierające przecinki lub cudzysłowy są automatycznie escapowane

## Przykład użycia

### Import przypadków testowych:
1. Otwórz stronę **Specyfikacja testowa**
2. Kliknij przycisk **"Importuj CSV"** w prawym górnym rogu
3. Wybierz plik CSV z przypadkami testowymi
4. Poczekaj na zakończenie importu
5. Sprawdź podsumowanie:
   - ✅ Liczba zaimportowanych TC
   - ℹ️ Liczba pominiętych TC (duplikaty)
   - ❌ Liczba błędów (jeśli wystąpiły)
6. Zaimportowane TC pojawią się na liście

**Uwagi dotyczące importu:**
- TC z tym samym ID co istniejące są pomijane
- Tagi które nie istnieją są tworzone automatycznie (z domyślnym kolorem)
- Zestawy testowe muszą istnieć przed importem (TC bez zestawu jeśli nie znajdzie)
- Wymagania muszą istnieć przed importem (powiązanie pomijane jeśli nie znajdzie)

### Eksport wymagań:
1. Otwórz stronę **Wymagania**
2. Aby wyeksportować wszystkie wymagania:
   - Kliknij przycisk **"Eksportuj CSV"** w prawym górnym rogu
   - Plik zostanie automatycznie pobrany
3. Aby wyeksportować pojedyncze wymaganie:
   - Znajdź wymaganie w tabeli
   - Kliknij zieloną ikonę **Download** w kolumnie Akcje
   - Plik zostanie automatycznie pobrany

### Eksport przypadków testowych:
1. Otwórz stronę **Specyfikacja testowa**
2. Aby wyeksportować wszystkie przypadki testowe:
   - Kliknij przycisk **"Eksportuj CSV"** w prawym górnym rogu
   - Plik zostanie automatycznie pobrany (uwzględnia wszystkie TC z zestawów i bez zestawów)
3. Aby wyeksportować pojedynczy przypadek testowy:
   - Znajdź przypadek testowy w tabeli (w zestawie lub sekcji "Bez zestawu")
   - Kliknij zieloną ikonę **Download** w kolumnie Akcje
   - Plik zostanie automatycznie pobrany

## Przykład CSV dla TC z krokami

Jeśli przypadek testowy ma 3 kroki, zostanie wyeksportowany jako 3 wiersze:

```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi,Data utworzenia
TC-001,Test logowania,Sprawdzenie logowania,Użytkownik niezalogowany,1,Otwórz stronę logowania,Strona logowania wyświetlona,Wysoki,Zatwierdzony,Moduł Auth,REQ-001,Backend,14.05.2026
TC-001,Test logowania,Sprawdzenie logowania,Użytkownik niezalogowany,2,Wprowadź login i hasło,Dane wprowadzone,Wysoki,Zatwierdzony,Moduł Auth,REQ-001,Backend,14.05.2026
TC-001,Test logowania,Sprawdzenie logowania,Użytkownik niezalogowany,3,Kliknij Zaloguj,Użytkownik zalogowany,Wysoki,Zatwierdzony,Moduł Auth,REQ-001,Backend,14.05.2026
```

## Uwagi

- Przycisk "Eksportuj CSV" jest nieaktywny gdy nie ma żadnych elementów w projekcie
- Wszystkie pola HTML (opis, warunki wstępne, akcje, oczekiwane rezultaty) są automatycznie czyszczone z tagów HTML
- Wszystkie wartości są prawidłowo escapowane dla bezpiecznego importu
- Eksport uwzględnia strukturę zestawów (wymagań i testowych) w dedykowanej kolumnie
- Tagi i powiązane elementy są eksportowane jako listy oddzielone przecinkami
- **Każdy przypadek testowy jest powielany dla każdego kroku** - ułatwia to analizę kroków w Excel/Sheets (filtrowanie, sortowanie)
- Jeśli TC nie ma kroków, zostanie wyeksportowany jako jeden wiersz z pustymi polami kroków
