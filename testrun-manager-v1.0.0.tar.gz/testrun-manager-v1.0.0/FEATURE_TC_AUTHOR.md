# Feature - Wyświetlanie autora przypadku testowego

## Opis
Dodano wyświetlanie informacji o autorze (twórcy) przypadku testowego w:
1. **Liście TC** - pod tagami
2. **Modalu podglądu** - osobna sekcja
3. **Eksporcie CSV** - nowa kolumna "Autor"

## Implementacja

### 1. Backend (już istniejące)

**Baza danych:**
```sql
CREATE TABLE test_specifications (
  ...
  created_by INTEGER NOT NULL,
  FOREIGN KEY (created_by) REFERENCES users(id)
);
```

**API - pobieranie danych:**
```typescript
const specifications = db.prepare(`
  SELECT ts.*, u.name as created_by_name, tsuite.name as test_suite_name
  FROM test_specifications ts
  LEFT JOIN users u ON ts.created_by = u.id
  LEFT JOIN test_suites tsuite ON ts.test_suite_id = tsuite.id
  WHERE ts.project_id = ?
`).all(project_id);
```

Backend już zwracał `created_by_name` - wystarczyło wyświetlić to na frontendzie.

### 2. Frontend - Lista TC

**Lokalizacja:** Pod tagami w każdym wierszu TC

```tsx
{spec.created_by_name && (
  <div className="flex items-center gap-1 mt-1" style={{ paddingLeft: `${paddingLeft}px` }}>
    <span className="text-xs text-gray-500">Autor:</span>
    <span className="text-xs text-gray-700 font-medium">{spec.created_by_name}</span>
  </div>
)}
```

**Wygląd:**
```
PT1-001 Test logowania
Wymagania: WYM-001
Tagi: Backend API
Autor: Jan Kowalski  ← NOWE
```

### 3. Frontend - Modal podglądu

**Lokalizacja:** Po tagach, przed priorytetem i statusem

```tsx
<div>
  <label className="block text-sm font-medium text-gray-700 mb-1">
    Autor
  </label>
  <div className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
    {viewSpec.created_by_name || 'Nieznany'}
  </div>
</div>
```

**Wygląd:**
```
┌─────────────────────────────────┐
│ Tagi                            │
│ [Backend] [API]                 │
├─────────────────────────────────┤
│ Autor                           │
│ Jan Kowalski          ← NOWE    │
├─────────────────────────────────┤
│ Priorytet    │ Status           │
│ Wysoki       │ Zatwierdzony     │
└─────────────────────────────────┘
```

### 4. Eksport CSV

**Nowa kolumna:** "Autor" (przed "Data utworzenia")

**Nagłówki CSV:**
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi,Autor,Data utworzenia
```

**Wartość:**
```typescript
escapeCSV(spec.created_by_name || '')
```

**Przykład wiersza:**
```csv
PT1-001,Test logowania,Opis,Warunki,1,Akcja,Rezultat,Wysoki,Szkic,Logowanie,WYM-001,Backend,Jan Kowalski,14.05.2026
```

## Przykłady użycia

### Scenariusz 1: Przeglądanie listy TC

**Widok:**
```
┌─────────────────────────────────────────────────────────┐
│ PT1-001 Test logowania                                  │
│ Wymagania: WYM-001                                      │
│ Tagi: Backend API                                       │
│ Autor: Jan Kowalski                                     │
├─────────────────────────────────────────────────────────┤
│ PT1-002 Test rejestracji                                │
│ Wymagania: WYM-002                                      │
│ Tagi: Frontend                                          │
│ Autor: Anna Nowak                                       │
└─────────────────────────────────────────────────────────┘
```

**Korzyść:** Szybko widać kto stworzył dany TC.

### Scenariusz 2: Podgląd szczegółów TC

**Akcja:** Kliknij ikonę oka przy TC

**Modal:**
```
┌─────────────────────────────────────────┐
│ Podgląd przypadku testowego        [X] │
├─────────────────────────────────────────┤
│ ID TC: PT1-001                          │
│ Tytuł: Test logowania                   │
│ Opis: Sprawdzenie procesu logowania     │
│ ...                                     │
│ Tagi: [Backend] [API]                   │
│ Autor: Jan Kowalski         ← NOWE      │
│ Priorytet: Wysoki                       │
│ Status: Zatwierdzony                    │
└─────────────────────────────────────────┘
```

**Korzyść:** Pełna informacja o autorze w jednym miejscu.

### Scenariusz 3: Eksport do CSV

**Akcja:** Kliknij "Eksportuj CSV"

**Plik CSV:**
```csv
ID TC,Tytuł,...,Tagi,Autor,Data utworzenia
PT1-001,Test logowania,...,Backend,Jan Kowalski,14.05.2026
PT1-002,Test rejestracji,...,Frontend,Anna Nowak,14.05.2026
PT1-003,Test API,...,Backend API,Jan Kowalski,14.05.2026
```

**Korzyść:** 
- Możliwość filtrowania w Excelu po autorze
- Analiza produktywności zespołu
- Raportowanie

### Scenariusz 4: TC bez autora (stare dane)

**Jeśli `created_by_name` jest puste:**

**Lista TC:**
```
Autor: (nie wyświetla się)
```

**Modal:**
```
Autor: Nieznany
```

**CSV:**
```csv
...,Tagi,Autor,Data utworzenia
...,,14.05.2026
```

## Szczegóły implementacji

### Warunkowe wyświetlanie w liście

```tsx
{spec.created_by_name && (
  // Wyświetl tylko jeśli autor istnieje
)}
```

**Dlaczego?** Stare TC mogą nie mieć przypisanego autora.

### Fallback w modalu

```tsx
{viewSpec.created_by_name || 'Nieznany'}
```

**Dlaczego?** Modal zawsze pokazuje pole, ale z wartością "Nieznany" jeśli brak autora.

### Pusta wartość w CSV

```tsx
escapeCSV(spec.created_by_name || '')
```

**Dlaczego?** CSV eksportuje pustą komórkę jeśli brak autora.

## Stylowanie

### Lista TC:
- **Rozmiar:** `text-xs` (mały tekst)
- **Kolor etykiety:** `text-gray-500` (szary)
- **Kolor wartości:** `text-gray-700 font-medium` (ciemniejszy, pogrubiony)
- **Odstęp:** `mt-1` (margines górny)
- **Wcięcie:** Zgodne z innymi elementami (`paddingLeft`)

### Modal:
- **Etykieta:** `text-sm font-medium text-gray-700`
- **Wartość:** `text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg`
- **Tło:** Szare tło jak inne pola

## Kolejność wyświetlania

### Lista TC (od góry):
1. ID TC + Tytuł
2. Wymagania (jeśli są)
3. Tagi (jeśli są)
4. **Autor** (jeśli jest) ← NOWE

### Modal (od góry):
1. ID TC
2. Tytuł
3. Opis
4. Warunki wstępne
5. Zestaw testowy
6. Powiązane wymagania
7. Tagi
8. **Autor** ← NOWE
9. Priorytet + Status (w jednym wierszu)
10. Kroki testowe

### CSV (kolumny):
1. ID TC
2. Tytuł
3. Opis
4. Warunki wstępne
5. Numer kroku
6. Akcja
7. Oczekiwany rezultat
8. Priorytet
9. Status
10. Zestaw testowy
11. Powiązane wymagania
12. Tagi
13. **Autor** ← NOWE
14. Data utworzenia

## Import CSV

**Uwaga:** Import CSV **nie** importuje autora z pliku.

**Dlaczego?**
- Autor jest zawsze ustawiany jako zalogowany użytkownik (`created_by`)
- Nie można przypisać TC do innego użytkownika podczas importu
- Kolumna "Autor" w CSV jest tylko do odczytu (informacyjna)

**Zachowanie:**
```
CSV: Autor: Jan Kowalski
Import: created_by = [ID zalogowanego użytkownika]
Rezultat: Nowy TC ma autora = zalogowany użytkownik (nie Jan Kowalski)
```

## Korzyści

### ✅ Przejrzystość:
- Wiadomo kto stworzył dany TC
- Łatwe śledzenie odpowiedzialności

### ✅ Współpraca:
- Zespół widzi kto pracował nad którymi TC
- Łatwiejsze pytania o szczegóły

### ✅ Raportowanie:
- Eksport CSV zawiera autora
- Analiza produktywności w Excelu
- Statystyki zespołu

### ✅ Audyt:
- Historia zmian (kto stworzył)
- Zgodność z procesami jakości

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Wyświetlanie autora w liście TC (linia 708-713)
  - Wyświetlanie autora w modalu podglądu (linia 1396-1403)
  - Naprawienie błędu TypeScript (linia 376)

- `/frontend/src/utils/csvExport.ts`:
  - Dodanie kolumny "Autor" do nagłówków (linia 98)
  - Dodanie wartości autora do wierszy z krokami (linia 162)
  - Dodanie wartości autora do wierszy bez kroków (linia 181)

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
