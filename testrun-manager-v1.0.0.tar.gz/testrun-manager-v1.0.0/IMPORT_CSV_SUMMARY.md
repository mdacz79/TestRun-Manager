# Podsumowanie - Import CSV dla przypadków testowych

## ✅ Zaimplementowano

### 1. Parser CSV (`csvImport.ts`)
- ✅ Parsowanie pliku CSV z obsługą cudzysłowów i escapowania
- ✅ Grupowanie wierszy według ID TC (każdy krok w osobnym wierszu)
- ✅ Mapowanie polskich nazw na angielskie (priorytet, status)
- ✅ Walidacja danych

### 2. Funkcja importu (`TestSpecifications.tsx`)
- ✅ Odczyt pliku CSV przez FileReader
- ✅ Sprawdzanie duplikatów (po test_case_id)
- ✅ Mapowanie zestawów testowych (po nazwie)
- ✅ Mapowanie wymagań (po requirement_id)
- ✅ Automatyczne tworzenie tagów (jeśli nie istnieją)
- ✅ Tworzenie TC przez API
- ✅ Podsumowanie importu (zaimportowane/pominięte/błędy)

### 3. UI
- ✅ Przycisk "Importuj CSV" (zielony, z ikoną Upload)
- ✅ Ukryty input file (accept=".csv")
- ✅ Toast notifications z postępem i podsumowaniem

## 📊 Przepływ importu

```
1. Użytkownik kliknie "Importuj CSV"
   ↓
2. Wybiera plik CSV
   ↓
3. Parser grupuje wiersze według ID TC
   PT1-001, krok 1  ┐
   PT1-001, krok 2  ├→ Jeden TC z 2 krokami
   PT1-002, krok 1  → Drugi TC z 1 krokiem
   ↓
4. Dla każdego TC:
   - Sprawdź duplikaty (pomiń jeśli istnieje)
   - Znajdź zestaw testowy (po nazwie)
   - Znajdź wymagania (po ID)
   - Znajdź/utwórz tagi (po nazwie)
   ↓
5. Utwórz TC przez API
   ↓
6. Podsumowanie:
   ✅ Zaimportowano: 5
   ℹ️ Pominięto: 2 (duplikaty)
   ❌ Błędy: 0
```

## 🎯 Kluczowe funkcje

### Automatyczne grupowanie kroków:
```csv
PT1-001,Test,Opis,Warunki,1,Akcja 1,Rezultat 1,...
PT1-001,Test,Opis,Warunki,2,Akcja 2,Rezultat 2,...
```
↓ Grupowanie ↓
```javascript
{
  test_case_id: 'PT1-001',
  title: 'Test',
  steps: [
    { action: 'Akcja 1', expected_result: 'Rezultat 1' },
    { action: 'Akcja 2', expected_result: 'Rezultat 2' }
  ]
}
```

### Automatyczne tworzenie tagów:
```javascript
// Tag "Backend" nie istnieje
tags: ['Backend', 'API']
↓
// Utwórz nowy tag
await tagsApi.create({
  name: 'Backend',
  color: '#3B82F6',
  project_id: projectId
})
```

### Obsługa duplikatów:
```javascript
// TC PT1-001 już istnieje
if (existingTC) {
  skipped++;
  continue; // Pomiń ten TC
}
```

## 📝 Format CSV

### Wymagane kolumny:
1. ID TC
2. Tytuł
3. Opis
4. Warunki wstępne
5. Numer kroku
6. Akcja
7. Oczekiwany rezultat
8. Priorytet (Wysoki/Średni/Niski)
9. Status (Szkic/Zatwierdzony/...)
10. Zestaw testowy
11. Powiązane wymagania (oddzielone przecinkami)
12. Tagi (oddzielone przecinkami)
13. Data utworzenia

### Przykład:
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi,Data utworzenia
PT1-001,Test 1,Opis,Warunki,1,Akcja 1,Rezultat 1,Średni,Szkic,Logowanie,WYM-PT1-001,"Backend, API",14.05.2026
PT1-001,Test 1,Opis,Warunki,2,Akcja 2,Rezultat 2,Średni,Szkic,Logowanie,WYM-PT1-001,"Backend, API",14.05.2026
```

## ⚠️ Ważne uwagi

### Co jest tworzone automatycznie:
✅ **Tagi** - jeśli nie istnieją (z domyślnym kolorem #3B82F6)

### Co musi istnieć przed importem:
❌ **Zestawy testowe** - TC bez zestawu jeśli nie znajdzie
❌ **Wymagania** - powiązanie pomijane jeśli nie znajdzie

### Obsługa duplikatów:
- TC z tym samym `test_case_id` są **pomijane**
- Wyświetlany licznik pominiętych TC
- Nie nadpisuje istniejących TC

## 🔧 Pliki

### Nowe:
- `/frontend/src/utils/csvImport.ts` - parser CSV

### Zmodyfikowane:
- `/frontend/src/pages/TestSpecifications.tsx` - UI i logika importu

### Dokumentacja:
- `FEATURE_TC_CSV_IMPORT.md` - pełna dokumentacja
- `EXPORT_CSV_INFO.md` - zaktualizowano o import
- `IMPORT_CSV_SUMMARY.md` - to podsumowanie

## 🎉 Gotowe do użycia!

1. Otwórz Specyfikacja testowa
2. Kliknij "Importuj CSV" (zielony przycisk)
3. Wybierz plik CSV
4. Sprawdź podsumowanie importu
5. TC są zaimportowane!

## Data implementacji
2026-05-14
