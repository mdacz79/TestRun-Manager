# Feature - Import przypadków testowych z CSV

## Opis
Dodano możliwość importowania przypadków testowych z pliku CSV. Import obsługuje pełną strukturę TC eksportowaną przez funkcję eksportu, w tym:
- Dane podstawowe TC (tytuł, opis, warunki wstępne, priorytet, status)
- Kroki testowe (każdy krok w osobnym wierszu CSV)
- Powiązania z wymaganiami
- Tagi (automatyczne tworzenie nowych tagów)
- Zestawy testowe

## Implementacja

### 1. Parser CSV (`/frontend/src/utils/csvImport.ts`)

#### Funkcja `parseTestCasesCSV`:
- Parsuje plik CSV z przypadkami testowymi
- Grupuje wiersze według ID TC (każdy krok to osobny wiersz)
- Obsługuje wartości w cudzysłowach i escapowane przecinki
- Mapuje polskie nazwy priorytetów i statusów na angielskie

#### Struktura parsowanego TC:
```typescript
interface ParsedTestCase {
  test_case_id: string;
  title: string;
  description: string;
  preconditions: string;
  priority: string;
  status: string;
  suite_name: string;
  requirements: string[];  // ID wymagań
  tags: string[];          // Nazwy tagów
  steps: Array<{ action: string; expected_result: string }>;
}
```

#### Funkcja `parseCSVLine`:
- Obsługuje wartości w cudzysłowach
- Obsługuje podwójne cudzysłowy wewnątrz wartości
- Obsługuje przecinki w wartościach

#### Mapowanie wartości:
```typescript
// Priorytety
'Wysoki' → 'high'
'Średni' → 'medium'
'Niski' → 'low'

// Statusy
'Szkic' → 'draft'
'Zatwierdzony' → 'approved'
'Odrzucony' → 'rejected'
'Zaliczony' → 'passed'
'Niezaliczony' → 'failed'
'Zablokowany' → 'blocked'
'Niewykonany' → 'not-run'
```

### 2. Funkcja importu (`/frontend/src/pages/TestSpecifications.tsx`)

#### `handleImportCSV`:
1. **Odczyt pliku** - użycie FileReader API
2. **Parsowanie CSV** - grupowanie kroków według TC
3. **Walidacja** - sprawdzenie czy TC już istnieje (po test_case_id)
4. **Mapowanie danych:**
   - Zestawy testowe - wyszukiwanie po nazwie
   - Wymagania - wyszukiwanie po requirement_id
   - Tagi - wyszukiwanie po nazwie lub tworzenie nowych
5. **Tworzenie TC** - wywołanie API dla każdego TC
6. **Podsumowanie** - wyświetlenie statystyk importu

#### Obsługa tagów:
```typescript
// Jeśli tag istnieje - użyj go
let tag = projectTags.find(t => t.name === tagName);

// Jeśli nie istnieje - utwórz nowy
if (!tag) {
  const newTagRes = await tagsApi.create({
    name: tagName,
    color: '#3B82F6',
    project_id: selectedProject!.id
  });
  tag = newTagRes.data;
}
```

#### Obsługa duplikatów:
```typescript
// Sprawdź czy TC o tym ID już istnieje
const existingTC = specificationsList.find(s => s.test_case_id === tc.test_case_id);
if (existingTC) {
  skipped++;
  continue;
}
```

### 3. UI - Przycisk importu

```tsx
<button onClick={() => fileInputRef.current?.click()}>
  <Upload className="h-4 w-4 mr-2" />
  Importuj CSV
</button>
<input
  ref={fileInputRef}
  type="file"
  accept=".csv"
  onChange={handleImportCSV}
  className="hidden"
/>
```

## Format pliku CSV

### Nagłówki (wymagane):
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi,Data utworzenia
```

### Przykładowe dane:
```csv
PT1-003,Test logowania,Sprawdzenie logowania,Użytkownik niezalogowany,1,Otwórz stronę,Strona wyświetlona,Średni,Szkic,Logowanie,WYM-PT1-002,test,14.05.2026
PT1-003,Test logowania,Sprawdzenie logowania,Użytkownik niezalogowany,2,Wprowadź dane,Dane wprowadzone,Średni,Szkic,Logowanie,WYM-PT1-002,test,14.05.2026
```

### Uwagi:
- Każdy krok TC to osobny wiersz
- Dane TC (tytuł, opis, etc.) są powtarzane dla każdego kroku
- Wartości z przecinkami muszą być w cudzysłowach: `"WYM-001, WYM-002"`
- Puste wartości są dozwolone

## Przepływ importu

### Krok 1: Wybór pliku
```
Użytkownik → Kliknij "Importuj CSV" → Wybierz plik CSV
```

### Krok 2: Parsowanie
```
Plik CSV → parseTestCasesCSV() → Tablica ParsedTestCase
```

### Krok 3: Grupowanie kroków
```
Wiersz 1: PT1-001, krok 1
Wiersz 2: PT1-001, krok 2  } → Jeden TC z 2 krokami
Wiersz 3: PT1-002, krok 1  → Drugi TC z 1 krokiem
```

### Krok 4: Mapowanie danych
```
Nazwa zestawu → ID zestawu
ID wymagania → ID wewnętrzne
Nazwa tagu → ID tagu (lub utwórz nowy)
```

### Krok 5: Tworzenie TC
```
Dla każdego TC:
  - Sprawdź duplikaty
  - Utwórz TC przez API
  - Zapisz kroki, wymagania, tagi
```

### Krok 6: Podsumowanie
```
✅ Zaimportowano: 5 TC
ℹ️ Pominięto: 2 TC (już istnieją)
❌ Błędy: 0
```

## Obsługa błędów

### Duplikaty:
- TC z tym samym `test_case_id` są pomijane
- Wyświetlany komunikat: "Pominięto X przypadków (już istnieją)"

### Błędy importu:
- Każdy błąd jest logowany do konsoli
- Licznik błędów jest wyświetlany w podsumowaniu
- Import kontynuuje dla pozostałych TC

### Walidacja:
- Plik musi zawierać nagłówki
- Każdy wiersz musi mieć co najmniej ID TC i tytuł
- Nieprawidłowe wiersze są pomijane z ostrzeżeniem

## Automatyczne tworzenie danych

### Tagi:
- Jeśli tag nie istnieje w projekcie - jest tworzony automatycznie
- Nowy tag otrzymuje domyślny kolor: `#3B82F6` (niebieski)
- Tag jest dodawany do listy tagów projektu

### Zestawy testowe:
- Jeśli zestaw nie istnieje - TC jest tworzony bez zestawu
- Nie tworzy automatycznie nowych zestawów

### Wymagania:
- Jeśli wymaganie nie istnieje - powiązanie jest pomijane
- Nie tworzy automatycznie nowych wymagań

## Przykłady użycia

### Scenariusz 1: Import nowych TC
1. Wyeksportuj TC z projektu A do CSV
2. Otwórz projekt B
3. Kliknij "Importuj CSV"
4. Wybierz plik CSV z projektu A
5. TC są importowane z nowymi ID

### Scenariusz 2: Backup i restore
1. Wyeksportuj wszystkie TC do CSV (backup)
2. Usuń TC z projektu
3. Importuj CSV (restore)
4. TC z duplikatami są pomijane

### Scenariusz 3: Migracja danych
1. Przygotuj CSV z TC w Excelu
2. Zapisz jako CSV UTF-8
3. Importuj do systemu
4. Tagi są tworzone automatycznie

## Pliki zmienione

### Frontend:
- `/frontend/src/utils/csvImport.ts` - nowy plik z parserem CSV
- `/frontend/src/pages/TestSpecifications.tsx`:
  - Import Upload icon i funkcji importu
  - Dodanie ref dla input file
  - Funkcja handleImportCSV
  - Przycisk "Importuj CSV" w UI
  - Ukryty input file

## Kompatybilność

✅ **Kompatybilny z eksportem** - plik CSV wyeksportowany przez system może być zaimportowany z powrotem
✅ **Excel/Google Sheets** - można edytować CSV w arkuszach kalkulacyjnych
✅ **UTF-8 z BOM** - obsługa polskich znaków
✅ **Escapowanie** - obsługa wartości z przecinkami i cudzysłowami

## Ograniczenia

⚠️ **ID TC musi być unikalne** - duplikaty są pomijane
⚠️ **Zestawy nie są tworzone** - muszą istnieć przed importem
⚠️ **Wymagania nie są tworzone** - muszą istnieć przed importem
⚠️ **Tagi są tworzone** - z domyślnym kolorem niebieskim

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
