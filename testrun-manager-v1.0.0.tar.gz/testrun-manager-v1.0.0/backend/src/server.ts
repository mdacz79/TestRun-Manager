import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth';
import projectRoutes from './routes/projects';
import testRoutes from './routes/tests';
import testRunRoutes from './routes/test-runs';
import statisticsRoutes from './routes/statistics';
import userRoutes from './routes/users';
import roleRoutes from './routes/roles';
import requirementsRoutes from './routes/requirements';
import requirementGroupsRoutes from './routes/requirement-groups';
import testSpecificationsRoutes from './routes/test-specifications';
import testSuitesRoutes from './routes/test-suites';
import defectsRoutes from './routes/defects';
import tagsRoutes from './routes/tags';
import testPlansRoutes from './routes/test-plans';
import testExecutionsRoutes from './routes/test-executions';
import bugsRoutes from './routes/bugs';
import statusesRoutes from './routes/statuses';
import './database';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 3000;

app.use(cors());
app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ limit: '50mb', extended: true }));

app.use('/api/auth', authRoutes);
app.use('/api/projects', projectRoutes);
app.use('/api/tests', testRoutes);
app.use('/api/test-runs', testRunRoutes);
app.use('/api/statistics', statisticsRoutes);
app.use('/api/users', userRoutes);
app.use('/api/roles', roleRoutes);
app.use('/api/requirements', requirementsRoutes);
app.use('/api/requirement-groups', requirementGroupsRoutes);
app.use('/api/test-specifications', testSpecificationsRoutes);
app.use('/api/test-suites', testSuitesRoutes);
app.use('/api/defects', defectsRoutes);
app.use('/api/tags', tagsRoutes);
app.use('/api/test-plans', testPlansRoutes);
app.use('/api/test-executions', testExecutionsRoutes);
app.use('/api/bugs', bugsRoutes);
app.use('/api/statuses', statusesRoutes);

app.get('/api/health', (req, res) => {
  res.json({ status: 'OK', message: 'TestFlow System API is running' });
});

// Daj chwilę na inicjalizację bazy danych
setTimeout(() => {
  app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
    console.log(`API endpoints available at http://localhost:${PORT}/api`);
  });
}, 1000);
