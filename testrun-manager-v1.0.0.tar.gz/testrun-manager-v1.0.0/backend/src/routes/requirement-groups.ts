import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const groups = db.prepare(`
      SELECT rg.*, u.name as created_by_name
      FROM requirement_groups rg
      LEFT JOIN users u ON rg.created_by = u.id
      WHERE rg.project_id = ?
      ORDER BY rg.created_at ASC
    `).all(project_id);
    
    res.json(groups);
  } catch (error) {
    console.error('Get requirement groups error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', (req: AuthRequest, res) => {
  try {
    const { name, description, project_id, parent_id } = req.body;

    if (!name || !project_id) {
      return res.status(400).json({ error: 'Name and project ID are required' });
    }

    const result = db.prepare(`
      INSERT INTO requirement_groups (name, description, project_id, parent_id, created_by)
      VALUES (?, ?, ?, ?, ?)
    `).run(name, description || '', project_id, parent_id || null, req.user!.id);

    const group = db.prepare('SELECT * FROM requirement_groups WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(group);
  } catch (error) {
    console.error('Create requirement group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, description, parent_id } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Name is required' });
    }

    const group = db.prepare('SELECT * FROM requirement_groups WHERE id = ?').get(id);
    if (!group) {
      return res.status(404).json({ error: 'Requirement group not found' });
    }

    db.prepare(`
      UPDATE requirement_groups 
      SET name = ?, description = ?, parent_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(name, description || '', parent_id || null, id);

    const updated = db.prepare('SELECT * FROM requirement_groups WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Update requirement group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { deleteRequirements } = req.query;

    const group = db.prepare('SELECT * FROM requirement_groups WHERE id = ?').get(id);
    if (!group) {
      return res.status(404).json({ error: 'Requirement group not found' });
    }

    if (deleteRequirements === 'true') {
      db.prepare('DELETE FROM requirements WHERE requirement_group_id = ?').run(id);
    } else {
      db.prepare('UPDATE requirements SET requirement_group_id = NULL WHERE requirement_group_id = ?').run(id);
    }

    db.prepare('DELETE FROM requirement_groups WHERE id = ?').run(id);
    res.json({ message: 'Requirement group deleted' });
  } catch (error) {
    console.error('Delete requirement group error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
