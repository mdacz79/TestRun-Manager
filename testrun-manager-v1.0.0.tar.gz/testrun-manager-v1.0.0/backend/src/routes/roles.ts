import { Router } from 'express';
import db from '../database';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

function checkAdmin(req: any, res: any, next: any) {
  try {
    const userRole = db.prepare('SELECT r.name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?')
      .get(req.user.id);
    
    if (!userRole || userRole.name !== 'Administrator') {
      return res.status(403).json({ error: 'Access denied. Admin only.' });
    }
    next();
  } catch (error) {
    console.error('Admin check error:', error);
    return res.status(500).json({ error: 'Authorization check failed' });
  }
}

function checkRoleManagement(req: any, res: any, next: any) {
  try {
    const userRole = db.prepare('SELECT r.name, r.permissions FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?')
      .get(req.user.id) as any;
    
    if (!userRole) {
      return res.status(403).json({ error: 'Access denied.' });
    }
    
    // Administrator lub użytkownik z uprawnieniem admin.manage_roles
    const canManageRoles = 
      userRole.name === 'Administrator' ||
      (userRole.permissions && userRole.permissions.includes('admin.manage_roles'));
    
    if (!canManageRoles) {
      return res.status(403).json({ error: 'Access denied. Role management permission required.' });
    }
    
    next();
  } catch (error) {
    console.error('Role management check error:', error);
    return res.status(500).json({ error: 'Authorization check failed' });
  }
}

router.get('/', (req: any, res: any) => {
  try {
    const roles = db.prepare('SELECT * FROM roles ORDER BY id').all();
    console.log('Fetched roles:', roles);
    res.json(roles);
  } catch (error) {
    console.error('Fetch roles error:', error);
    res.status(500).json({ error: 'Failed to fetch roles' });
  }
});

router.post('/', checkRoleManagement, (req: any, res: any) => {
  try {
    const { name, description, permissions } = req.body;
    
    if (!name) {
      return res.status(400).json({ error: 'Role name is required' });
    }

    const result = db.prepare(
      'INSERT INTO roles (name, description, permissions) VALUES (?, ?, ?)'
    ).run(name, description || '', permissions || '');

    res.status(201).json({ 
      id: result.lastInsertRowid,
      name,
      description,
      permissions
    });
  } catch (error: any) {
    if (error.message?.includes('UNIQUE')) {
      return res.status(400).json({ error: 'Role name already exists' });
    }
    res.status(500).json({ error: 'Failed to create role' });
  }
});

router.put('/:id', checkRoleManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { name, description, permissions } = req.body;

    if (parseInt(id) <= 4) {
      return res.status(400).json({ error: 'Cannot modify default roles' });
    }

    const role = db.prepare('SELECT id FROM roles WHERE id = ?').get(id);
    if (!role) {
      return res.status(404).json({ error: 'Role not found' });
    }

    db.prepare(
      'UPDATE roles SET name = ?, description = ?, permissions = ? WHERE id = ?'
    ).run(name, description, permissions, id);

    res.json({ message: 'Role updated successfully' });
  } catch (error: any) {
    if (error.message?.includes('UNIQUE')) {
      return res.status(400).json({ error: 'Role name already exists' });
    }
    res.status(500).json({ error: 'Failed to update role' });
  }
});

router.delete('/:id', checkRoleManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;

    if (parseInt(id) <= 4) {
      return res.status(400).json({ error: 'Cannot delete default roles' });
    }

    const role = db.prepare('SELECT id FROM roles WHERE id = ?').get(id);
    if (!role) {
      return res.status(404).json({ error: 'Role not found' });
    }

    const usersWithRole = db.prepare('SELECT COUNT(*) as count FROM users WHERE role_id = ?').get(id);
    if (usersWithRole && usersWithRole.count > 0) {
      return res.status(400).json({ error: 'Cannot delete role with assigned users' });
    }

    db.prepare('DELETE FROM roles WHERE id = ?').run(id);
    res.json({ message: 'Role deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete role' });
  }
});

export default router;
