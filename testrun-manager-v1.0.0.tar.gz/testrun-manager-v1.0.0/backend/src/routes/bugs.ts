import express from 'express';
import multer from 'multer';
import path from 'path';
import fs from 'fs';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

// Konfiguracja multer dla uploadów
const storage = multer.diskStorage({
  destination: (req, file, cb) => {
    const uploadDir = path.join(__dirname, '../../uploads/bug-attachments');
    if (!fs.existsSync(uploadDir)) {
      fs.mkdirSync(uploadDir, { recursive: true });
    }
    cb(null, uploadDir);
  },
  filename: (req, file, cb) => {
    const uniqueSuffix = Date.now() + '-' + Math.round(Math.random() * 1E9);
    cb(null, uniqueSuffix + path.extname(file.originalname));
  }
});

const upload = multer({
  storage: storage,
  limits: {
    fileSize: 10 * 1024 * 1024 // 10MB limit
  }
});

router.use(authenticateToken);

// Pobierz wszystkie błędy dla projektu
router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const bugs = db.prepare(`
      SELECT b.*, 
        u1.name as reported_by_name,
        u2.name as assigned_to_name
      FROM bugs b
      LEFT JOIN users u1 ON b.reported_by = u1.id
      LEFT JOIN users u2 ON b.assigned_to = u2.id
      WHERE b.project_id = ?
      ORDER BY b.created_at DESC
    `).all(project_id);
    
    res.json(bugs);
  } catch (error) {
    console.error('Error fetching bugs:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz szczegóły błędu
router.get('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const bug = db.prepare(`
      SELECT b.*, 
        u1.name as reported_by_name,
        u2.name as assigned_to_name
      FROM bugs b
      LEFT JOIN users u1 ON b.reported_by = u1.id
      LEFT JOIN users u2 ON b.assigned_to = u2.id
      WHERE b.id = ?
    `).get(id);
    
    if (!bug) {
      return res.status(404).json({ error: 'Bug not found' });
    }

    // Pobierz powiązane wykonania testów
    const executions = db.prepare(`
      SELECT te.*,
        ts.test_case_id, ts.title as test_title,
        tp.name as test_plan_name,
        u.name as executed_by_name
      FROM test_executions te
      JOIN test_plan_cases tpc ON te.test_plan_case_id = tpc.id
      JOIN test_specifications ts ON tpc.test_specification_id = ts.id
      JOIN test_plans tp ON tpc.test_plan_id = tp.id
      LEFT JOIN users u ON te.executed_by = u.id
      WHERE te.bug_id = ?
      ORDER BY te.created_at DESC
    `).all(id);
    
    res.json({ ...bug, executions });
  } catch (error) {
    console.error('Error fetching bug:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Utwórz nowy błąd
router.post('/', (req: AuthRequest, res) => {
  try {
    const { title, description, steps_to_reproduce, severity, priority, status, test_specification_id, project_id, assigned_to } = req.body;
    const userId = req.user?.id;

    console.log('Creating bug with data:', { title, description, steps_to_reproduce, severity, priority, status, project_id, assigned_to });

    if (!title || !project_id) {
      return res.status(400).json({ error: 'Title and project_id are required' });
    }

    // Generuj bug_id (globalnie unikalny)
    // Używamy MAX(id) zamiast COUNT(*) aby uniknąć konfliktów po usunięciu defektów
    const maxIdResult: any = db.prepare('SELECT MAX(id) as max_id FROM bugs').get();
    const nextId = (maxIdResult?.max_id || 0) + 1;
    const bugId = `BUG-${String(nextId).padStart(4, '0')}`;

    console.log('Generated bug_id:', bugId, 'for project:', project_id);

    const result = db.prepare(`
      INSERT INTO bugs (bug_id, title, description, steps_to_reproduce, severity, priority, status, test_specification_id, project_id, reported_by, assigned_to)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      bugId, 
      title, 
      description || '', 
      steps_to_reproduce || '',
      severity || 'medium',
      priority || 'medium',
      status || 'new',
      test_specification_id || null,
      project_id, 
      userId, 
      assigned_to || null
    );

    const newBug = db.prepare('SELECT * FROM bugs WHERE id = ?').get(result.lastInsertRowid);
    console.log('Bug created successfully:', newBug);
    res.status(201).json(newBug);
  } catch (error) {
    console.error('Error creating bug:', error);
    console.error('Error details:', error instanceof Error ? error.message : error);
    console.error('Stack trace:', error instanceof Error ? error.stack : '');
    res.status(500).json({ error: 'Internal server error', details: error instanceof Error ? error.message : String(error) });
  }
});

// Aktualizuj błąd
router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { title, description, steps_to_reproduce, severity, priority, status, test_specification_id, assigned_to } = req.body;

    // Pobierz obecne dane błędu
    const currentBug = db.prepare('SELECT * FROM bugs WHERE id = ?').get(id);
    if (!currentBug) {
      return res.status(404).json({ error: 'Bug not found' });
    }

    // Sprawdź czy zmienił się status
    const newStatus = status !== undefined ? status : currentBug.status;
    if (status !== undefined && status !== currentBug.status) {
      // Zapisz historię zmiany statusu
      db.prepare(`
        INSERT INTO bug_status_history (bug_id, old_status, new_status, changed_by)
        VALUES (?, ?, ?, ?)
      `).run(id, currentBug.status, status, req.user!.id);
    }

    // Użyj obecnych wartości jeśli nowe nie zostały przekazane
    db.prepare(`
      UPDATE bugs 
      SET title = ?, description = ?, steps_to_reproduce = ?, severity = ?, priority = ?, status = ?, test_specification_id = ?, assigned_to = ?, updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(
      title !== undefined ? title : currentBug.title,
      description !== undefined ? description : currentBug.description,
      steps_to_reproduce !== undefined ? steps_to_reproduce : currentBug.steps_to_reproduce,
      severity !== undefined ? severity : currentBug.severity,
      priority !== undefined ? priority : currentBug.priority,
      newStatus,
      test_specification_id !== undefined ? test_specification_id : currentBug.test_specification_id,
      assigned_to !== undefined ? assigned_to : currentBug.assigned_to,
      id
    );

    const updated = db.prepare('SELECT * FROM bugs WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Error updating bug:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Usuń błąd
router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    db.prepare('DELETE FROM bugs WHERE id = ?').run(id);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting bug:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz komentarze do błędu
router.get('/:id/comments', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const comments = db.prepare(`
      SELECT bc.*, 
             u.name as user_name,
             u1.name as old_assignee_name,
             u2.name as new_assignee_name
      FROM bug_comments bc
      LEFT JOIN users u ON bc.user_id = u.id
      LEFT JOIN users u1 ON bc.old_assignee_id = u1.id
      LEFT JOIN users u2 ON bc.new_assignee_id = u2.id
      WHERE bc.bug_id = ?
      ORDER BY bc.created_at DESC
    `).all(id);
    
    res.json(comments);
  } catch (error) {
    console.error('Error fetching comments:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Dodaj komentarz do błędu
router.post('/:id/comments', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { comment } = req.body;
    const userId = req.user?.id;

    if (!comment) {
      return res.status(400).json({ error: 'Comment is required' });
    }

    const result = db.prepare(`
      INSERT INTO bug_comments (bug_id, user_id, comment)
      VALUES (?, ?, ?)
    `).run(id, userId, comment);

    // Aktualizuj updated_at w bugs
    db.prepare(`
      UPDATE bugs 
      SET updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(id);

    const newComment = db.prepare(`
      SELECT bc.*, u.name as user_name
      FROM bug_comments bc
      LEFT JOIN users u ON bc.user_id = u.id
      WHERE bc.id = ?
    `).get(result.lastInsertRowid);

    res.status(201).json(newComment);
  } catch (error) {
    console.error('Error adding comment:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Przepisz błąd (reassign)
router.post('/:id/reassign', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { new_assignee_id, comment } = req.body;
    const userId = req.user?.id;

    if (!new_assignee_id) {
      return res.status(400).json({ error: 'New assignee is required' });
    }

    // Pobierz obecnego assignee
    const bug = db.prepare('SELECT assigned_to FROM bugs WHERE id = ?').get(id);
    const oldAssigneeId = bug?.assigned_to;

    // Aktualizuj błąd
    db.prepare(`
      UPDATE bugs 
      SET assigned_to = ?, updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(new_assignee_id, id);

    // Dodaj komentarz o przepisaniu
    db.prepare(`
      INSERT INTO bug_comments (bug_id, user_id, comment, is_reassignment, old_assignee_id, new_assignee_id)
      VALUES (?, ?, ?, 1, ?, ?)
    `).run(id, userId, comment || 'Przepisano błąd', oldAssigneeId, new_assignee_id);

    const updated = db.prepare(`
      SELECT b.*, u.name as assigned_to_name
      FROM bugs b
      LEFT JOIN users u ON b.assigned_to = u.id
      WHERE b.id = ?
    `).get(id);

    res.json(updated);
  } catch (error) {
    console.error('Error reassigning bug:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz historię zmian statusów dla błędu
router.get('/:id/status-history', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const history = db.prepare(`
      SELECT 
        h.*,
        u.name as changed_by_name
      FROM bug_status_history h
      LEFT JOIN users u ON h.changed_by = u.id
      WHERE h.bug_id = ?
      ORDER BY h.created_at DESC
    `).all(id);
    
    res.json(history);
  } catch (error) {
    console.error('Error fetching status history:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Upload załącznika do błędu
router.post('/:id/attachments', upload.single('file'), (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const userId = req.user?.id;
    const file = req.file;

    if (!file) {
      return res.status(400).json({ error: 'No file uploaded' });
    }

    const result = db.prepare(`
      INSERT INTO bug_attachments (bug_id, filename, original_filename, file_path, file_size, mime_type, uploaded_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(id, file.filename, file.originalname, file.path, file.size, file.mimetype, userId);

    const attachment = db.prepare(`
      SELECT a.*, u.name as uploaded_by_name
      FROM bug_attachments a
      LEFT JOIN users u ON a.uploaded_by = u.id
      WHERE a.id = ?
    `).get(result.lastInsertRowid);

    res.status(201).json(attachment);
  } catch (error) {
    console.error('Error uploading attachment:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz załączniki dla błędu
router.get('/:id/attachments', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const attachments = db.prepare(`
      SELECT a.*, u.name as uploaded_by_name
      FROM bug_attachments a
      LEFT JOIN users u ON a.uploaded_by = u.id
      WHERE a.bug_id = ?
      ORDER BY a.created_at DESC
    `).all(id);
    
    res.json(attachments);
  } catch (error) {
    console.error('Error fetching attachments:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz plik załącznika
router.get('/attachments/:attachmentId/download', (req: AuthRequest, res) => {
  try {
    const { attachmentId } = req.params;
    
    const attachment: any = db.prepare('SELECT * FROM bug_attachments WHERE id = ?').get(attachmentId);
    
    if (!attachment) {
      return res.status(404).json({ error: 'Attachment not found' });
    }

    res.download(attachment.file_path, attachment.original_filename);
  } catch (error) {
    console.error('Error downloading attachment:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Usuń załącznik
router.delete('/attachments/:attachmentId', (req: AuthRequest, res) => {
  try {
    const { attachmentId } = req.params;
    
    const attachment: any = db.prepare('SELECT * FROM bug_attachments WHERE id = ?').get(attachmentId);
    
    if (!attachment) {
      return res.status(404).json({ error: 'Attachment not found' });
    }

    // Usuń plik z dysku
    if (fs.existsSync(attachment.file_path)) {
      fs.unlinkSync(attachment.file_path);
    }

    // Usuń z bazy danych
    db.prepare('DELETE FROM bug_attachments WHERE id = ?').run(attachmentId);
    
    res.json({ message: 'Attachment deleted successfully' });
  } catch (error) {
    console.error('Error deleting attachment:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
