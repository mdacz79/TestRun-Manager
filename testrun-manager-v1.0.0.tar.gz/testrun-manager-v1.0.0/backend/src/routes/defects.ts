import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const defects = db.prepare(`
      SELECT d.*, 
             u1.name as reported_by_name,
             u2.name as assigned_to_name,
             ts.title as test_specification_title
      FROM defects d
      LEFT JOIN users u1 ON d.reported_by = u1.id
      LEFT JOIN users u2 ON d.assigned_to = u2.id
      LEFT JOIN test_specifications ts ON d.test_specification_id = ts.id
      WHERE d.project_id = ?
      ORDER BY d.created_at DESC
    `).all(project_id);
    
    res.json(defects);
  } catch (error) {
    console.error('Get defects error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const defect = db.prepare(`
      SELECT d.*, 
             u1.name as reported_by_name,
             u2.name as assigned_to_name,
             ts.title as test_specification_title
      FROM defects d
      LEFT JOIN users u1 ON d.reported_by = u1.id
      LEFT JOIN users u2 ON d.assigned_to = u2.id
      LEFT JOIN test_specifications ts ON d.test_specification_id = ts.id
      WHERE d.id = ?
    `).get(id);
    
    if (!defect) {
      return res.status(404).json({ error: 'Defect not found' });
    }
    
    res.json(defect);
  } catch (error) {
    console.error('Get defect error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', (req: AuthRequest, res) => {
  try {
    const { 
      title, 
      description, 
      steps_to_reproduce, 
      severity, 
      priority, 
      status, 
      test_specification_id, 
      project_id,
      assigned_to
    } = req.body;

    if (!title || !project_id) {
      return res.status(400).json({ error: 'Title and project ID are required' });
    }

    // Generuj defect_id
    const count = db.prepare('SELECT COUNT(*) as count FROM defects WHERE project_id = ?').get(project_id);
    const defectId = `DEF-${String(count.count + 1).padStart(4, '0')}`;

    const result = db.prepare(`
      INSERT INTO defects 
      (defect_id, title, description, steps_to_reproduce, severity, priority, status, 
       test_specification_id, project_id, reported_by, assigned_to)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      defectId,
      title,
      description || '',
      steps_to_reproduce || '',
      severity || 'medium',
      priority || 'medium',
      status || 'new',
      test_specification_id || null,
      project_id,
      req.user!.id,
      assigned_to || null
    );

    const defect = db.prepare('SELECT * FROM defects WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(defect);
  } catch (error) {
    console.error('Create defect error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { 
      title, 
      description, 
      steps_to_reproduce, 
      severity, 
      priority, 
      status, 
      test_specification_id,
      assigned_to
    } = req.body;

    const defect = db.prepare('SELECT * FROM defects WHERE id = ?').get(id);
    if (!defect) {
      return res.status(404).json({ error: 'Defect not found' });
    }

    db.prepare(`
      UPDATE defects 
      SET title = ?, description = ?, steps_to_reproduce = ?, severity = ?, priority = ?, 
          status = ?, test_specification_id = ?, assigned_to = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(
      title, 
      description, 
      steps_to_reproduce, 
      severity, 
      priority, 
      status, 
      test_specification_id || null,
      assigned_to || null,
      id
    );

    const updated = db.prepare('SELECT * FROM defects WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Update defect error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const defect = db.prepare('SELECT * FROM defects WHERE id = ?').get(id);
    if (!defect) {
      return res.status(404).json({ error: 'Defect not found' });
    }

    db.prepare('DELETE FROM defects WHERE id = ?').run(id);
    res.json({ message: 'Defect deleted' });
  } catch (error) {
    console.error('Delete defect error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
