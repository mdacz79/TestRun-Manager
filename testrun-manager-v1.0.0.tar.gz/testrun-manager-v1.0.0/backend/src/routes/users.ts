import { Router } from 'express';
import bcrypt from 'bcryptjs';
import db from '../database';
import { authenticateToken } from '../middleware/auth';

const router = Router();

router.use(authenticateToken);

function checkAdmin(req: any, res: any, next: any) {
  try {
    const userRole = db.prepare('SELECT r.name FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?')
      .get(req.user.id);
    
    console.log('User role check:', userRole);
    
    if (!userRole || userRole.name !== 'Administrator') {
      return res.status(403).json({ error: 'Access denied. Admin only.' });
    }
    next();
  } catch (error) {
    console.error('Admin check error:', error);
    return res.status(500).json({ error: 'Authorization check failed' });
  }
}

function checkUserManagement(req: any, res: any, next: any) {
  try {
    const userRole = db.prepare('SELECT r.name, r.permissions FROM users u JOIN roles r ON u.role_id = r.id WHERE u.id = ?')
      .get(req.user.id) as any;
    
    if (!userRole) {
      return res.status(403).json({ error: 'Access denied.' });
    }
    
    // Administrator lub użytkownik z uprawnieniem admin.manage_users
    const canManageUsers = 
      userRole.name === 'Administrator' ||
      (userRole.permissions && userRole.permissions.includes('admin.manage_users'));
    
    if (!canManageUsers) {
      return res.status(403).json({ error: 'Access denied. User management permission required.' });
    }
    
    next();
  } catch (error) {
    console.error('User management check error:', error);
    return res.status(500).json({ error: 'Authorization check failed' });
  }
}

// Endpoint dostępny dla wszystkich zalogowanych użytkowników - zwraca tylko podstawowe dane
router.get('/list', (req: any, res: any) => {
  try {
    const users = db.prepare(`
      SELECT u.id, u.email, u.name, u.is_active,
             r.id as role_id, r.name as role_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
      WHERE u.is_active = 1
      ORDER BY u.name ASC
    `).all();
    res.json(users);
  } catch (error) {
    console.error('Fetch users list error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

router.get('/', checkUserManagement, (req: any, res: any) => {
  try {
    const users = db.prepare(`
      SELECT u.id, u.email, u.name, u.is_active, u.created_at, 
             r.id as role_id, r.name as role_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
      ORDER BY u.created_at DESC
    `).all();
    
    // Dla każdego użytkownika pobierz przypisane projekty
    const usersWithProjects = users.map((user: any) => {
      const projects = db.prepare(`
        SELECT p.id, p.name
        FROM user_projects up
        JOIN projects p ON up.project_id = p.id
        WHERE up.user_id = ?
        ORDER BY p.name
      `).all(user.id);
      
      return {
        ...user,
        projects: projects
      };
    });
    
    console.log('Fetched users with projects:', usersWithProjects);
    res.json(usersWithProjects);
  } catch (error) {
    console.error('Fetch users error:', error);
    res.status(500).json({ error: 'Failed to fetch users' });
  }
});

router.post('/', checkUserManagement, (req: any, res: any) => {
  try {
    const { email, password, name, role_id } = req.body;
    
    if (!email || !password || !name) {
      return res.status(400).json({ error: 'Email, password and name are required' });
    }

    const hashedPassword = bcrypt.hashSync(password, 10);
    
    const result = db.prepare(
      'INSERT INTO users (email, password, name, role_id, is_active) VALUES (?, ?, ?, ?, ?)'
    ).run(email, hashedPassword, name, role_id || 4, 1);

    res.status(201).json({ 
      id: result.lastInsertRowid,
      email,
      name,
      role_id: role_id || 4
    });
  } catch (error: any) {
    if (error.message?.includes('UNIQUE')) {
      return res.status(400).json({ error: 'Email already exists' });
    }
    res.status(500).json({ error: 'Failed to create user' });
  }
});

router.put('/:id', checkUserManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { email, name, role_id, is_active } = req.body;

    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    db.prepare(
      'UPDATE users SET email = ?, name = ?, role_id = ?, is_active = ? WHERE id = ?'
    ).run(email, name, role_id, is_active, id);

    res.json({ message: 'User updated successfully' });
  } catch (error: any) {
    if (error.message?.includes('UNIQUE')) {
      return res.status(400).json({ error: 'Email already exists' });
    }
    res.status(500).json({ error: 'Failed to update user' });
  }
});

router.delete('/:id', checkUserManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;

    if (parseInt(id) === req.user.userId) {
      return res.status(400).json({ error: 'Cannot delete your own account' });
    }

    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    db.prepare('DELETE FROM users WHERE id = ?').run(id);
    res.json({ message: 'User deleted successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to delete user' });
  }
});

router.post('/:id/reset-password', checkUserManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { new_password } = req.body;

    if (!new_password) {
      return res.status(400).json({ error: 'New password is required' });
    }

    const user = db.prepare('SELECT id FROM users WHERE id = ?').get(id);
    if (!user) {
      return res.status(404).json({ error: 'User not found' });
    }

    const hashedPassword = bcrypt.hashSync(new_password, 10);
    db.prepare('UPDATE users SET password = ? WHERE id = ?').run(hashedPassword, id);

    res.json({ message: 'Password reset successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to reset password' });
  }
});

router.get('/:id/projects', checkUserManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;
    
    const projects = db.prepare(`
      SELECT p.id, p.name, p.description
      FROM user_projects up
      JOIN projects p ON up.project_id = p.id
      WHERE up.user_id = ?
    `).all(id);

    res.json(projects);
  } catch (error) {
    res.status(500).json({ error: 'Failed to fetch user projects' });
  }
});

router.post('/:id/projects', checkUserManagement, (req: any, res: any) => {
  try {
    const { id } = req.params;
    const { project_id } = req.body;

    db.prepare(
      'INSERT OR IGNORE INTO user_projects (user_id, project_id) VALUES (?, ?)'
    ).run(id, project_id);

    res.json({ message: 'Project assigned successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to assign project' });
  }
});

router.delete('/:id/projects/:projectId', checkUserManagement, (req: any, res: any) => {
  try {
    const { id, projectId } = req.params;

    db.prepare(
      'DELETE FROM user_projects WHERE user_id = ? AND project_id = ?'
    ).run(id, projectId);

    res.json({ message: 'Project unassigned successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Failed to unassign project' });
  }
});

export default router;
