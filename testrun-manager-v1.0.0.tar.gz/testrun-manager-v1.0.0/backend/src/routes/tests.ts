import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.get('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    let query = `
      SELECT tc.*, p.name as project_name 
      FROM test_cases tc 
      JOIN projects p ON tc.project_id = p.id 
      WHERE p.user_id = ?
    `;
    const params: any[] = [req.user!.id];

    if (project_id) {
      query += ' AND tc.project_id = ?';
      params.push(project_id);
    }

    query += ' ORDER BY tc.created_at DESC';

    const tests = db.prepare(query).all(...params);
    res.json(tests);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:id', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const test = db.prepare(`
      SELECT tc.*, p.name as project_name, u.name as creator_name
      FROM test_cases tc
      JOIN projects p ON tc.project_id = p.id
      JOIN users u ON tc.created_by = u.id
      WHERE tc.id = ? AND p.user_id = ?
    `).get(id, req.user!.id);

    if (!test) {
      return res.status(404).json({ error: 'Test case not found' });
    }

    res.json(test);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { title, description, steps, expected_result, priority, project_id } = req.body;

    if (!title || !project_id) {
      return res.status(400).json({ error: 'Title and project_id are required' });
    }

    const project = db.prepare('SELECT * FROM projects WHERE id = ? AND user_id = ?').get(project_id, req.user!.id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    const result = db.prepare(`
      INSERT INTO test_cases (title, description, steps, expected_result, priority, project_id, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(
      title,
      description || '',
      steps || '',
      expected_result || '',
      priority || 'medium',
      project_id,
      req.user!.id
    );

    const test = db.prepare('SELECT * FROM test_cases WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(test);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { title, description, steps, expected_result, priority, status } = req.body;

    const test = db.prepare(`
      SELECT tc.* FROM test_cases tc
      JOIN projects p ON tc.project_id = p.id
      WHERE tc.id = ? AND p.user_id = ?
    `).get(id, req.user!.id);

    if (!test) {
      return res.status(404).json({ error: 'Test case not found' });
    }

    db.prepare(`
      UPDATE test_cases 
      SET title = ?, description = ?, steps = ?, expected_result = ?, priority = ?, status = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(title, description, steps, expected_result, priority, status, id);

    const updated = db.prepare('SELECT * FROM test_cases WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const test = db.prepare(`
      SELECT tc.* FROM test_cases tc
      JOIN projects p ON tc.project_id = p.id
      WHERE tc.id = ? AND p.user_id = ?
    `).get(id, req.user!.id);

    if (!test) {
      return res.status(404).json({ error: 'Test case not found' });
    }

    db.prepare('DELETE FROM test_cases WHERE id = ?').run(id);
    res.json({ message: 'Test case deleted' });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
