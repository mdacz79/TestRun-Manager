import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

// Pobierz wszystkie plany testów dla projektu
router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const plans = db.prepare(`
      SELECT tp.*, u.name as created_by_name,
        (SELECT COUNT(*) FROM test_plan_cases WHERE test_plan_id = tp.id) as test_count
      FROM test_plans tp
      LEFT JOIN users u ON tp.created_by = u.id
      WHERE tp.project_id = ?
      ORDER BY tp.created_at DESC
    `).all(project_id);
    
    res.json(plans);
  } catch (error) {
    console.error('Error fetching test plans:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz szczegóły planu testów
router.get('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const plan = db.prepare(`
      SELECT tp.*, u.name as created_by_name
      FROM test_plans tp
      LEFT JOIN users u ON tp.created_by = u.id
      WHERE tp.id = ?
    `).get(id);
    
    if (!plan) {
      return res.status(404).json({ error: 'Test plan not found' });
    }

    // Pobierz przypadki testowe przypisane do planu
    const cases = db.prepare(`
      SELECT tpc.*, 
        ts.test_case_id, ts.title, ts.description, ts.preconditions,
        u.name as assigned_to_name,
        (SELECT COUNT(*) FROM test_executions WHERE test_plan_case_id = tpc.id) as execution_count
      FROM test_plan_cases tpc
      JOIN test_specifications ts ON tpc.test_specification_id = ts.id
      LEFT JOIN users u ON tpc.assigned_to = u.id
      WHERE tpc.test_plan_id = ?
      ORDER BY tpc.order_index ASC
    `).all(id);
    
    // Pobierz kroki testowe dla każdego przypadku
    const casesWithSteps = cases.map((testCase: any) => {
      const steps = db.prepare(`
        SELECT step_number, action, expected_result
        FROM test_steps
        WHERE test_specification_id = ?
        ORDER BY step_number ASC
      `).all(testCase.test_specification_id);
      
      return { ...testCase, steps };
    });
    
    res.json({ ...plan, cases: casesWithSteps });
  } catch (error) {
    console.error('Error fetching test plan:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Utwórz nowy plan testów
router.post('/', (req: AuthRequest, res) => {
  try {
    const { name, description, project_id, start_date, end_date, test_completion_date } = req.body;
    const userId = req.user?.id;

    if (!name || !project_id) {
      return res.status(400).json({ error: 'Name and project_id are required' });
    }

    const result = db.prepare(`
      INSERT INTO test_plans (name, description, project_id, created_by, start_date, end_date, test_completion_date)
      VALUES (?, ?, ?, ?, ?, ?, ?)
    `).run(name, description || '', project_id, userId, start_date || null, end_date || null, test_completion_date || null);

    const newPlan = db.prepare('SELECT * FROM test_plans WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(newPlan);
  } catch (error) {
    console.error('Error creating test plan:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Aktualizuj plan testów
router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, description, start_date, end_date, test_completion_date } = req.body;

    db.prepare(`
      UPDATE test_plans 
      SET name = ?, description = ?, start_date = ?, end_date = ?, test_completion_date = ?, updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(name, description, start_date || null, end_date || null, test_completion_date || null, id);

    const updated = db.prepare('SELECT * FROM test_plans WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Error updating test plan:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Usuń plan testów
router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    db.prepare('DELETE FROM test_plans WHERE id = ?').run(id);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting test plan:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Dodaj przypadek testowy do planu
router.post('/:id/cases', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { test_specification_id, assigned_to } = req.body;

    if (!test_specification_id) {
      return res.status(400).json({ error: 'test_specification_id is required' });
    }

    // Sprawdź czy przypadek już istnieje w planie
    const existing = db.prepare(`
      SELECT id FROM test_plan_cases 
      WHERE test_plan_id = ? AND test_specification_id = ?
    `).get(id, test_specification_id);

    if (existing) {
      return res.status(400).json({ error: 'Test case already exists in this plan' });
    }

    // Pobierz maksymalny order_index
    const maxOrder = db.prepare(`
      SELECT MAX(order_index) as max_order FROM test_plan_cases WHERE test_plan_id = ?
    `).get(id);
    
    const orderIndex = (maxOrder?.max_order || 0) + 1;

    const result = db.prepare(`
      INSERT INTO test_plan_cases (test_plan_id, test_specification_id, assigned_to, order_index)
      VALUES (?, ?, ?, ?)
    `).run(id, test_specification_id, assigned_to || null, orderIndex);

    const newCase = db.prepare(`
      SELECT tpc.*, ts.test_case_id, ts.title, u.name as assigned_to_name
      FROM test_plan_cases tpc
      JOIN test_specifications ts ON tpc.test_specification_id = ts.id
      LEFT JOIN users u ON tpc.assigned_to = u.id
      WHERE tpc.id = ?
    `).get(result.lastInsertRowid);

    res.status(201).json(newCase);
  } catch (error) {
    console.error('Error adding test case to plan:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Usuń przypadek testowy z planu
router.delete('/:planId/cases/:caseId', (req: AuthRequest, res) => {
  try {
    const { caseId } = req.params;
    
    db.prepare('DELETE FROM test_plan_cases WHERE id = ?').run(caseId);
    res.status(204).send();
  } catch (error) {
    console.error('Error removing test case from plan:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Przypisz użytkownika do przypadku testowego
router.put('/:planId/cases/:caseId/assign', (req: AuthRequest, res) => {
  try {
    const { caseId } = req.params;
    const { assigned_to } = req.body;

    db.prepare(`
      UPDATE test_plan_cases 
      SET assigned_to = ?
      WHERE id = ?
    `).run(assigned_to || null, caseId);

    const updated = db.prepare(`
      SELECT tpc.*, u.name as assigned_to_name
      FROM test_plan_cases tpc
      LEFT JOIN users u ON tpc.assigned_to = u.id
      WHERE tpc.id = ?
    `).get(caseId);

    res.json(updated);
  } catch (error) {
    console.error('Error assigning user to test case:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Aktywuj/dezaktywuj plan testów
router.patch('/:id/toggle-active', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    // Pobierz obecny stan
    const plan: any = db.prepare('SELECT is_active FROM test_plans WHERE id = ?').get(id);
    
    if (!plan) {
      return res.status(404).json({ error: 'Test plan not found' });
    }
    
    // Przełącz stan
    const newState = plan.is_active === 1 ? 0 : 1;
    
    db.prepare(`
      UPDATE test_plans 
      SET is_active = ?, updated_at = datetime('now', 'localtime')
      WHERE id = ?
    `).run(newState, id);

    const updated = db.prepare('SELECT * FROM test_plans WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Error toggling test plan active state:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Funkcja sprawdzająca czy dzień jest dniem roboczym (pn-pt, bez świąt)
function isWorkingDay(date: Date): boolean {
  const dayOfWeek = date.getDay();
  
  // Sobota (6) lub niedziela (0)
  if (dayOfWeek === 0 || dayOfWeek === 6) {
    return false;
  }
  
  // Polskie święta 2026 (można rozszerzyć o inne lata)
  const year = date.getFullYear();
  const month = date.getMonth() + 1; // 1-12
  const day = date.getDate();
  
  const holidays = [
    { month: 1, day: 1 },   // Nowy Rok
    { month: 1, day: 6 },   // Trzech Króli
    { month: 4, day: 5 },   // Wielkanoc 2026
    { month: 4, day: 6 },   // Poniedziałek Wielkanocny 2026
    { month: 5, day: 1 },   // Święto Pracy
    { month: 5, day: 3 },   // Święto Konstytucji 3 Maja
    { month: 5, day: 24 },  // Zielone Świątki 2026
    { month: 6, day: 4 },   // Boże Ciało 2026
    { month: 8, day: 15 },  // Wniebowzięcie NMP
    { month: 11, day: 1 },  // Wszystkich Świętych
    { month: 11, day: 11 }, // Święto Niepodległości
    { month: 12, day: 25 }, // Boże Narodzenie
    { month: 12, day: 26 }  // Drugi dzień Bożego Narodzenia
  ];
  
  return !holidays.some(h => h.month === month && h.day === day);
}

// Funkcja licząca dni robocze między dwiema datami
function countWorkingDays(startDate: Date, endDate: Date): number {
  let count = 0;
  const current = new Date(startDate);
  
  while (current <= endDate) {
    if (isWorkingDay(current)) {
      count++;
    }
    current.setDate(current.getDate() + 1);
  }
  
  return count;
}

// Pobierz dane burndown dla planu testów
router.get('/:id/burndown', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    // Pobierz plan testów z datami
    const plan: any = db.prepare(`
      SELECT id, name, start_date, end_date, test_completion_date,
        (SELECT COUNT(*) FROM test_plan_cases WHERE test_plan_id = ?) as total_tests
      FROM test_plans 
      WHERE id = ?
    `).get(id, id);
    
    if (!plan) {
      return res.status(404).json({ error: 'Test plan not found' });
    }

    // Pobierz wszystkie test cases z planu wraz z ich statusem i datą pierwszego wykonania
    const executions = db.prepare(`
      SELECT 
        tpc.id as test_plan_case_id,
        tpc.status as current_status,
        COALESCE(
          (
            SELECT MIN(DATE(te.completed_at))
            FROM test_executions te
            WHERE te.test_plan_case_id = tpc.id
              AND te.completed_at IS NOT NULL
          ),
          DATE('now')
        ) as execution_date
      FROM test_plan_cases tpc
      WHERE tpc.test_plan_id = ?
        AND tpc.status IN ('PASSED', 'FAILED', 'BLOCKED', 'SKIPPED', 'IN_PROGRESS')
      ORDER BY execution_date ASC
    `).all(id);

    console.log('Total test cases with execution status:', executions.length);
    
    // Grupuj wykonania po datach, ze statusem z test_plan_cases
    const executionsByDate: { [key: string]: { total: number; passed: number; failed: number } } = {};
    const todayDate = new Date();
    todayDate.setHours(0, 0, 0, 0);
    const todayStr = todayDate.toISOString().split('T')[0];
    
    executions.forEach((exec: any) => {
      let date = exec.execution_date;
      
      // WAŻNE: Jeśli data wykonania jest w przyszłości (błąd danych), użyj dzisiejszej daty
      if (new Date(date) > todayDate) {
        console.log(`WARNING: Test case ${exec.test_plan_case_id} has future execution_date ${date}, using today ${todayStr} instead`);
        date = todayStr;
      }
      
      if (!executionsByDate[date]) {
        executionsByDate[date] = { total: 0, passed: 0, failed: 0 };
      }
      executionsByDate[date].total++;
      
      // Liczymy passed/failed na podstawie aktualnego statusu z test_plan_cases
      if (exec.current_status === 'PASSED') {
        executionsByDate[date].passed++;
      } else if (exec.current_status === 'FAILED') {
        executionsByDate[date].failed++;
      }
      
      console.log(`Date ${date}: test_case_id=${exec.test_plan_case_id}, status=${exec.current_status}`);
    });

    console.log('Executions by date summary:', executionsByDate);

    // Buduj dane burndown
    const startDate = plan.start_date ? new Date(plan.start_date) : new Date();
    startDate.setHours(0, 0, 0, 0); // Resetuj czas do początku dnia
    
    const endDate = plan.end_date ? new Date(plan.end_date) : new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    endDate.setHours(0, 0, 0, 0); // Resetuj czas do początku dnia
    
    // Data realizacji testów (do kiedy powinny być wykonane wszystkie TC)
    const testCompletionDate = plan.test_completion_date ? new Date(plan.test_completion_date) : endDate;
    testCompletionDate.setHours(0, 0, 0, 0);
    
    const today = new Date();
    today.setHours(0, 0, 0, 0); // Resetuj czas do początku dnia
    
    const totalTests = plan.total_tests;

    // Oblicz całkowitą liczbę dni roboczych od start do test_completion_date (dla idealnej linii)
    const totalWorkingDays = countWorkingDays(startDate, testCompletionDate);
    
    // Oblicz dzienne tempo wykonania testów
    const dailyTestsTarget = totalWorkingDays > 0 ? Math.ceil(totalTests / totalWorkingDays) : 0;
    
    console.log('Burndown data generation:', {
      planId: id,
      startDate: startDate.toISOString().split('T')[0],
      endDate: endDate.toISOString().split('T')[0],
      today: today.toISOString().split('T')[0],
      totalTests,
      totalWorkingDays,
      executionsCount: executions.length
    });
    
    // Generuj dane dla wszystkich linii
    const burndownData = [];
    let currentDate = new Date(startDate);
    currentDate.setHours(0, 0, 0, 0); // Resetuj czas do początku dnia
    let totalExecuted = 0;
    let totalPassed = 0;
    let totalFailed = 0;
    let workingDayIndex = 0; // Licznik tylko dni roboczych

    while (currentDate <= endDate) {
      const dateStr = currentDate.toISOString().split('T')[0];
      const isWorking = isWorkingDay(currentDate);
      
      // Dodaj testy wykonane tego dnia (tylko dla rzeczywistych danych)
      if (executionsByDate[dateStr]) {
        totalExecuted += executionsByDate[dateStr].total;
        totalPassed += executionsByDate[dateStr].passed;
        totalFailed += executionsByDate[dateStr].failed;
        console.log(`Date ${dateStr}: +${executionsByDate[dateStr].total} executed, +${executionsByDate[dateStr].passed} passed, +${executionsByDate[dateStr].failed} failed (cumulative: ${totalExecuted} executed, ${totalPassed} passed, ${totalFailed} failed)`);
      }

      // Oblicz idealną linię tylko dla dni roboczych (rosnąca - od 0 do totalTests)
      let idealCompleted = 0;
      
      if (currentDate <= testCompletionDate) {
        // Do daty realizacji testów - linia rośnie
        if (isWorking) {
          workingDayIndex++;
          idealCompleted = totalWorkingDays > 0 
            ? Math.min(totalTests, Math.round((totalTests * workingDayIndex) / totalWorkingDays))
            : totalTests;
        } else {
          // Dla weekendów i świąt - zachowaj wartość z ostatniego dnia roboczego
          if (burndownData.length > 0) {
            idealCompleted = burndownData[burndownData.length - 1].target;
          }
        }
      } else {
        // Po dacie realizacji testów - linia pozostaje na poziomie totalTests (czas na retesty)
        idealCompleted = totalTests;
      }

      const dataPoint: any = {
        date: dateStr,
        target: idealCompleted,  // Cel (niebieski) - idealna linia
        isWorkingDay: isWorking  // Informacja czy to dzień roboczy
      };

      // Dodaj rzeczywiste dane tylko do dzisiaj (sysdate)
      const isBeforeOrToday = currentDate <= today;
      if (isBeforeOrToday) {
        dataPoint.executed = totalExecuted;  // Uruchomione (pomarańczowy)
        dataPoint.passed = totalPassed;      // Passed (zielony)
        dataPoint.failed = totalFailed;      // Failed (czerwony)
        if (dateStr === today.toISOString().split('T')[0]) {
          console.log(`TODAY ${dateStr}: executed=${totalExecuted}, passed=${totalPassed}, failed=${totalFailed}`);
        }
      } else {
        console.log(`FUTURE DATE ${dateStr}: skipping real data (currentDate=${currentDate.toISOString()}, today=${today.toISOString()})`);
      }

      burndownData.push(dataPoint);

      // Następny dzień
      currentDate.setDate(currentDate.getDate() + 1);
    }

    console.log('Burndown data generated:', burndownData.length, 'data points', workingDayIndex, 'working days');
    
    // Loguj ostatnie 5 punktów danych dla diagnostyki
    console.log('Last 5 data points:');
    burndownData.slice(-5).forEach((point: any) => {
      console.log(`  ${point.date}: target=${point.target}, executed=${point.executed}, passed=${point.passed}, failed=${point.failed}, isWorkingDay=${point.isWorkingDay}`);
    });
    
    // Loguj podsumowanie
    const lastPoint = burndownData[burndownData.length - 1];
    console.log('Summary - Last point:', {
      date: lastPoint.date,
      target: lastPoint.target,
      executed: lastPoint.executed,
      passed: lastPoint.passed,
      failed: lastPoint.failed
    });

    res.json({
      plan: {
        id: plan.id,
        name: plan.name,
        start_date: plan.start_date,
        end_date: plan.end_date,
        test_completion_date: plan.test_completion_date,
        total_tests: totalTests,
        working_days: totalWorkingDays,
        daily_tests_target: dailyTestsTarget
      },
      burndown: burndownData
    });
  } catch (error) {
    console.error('Error fetching burndown data:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
