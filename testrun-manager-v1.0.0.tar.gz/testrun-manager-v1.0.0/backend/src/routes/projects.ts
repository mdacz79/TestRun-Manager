import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.get('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    // Sprawdź rolę i uprawnienia użytkownika
    const userRole = db.prepare(`
      SELECT r.name, r.permissions 
      FROM users u 
      JOIN roles r ON u.role_id = r.id 
      WHERE u.id = ?
    `).get(req.user!.id) as any;
    
    let projects;
    
    // Administrator lub użytkownik z uprawnieniem projects.view widzi wszystkie projekty
    if (userRole && (userRole.name === 'Administrator' || (userRole.permissions && userRole.permissions.includes('projects.view')))) {
      projects = db.prepare(`
        SELECT p.*, u.name as project_manager_name, u.email as project_manager_email
        FROM projects p
        LEFT JOIN users u ON p.project_manager_id = u.id
        ORDER BY p.created_at DESC
      `).all();
    } else {
      // Użytkownik bez uprawnień widzi tylko przypisane projekty
      projects = db.prepare(`
        SELECT DISTINCT p.*, u.name as project_manager_name, u.email as project_manager_email
        FROM projects p
        LEFT JOIN user_projects up ON p.id = up.project_id
        LEFT JOIN users u ON p.project_manager_id = u.id
        WHERE p.user_id = ? OR up.user_id = ?
        ORDER BY p.created_at DESC
      `).all(req.user!.id, req.user!.id);
    }
    
    console.log('Projects for user', req.user!.id, ':', projects);
    res.json(projects);
  } catch (error) {
    console.error('Get projects error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { name, tag, description, project_manager_id } = req.body;

    if (!name) {
      return res.status(400).json({ error: 'Project name is required' });
    }

    if (!tag) {
      return res.status(400).json({ error: 'Project tag is required' });
    }

    if (tag.length > 5) {
      return res.status(400).json({ error: 'Project tag must be max 5 characters' });
    }

    if (!project_manager_id) {
      return res.status(400).json({ error: 'Project manager is required' });
    }

    const result = db.prepare('INSERT INTO projects (name, tag, description, user_id, project_manager_id) VALUES (?, ?, ?, ?, ?)').run(
      name,
      tag.toUpperCase(),
      description || '',
      req.user!.id,
      project_manager_id
    );

    const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(project);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { name, tag, description, project_manager_id } = req.body;
    const { id } = req.params;

    // Sprawdź uprawnienia użytkownika
    const userRole = db.prepare(`
      SELECT r.name, r.permissions 
      FROM users u 
      JOIN roles r ON u.role_id = r.id 
      WHERE u.id = ?
    `).get(req.user!.id) as any;

    // Sprawdź czy projekt istnieje
    const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Użytkownik może edytować projekt jeśli:
    // 1. Jest administratorem
    // 2. Ma uprawnienie projects.edit
    // 3. Jest właścicielem projektu (user_id)
    const canEdit = 
      userRole.name === 'Administrator' ||
      (userRole.permissions && userRole.permissions.includes('projects.edit')) ||
      project.user_id === req.user!.id;

    if (!canEdit) {
      return res.status(403).json({ error: 'Brak uprawnień do edycji projektu' });
    }

    if (!name) {
      return res.status(400).json({ error: 'Project name is required' });
    }

    if (!tag) {
      return res.status(400).json({ error: 'Project tag is required' });
    }

    if (tag.length > 5) {
      return res.status(400).json({ error: 'Project tag must be max 5 characters' });
    }

    if (!project_manager_id) {
      return res.status(400).json({ error: 'Project manager is required' });
    }

    db.prepare('UPDATE projects SET name = ?, tag = ?, description = ?, project_manager_id = ? WHERE id = ?').run(
      name, 
      tag.toUpperCase(), 
      description, 
      project_manager_id, 
      id
    );
    const updated = db.prepare('SELECT * FROM projects WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    // Sprawdź uprawnienia użytkownika
    const userRole = db.prepare(`
      SELECT r.name, r.permissions 
      FROM users u 
      JOIN roles r ON u.role_id = r.id 
      WHERE u.id = ?
    `).get(req.user!.id) as any;

    // Sprawdź czy projekt istnieje
    const project = db.prepare('SELECT * FROM projects WHERE id = ?').get(id);
    if (!project) {
      return res.status(404).json({ error: 'Project not found' });
    }

    // Użytkownik może usunąć projekt jeśli:
    // 1. Jest administratorem
    // 2. Ma uprawnienie projects.delete
    // 3. Jest właścicielem projektu (user_id)
    const canDelete = 
      userRole.name === 'Administrator' ||
      (userRole.permissions && userRole.permissions.includes('projects.delete')) ||
      project.user_id === req.user!.id;

    if (!canDelete) {
      return res.status(403).json({ error: 'Brak uprawnień do usunięcia projektu' });
    }

    db.prepare('DELETE FROM projects WHERE id = ?').run(id);
    res.json({ message: 'Project deleted' });
  } catch (error) {
    console.error('Delete project error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
