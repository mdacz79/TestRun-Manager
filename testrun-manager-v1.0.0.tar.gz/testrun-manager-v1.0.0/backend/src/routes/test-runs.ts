import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.get('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { test_case_id } = req.query;
    
    let query = `
      SELECT tr.*, tc.title as test_title, u.name as executor_name
      FROM test_runs tr
      JOIN test_cases tc ON tr.test_case_id = tc.id
      JOIN users u ON tr.executed_by = u.id
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ?
    `;
    const params: any[] = [req.user!.id];

    if (test_case_id) {
      query += ' AND tr.test_case_id = ?';
      params.push(test_case_id);
    }

    query += ' ORDER BY tr.executed_at DESC';

    const runs = db.prepare(query).all(...params);
    res.json(runs);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const { test_case_id, result, notes } = req.body;

    if (!test_case_id || !result) {
      return res.status(400).json({ error: 'test_case_id and result are required' });
    }

    const test = db.prepare(`
      SELECT tc.* FROM test_cases tc
      JOIN projects p ON tc.project_id = p.id
      WHERE tc.id = ? AND p.user_id = ?
    `).get(test_case_id, req.user!.id);

    if (!test) {
      return res.status(404).json({ error: 'Test case not found' });
    }

    const runResult = db.prepare(`
      INSERT INTO test_runs (test_case_id, result, notes, executed_by)
      VALUES (?, ?, ?, ?)
    `).run(test_case_id, result, notes || '', req.user!.id);

    const run = db.prepare('SELECT * FROM test_runs WHERE id = ?').get(runResult.lastInsertRowid);
    res.status(201).json(run);
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
