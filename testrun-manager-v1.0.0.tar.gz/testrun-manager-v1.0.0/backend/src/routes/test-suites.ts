import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const suites = db.prepare(`
      SELECT ts.*, u.name as created_by_name,
             (SELECT COUNT(*) FROM test_specifications WHERE test_suite_id = ts.id) as test_count
      FROM test_suites ts
      LEFT JOIN users u ON ts.created_by = u.id
      WHERE ts.project_id = ?
      ORDER BY ts.created_at DESC
    `).all(project_id);
    
    res.json(suites);
  } catch (error) {
    console.error('Get test suites error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', (req: AuthRequest, res) => {
  try {
    const { name, description, project_id, parent_id } = req.body;

    if (!name || !project_id) {
      return res.status(400).json({ error: 'Name and project ID are required' });
    }

    const result = db.prepare(`
      INSERT INTO test_suites (name, description, project_id, parent_id, created_by)
      VALUES (?, ?, ?, ?, ?)
    `).run(name, description || '', project_id, parent_id || null, req.user!.id);

    const suite = db.prepare('SELECT * FROM test_suites WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(suite);
  } catch (error) {
    console.error('Create test suite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, description, parent_id } = req.body;

    const suite = db.prepare('SELECT * FROM test_suites WHERE id = ?').get(id);
    if (!suite) {
      return res.status(404).json({ error: 'Test suite not found' });
    }

    db.prepare(`
      UPDATE test_suites 
      SET name = ?, description = ?, parent_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(name, description, parent_id || null, id);

    const updated = db.prepare('SELECT * FROM test_suites WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Update test suite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { deleteTests } = req.query;

    const suite = db.prepare('SELECT * FROM test_suites WHERE id = ?').get(id);
    if (!suite) {
      return res.status(404).json({ error: 'Test suite not found' });
    }

    // Sprawdź ile przypadków testowych jest w zestawie
    const testCount = db.prepare('SELECT COUNT(*) as count FROM test_specifications WHERE test_suite_id = ?').get(id) as any;

    if (deleteTests === 'true') {
      // Usuń wszystkie przypadki testowe w zestawie
      db.prepare('DELETE FROM test_specifications WHERE test_suite_id = ?').run(id);
    } else {
      // Odepnij przypadki testowe od zestawu (ustaw test_suite_id na NULL)
      db.prepare('UPDATE test_specifications SET test_suite_id = NULL WHERE test_suite_id = ?').run(id);
    }

    // Usuń zestaw
    db.prepare('DELETE FROM test_suites WHERE id = ?').run(id);
    res.json({ message: 'Test suite deleted', deletedTests: deleteTests === 'true' ? testCount.count : 0 });
  } catch (error) {
    console.error('Delete test suite error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
