import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

// Get all global tags
router.get('/', (req: AuthRequest, res) => {
  try {
    const tags = db.prepare('SELECT * FROM tags WHERE project_id IS NULL ORDER BY name ASC').all();
    res.json(tags);
  } catch (error) {
    console.error('Error fetching tags:', error);
    res.status(500).json({ error: 'Failed to fetch tags' });
  }
});

// Get all tags for a project (deprecated - kept for backward compatibility)
router.get('/project/:projectId', (req: AuthRequest, res) => {
  try {
    const tags = db.prepare('SELECT * FROM tags WHERE project_id = ? OR project_id IS NULL ORDER BY name ASC').all(req.params.projectId);
    res.json(tags);
  } catch (error) {
    console.error('Error fetching tags:', error);
    res.status(500).json({ error: 'Failed to fetch tags' });
  }
});

// Create a new global tag
router.post('/', (req: AuthRequest, res) => {
  try {
    const { name, color, description } = req.body;
    
    console.log('Creating tag:', { name, color, description });
    
    // Walidacja
    if (!name || name.trim() === '') {
      return res.status(400).json({ error: 'Tag name is required' });
    }
    
    // Check if tag with same name exists globally
    const existing = db.prepare('SELECT * FROM tags WHERE project_id IS NULL AND name = ?').get(name);
    
    if (existing) {
      console.log('Tag already exists:', existing);
      return res.status(400).json({ error: 'Tag with this name already exists' });
    }
    
    const result = db.prepare(
      'INSERT INTO tags (project_id, name, color, description) VALUES (NULL, ?, ?, ?)'
    ).run(name, color || '#3B82F6', description || null);
    
    const tag = db.prepare('SELECT * FROM tags WHERE id = ?').get(result.lastInsertRowid);
    console.log('Tag created successfully:', tag);
    res.status(201).json(tag);
  } catch (error) {
    console.error('Error creating tag:', error);
    res.status(500).json({ error: 'Failed to create tag', details: error instanceof Error ? error.message : 'Unknown error' });
  }
});

// Update a tag
router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { name, color, description } = req.body;
    const tag = db.prepare('SELECT * FROM tags WHERE id = ?').get(req.params.id);
    
    if (!tag) {
      return res.status(404).json({ error: 'Tag not found' });
    }
    
    db.prepare('UPDATE tags SET name = ?, color = ?, description = ?, updated_at = CURRENT_TIMESTAMP WHERE id = ?')
      .run(name, color, description, req.params.id);
    
    const updatedTag = db.prepare('SELECT * FROM tags WHERE id = ?').get(req.params.id);
    res.json(updatedTag);
  } catch (error) {
    console.error('Error updating tag:', error);
    res.status(500).json({ error: 'Failed to update tag' });
  }
});

// Delete a tag
router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const tag = db.prepare('SELECT * FROM tags WHERE id = ?').get(req.params.id);
    
    if (!tag) {
      return res.status(404).json({ error: 'Tag not found' });
    }
    
    db.prepare('DELETE FROM tags WHERE id = ?').run(req.params.id);
    res.json({ message: 'Tag deleted successfully' });
  } catch (error) {
    console.error('Error deleting tag:', error);
    res.status(500).json({ error: 'Failed to delete tag' });
  }
});

// Assign tags to requirement
router.post('/requirement/:requirementId', (req: AuthRequest, res) => {
  try {
    const { tag_ids } = req.body;
    const requirementId = req.params.requirementId;
    
    // Remove existing tags
    db.prepare('DELETE FROM requirement_tags WHERE requirement_id = ?').run(requirementId);
    
    // Add new tags
    if (tag_ids && tag_ids.length > 0) {
      const stmt = db.prepare('INSERT INTO requirement_tags (requirement_id, tag_id) VALUES (?, ?)');
      tag_ids.forEach((tag_id: number) => {
        stmt.run(requirementId, tag_id);
      });
    }
    
    res.json({ message: 'Tags assigned successfully' });
  } catch (error) {
    console.error('Error assigning tags to requirement:', error);
    res.status(500).json({ error: 'Failed to assign tags' });
  }
});

// Assign tags to test specification
router.post('/test-specification/:specId', (req: AuthRequest, res) => {
  try {
    const { tag_ids } = req.body;
    const specId = req.params.specId;
    
    // Remove existing tags
    db.prepare('DELETE FROM test_specification_tags WHERE test_specification_id = ?').run(specId);
    
    // Add new tags
    if (tag_ids && tag_ids.length > 0) {
      const stmt = db.prepare('INSERT INTO test_specification_tags (test_specification_id, tag_id) VALUES (?, ?)');
      tag_ids.forEach((tag_id: number) => {
        stmt.run(specId, tag_id);
      });
    }
    
    res.json({ message: 'Tags assigned successfully' });
  } catch (error) {
    console.error('Error assigning tags to test specification:', error);
    res.status(500).json({ error: 'Failed to assign tags' });
  }
});

export default router;
