import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

// Rozpocznij wykonywanie testu
router.post('/start', (req: AuthRequest, res) => {
  try {
    const { test_plan_case_id } = req.body;
    const userId = req.user?.id;

    if (!test_plan_case_id) {
      return res.status(400).json({ error: 'test_plan_case_id is required' });
    }

    // Zmień status na IN_PROGRESS
    db.prepare(`
      UPDATE test_plan_cases 
      SET status = 'IN_PROGRESS'
      WHERE id = ?
    `).run(test_plan_case_id);

    // Utwórz rekord wykonania
    const result = db.prepare(`
      INSERT INTO test_executions (test_plan_case_id, executed_by, status, started_at)
      VALUES (?, ?, 'IN_PROGRESS', CURRENT_TIMESTAMP)
    `).run(test_plan_case_id, userId);

    const execution = db.prepare('SELECT * FROM test_executions WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(execution);
  } catch (error) {
    console.error('Error starting test execution:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Zakończ wykonywanie testu
router.post('/complete', (req: AuthRequest, res) => {
  try {
    const { execution_id, status, bug_id, notes } = req.body;

    if (!execution_id || !status) {
      return res.status(400).json({ error: 'execution_id and status are required' });
    }

    // Jeśli status to FAILED, bug_id jest wymagany
    if (status === 'FAILED' && !bug_id) {
      return res.status(400).json({ error: 'bug_id is required for FAILED status' });
    }

    // Aktualizuj wykonanie
    db.prepare(`
      UPDATE test_executions 
      SET status = ?, bug_id = ?, notes = ?, completed_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(status, bug_id || null, notes || '', execution_id);

    // Pobierz test_plan_case_id
    const execution = db.prepare('SELECT test_plan_case_id FROM test_executions WHERE id = ?').get(execution_id);

    // Aktualizuj status w test_plan_cases
    db.prepare(`
      UPDATE test_plan_cases 
      SET status = ?
      WHERE id = ?
    `).run(status, execution.test_plan_case_id);

    const updated = db.prepare('SELECT * FROM test_executions WHERE id = ?').get(execution_id);
    res.json(updated);
  } catch (error) {
    console.error('Error completing test execution:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz historię wykonań dla przypadku testowego
router.get('/history/:testPlanCaseId', (req: AuthRequest, res) => {
  try {
    const { testPlanCaseId } = req.params;

    const history = db.prepare(`
      SELECT te.*,
        u.name as executed_by_name,
        b.bug_id, b.title as bug_title,
        tp.name as test_plan_name
      FROM test_executions te
      LEFT JOIN users u ON te.executed_by = u.id
      LEFT JOIN bugs b ON te.bug_id = b.id
      LEFT JOIN test_plan_cases tpc ON te.test_plan_case_id = tpc.id
      LEFT JOIN test_plans tp ON tpc.test_plan_id = tp.id
      WHERE te.test_plan_case_id = ?
      ORDER BY te.created_at DESC
    `).all(testPlanCaseId);

    res.json(history);
  } catch (error) {
    console.error('Error fetching execution history:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz wszystkie wykonania dla planu testów
router.get('/plan/:planId', (req: AuthRequest, res) => {
  try {
    const { planId } = req.params;

    const executions = db.prepare(`
      SELECT te.*,
        u.name as executed_by_name,
        ts.test_case_id, ts.title as test_title,
        b.bug_id, b.title as bug_title
      FROM test_executions te
      JOIN test_plan_cases tpc ON te.test_plan_case_id = tpc.id
      JOIN test_specifications ts ON tpc.test_specification_id = ts.id
      LEFT JOIN users u ON te.executed_by = u.id
      LEFT JOIN bugs b ON te.bug_id = b.id
      WHERE tpc.test_plan_id = ?
      ORDER BY te.created_at DESC
    `).all(planId);

    res.json(executions);
  } catch (error) {
    console.error('Error fetching plan executions:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
