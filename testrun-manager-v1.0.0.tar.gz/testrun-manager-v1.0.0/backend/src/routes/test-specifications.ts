import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const specifications = db.prepare(`
      SELECT ts.*, u.name as created_by_name, tsuite.name as test_suite_name
      FROM test_specifications ts
      LEFT JOIN users u ON ts.created_by = u.id
      LEFT JOIN test_suites tsuite ON ts.test_suite_id = tsuite.id
      WHERE ts.project_id = ?
      ORDER BY ts.display_order ASC, ts.created_at DESC
    `).all(project_id);
    
    // Dla każdej specyfikacji pobierz kroki, wymagania i tagi
    const enrichedSpecs = specifications.map((spec: any) => {
      const steps = db.prepare('SELECT * FROM test_steps WHERE test_specification_id = ? ORDER BY step_number').all(spec.id);
      const requirements = db.prepare(`
        SELECT r.id, r.requirement_id, r.title 
        FROM requirements r
        JOIN test_spec_requirements tsr ON r.id = tsr.requirement_id
        WHERE tsr.test_specification_id = ?
      `).all(spec.id);
      const tags = db.prepare(`
        SELECT t.id, t.name, t.color
        FROM tags t
        INNER JOIN test_specification_tags tst ON t.id = tst.tag_id
        WHERE tst.test_specification_id = ?
      `).all(spec.id);
      return { 
        ...spec, 
        steps, 
        requirements, 
        tags: tags || [],
        suite_name: spec.test_suite_name // Dodaj alias dla kompatybilności z frontendem
      };
    });
    
    res.json(enrichedSpecs);
  } catch (error: any) {
    console.error('Get test specifications error:', error);
    console.error('Error details:', error.message, error.stack);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

router.get('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const specification = db.prepare(`
      SELECT ts.*, u.name as created_by_name, tsuite.name as test_suite_name
      FROM test_specifications ts
      LEFT JOIN users u ON ts.created_by = u.id
      LEFT JOIN test_suites tsuite ON ts.test_suite_id = tsuite.id
      WHERE ts.id = ?
    `).get(id);
    
    if (!specification) {
      return res.status(404).json({ error: 'Test specification not found' });
    }
    
    const steps = db.prepare('SELECT * FROM test_steps WHERE test_specification_id = ? ORDER BY step_number').all(id);
    const requirements = db.prepare(`
      SELECT r.id, r.title 
      FROM requirements r
      JOIN test_spec_requirements tsr ON r.id = tsr.requirement_id
      WHERE tsr.test_specification_id = ?
    `).all(id);
    
    res.json({ ...specification, steps, requirements });
  } catch (error) {
    console.error('Get test specification error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', (req: AuthRequest, res) => {
  try {
    const { title, description, preconditions, priority, status, test_suite_id, project_id, steps, requirement_ids, tag_ids } = req.body;

    if (!title || !project_id) {
      return res.status(400).json({ error: 'Title and project ID are required' });
    }

    // Pobierz TAG projektu
    const project = db.prepare('SELECT tag FROM projects WHERE id = ?').get(project_id) as any;
    if (!project) {
      return res.status(400).json({ error: 'Project not found' });
    }

    // Znajdź najwyższy numer dla tego projektu
    const lastSpec = db.prepare(`
      SELECT test_case_id FROM test_specifications 
      WHERE project_id = ? AND test_case_id LIKE ?
      ORDER BY id DESC LIMIT 1
    `).get(project_id, `${project.tag}-%`) as any;

    let nextNumber = 1;
    if (lastSpec && lastSpec.test_case_id) {
      const match = lastSpec.test_case_id.match(/-(\d+)$/);
      if (match) {
        nextNumber = parseInt(match[1]) + 1;
      }
    }

    const testCaseId = `${project.tag}-${String(nextNumber).padStart(3, '0')}`;

    const result = db.prepare(`
      INSERT INTO test_specifications 
      (test_case_id, title, description, preconditions, priority, status, test_suite_id, project_id, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      testCaseId,
      title,
      description || '',
      preconditions || '',
      priority || 'medium',
      status || 'draft',
      test_suite_id || null,
      project_id,
      req.user!.id
    );

    const specId = result.lastInsertRowid;

    // Dodaj kroki
    if (steps && Array.isArray(steps)) {
      steps.forEach((step: any, index: number) => {
        db.prepare(`
          INSERT INTO test_steps (test_specification_id, step_number, action, expected_result)
          VALUES (?, ?, ?, ?)
        `).run(specId, index + 1, step.action, step.expected_result);
      });
    }

    // Dodaj powiązania z wymaganiami
    if (requirement_ids && Array.isArray(requirement_ids)) {
      requirement_ids.forEach((reqId: number) => {
        db.prepare(`
          INSERT INTO test_spec_requirements (test_specification_id, requirement_id)
          VALUES (?, ?)
        `).run(specId, reqId);
      });
    }

    // Dodaj powiązania z tagami
    if (tag_ids && Array.isArray(tag_ids)) {
      tag_ids.forEach((tagId: number) => {
        db.prepare(`
          INSERT INTO test_specification_tags (test_specification_id, tag_id)
          VALUES (?, ?)
        `).run(specId, tagId);
      });
    }

    const specification = db.prepare('SELECT * FROM test_specifications WHERE id = ?').get(specId);
    res.status(201).json(specification);
  } catch (error: any) {
    console.error('Create test specification error:', error);
    console.error('Error details:', error.message, error.stack);
    res.status(500).json({ error: 'Server error', details: error.message });
  }
});

router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { title, description, preconditions, priority, status, test_suite_id, steps, requirement_ids, tag_ids } = req.body;

    const specification = db.prepare('SELECT * FROM test_specifications WHERE id = ?').get(id);
    if (!specification) {
      return res.status(404).json({ error: 'Test specification not found' });
    }

    db.prepare(`
      UPDATE test_specifications 
      SET title = ?, description = ?, preconditions = ?, priority = ?, status = ?, test_suite_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(title, description, preconditions, priority, status, test_suite_id || null, id);

    // Usuń stare kroki i dodaj nowe
    db.prepare('DELETE FROM test_steps WHERE test_specification_id = ?').run(id);
    if (steps && Array.isArray(steps)) {
      steps.forEach((step: any, index: number) => {
        db.prepare(`
          INSERT INTO test_steps (test_specification_id, step_number, action, expected_result)
          VALUES (?, ?, ?, ?)
        `).run(id, index + 1, step.action, step.expected_result);
      });
    }

    // Usuń stare powiązania i dodaj nowe
    db.prepare('DELETE FROM test_spec_requirements WHERE test_specification_id = ?').run(id);
    if (requirement_ids && Array.isArray(requirement_ids)) {
      requirement_ids.forEach((reqId: number) => {
        db.prepare(`
          INSERT INTO test_spec_requirements (test_specification_id, requirement_id)
          VALUES (?, ?)
        `).run(id, reqId);
      });
    }

    // Usuń stare tagi i dodaj nowe
    db.prepare('DELETE FROM test_specification_tags WHERE test_specification_id = ?').run(id);
    if (tag_ids && Array.isArray(tag_ids)) {
      tag_ids.forEach((tagId: number) => {
        db.prepare(`
          INSERT INTO test_specification_tags (test_specification_id, tag_id)
          VALUES (?, ?)
        `).run(id, tagId);
      });
    }

    const updated = db.prepare('SELECT * FROM test_specifications WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Update test specification error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.patch('/:id/reorder', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { test_suite_id, display_order } = req.body;

    const specification = db.prepare('SELECT * FROM test_specifications WHERE id = ?').get(id);
    if (!specification) {
      return res.status(404).json({ error: 'Test specification not found' });
    }

    db.prepare(`
      UPDATE test_specifications 
      SET test_suite_id = ?, display_order = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(test_suite_id || null, display_order || 0, id);

    const updated = db.prepare('SELECT * FROM test_specifications WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Reorder test specification error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const specification = db.prepare('SELECT * FROM test_specifications WHERE id = ?').get(id);
    if (!specification) {
      return res.status(404).json({ error: 'Test specification not found' });
    }

    db.prepare('DELETE FROM test_specifications WHERE id = ?').run(id);
    res.json({ message: 'Test specification deleted' });
  } catch (error) {
    console.error('Delete test specification error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
