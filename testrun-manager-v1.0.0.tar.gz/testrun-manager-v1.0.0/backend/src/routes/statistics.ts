import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.get('/', authenticateToken, (req: AuthRequest, res) => {
  try {
    const totalProjects = db.prepare('SELECT COUNT(*) as count FROM projects WHERE user_id = ?').get(req.user!.id) as any;
    
    const totalTests = db.prepare(`
      SELECT COUNT(*) as count FROM test_cases tc
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ?
    `).get(req.user!.id) as any;

    const totalRuns = db.prepare(`
      SELECT COUNT(*) as count FROM test_runs tr
      JOIN test_cases tc ON tr.test_case_id = tc.id
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ?
    `).get(req.user!.id) as any;

    const passedTests = db.prepare(`
      SELECT COUNT(*) as count FROM test_runs tr
      JOIN test_cases tc ON tr.test_case_id = tc.id
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ? AND tr.result = 'passed'
    `).get(req.user!.id) as any;

    const failedTests = db.prepare(`
      SELECT COUNT(*) as count FROM test_runs tr
      JOIN test_cases tc ON tr.test_case_id = tc.id
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ? AND tr.result = 'failed'
    `).get(req.user!.id) as any;

    const testsByPriority = db.prepare(`
      SELECT priority, COUNT(*) as count FROM test_cases tc
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ?
      GROUP BY priority
    `).all(req.user!.id);

    const recentRuns = db.prepare(`
      SELECT tr.*, tc.title as test_title
      FROM test_runs tr
      JOIN test_cases tc ON tr.test_case_id = tc.id
      JOIN projects p ON tc.project_id = p.id
      WHERE p.user_id = ?
      ORDER BY tr.executed_at DESC
      LIMIT 10
    `).all(req.user!.id);

    res.json({
      totalProjects: totalProjects.count,
      totalTests: totalTests.count,
      totalRuns: totalRuns.count,
      passedTests: passedTests.count,
      failedTests: failedTests.count,
      testsByPriority,
      recentRuns
    });
  } catch (error) {
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
