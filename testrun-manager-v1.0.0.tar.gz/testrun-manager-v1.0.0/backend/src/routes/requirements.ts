import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

router.get('/', (req: AuthRequest, res) => {
  try {
    const { project_id } = req.query;
    
    if (!project_id) {
      return res.status(400).json({ error: 'Project ID is required' });
    }

    const requirements = db.prepare(`
      SELECT r.*, u.name as created_by_name, rg.name as group_name
      FROM requirements r
      LEFT JOIN users u ON r.created_by = u.id
      LEFT JOIN requirement_groups rg ON r.requirement_group_id = rg.id
      WHERE r.project_id = ?
      ORDER BY r.created_at DESC
    `).all(project_id);
    
    // Dodaj liczbę przypadków testowych i tagi dla każdego wymagania
    const enrichedRequirements = requirements.map((req: any) => {
      const testCaseCount = db.prepare(`
        SELECT COUNT(*) as count
        FROM test_spec_requirements
        WHERE requirement_id = ?
      `).get(req.id) as any;
      
      const tags = db.prepare(`
        SELECT t.id, t.name, t.color
        FROM tags t
        INNER JOIN requirement_tags rt ON t.id = rt.tag_id
        WHERE rt.requirement_id = ?
      `).all(req.id);
      
      return {
        ...req,
        test_case_count: testCaseCount?.count || 0,
        tags: tags || []
      };
    });
    
    res.json(enrichedRequirements);
  } catch (error) {
    console.error('Get requirements error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.get('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    const requirement = db.prepare(`
      SELECT r.*, u.name as created_by_name
      FROM requirements r
      LEFT JOIN users u ON r.created_by = u.id
      WHERE r.id = ?
    `).get(id);
    
    if (!requirement) {
      return res.status(404).json({ error: 'Requirement not found' });
    }
    
    res.json(requirement);
  } catch (error) {
    console.error('Get requirement error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.post('/', (req: AuthRequest, res) => {
  try {
    const { title, description, priority, status, requirement_group_id, project_id } = req.body;

    if (!title || !project_id) {
      return res.status(400).json({ error: 'Title and project ID are required' });
    }

    // Pobierz TAG projektu
    const project = db.prepare('SELECT tag FROM projects WHERE id = ?').get(project_id) as any;
    if (!project) {
      return res.status(400).json({ error: 'Project not found' });
    }

    // Znajdź najwyższy numer dla tego projektu
    const lastReq = db.prepare(`
      SELECT requirement_id FROM requirements 
      WHERE project_id = ? AND requirement_id LIKE ?
      ORDER BY id DESC LIMIT 1
    `).get(project_id, `WYM-${project.tag}-%`) as any;

    let nextNumber = 1;
    if (lastReq && lastReq.requirement_id) {
      const match = lastReq.requirement_id.match(/-(\d+)$/);
      if (match) {
        nextNumber = parseInt(match[1]) + 1;
      }
    }

    const requirementId = `WYM-${project.tag}-${String(nextNumber).padStart(3, '0')}`;

    const result = db.prepare(`
      INSERT INTO requirements (requirement_id, title, description, priority, status, requirement_group_id, project_id, created_by)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      requirementId,
      title,
      description || '',
      priority || 'medium',
      status || 'draft',
      requirement_group_id || null,
      project_id,
      req.user!.id
    );

    const requirement = db.prepare('SELECT * FROM requirements WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(requirement);
  } catch (error) {
    console.error('Create requirement error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.put('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { title, description, priority, status, requirement_group_id } = req.body;

    const requirement = db.prepare('SELECT * FROM requirements WHERE id = ?').get(id);
    if (!requirement) {
      return res.status(404).json({ error: 'Requirement not found' });
    }

    db.prepare(`
      UPDATE requirements 
      SET title = ?, description = ?, priority = ?, status = ?, requirement_group_id = ?, updated_at = CURRENT_TIMESTAMP
      WHERE id = ?
    `).run(title, description, priority, status, requirement_group_id || null, id);

    const updated = db.prepare('SELECT * FROM requirements WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Update requirement error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

router.delete('/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;

    const requirement = db.prepare('SELECT * FROM requirements WHERE id = ?').get(id);
    if (!requirement) {
      return res.status(404).json({ error: 'Requirement not found' });
    }

    db.prepare('DELETE FROM requirements WHERE id = ?').run(id);
    res.json({ message: 'Requirement deleted' });
  } catch (error) {
    console.error('Delete requirement error:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

export default router;
