import express from 'express';
import db from '../database';
import { authenticateToken, AuthRequest } from '../middleware/auth';

const router = express.Router();

router.use(authenticateToken);

// ===== TEST EXECUTION STATUSES =====

// Pobierz wszystkie statusy wykonania testów
router.get('/test-execution', (req: AuthRequest, res) => {
  try {
    const statuses = db.prepare(`
      SELECT * FROM test_execution_statuses
      ORDER BY display_order ASC, name ASC
    `).all();
    
    res.json(statuses);
  } catch (error) {
    console.error('Error fetching test execution statuses:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz aktywne statusy dla projektu
router.get('/test-execution/project/:projectId', (req: AuthRequest, res) => {
  try {
    const { projectId } = req.params;
    
    const statuses = db.prepare(`
      SELECT tes.*, 
             COALESCE(ptes.is_enabled, 1) as is_enabled
      FROM test_execution_statuses tes
      LEFT JOIN project_test_execution_statuses ptes 
        ON tes.id = ptes.status_id AND ptes.project_id = ?
      WHERE tes.is_active = 1
      ORDER BY tes.display_order ASC, tes.name ASC
    `).all(projectId);
    
    res.json(statuses);
  } catch (error) {
    console.error('Error fetching project test execution statuses:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Utwórz nowy status wykonania testu
router.post('/test-execution', (req: AuthRequest, res) => {
  try {
    const { name, key, color, description, display_order } = req.body;

    if (!name || !key || !color) {
      return res.status(400).json({ error: 'Name, key and color are required' });
    }

    const result = db.prepare(`
      INSERT INTO test_execution_statuses (name, key, color, description, is_system, is_active, display_order)
      VALUES (?, ?, ?, ?, 0, 1, ?)
    `).run(name, key, color, description || '', display_order || 999);

    const newStatus = db.prepare('SELECT * FROM test_execution_statuses WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(newStatus);
  } catch (error) {
    console.error('Error creating test execution status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Aktualizuj status wykonania testu
router.put('/test-execution/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, key, color, description, is_active, display_order } = req.body;

    db.prepare(`
      UPDATE test_execution_statuses 
      SET name = ?, key = ?, color = ?, description = ?, is_active = ?, display_order = ?
      WHERE id = ?
    `).run(name, key, color, description || '', is_active, display_order, id);

    const updated = db.prepare('SELECT * FROM test_execution_statuses WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Error updating test execution status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Usuń status wykonania testu (tylko niestandardowe)
router.delete('/test-execution/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    // Sprawdź czy to status systemowy
    const status = db.prepare('SELECT is_system FROM test_execution_statuses WHERE id = ?').get(id);
    if (status?.is_system) {
      return res.status(400).json({ error: 'Cannot delete system status' });
    }

    db.prepare('DELETE FROM test_execution_statuses WHERE id = ?').run(id);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting test execution status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Włącz/wyłącz status dla projektu
router.post('/test-execution/project/:projectId/toggle/:statusId', (req: AuthRequest, res) => {
  try {
    const { projectId, statusId } = req.params;
    const { is_enabled } = req.body;

    // Sprawdź czy istnieje wpis
    const existing = db.prepare(`
      SELECT * FROM project_test_execution_statuses 
      WHERE project_id = ? AND status_id = ?
    `).get(projectId, statusId);

    if (existing) {
      db.prepare(`
        UPDATE project_test_execution_statuses 
        SET is_enabled = ?
        WHERE project_id = ? AND status_id = ?
      `).run(is_enabled ? 1 : 0, projectId, statusId);
    } else {
      db.prepare(`
        INSERT INTO project_test_execution_statuses (project_id, status_id, is_enabled)
        VALUES (?, ?, ?)
      `).run(projectId, statusId, is_enabled ? 1 : 0);
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Error toggling project test execution status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// ===== BUG STATUSES =====

// Pobierz wszystkie statusy błędów
router.get('/bug', (req: AuthRequest, res) => {
  try {
    const statuses = db.prepare(`
      SELECT * FROM bug_statuses
      ORDER BY display_order ASC, name ASC
    `).all();
    
    res.json(statuses);
  } catch (error) {
    console.error('Error fetching bug statuses:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Pobierz aktywne statusy dla projektu
router.get('/bug/project/:projectId', (req: AuthRequest, res) => {
  try {
    const { projectId } = req.params;
    
    const statuses = db.prepare(`
      SELECT bs.*, 
             COALESCE(pbs.is_enabled, 1) as is_enabled
      FROM bug_statuses bs
      LEFT JOIN project_bug_statuses pbs 
        ON bs.id = pbs.status_id AND pbs.project_id = ?
      WHERE bs.is_active = 1
      ORDER BY bs.display_order ASC, bs.name ASC
    `).all(projectId);
    
    res.json(statuses);
  } catch (error) {
    console.error('Error fetching project bug statuses:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Utwórz nowy status błędu
router.post('/bug', (req: AuthRequest, res) => {
  try {
    const { name, key, color, description, display_order } = req.body;

    if (!name || !key || !color) {
      return res.status(400).json({ error: 'Name, key and color are required' });
    }

    const result = db.prepare(`
      INSERT INTO bug_statuses (name, key, color, description, is_system, is_active, display_order)
      VALUES (?, ?, ?, ?, 0, 1, ?)
    `).run(name, key, color, description || '', display_order || 999);

    const newStatus = db.prepare('SELECT * FROM bug_statuses WHERE id = ?').get(result.lastInsertRowid);
    res.status(201).json(newStatus);
  } catch (error) {
    console.error('Error creating bug status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Aktualizuj status błędu
router.put('/bug/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    const { name, key, color, description, is_active, display_order } = req.body;

    db.prepare(`
      UPDATE bug_statuses 
      SET name = ?, key = ?, color = ?, description = ?, is_active = ?, display_order = ?
      WHERE id = ?
    `).run(name, key, color, description || '', is_active, display_order, id);

    const updated = db.prepare('SELECT * FROM bug_statuses WHERE id = ?').get(id);
    res.json(updated);
  } catch (error) {
    console.error('Error updating bug status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Usuń status błędu (tylko niestandardowe)
router.delete('/bug/:id', (req: AuthRequest, res) => {
  try {
    const { id } = req.params;
    
    // Sprawdź czy to status systemowy
    const status = db.prepare('SELECT is_system FROM bug_statuses WHERE id = ?').get(id);
    if (status?.is_system) {
      return res.status(400).json({ error: 'Cannot delete system status' });
    }

    db.prepare('DELETE FROM bug_statuses WHERE id = ?').run(id);
    res.status(204).send();
  } catch (error) {
    console.error('Error deleting bug status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

// Włącz/wyłącz status dla projektu
router.post('/bug/project/:projectId/toggle/:statusId', (req: AuthRequest, res) => {
  try {
    const { projectId, statusId } = req.params;
    const { is_enabled } = req.body;

    // Sprawdź czy istnieje wpis
    const existing = db.prepare(`
      SELECT * FROM project_bug_statuses 
      WHERE project_id = ? AND status_id = ?
    `).get(projectId, statusId);

    if (existing) {
      db.prepare(`
        UPDATE project_bug_statuses 
        SET is_enabled = ?
        WHERE project_id = ? AND status_id = ?
      `).run(is_enabled ? 1 : 0, projectId, statusId);
    } else {
      db.prepare(`
        INSERT INTO project_bug_statuses (project_id, status_id, is_enabled)
        VALUES (?, ?, ?)
      `).run(projectId, statusId, is_enabled ? 1 : 0);
    }

    res.json({ success: true });
  } catch (error) {
    console.error('Error toggling project bug status:', error);
    res.status(500).json({ error: 'Internal server error' });
  }
});

export default router;
