import initSqlJs, { Database } from 'sql.js';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

let db: Database;
const dbPath = path.join(__dirname, '../database.db');

async function initDatabase() {
  const SQL = await initSqlJs();
  
  if (fs.existsSync(dbPath)) {
    const buffer = fs.readFileSync(dbPath);
    db = new SQL.Database(buffer);
  } else {
    db = new SQL.Database();
  }
  
  return db;
}

const dbPromise = initDatabase();

dbPromise.then((database) => {
  db = database;
  
  db.exec(`
  CREATE TABLE IF NOT EXISTS roles (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT UNIQUE NOT NULL,
    description TEXT,
    permissions TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    name TEXT NOT NULL,
    role_id INTEGER DEFAULT 4,
    is_active INTEGER DEFAULT 1,
    created_at DATETIME DEFAULT (datetime('now', 'localtime')),
    FOREIGN KEY (role_id) REFERENCES roles(id)
  );

  CREATE TABLE IF NOT EXISTS projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    tag TEXT NOT NULL,
    description TEXT,
    user_id INTEGER NOT NULL,
    project_manager_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (project_manager_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    description TEXT,
    steps TEXT,
    expected_result TEXT,
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'active',
    project_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_case_id INTEGER NOT NULL,
    result TEXT NOT NULL,
    notes TEXT,
    executed_by INTEGER NOT NULL,
    executed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_case_id) REFERENCES test_cases(id),
    FOREIGN KEY (executed_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS user_projects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    project_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    UNIQUE(user_id, project_id)
  );

  CREATE TABLE IF NOT EXISTS requirement_groups (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    project_id INTEGER NOT NULL,
    parent_id INTEGER,
    created_by INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (parent_id) REFERENCES requirement_groups(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS requirements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    requirement_id TEXT UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'draft',
    requirement_group_id INTEGER,
    project_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (requirement_group_id) REFERENCES requirement_groups(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_suites (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    project_id INTEGER NOT NULL,
    parent_id INTEGER,
    created_by INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (parent_id) REFERENCES test_suites(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_specifications (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_case_id TEXT UNIQUE,
    title TEXT NOT NULL,
    description TEXT,
    preconditions TEXT,
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'draft',
    test_suite_id INTEGER,
    display_order INTEGER DEFAULT 0,
    project_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_suite_id) REFERENCES test_suites(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_steps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_specification_id INTEGER NOT NULL,
    step_number INTEGER NOT NULL,
    action TEXT NOT NULL,
    expected_result TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS test_spec_requirements (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_specification_id INTEGER NOT NULL,
    requirement_id INTEGER NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id) ON DELETE CASCADE,
    FOREIGN KEY (requirement_id) REFERENCES requirements(id),
    UNIQUE(test_specification_id, requirement_id)
  );

  CREATE TABLE IF NOT EXISTS defects (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    defect_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    steps_to_reproduce TEXT,
    severity TEXT DEFAULT 'medium',
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'new',
    test_specification_id INTEGER,
    project_id INTEGER NOT NULL,
    reported_by INTEGER NOT NULL,
    assigned_to INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id),
    FOREIGN KEY (project_id) REFERENCES projects(id),
    FOREIGN KEY (reported_by) REFERENCES users(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS tags (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    color TEXT DEFAULT '#3B82F6',
    description TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    UNIQUE(project_id, name)
  );

  CREATE TABLE IF NOT EXISTS requirement_tags (
    requirement_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,
    FOREIGN KEY (requirement_id) REFERENCES requirements(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (requirement_id, tag_id)
  );

  CREATE TABLE IF NOT EXISTS test_specification_tags (
    test_specification_id INTEGER NOT NULL,
    tag_id INTEGER NOT NULL,
    FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id) ON DELETE CASCADE,
    FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE,
    PRIMARY KEY (test_specification_id, tag_id)
  );

  CREATE TABLE IF NOT EXISTS test_plans (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    description TEXT,
    project_id INTEGER NOT NULL,
    created_by INTEGER NOT NULL,
    is_active INTEGER DEFAULT 1,
    start_date DATE,
    end_date DATE,
    test_completion_date DATE,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_plan_cases (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_plan_id INTEGER NOT NULL,
    test_specification_id INTEGER NOT NULL,
    assigned_to INTEGER,
    status TEXT DEFAULT 'NOT_RUN',
    order_index INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_plan_id) REFERENCES test_plans(id) ON DELETE CASCADE,
    FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id) ON DELETE CASCADE,
    FOREIGN KEY (assigned_to) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS bugs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bug_id TEXT,
    title TEXT NOT NULL,
    description TEXT,
    steps_to_reproduce TEXT,
    severity TEXT DEFAULT 'medium',
    priority TEXT DEFAULT 'medium',
    status TEXT DEFAULT 'open',
    test_specification_id INTEGER,
    project_id INTEGER NOT NULL,
    reported_by INTEGER NOT NULL,
    assigned_to INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id),
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (reported_by) REFERENCES users(id),
    FOREIGN KEY (assigned_to) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS bug_comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bug_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    comment TEXT NOT NULL,
    is_reassignment BOOLEAN DEFAULT 0,
    old_assignee_id INTEGER,
    new_assignee_id INTEGER,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (bug_id) REFERENCES bugs(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (old_assignee_id) REFERENCES users(id),
    FOREIGN KEY (new_assignee_id) REFERENCES users(id)
  );

  CREATE TABLE IF NOT EXISTS test_execution_statuses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    key TEXT NOT NULL UNIQUE,
    color TEXT NOT NULL,
    description TEXT,
    is_system BOOLEAN DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    display_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS bug_statuses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    key TEXT NOT NULL UNIQUE,
    color TEXT NOT NULL,
    description TEXT,
    is_system BOOLEAN DEFAULT 0,
    is_active BOOLEAN DEFAULT 1,
    display_order INTEGER DEFAULT 0,
    created_at DATETIME DEFAULT (datetime('now', 'localtime'))
  );

  CREATE TABLE IF NOT EXISTS project_test_execution_statuses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    status_id INTEGER NOT NULL,
    is_enabled BOOLEAN DEFAULT 1,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (status_id) REFERENCES test_execution_statuses(id) ON DELETE CASCADE,
    UNIQUE(project_id, status_id)
  );

  CREATE TABLE IF NOT EXISTS project_bug_statuses (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    project_id INTEGER NOT NULL,
    status_id INTEGER NOT NULL,
    is_enabled BOOLEAN DEFAULT 1,
    FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE CASCADE,
    FOREIGN KEY (status_id) REFERENCES bug_statuses(id) ON DELETE CASCADE,
    UNIQUE(project_id, status_id)
  );

  CREATE TABLE IF NOT EXISTS test_executions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    test_plan_case_id INTEGER NOT NULL,
    executed_by INTEGER NOT NULL,
    status TEXT NOT NULL,
    bug_id INTEGER,
    notes TEXT,
    started_at DATETIME,
    completed_at DATETIME,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (test_plan_case_id) REFERENCES test_plan_cases(id) ON DELETE CASCADE,
    FOREIGN KEY (executed_by) REFERENCES users(id),
    FOREIGN KEY (bug_id) REFERENCES bugs(id)
  );
  `);

  saveDatabase();

  // Tworzenie domyślnych ról
  const rolesExist = db.exec('SELECT id FROM roles LIMIT 1')[0];
  if (!rolesExist || rolesExist.values.length === 0) {
    const defaultRoles = [
      { name: 'Administrator', description: 'Pełny dostęp do systemu', permissions: 'all' },
      { name: 'Test Manager', description: 'Zarządzanie projektami i testami', permissions: 'manage_projects,manage_tests,execute_tests' },
      { name: 'Analityk', description: 'Tworzenie i edycja testów', permissions: 'create_tests,edit_tests,execute_tests' },
      { name: 'Tester', description: 'Wykonywanie testów', permissions: 'execute_tests,view_tests' }
    ];
    
    defaultRoles.forEach(role => {
      db.run(
        'INSERT INTO roles (name, description, permissions) VALUES (?, ?, ?)',
        [role.name, role.description, role.permissions]
      );
    });
    saveDatabase();
    console.log('Default roles created');
  }

  // Migracja: Dodaj kolumnę parent_id do test_suites jeśli nie istnieje
  try {
    const columns = db.exec('PRAGMA table_info(test_suites)')[0];
    const hasParentId = columns?.values.some((col: any) => col[1] === 'parent_id');
    
    if (!hasParentId) {
      console.log('Adding parent_id column to test_suites...');
      db.exec('ALTER TABLE test_suites ADD COLUMN parent_id INTEGER REFERENCES test_suites(id) ON DELETE CASCADE');
      saveDatabase();
      console.log('Migration completed: parent_id column added');
    }
  } catch (error) {
    console.log('Migration check:', error);
  }

  // Migracja: Dodaj kolumny tag i project_manager_id do projects jeśli nie istnieją
  try {
    const projectColumns = db.exec('PRAGMA table_info(projects)')[0];
    const hasTag = projectColumns?.values.some((col: any) => col[1] === 'tag');
    const hasProjectManager = projectColumns?.values.some((col: any) => col[1] === 'project_manager_id');
    
    if (!hasTag) {
      console.log('Adding tag column to projects...');
      db.exec('ALTER TABLE projects ADD COLUMN tag TEXT DEFAULT "PROJ"');
      saveDatabase();
      console.log('Migration completed: tag column added');
    }
    
    if (!hasProjectManager) {
      console.log('Adding project_manager_id column to projects...');
      db.exec('ALTER TABLE projects ADD COLUMN project_manager_id INTEGER REFERENCES users(id)');
      // Ustaw domyślnie user_id jako project_manager_id dla istniejących projektów
      db.exec('UPDATE projects SET project_manager_id = user_id WHERE project_manager_id IS NULL');
      saveDatabase();
      console.log('Migration completed: project_manager_id column added');
    }
  } catch (error) {
    console.log('Migration check for projects:', error);
  }

  // Migracja: Dodaj kolumnę is_active do test_plans jeśli nie istnieje
  try {
    const planColumns = db.exec('PRAGMA table_info(test_plans)')[0];
    const hasIsActive = planColumns?.values.some((col: any) => col[1] === 'is_active');
    const hasStartDate = planColumns?.values.some((col: any) => col[1] === 'start_date');
    const hasEndDate = planColumns?.values.some((col: any) => col[1] === 'end_date');
    
    if (!hasIsActive) {
      console.log('Adding is_active column to test_plans...');
      db.exec('ALTER TABLE test_plans ADD COLUMN is_active INTEGER DEFAULT 1');
      saveDatabase();
      console.log('Migration completed: is_active column added to test_plans');
    }
    
    if (!hasStartDate) {
      console.log('Adding start_date column to test_plans...');
      db.exec('ALTER TABLE test_plans ADD COLUMN start_date DATE');
      saveDatabase();
      console.log('Migration completed: start_date column added to test_plans');
    }
    
    if (!hasEndDate) {
      console.log('Adding end_date column to test_plans...');
      db.exec('ALTER TABLE test_plans ADD COLUMN end_date DATE');
      saveDatabase();
      console.log('Migration completed: end_date column added to test_plans');
    }
  } catch (error) {
    console.log('Migration check for test_plans:', error);
  }

  // Migracja: Dodaj kolumnę test_case_id do test_specifications jeśli nie istnieje
  try {
    const specColumns = db.exec('PRAGMA table_info(test_specifications)')[0];
    const hasTestCaseId = specColumns?.values.some((col: any) => col[1] === 'test_case_id');
    
    if (!hasTestCaseId) {
      console.log('Adding test_case_id column to test_specifications...');
      db.exec('ALTER TABLE test_specifications ADD COLUMN test_case_id TEXT UNIQUE');
      saveDatabase();
      console.log('Migration completed: test_case_id column added');
    }
  } catch (error) {
    console.log('Migration check for test_specifications:', error);
  }

  // Migracja: Dodaj kolumnę display_order do test_specifications jeśli nie istnieje
  try {
    const specColumns = db.exec('PRAGMA table_info(test_specifications)')[0];
    const hasDisplayOrder = specColumns?.values.some((col: any) => col[1] === 'display_order');
    
    if (!hasDisplayOrder) {
      console.log('Adding display_order column to test_specifications...');
      db.exec('ALTER TABLE test_specifications ADD COLUMN display_order INTEGER DEFAULT 0');
      saveDatabase();
      console.log('Migration completed: display_order column added');
    }
  } catch (error) {
    console.log('Migration check for display_order:', error);
  }

  // Migracja: Dodaj kolumnę requirement_group_id do requirements jeśli nie istnieje
  try {
    const reqColumns = db.exec('PRAGMA table_info(requirements)')[0];
    const hasGroupId = reqColumns?.values.some((col: any) => col[1] === 'requirement_group_id');
    
    if (!hasGroupId) {
      console.log('Adding requirement_group_id column to requirements...');
      db.exec('ALTER TABLE requirements ADD COLUMN requirement_group_id INTEGER REFERENCES requirement_groups(id)');
      saveDatabase();
      console.log('Migration completed: requirement_group_id column added');
    }
  } catch (error) {
    console.log('Migration check for requirement_group_id:', error);
  }

  // Migracja: Dodaj kolumnę requirement_id do requirements jeśli nie istnieje
  try {
    const reqColumns = db.exec('PRAGMA table_info(requirements)')[0];
    const hasReqId = reqColumns?.values.some((col: any) => col[1] === 'requirement_id');
    
    if (!hasReqId) {
      console.log('Adding requirement_id column to requirements...');
      db.exec('ALTER TABLE requirements ADD COLUMN requirement_id TEXT UNIQUE');
      saveDatabase();
      console.log('Migration completed: requirement_id column added');
    }
  } catch (error) {
    console.log('Migration check for requirement_id:', error);
  }

  // Migracja: Dodaj kolumnę defect_id do defects jeśli nie istnieje
  try {
    const defectColumns = db.exec('PRAGMA table_info(defects)')[0];
    const hasDefectId = defectColumns?.values.some((col: any) => col[1] === 'defect_id');
    
    if (!hasDefectId) {
      console.log('Adding defect_id column to defects...');
      db.exec('ALTER TABLE defects ADD COLUMN defect_id TEXT');
      saveDatabase();
      console.log('Migration completed: defect_id column added');
    }
  } catch (error) {
    console.log('Migration check for defect_id:', error);
  }

  // Migracja: Dodaj kolumny steps_to_reproduce, priority i test_specification_id do bugs jeśli nie istnieją
  try {
    const bugColumns = db.exec('PRAGMA table_info(bugs)')[0];
    const hasSteps = bugColumns?.values.some((col: any) => col[1] === 'steps_to_reproduce');
    const hasPriority = bugColumns?.values.some((col: any) => col[1] === 'priority');
    const hasTestSpecId = bugColumns?.values.some((col: any) => col[1] === 'test_specification_id');
    
    if (!hasSteps) {
      console.log('Adding steps_to_reproduce column to bugs...');
      db.exec('ALTER TABLE bugs ADD COLUMN steps_to_reproduce TEXT');
      saveDatabase();
      console.log('Migration completed: steps_to_reproduce column added');
    }
    
    if (!hasPriority) {
      console.log('Adding priority column to bugs...');
      db.exec('ALTER TABLE bugs ADD COLUMN priority TEXT DEFAULT "medium"');
      saveDatabase();
      console.log('Migration completed: priority column added');
    }
    
    if (!hasTestSpecId) {
      console.log('Adding test_specification_id column to bugs...');
      db.exec('ALTER TABLE bugs ADD COLUMN test_specification_id INTEGER REFERENCES test_specifications(id)');
      saveDatabase();
      console.log('Migration completed: test_specification_id column added');
    }
  } catch (error) {
    console.log('Migration check for bugs columns:', error);
  }

  // Tworzenie domyślnego administratora
  const adminExists = db.exec('SELECT id FROM users WHERE email = "admin@test.com"')[0];
  if (!adminExists || adminExists.values.length === 0) {
    const hashedPassword = bcrypt.hashSync('admin123', 10);
    db.run(
      'INSERT INTO users (email, password, name, role_id, is_active) VALUES (?, ?, ?, ?, ?)',
      ['admin@test.com', hashedPassword, 'Administrator', 1, 1]
    );
    saveDatabase();
    console.log('Default admin user created');
  }

  // Dodaj domyślne statusy wykonania testów
  const testExecutionStatusesExist = db.exec('SELECT COUNT(*) as count FROM test_execution_statuses');
  if (!testExecutionStatusesExist || testExecutionStatusesExist[0]?.values[0][0] === 0) {
    const defaultTestStatuses = [
      { name: 'Passed', key: 'passed', color: '#10b981', description: 'Test zakończony sukcesem', is_system: 1, display_order: 1 },
      { name: 'Failed', key: 'failed', color: '#ef4444', description: 'Test zakończony niepowodzeniem', is_system: 1, display_order: 2 },
      { name: 'Blocked', key: 'blocked', color: '#f59e0b', description: 'Test zablokowany', is_system: 1, display_order: 3 },
      { name: 'Skipped', key: 'skipped', color: '#6b7280', description: 'Test pominięty', is_system: 1, display_order: 4 }
    ];
    
    defaultTestStatuses.forEach(status => {
      db.run(
        'INSERT INTO test_execution_statuses (name, key, color, description, is_system, is_active, display_order) VALUES (?, ?, ?, ?, ?, 1, ?)',
        [status.name, status.key, status.color, status.description, status.is_system, status.display_order]
      );
    });
    saveDatabase();
    console.log('Default test execution statuses created');
  }

  // Dodaj domyślne statusy błędów
  const bugStatusesExist = db.exec('SELECT COUNT(*) as count FROM bug_statuses');
  if (!bugStatusesExist || bugStatusesExist[0]?.values[0][0] === 0) {
    const defaultBugStatuses = [
      { name: 'Nowy', key: 'new', color: '#8b5cf6', description: 'Nowy błąd', is_system: 1, display_order: 1 },
      { name: 'Otwarty', key: 'open', color: '#3b82f6', description: 'Błąd otwarty', is_system: 1, display_order: 2 },
      { name: 'W trakcie', key: 'in_progress', color: '#f59e0b', description: 'Błąd w trakcie naprawy', is_system: 1, display_order: 3 },
      { name: 'Rozwiązany', key: 'resolved', color: '#10b981', description: 'Błąd rozwiązany', is_system: 1, display_order: 4 },
      { name: 'Zamknięty', key: 'closed', color: '#6b7280', description: 'Błąd zamknięty', is_system: 1, display_order: 5 },
      { name: 'Odrzucony', key: 'rejected', color: '#ef4444', description: 'Błąd odrzucony', is_system: 0, display_order: 6 }
    ];
    
    defaultBugStatuses.forEach(status => {
      db.run(
        'INSERT INTO bug_statuses (name, key, color, description, is_system, is_active, display_order) VALUES (?, ?, ?, ?, ?, 1, ?)',
        [status.name, status.key, status.color, status.description, status.is_system, status.display_order]
      );
    });
    saveDatabase();
    console.log('Default bug statuses created');
  }
  
  console.log('Database initialized successfully');
}).catch(error => {
  console.error('Database initialization error:', error);
});

function saveDatabase() {
  if (db) {
    const data = db.export();
    fs.writeFileSync(dbPath, data);
  }
}

function query(sql: string, params: any[] = []): any[] {
  if (!db) return [];
  const stmt = db.prepare(sql);
  stmt.bind(params);
  const results: any[] = [];
  while (stmt.step()) {
    results.push(stmt.getAsObject());
  }
  stmt.free();
  return results;
}

function run(sql: string, params: any[] = []): any {
  if (!db) return { lastInsertRowid: 0 };
  try {
    const stmt = db.prepare(sql);
    stmt.bind(params);
    stmt.step();
    stmt.free();
    const lastId = query('SELECT last_insert_rowid() as id')[0]?.id || 0;
    saveDatabase();
    return {
      lastInsertRowid: lastId
    };
  } catch (error) {
    console.error('Database run error:', error);
    throw error;
  }
}

function get(sql: string, params: any[] = []): any {
  const results = query(sql, params);
  return results[0] || null;
}

function all(sql: string, params: any[] = []): any[] {
  return query(sql, params);
}

// Migracja: dodaj kolumnę test_completion_date jeśli nie istnieje
dbPromise.then(() => {
  try {
    // Sprawdź czy kolumna istnieje
    const tableInfo: any[] = query('PRAGMA table_info(test_plans)', []);
    const hasTestCompletionDate = tableInfo.some((col: any) => col.name === 'test_completion_date');
    
    if (!hasTestCompletionDate) {
      console.log('Adding test_completion_date column to test_plans table...');
      db.exec('ALTER TABLE test_plans ADD COLUMN test_completion_date DATE');
      saveDatabase();
      console.log('Migration completed successfully - test_completion_date column added');
    } else {
      console.log('test_completion_date column already exists');
    }
  } catch (error) {
    console.error('Migration error:', error);
  }
});

export default {
  prepare: (sql: string) => ({
    get: (...params: any[]) => get(sql, params),
    all: (...params: any[]) => all(sql, params),
    run: (...params: any[]) => run(sql, params)
  }),
  exec: (sql: string) => db?.exec(sql)
};
