// Prosty test bazy danych
const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

const dbPath = path.join(__dirname, 'database.db');

async function testDatabase() {
  try {
    const SQL = await initSqlJs();
    
    if (!fs.existsSync(dbPath)) {
      console.log('❌ Database file does not exist!');
      return;
    }
    
    const buffer = fs.readFileSync(dbPath);
    const db = new SQL.Database(buffer);
    
    console.log('✅ Database loaded successfully\n');
    
    // Test 1: Check roles
    console.log('📋 Roles:');
    const rolesStmt = db.prepare('SELECT * FROM roles');
    while (rolesStmt.step()) {
      const role = rolesStmt.getAsObject();
      console.log('  -', role);
    }
    rolesStmt.free();
    
    // Test 2: Check users
    console.log('\n👥 Users:');
    const usersStmt = db.prepare(`
      SELECT u.id, u.email, u.name, u.is_active, r.name as role_name
      FROM users u
      LEFT JOIN roles r ON u.role_id = r.id
    `);
    while (usersStmt.step()) {
      const user = usersStmt.getAsObject();
      console.log('  -', user);
    }
    usersStmt.free();
    
    db.close();
    console.log('\n✅ Database test completed');
    
  } catch (error) {
    console.error('❌ Database test failed:', error);
  }
}

testDatabase();
