# Feature - Automatyczne tworzenie zestawów testowych podczas importu CSV

## Opis
Podczas importu przypadków testowych z CSV, jeśli zestaw testowy podany w kolumnie "Zestaw testowy" nie istnieje w projekcie, zostanie automatycznie utworzony.

## Implementacja

### Logika tworzenia zestawów (`TestSpecifications.tsx`)

#### Przed:
```typescript
// Znajdź zestaw testowy po nazwie
let suiteId = null;
if (tc.suite_name) {
  const suite = projectSuites.find(s => s.name === tc.suite_name);
  suiteId = suite?.id || null; // null jeśli nie znaleziono
}
```

**Problem:** TC był tworzony bez zestawu jeśli zestaw nie istniał.

#### Po:
```typescript
// Znajdź lub utwórz zestaw testowy
let suiteId = null;
if (tc.suite_name) {
  let suite = projectSuites.find(s => s.name === tc.suite_name);
  if (!suite) {
    // Utwórz nowy zestaw testowy
    const newSuiteRes = await testSuites.create({
      name: tc.suite_name,
      description: `Automatycznie utworzony podczas importu CSV`,
      project_id: selectedProject!.id,
      parent_id: null
    });
    suite = newSuiteRes.data;
    projectSuites.push(suite); // Dodaj do listy
    createdSuites++;
  }
  suiteId = suite?.id || null;
}
```

**Rozwiązanie:** Zestaw jest tworzony automatycznie jeśli nie istnieje.

### Nowy licznik i komunikat

```typescript
let createdSuites = 0;

// Po imporcie:
if (createdSuites > 0) {
  toast.success(`📁 Utworzono ${createdSuites} nowych zestawów testowych`);
}
```

## Scenariusze użycia

### Scenariusz 1: Import TC z istniejącym zestawem

**CSV:**
```csv
ID TC,Tytuł,...,Zestaw testowy,...
PT1-001,Test 1,...,Logowanie,...
```

**Rezultat:**
- Zestaw "Logowanie" istnieje → TC przypisany do istniejącego zestawu
- Komunikat: `✅ Utworzono 1 nowych przypadków testowych`

### Scenariusz 2: Import TC z nowym zestawem

**CSV:**
```csv
ID TC,Tytuł,...,Zestaw testowy,...
PT1-002,Test 2,...,Nowy Moduł API,...
```

**Rezultat:**
- Zestaw "Nowy Moduł API" nie istnieje → **utworzony automatycznie**
- TC przypisany do nowo utworzonego zestawu
- Komunikaty:
  ```
  ✅ Utworzono 1 nowych przypadków testowych
  📁 Utworzono 1 nowych zestawów testowych
  ```

### Scenariusz 3: Import wielu TC z różnymi zestawami

**CSV:**
```csv
ID TC,Tytuł,...,Zestaw testowy,...
PT1-003,Test 3,...,Logowanie,...         ← istnieje
PT1-004,Test 4,...,Nowy Moduł,...        ← nowy
PT1-005,Test 5,...,Nowy Moduł,...        ← już utworzony w tym imporcie
PT1-006,Test 6,...,Inny Nowy Moduł,...   ← nowy
```

**Rezultat:**
- Zestaw "Logowanie" → użyty istniejący
- Zestaw "Nowy Moduł" → utworzony (raz)
- Zestaw "Nowy Moduł" → użyty już utworzony w tym samym imporcie
- Zestaw "Inny Nowy Moduł" → utworzony
- Komunikaty:
  ```
  ✅ Utworzono 4 nowych przypadków testowych
  📁 Utworzono 2 nowych zestawów testowych
  ```

### Scenariusz 4: Import TC bez zestawu

**CSV:**
```csv
ID TC,Tytuł,...,Zestaw testowy,...
PT1-007,Test 7,...,,...
PT1-008,Test 8,...,Bez zestawu,...
```

**Rezultat:**
- Puste pole → TC bez zestawu
- "Bez zestawu" → TC bez zestawu (specjalna wartość)
- Komunikat: `✅ Utworzono 2 nowych przypadków testowych`

## Właściwości utworzonych zestawów

### Dane zestawu:
```typescript
{
  name: "Nazwa z CSV",
  description: "Automatycznie utworzony podczas importu CSV",
  project_id: [ID projektu],
  parent_id: null  // Zawsze główny poziom
}
```

### Charakterystyka:
- ✅ **Nazwa** - dokładnie taka jak w CSV
- ✅ **Opis** - automatyczny opis informujący o źródle
- ✅ **Poziom** - zawsze główny poziom (parent_id = null)
- ✅ **Projekt** - przypisany do aktualnego projektu

## Deduplikacja zestawów

Parser sprawdza czy zestaw już istnieje **przed każdym TC**:

```typescript
let suite = projectSuites.find(s => s.name === tc.suite_name);
if (!suite) {
  // Utwórz tylko jeśli nie znaleziono
  suite = await testSuites.create(...);
  projectSuites.push(suite); // Dodaj do listy lokalnej
}
```

**Korzyści:**
- Jeśli wiele TC ma ten sam nowy zestaw → zestaw tworzony **tylko raz**
- Nowo utworzone zestawy są dodawane do lokalnej listy
- Kolejne TC w tym samym imporcie używają już utworzonego zestawu

## Przykład importu

### CSV:
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-010,Test API 1,Opis,Warunki,1,Akcja,Rezultat,Wysoki,Szkic,API Tests,WYM-001,Backend
PT1-011,Test API 2,Opis,Warunki,1,Akcja,Rezultat,Wysoki,Szkic,API Tests,WYM-001,Backend
PT1-012,Test UI 1,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,UI Tests,WYM-002,Frontend
```

### Przed importem:
- Zestawy: Logowanie, Rejestracja

### Po imporcie:
- Zestawy: Logowanie, Rejestracja, **API Tests**, **UI Tests**
- TC PT1-010 → w zestawie "API Tests"
- TC PT1-011 → w zestawie "API Tests" (ten sam)
- TC PT1-012 → w zestawie "UI Tests"

### Komunikaty:
```
✅ Utworzono 3 nowych przypadków testowych
📁 Utworzono 2 nowych zestawów testowych
```

## Integracja z innymi funkcjami

### Tagi:
- ✅ Tagi są tworzone automatycznie (już działało)
- ✅ Zestawy są tworzone automatycznie (NOWE)

### Wymagania:
- ❌ Wymagania NIE są tworzone automatycznie
- Powiązanie pomijane jeśli wymaganie nie istnieje

### Podsumowanie automatycznego tworzenia:
| Element | Tworzony automatycznie? |
|---------|------------------------|
| Tagi | ✅ TAK |
| Zestawy testowe | ✅ TAK (NOWE) |
| Wymagania | ❌ NIE |

## Korzyści

✅ **Wygoda** - nie trzeba ręcznie tworzyć zestawów przed importem
✅ **Szybkość** - import działa od razu, bez przygotowania
✅ **Migracja** - łatwe przenoszenie TC z innych systemów
✅ **Organizacja** - TC automatycznie grupowane w zestawy
✅ **Deduplikacja** - ten sam zestaw nie jest tworzony wielokrotnie

## Edycja utworzonych zestawów

Po imporcie możesz:
1. Zmienić opis zestawu (domyślny: "Automatycznie utworzony...")
2. Przenieść zestaw do innego zestawu nadrzędnego
3. Dodać więcej TC do zestawu
4. Zmienić nazwę zestawu

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Automatyczne tworzenie zestawów testowych
  - Licznik `createdSuites`
  - Komunikat o utworzonych zestawach
  - Dodawanie nowych zestawów do lokalnej listy

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
