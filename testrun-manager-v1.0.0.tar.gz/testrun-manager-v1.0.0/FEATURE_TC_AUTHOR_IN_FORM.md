# Feature - Wyświetlanie autora w formularzu TC

## Opis
Dodano wyświetlanie informacji o autorze w formularzu tworzenia/edycji przypadku testowego:
- **Nowy TC:** Informacja że zalogowany użytkownik zostanie autorem
- **Edycja TC:** Wyświetlenie obecnego autora (tylko do odczytu)

## Implementacja

### 1. Import funkcji getUser

```typescript
import { getUser } from '../lib/auth';
```

**Funkcja `getUser()`:**
- Pobiera dane zalogowanego użytkownika z `localStorage`
- Zwraca obiekt użytkownika z polem `name`

### 2. Pole autora w formularzu

**Lokalizacja:** Po TagSelector, przed przyciskami Zapisz/Anuluj

```tsx
{/* Informacja o autorze */}
<div className="bg-blue-50 border border-blue-200 rounded-md p-3">
  <div className="flex items-center gap-2">
    <span className="text-sm font-medium text-blue-900">
      {selectedSpec ? 'Autor:' : 'Zostaniesz autorem tego przypadku testowego:'}
    </span>
    <span className="text-sm text-blue-700 font-semibold">
      {selectedSpec?.created_by_name || getUser()?.name || 'Nieznany'}
    </span>
  </div>
  {!selectedSpec && (
    <p className="text-xs text-blue-600 mt-1">
      Twoje imię i nazwisko zostanie automatycznie przypisane jako autor.
    </p>
  )}
</div>
```

### 3. Logika wyświetlania

**Tryb tworzenia (nowy TC):**
```typescript
selectedSpec === null
↓
Etykieta: "Zostaniesz autorem tego przypadku testowego:"
Wartość: getUser()?.name (zalogowany użytkownik)
Podpowiedź: "Twoje imię i nazwisko zostanie automatycznie przypisane jako autor."
```

**Tryb edycji (istniejący TC):**
```typescript
selectedSpec !== null
↓
Etykieta: "Autor:"
Wartość: selectedSpec.created_by_name (obecny autor)
Podpowiedź: brak (autor nie zmienia się przy edycji)
```

## Wygląd UI

### Nowy TC:
```
┌─────────────────────────────────────────────────────────┐
│ Tagi                                                    │
│ [Backend] [API]                                         │
├─────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────┐ │
│ │ Zostaniesz autorem tego przypadku testowego:        │ │
│ │ Jan Kowalski                                        │ │
│ │                                                     │ │
│ │ Twoje imię i nazwisko zostanie automatycznie        │ │
│ │ przypisane jako autor.                              │ │
│ └─────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────┤
│                                      [Anuluj] [Utwórz]  │
└─────────────────────────────────────────────────────────┘
```

### Edycja TC:
```
┌─────────────────────────────────────────────────────────┐
│ Tagi                                                    │
│ [Backend] [API]                                         │
├─────────────────────────────────────────────────────────┤
│ ┌─────────────────────────────────────────────────────┐ │
│ │ Autor: Jan Kowalski                                 │ │
│ └─────────────────────────────────────────────────────┘ │
├─────────────────────────────────────────────────────────┤
│                                      [Anuluj] [Zapisz]  │
└─────────────────────────────────────────────────────────┘
```

## Stylowanie

### Kontener:
- **Tło:** `bg-blue-50` (jasnoniebieski)
- **Ramka:** `border border-blue-200` (niebieska)
- **Zaokrąglenie:** `rounded-md`
- **Padding:** `p-3`

### Etykieta:
- **Rozmiar:** `text-sm`
- **Waga:** `font-medium`
- **Kolor:** `text-blue-900` (ciemnoniebieski)

### Wartość (imię autora):
- **Rozmiar:** `text-sm`
- **Waga:** `font-semibold` (pogrubiona)
- **Kolor:** `text-blue-700` (niebieski)

### Podpowiedź:
- **Rozmiar:** `text-xs` (mały)
- **Kolor:** `text-blue-600`
- **Margines:** `mt-1` (margines górny)

## Przykłady użycia

### Scenariusz 1: Tworzenie nowego TC

**Akcja:** Kliknij "Dodaj przypadek"

**Formularz:**
```
┌─────────────────────────────────────┐
│ Nowy przypadek testowy              │
├─────────────────────────────────────┤
│ Tytuł: [Test logowania]            │
│ Opis: [...]                         │
│ ...                                 │
│ Tagi: [Backend]                     │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ Zostaniesz autorem tego         │ │
│ │ przypadku testowego:            │ │
│ │ Jan Kowalski                    │ │
│ │                                 │ │
│ │ Twoje imię i nazwisko zostanie  │ │
│ │ automatycznie przypisane jako   │ │
│ │ autor.                          │ │
│ └─────────────────────────────────┘ │
│                                     │
│                  [Anuluj] [Utwórz]  │
└─────────────────────────────────────┘
```

**Rezultat po kliknięciu "Utwórz":**
- TC utworzony z `created_by` = ID zalogowanego użytkownika
- `created_by_name` = "Jan Kowalski"

### Scenariusz 2: Edycja istniejącego TC

**Akcja:** Kliknij ikonę edycji przy TC

**Formularz:**
```
┌─────────────────────────────────────┐
│ Edytuj przypadek testowy            │
├─────────────────────────────────────┤
│ Tytuł: [Test logowania]            │
│ Opis: [...]                         │
│ ...                                 │
│ Tagi: [Backend]                     │
│                                     │
│ ┌─────────────────────────────────┐ │
│ │ Autor: Jan Kowalski             │ │
│ └─────────────────────────────────┘ │
│                                     │
│                  [Anuluj] [Zapisz]  │
└─────────────────────────────────────┘
```

**Rezultat po kliknięciu "Zapisz":**
- TC zaktualizowany
- `created_by` i `created_by_name` **nie zmieniają się** (pozostaje oryginalny autor)

### Scenariusz 3: Edycja TC przez innego użytkownika

**TC stworzony przez:** Jan Kowalski
**Edytuje:** Anna Nowak (zalogowana)

**Formularz:**
```
┌─────────────────────────────────────┐
│ Edytuj przypadek testowy            │
├─────────────────────────────────────┤
│ ...                                 │
│ ┌─────────────────────────────────┐ │
│ │ Autor: Jan Kowalski             │ │ ← Oryginalny autor
│ └─────────────────────────────────┘ │
│                                     │
│                  [Anuluj] [Zapisz]  │
└─────────────────────────────────────┘
```

**Rezultat:**
- Anna Nowak może edytować TC
- Autor pozostaje: Jan Kowalski (nie zmienia się na Anna Nowak)

## Różnice między trybami

| Aspekt | Nowy TC | Edycja TC |
|--------|---------|-----------|
| **Etykieta** | "Zostaniesz autorem..." | "Autor:" |
| **Wartość** | Zalogowany użytkownik | Oryginalny autor |
| **Podpowiedź** | Tak (informacja) | Nie |
| **Edytowalność** | Nie (automatyczne) | Nie (tylko odczyt) |
| **Zmiana autora** | Nie dotyczy | Niemożliwa |

## Zachowanie autora

### Tworzenie:
```
Użytkownik: Jan Kowalski (ID: 1)
↓
Backend: created_by = 1
↓
Baza danych: created_by = 1, created_by_name = "Jan Kowalski"
```

### Edycja:
```
Oryginalny autor: Jan Kowalski (ID: 1)
Edytuje: Anna Nowak (ID: 2)
↓
Backend: created_by pozostaje = 1 (nie zmienia się)
↓
Baza danych: created_by = 1, created_by_name = "Jan Kowalski" (bez zmian)
```

## Fallback dla brakujących danych

### Nowy TC - brak danych użytkownika:
```typescript
getUser()?.name || 'Nieznany'
```

**Jeśli:**
- `getUser()` zwraca `null` → "Nieznany"
- `getUser().name` jest puste → "Nieznany"

### Edycja TC - brak autora:
```typescript
selectedSpec?.created_by_name || getUser()?.name || 'Nieznany'
```

**Jeśli:**
- `created_by_name` jest puste → użyj zalogowanego użytkownika
- Zalogowany użytkownik brak → "Nieznany"

## Integracja z istniejącymi funkcjami

### Formularz już wyświetla:
1. Tytuł
2. Opis
3. Warunki wstępne
4. Kroki testowe
5. Powiązane wymagania
6. Zestaw testowy
7. Priorytet
8. Status
9. Tagi

### Nowe pole autora:
10. **Autor** ← NOWE (po tagach, przed przyciskami)

## Korzyści

### ✅ Przejrzystość:
- Użytkownik wie że zostanie autorem
- Jasna informacja w formularzu

### ✅ Edukacja:
- Nowi użytkownicy rozumieją mechanizm autorstwa
- Podpowiedź wyjaśnia automatyczne przypisanie

### ✅ Kontrola:
- Przy edycji widać oryginalnego autora
- Brak możliwości przypadkowej zmiany autora

### ✅ Spójność:
- Pole autora w formularzu
- Pole autora w podglądzie
- Pole autora w liście TC
- Pole autora w CSV

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Import `getUser` z `../lib/auth`
  - Dodanie pola autora w formularzu (linia 1198-1213)

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
