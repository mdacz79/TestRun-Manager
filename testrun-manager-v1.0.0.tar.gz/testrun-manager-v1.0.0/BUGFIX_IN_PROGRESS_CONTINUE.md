# Bugfix - Niemożność Kontynuowania Testu IN_PROGRESS

## Problem

Gdy przypadek testowy był w statusie "W trakcie" (IN_PROGRESS), nie można było do niego wrócić aby zmienić status. Przycisk był nieaktywny (disabled) i pokazywał "W trakcie".

**Zrzut ekranu problemu:**
- Status: "W trakcie" (niebieski badge)
- Przycisk: "W trakcie" (szary, nieaktywny)
- Użytkownik nie mógł kliknąć aby dokończyć test

## Przyczyna

1. **Przycisk disabled** - Gdy `testCase.status === 'IN_PROGRESS'`, przycisk był wyłączony
2. **Brak logiki kontynuacji** - Funkcja `handleStartTest` zawsze próbowała utworzyć nowe wykonanie
3. **Brak dostępu do istniejącego wykonania** - Nie było sposobu aby pobrać aktywne wykonanie

```typescript
// PRZED (błędny kod):
<button
  onClick={() => handleStartTest(testCase)}
  disabled={testCase.status === 'IN_PROGRESS'}  // ← Przycisk wyłączony!
  className="... disabled:bg-gray-400"
>
  {testCase.status === 'IN_PROGRESS' ? 'W trakcie' : 'Wykonaj'}
</button>
```

## Rozwiązanie

### 1. Zmiana Logiki handleStartTest

Dodano sprawdzenie - jeśli test jest IN_PROGRESS, pobierz istniejące wykonanie zamiast tworzyć nowe:

```typescript
const handleStartTest = async (testCase: any) => {
  try {
    // Jeśli test jest już IN_PROGRESS, pobierz istniejące wykonanie
    if (testCase.status === 'IN_PROGRESS') {
      // Pobierz historię i znajdź ostatnie IN_PROGRESS wykonanie
      const historyRes = await testExecutions.getHistory(testCase.id);
      const inProgressExecution = historyRes.data.find((exec: any) => exec.status === 'IN_PROGRESS');
      
      if (inProgressExecution) {
        setCurrentExecution(inProgressExecution);
        setSelectedTestCase(testCase);
        setShowExecuteModal(true);
        return;  // ← Nie twórz nowego wykonania
      }
    }
    
    // W przeciwnym razie rozpocznij nowe wykonanie
    const res = await testExecutions.start(testCase.id);
    setCurrentExecution(res.data);
    setSelectedTestCase(testCase);
    setShowExecuteModal(true);
    loadPlanDetails(selectedPlan.id);
  } catch (error) {
    console.error('Error starting test:', error);
    toast.error('❌ Błąd podczas rozpoczynania testu');
  }
};
```

**Przepływ:**
```
1. Sprawdź czy status === 'IN_PROGRESS'
   ↓ TAK
2. Pobierz historię wykonań (GET /api/test-executions/history/:id)
3. Znajdź wykonanie ze statusem 'IN_PROGRESS'
4. Ustaw jako currentExecution
5. Otwórz modal
   ↓ NIE
6. Utwórz nowe wykonanie (POST /api/test-executions/start)
7. Otwórz modal
```

### 2. Usunięcie disabled z Przycisku

Przycisk jest teraz zawsze aktywny, zmienia tylko kolor i tekst:

```typescript
<button
  onClick={() => handleStartTest(testCase)}
  className={`inline-flex items-center px-3 py-1 text-white rounded text-sm ${
    testCase.status === 'IN_PROGRESS' 
      ? 'bg-blue-600 hover:bg-blue-700'   // ← Niebieski dla IN_PROGRESS
      : 'bg-green-600 hover:bg-green-700'  // ← Zielony dla innych
  }`}
>
  <Play className="h-3 w-3 mr-1" />
  {testCase.status === 'IN_PROGRESS' ? 'Kontynuuj' : 'Wykonaj'}
</button>
```

**Zmiany:**
- ❌ Usunięto: `disabled={testCase.status === 'IN_PROGRESS'}`
- ❌ Usunięto: `disabled:bg-gray-400`
- ✅ Dodano: Dynamiczny kolor (niebieski dla IN_PROGRESS, zielony dla innych)
- ✅ Zmieniono: Tekst z "W trakcie" na "Kontynuuj"

## Wygląd UI

### Przed (Problem):
```
┌─────────────────────────────────────────────────┐
│ ⏱️ PT1-003  [W trakcie]                        │
│ Test 4                                          │
│ 👤 Jan Kowalski                                 │
│ [📜] [👤 dropdown] [W trakcie] ← SZARY, DISABLED│
└─────────────────────────────────────────────────┘
```

### Po (Naprawione):
```
┌─────────────────────────────────────────────────┐
│ ⏱️ PT1-003  [W trakcie]                        │
│ Test 4                                          │
│ 👤 Jan Kowalski                                 │
│ [📜] [👤 dropdown] [▶️ Kontynuuj] ← NIEBIESKI, AKTYWNY│
└─────────────────────────────────────────────────┘
```

## Przepływ Użytkownika

### Scenariusz 1: Rozpoczęcie Nowego Testu
```
1. Test ma status NOT_RUN (📋)
2. Przycisk: "Wykonaj" (zielony)
3. Kliknij → Tworzy nowe wykonanie
4. Status zmienia się na IN_PROGRESS (⏱️)
5. Modal się otwiera
```

### Scenariusz 2: Kontynuacja Testu IN_PROGRESS
```
1. Test ma status IN_PROGRESS (⏱️)
2. Przycisk: "Kontynuuj" (niebieski)
3. Kliknij → Pobiera istniejące wykonanie
4. Modal się otwiera z tym samym wykonaniem
5. Użytkownik może dokończyć test
```

### Scenariusz 3: Ponowne Wykonanie Zakończonego Testu
```
1. Test ma status PASSED/FAILED/SKIPPED/BLOCKED
2. Przycisk: "Wykonaj" (zielony)
3. Kliknij → Tworzy NOWE wykonanie
4. Status zmienia się na IN_PROGRESS
5. Modal się otwiera
6. Poprzednie wykonanie pozostaje w historii
```

## Kolory Przycisków

| Status | Kolor | Tekst | Akcja |
|--------|-------|-------|-------|
| NOT_RUN | 🟢 Zielony | Wykonaj | Nowe wykonanie |
| IN_PROGRESS | 🔵 Niebieski | Kontynuuj | Istniejące wykonanie |
| PASSED | 🟢 Zielony | Wykonaj | Nowe wykonanie |
| FAILED | 🟢 Zielony | Wykonaj | Nowe wykonanie |
| SKIPPED | 🟢 Zielony | Wykonaj | Nowe wykonanie |
| BLOCKED | 🟢 Zielony | Wykonaj | Nowe wykonanie |

## Testowanie

### Test 1: Kontynuacja testu IN_PROGRESS
```
1. Rozpocznij test (status → IN_PROGRESS)
2. Zamknij modal (Anuluj)
3. Sprawdź czy przycisk pokazuje "Kontynuuj" (niebieski)
4. Kliknij "Kontynuuj"
5. Sprawdź czy modal się otwiera
6. Sprawdź czy to to samo wykonanie (execution_id)
7. Dokończ test
```

### Test 2: Rozpoczęcie nowego testu
```
1. Test ma status NOT_RUN
2. Sprawdź czy przycisk pokazuje "Wykonaj" (zielony)
3. Kliknij "Wykonaj"
4. Sprawdź czy tworzy się nowe wykonanie
5. Sprawdź czy status zmienia się na IN_PROGRESS
```

### Test 3: Ponowne wykonanie zakończonego testu
```
1. Test ma status PASSED
2. Sprawdź czy przycisk pokazuje "Wykonaj" (zielony)
3. Kliknij "Wykonaj"
4. Sprawdź czy tworzy się NOWE wykonanie (nowy execution_id)
5. Sprawdź czy poprzednie wykonanie jest w historii
```

### Test 4: Przerwanie i kontynuacja
```
1. Rozpocznij test
2. Wybierz status FAILED
3. Zamknij modal bez zgłoszenia błędu (Anuluj)
4. Test pozostaje IN_PROGRESS
5. Kliknij "Kontynuuj"
6. Modal się otwiera z tym samym wykonaniem
7. Zgłoś błąd
8. Dokończ test
```

## API Calls

### Kontynuacja IN_PROGRESS:
```
GET /api/test-executions/history/:testPlanCaseId
→ Zwraca listę wykonań
→ Znajduje wykonanie ze statusem 'IN_PROGRESS'
→ Używa tego execution_id
```

### Nowe wykonanie:
```
POST /api/test-executions/start
Body: { test_plan_case_id: 123 }
→ Tworzy nowy rekord w test_executions
→ Zmienia status test_plan_cases na IN_PROGRESS
→ Zwraca nowe execution
```

## Korzyści

✅ **Możliwość kontynuacji** - Użytkownik może wrócić do testu IN_PROGRESS
✅ **Jasny UI** - Niebieski przycisk "Kontynuuj" vs zielony "Wykonaj"
✅ **Spójność danych** - Nie tworzy duplikatów wykonań IN_PROGRESS
✅ **Lepszy UX** - Użytkownik może przerwać i wrócić później
✅ **Historia zachowana** - Wszystkie wykonania są w historii

## Pliki Zmienione

### TestExecution.tsx

**Linia 96-122: Logika handleStartTest**
- Dodano sprawdzenie `if (testCase.status === 'IN_PROGRESS')`
- Pobieranie historii i znajdowanie aktywnego wykonania
- Warunkowe tworzenie nowego wykonania

**Linia 307-317: Przycisk wykonania**
- Usunięto `disabled={testCase.status === 'IN_PROGRESS'}`
- Dodano dynamiczny kolor (niebieski/zielony)
- Zmieniono tekst na "Kontynuuj" dla IN_PROGRESS

## Data naprawy
2026-05-17

## Status
✅ Naprawione - Można teraz kontynuować testy IN_PROGRESS
