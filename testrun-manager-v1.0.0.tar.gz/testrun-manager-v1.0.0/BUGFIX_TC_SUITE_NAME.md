# Bugfix - Wyświetlanie zestawu testowego w podglądzie TC

## Problem
W modalu podglądu przypadku testowego wyświetlało się "Bez zestawu" mimo że TC był przypisany do zestawu testowego.

## Przyczyna
Backend zwracał pole `test_suite_name` w zapytaniu SQL, ale frontend oczekiwał pola `suite_name`.

## Rozwiązanie
Dodano alias `suite_name` w backendzie (`/backend/src/routes/test-specifications.ts`) aby zapewnić kompatybilność z frontendem.

### Zmiana w kodzie:
```typescript
// Przed:
return { ...spec, steps, requirements, tags: tags || [] };

// Po:
return { 
  ...spec, 
  steps, 
  requirements, 
  tags: tags || [],
  suite_name: spec.test_suite_name // Dodaj alias dla kompatybilności z frontendem
};
```

## Weryfikacja
1. Otwórz stronę Specyfikacja testowa
2. Kliknij ikonę "Podgląd" (oko) przy dowolnym TC przypisanym do zestawu
3. Sprawdź pole "Zestaw testowy" - powinno wyświetlać nazwę zestawu zamiast "Bez zestawu"

## Pliki zmienione
- `/backend/src/routes/test-specifications.ts` - dodano alias `suite_name`

## Data naprawy
2026-05-14

## Status
✅ Naprawione - ts-node-dev automatycznie zrestartował backend
