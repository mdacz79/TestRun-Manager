# Changelog

All notable changes to TestRun Manager will be documented in this file.

The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [1.0.0] - 2026-06-10

### Added - Initial Release

#### Core Features
- ✅ **Zarządzanie projektami** - Tworzenie i organizacja projektów testowych
- ✅ **Wymagania** - Moduł zarządzania wymaganiami z edytorem Rich Text (TipTap)
- ✅ **Specyfikacja testowa** - Tworzenie przypadków testowych z krokami i oczekiwanymi rezultatami
- ✅ **Plany testowe** - Planowanie i organizacja wykonania testów
- ✅ **Wykonywanie testów** - Interaktywne wykonywanie testów z zapisem wyników
- ✅ **Defekty** - Zarządzanie błędami z priorytetami i severity
- ✅ **Raporty** - Kompleksowe raporty z wykresami i statystykami

#### Reporting Module
- 📊 **Wykres Burndown** - Wizualizacja postępu wykonania testów
  - Linia idealna (target) z uwzględnieniem dni roboczych i świąt
  - Linia wykonanych testów (executed)
  - Linie passed i failed
  - Data realizacji testów z obliczeniem dziennego tempa
- 📈 **Statystyki wykonania** - Szczegółowe statystyki planów testowych
- 🐛 **Analiza defektów** - Wykresy według statusu, priorytetu i severity
- 📋 **Macierz pokrycia** - Pokrycie wymagań przypadkami testowymi
- 💾 **Eksport CSV** - Eksport raportów do plików CSV

#### User Management
- 👥 **System ról i uprawnień** - 4 domyślne role (Administrator, Test Manager, Analityk, Tester)
- 🔐 **Autentykacja JWT** - Bezpieczne logowanie i zarządzanie sesjami
- 👤 **Panel administracyjny** - Zarządzanie użytkownikami i rolami
- 🔑 **Reset hasła** - Funkcja resetowania haseł przez administratora

#### Technical Features
- 🎨 **Nowoczesne logo** - Profesjonalne logo SVG z gradientem
- 📱 **Responsywny UI** - Interfejs dostosowany do różnych urządzeń
- 🌐 **Wielojęzyczność** - Interfejs w języku polskim
- 💾 **SQLite database** - Lekka baza danych bez dodatkowych zależności
- 🔄 **Real-time updates** - Automatyczna aktualizacja danych

#### Installation & Deployment
- 🚀 **Automatyczne skrypty instalacyjne**
  - `install.sh` dla Linux/Mac
  - `install.ps1` dla Windows
- 📦 **Skrypt tworzenia release** - `create-release.sh`
- 📖 **Pełna dokumentacja**
  - INSTALLATION.md - Szczegółowa instrukcja instalacji
  - QUICK_START.md - Szybki start (5 minut)
  - README.md - Przegląd systemu
- 🔧 **Konfiguracja PM2** - Automatyczne zarządzanie procesem (Linux)
- 🌐 **Konfiguracja Nginx** - Reverse proxy i serwowanie statycznych plików
- 🪟 **Windows Service** - Instalacja jako usługa Windows

#### Security
- 🔒 **Hashowanie haseł** - bcryptjs
- 🎫 **JWT tokens** - Bezpieczna autentykacja
- 🛡️ **Middleware autoryzacji** - Sprawdzanie uprawnień
- 🔐 **CORS protection** - Konfiguracja CORS

### Technical Stack

#### Backend
- Node.js + Express
- TypeScript
- SQLite (sql.js)
- JWT authentication
- bcryptjs password hashing

#### Frontend
- React 18
- TypeScript
- Vite
- TailwindCSS
- Lucide Icons
- Recharts (wykresy)
- TipTap (Rich Text Editor)
- React Router
- Axios

### System Requirements

- **Node.js**: v18.0 lub nowszy
- **RAM**: 2 GB (zalecane 4 GB)
- **Dysk**: 1 GB wolnego miejsca
- **OS**: Linux (Ubuntu 20.04+), Windows Server 2019+, macOS

### Known Issues

Brak znanych problemów w tej wersji.

### Credits

**Autor**: ITM Marek Dacz  
**Wersja**: 1.0.0  
**Data wydania**: 2026-06-10  
**Licencja**: MIT

---

## [Unreleased]

### Planned Features
- [ ] Integracja z systemami CI/CD
- [ ] API dla zewnętrznych narzędzi
- [ ] Powiadomienia email
- [ ] Eksport do PDF
- [ ] Dashboard z widgetami
- [ ] Zaawansowane filtrowanie i wyszukiwanie
- [ ] Historia zmian (audit log)
- [ ] Komentarze i dyskusje
- [ ] Załączniki do testów i defektów
- [ ] Szablony testów
- [ ] Klonowanie planów testowych

---

[1.0.0]: https://github.com/itm-marek-dacz/testrun-manager/releases/tag/v1.0.0
