# TestRun Manager v1.0 - Instrukcja Instalacji

## Spis treści
1. [Wymagania systemowe](#wymagania-systemowe)
2. [Instalacja na serwerze Linux](#instalacja-na-serwerze-linux)
3. [Instalacja na serwerze Windows](#instalacja-na-serwerze-windows)
4. [Konfiguracja](#konfiguracja)
5. [Uruchomienie](#uruchomienie)
6. [Rozwiązywanie problemów](#rozwiązywanie-problemów)

---

## Wymagania systemowe

### Minimalne wymagania:
- **System operacyjny**: Linux (Ubuntu 20.04+, CentOS 8+) lub Windows Server 2019+
- **Node.js**: v18.0 lub nowszy
- **RAM**: 2 GB
- **Dysk**: 1 GB wolnego miejsca
- **Port**: 3000 (backend), 5173 (frontend - development) lub 80/443 (production)

### Zalecane wymagania:
- **RAM**: 4 GB
- **Dysk**: 5 GB wolnego miejsca
- **CPU**: 2 rdzenie

---

## Instalacja na serwerze Linux (Ubuntu/Debian)

### Krok 1: Instalacja Node.js

```bash
# Aktualizacja systemu
sudo apt update && sudo apt upgrade -y

# Instalacja Node.js 18.x
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Weryfikacja instalacji
node --version
npm --version
```

### Krok 2: Pobranie i rozpakowanie systemu

```bash
# Utwórz katalog dla aplikacji
sudo mkdir -p /opt/testrun-manager
cd /opt/testrun-manager

# Skopiuj pliki systemu (zakładając, że masz plik testrun-manager-v1.0.tar.gz)
# Opcja A: Jeśli masz archiwum
tar -xzf testrun-manager-v1.0.tar.gz

# Opcja B: Jeśli korzystasz z Git
git clone <repository-url> .
```

### Krok 3: Instalacja zależności

```bash
# Backend
cd /opt/testrun-manager/backend
npm install --production

# Frontend
cd /opt/testrun-manager/frontend
npm install
npm run build
```

### Krok 4: Konfiguracja zmiennych środowiskowych

```bash
# Utwórz plik .env w katalogu backend
cd /opt/testrun-manager/backend
nano .env
```

Zawartość pliku `.env`:
```env
# Port backendu
PORT=3000

# JWT Secret (zmień na losowy ciąg znaków)
JWT_SECRET=your-super-secret-jwt-key-change-this-in-production

# CORS Origin (adres frontendu)
CORS_ORIGIN=http://your-domain.com

# Database path (domyślnie SQLite)
DB_PATH=./database.db

# Environment
NODE_ENV=production
```

### Krok 5: Instalacja PM2 (Process Manager)

```bash
# Instalacja PM2 globalnie
sudo npm install -g pm2

# Uruchomienie backendu przez PM2
cd /opt/testrun-manager/backend
pm2 start npm --name "testrun-backend" -- start

# Zapisz konfigurację PM2
pm2 save

# Ustaw PM2 do automatycznego startu
pm2 startup
```

### Krok 6: Konfiguracja Nginx (reverse proxy)

```bash
# Instalacja Nginx
sudo apt install -y nginx

# Utwórz konfigurację dla TestRun Manager
sudo nano /etc/nginx/sites-available/testrun-manager
```

Zawartość pliku konfiguracyjnego Nginx:
```nginx
server {
    listen 80;
    server_name your-domain.com;

    # Frontend (pliki statyczne)
    location / {
        root /opt/testrun-manager/frontend/dist;
        try_files $uri $uri/ /index.html;
    }

    # Backend API
    location /api {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }
}
```

```bash
# Aktywuj konfigurację
sudo ln -s /etc/nginx/sites-available/testrun-manager /etc/nginx/sites-enabled/

# Testuj konfigurację
sudo nginx -t

# Restart Nginx
sudo systemctl restart nginx
```

### Krok 7: Konfiguracja SSL (opcjonalnie, ale zalecane)

```bash
# Instalacja Certbot
sudo apt install -y certbot python3-certbot-nginx

# Uzyskanie certyfikatu SSL
sudo certbot --nginx -d your-domain.com

# Automatyczne odnawianie certyfikatu
sudo certbot renew --dry-run
```

---

## Instalacja na serwerze Windows

### Krok 1: Instalacja Node.js

1. Pobierz Node.js z https://nodejs.org/ (wersja 18.x LTS)
2. Uruchom instalator i postępuj zgodnie z instrukcjami
3. Zrestartuj komputer

### Krok 2: Instalacja systemu

```powershell
# Utwórz katalog
mkdir C:\testrun-manager
cd C:\testrun-manager

# Rozpakuj pliki systemu do tego katalogu
```

**WAŻNE**: Jeśli podczas uruchamiania skryptu `install.ps1` pojawi się błąd:
```
.\install.ps1 : File cannot be loaded because running scripts is disabled on this system.
```

Wykonaj jedną z poniższych opcji:

**Opcja A - Tymczasowe zezwolenie (zalecane dla jednorazowej instalacji)**:
```powershell
# Uruchom PowerShell jako Administrator i wykonaj:
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
# Następnie uruchom skrypt instalacyjny
.\install.ps1
```

**Opcja B - Uruchomienie z pominięciem polityki**:
```powershell
# Uruchom bezpośrednio z parametrem Bypass:
powershell -ExecutionPolicy Bypass -File .\install.ps1
```

**Opcja C - Zmiana polityki dla bieżącego użytkownika**:
```powershell
# Uruchom PowerShell jako Administrator:
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
# Następnie uruchom skrypt instalacyjny
.\install.ps1
```

### Krok 3: Instalacja zależności

```powershell
# Backend
cd C:\testrun-manager\backend
npm install --production

# Frontend
cd C:\testrun-manager\frontend
npm install
npm run build
```

### Krok 4: Konfiguracja

Utwórz plik `C:\testrun-manager\backend\.env`:
```env
PORT=3000
JWT_SECRET=your-super-secret-jwt-key-change-this
CORS_ORIGIN=http://localhost
NODE_ENV=production
```

### Krok 5: Instalacja jako usługa Windows

```powershell
# Instalacja node-windows
cd C:\testrun-manager\backend
npm install -g node-windows

# Utwórz skrypt usługi (service.js)
```

Zawartość `service.js`:
```javascript
var Service = require('node-windows').Service;

var svc = new Service({
  name: 'TestRun Manager Backend',
  description: 'TestRun Manager Backend Service',
  script: 'C:\\testrun-manager\\backend\\dist\\server.js'
});

svc.on('install', function(){
  svc.start();
});

svc.install();
```

```powershell
# Uruchom instalację usługi
node service.js
```

### Krok 6: Konfiguracja IIS (opcjonalnie)

1. Zainstaluj IIS z URL Rewrite i ARR (Application Request Routing)
2. Utwórz nową witrynę w IIS wskazującą na `C:\testrun-manager\frontend\dist`
3. Skonfiguruj reverse proxy dla `/api` do `http://localhost:3000`

---

## Konfiguracja

### Domyślne konto administratora

Po pierwszym uruchomieniu systemu, utwórz konto administratora:

1. Otwórz przeglądarkę i przejdź do `http://your-domain.com`
2. Kliknij "Zarejestruj się"
3. Wprowadź dane:
   - Email: admin@example.com
   - Hasło: (wybierz silne hasło)
   - Imię i nazwisko: Administrator

**WAŻNE**: Pierwsze utworzone konto automatycznie otrzymuje uprawnienia administratora.

### Konfiguracja bazy danych

System domyślnie używa SQLite. Baza danych jest tworzona automatycznie przy pierwszym uruchomieniu w lokalizacji:
- Linux: `/opt/testrun-manager/backend/database.db`
- Windows: `C:\testrun-manager\backend\database.db`

### Backup bazy danych

```bash
# Linux
cp /opt/testrun-manager/backend/database.db /backup/database-$(date +%Y%m%d).db

# Windows
copy C:\testrun-manager\backend\database.db C:\backup\database-%date%.db
```

---

## Uruchomienie

### Development (dla testów)

```bash
# Backend
cd backend
npm run dev

# Frontend (w nowym terminalu)
cd frontend
npm run dev
```

### Production

```bash
# Backend (z PM2 na Linux)
pm2 start testrun-backend
pm2 logs testrun-backend

# Backend (bezpośrednio)
cd backend
npm start

# Frontend jest serwowany jako pliki statyczne przez Nginx/IIS
```

### Sprawdzenie statusu

```bash
# PM2
pm2 status
pm2 logs testrun-backend

# Nginx
sudo systemctl status nginx

# Sprawdź czy backend działa
curl http://localhost:3000/api/health
```

---

## Rozwiązywanie problemów

### Problem: Backend nie startuje

**Rozwiązanie**:
```bash
# Sprawdź logi
pm2 logs testrun-backend

# Sprawdź czy port 3000 jest wolny
sudo netstat -tulpn | grep 3000

# Sprawdź uprawnienia do plików
sudo chown -R $USER:$USER /opt/testrun-manager
```

### Problem: Linux - Błąd "cannot copy a directory into itself"

**Objawy**:
```
cp: cannot copy a directory, '/path/to/testrun-manager-v1.0.0/y', into itself
```

**Przyczyna**: Starsze wersje skryptu `install.sh` miały błąd w kopiowaniu plików.

**Rozwiązanie**:
1. Pobierz najnowszą wersję skryptu instalacyjnego
2. Lub zainstaluj ręcznie:
```bash
# Utwórz katalog docelowy
sudo mkdir -p /opt/testrun-manager
sudo chown $USER:$USER /opt/testrun-manager

# Skopiuj tylko niezbędne pliki
cp -r backend frontend *.md LICENSE /opt/testrun-manager/
cd /opt/testrun-manager

# Kontynuuj instalację ręcznie według dokumentacji
```

### Problem: Linux - Błąd "tsc: not found" podczas instalacji

**Objawy**:
```
> testrun-manager-backend@1.0.0 build
> tsc

sh: 1: tsc: not found
```

**Przyczyna**: Starsze wersje skryptu instalowały backend z flagą `--production`, która pomijała TypeScript.

**Rozwiązanie**:
1. Pobierz najnowszą wersję skryptu `install.sh` (v1.0.1+)
2. Lub napraw ręcznie:
```bash
cd /opt/testrun-manager/backend
npm install  # zainstaluj wszystkie zależności włącznie z TypeScript
npm run build  # zbuduj backend
pm2 start dist/server.js --name testrun-backend
pm2 save
```

### Problem: Błąd połączenia z API

**Rozwiązanie**:
1. Sprawdź czy backend działa: `pm2 status`
2. Sprawdź konfigurację CORS w `.env`
3. Sprawdź konfigurację Nginx/IIS
4. Sprawdź firewall: `sudo ufw allow 3000`

### Problem: Nie można zalogować się

**Rozwiązanie**:
1. Sprawdź czy baza danych istnieje
2. Zresetuj hasło administratora (skrypt w `backend/scripts/reset-password.js`)
3. Sprawdź logi backendu

### Problem: Brak uprawnień

**Rozwiązanie**:
```bash
# Nadaj uprawnienia do katalogu
sudo chown -R www-data:www-data /opt/testrun-manager

# Lub dla użytkownika
sudo chown -R $USER:$USER /opt/testrun-manager
```

### Problem: Windows - Błąd "running scripts is disabled"

**Objawy**:
```
.\install.ps1 : File cannot be loaded because running scripts is disabled on this system.
```

**Rozwiązanie**:
```powershell
# Opcja 1 - Tymczasowe (zalecane):
Set-ExecutionPolicy -ExecutionPolicy Bypass -Scope Process
.\install.ps1

# Opcja 2 - Bezpośrednie uruchomienie:
powershell -ExecutionPolicy Bypass -File .\install.ps1

# Opcja 3 - Zmiana dla użytkownika (wymaga uprawnień administratora):
Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
```

### Problem: Windows - Błąd "The term 'np.' is not recognized"

**Objawy**:
```
The term 'np.' is not recognized as the name of a cmdlet, function, script file...
```

**Przyczyna**: Starsze wersje skryptu `install.ps1` zawierały błąd parsowania w linii z tekstem "(np. testrun.example.com)".

**Rozwiązanie**:
Pobierz najnowszą wersję skryptu instalacyjnego lub ręcznie edytuj plik `install.ps1`:
- Znajdź linię 77: `$domain = Read-Host "Domena (np. testrun.example.com)..."`
- Zamień `np.` na `przyklad:` lub usuń ten fragment tekstu

### Problem: Windows - Puste wartości w podsumowaniu instalacji

**Objawy**:
Po instalacji wyświetlane są puste wartości:
```
Katalog:
Backend port:
Domena:
```

**Przyczyna**: Problemy z kodowaniem UTF-8 lub interpolacją zmiennych w PowerShell.

**Rozwiązanie**:
1. Pobierz najnowszą wersję skryptu `install.ps1` (zawiera poprawki kodowania)
2. Sprawdź wartości ręcznie:
   - Katalog instalacji: `C:\testrun-manager` (domyślnie)
   - Backend port: `3000` (domyślnie)
   - Domena: `localhost` (domyślnie)
3. Sprawdź czy backend działa: `http://localhost:3000/api/health`

---

## Aktualizacja systemu

```bash
# 1. Zatrzymaj backend
pm2 stop testrun-backend

# 2. Backup bazy danych
cp /opt/testrun-manager/backend/database.db /backup/database-backup.db

# 3. Pobierz nową wersję
cd /opt/testrun-manager
git pull  # lub rozpakuj nowe archiwum

# 4. Zainstaluj zależności
cd backend && npm install --production
cd ../frontend && npm install && npm run build

# 5. Uruchom ponownie
pm2 restart testrun-backend
```

---

## Wsparcie

**Autor**: ITM Marek Dacz  
**Wersja**: 1.0  
**Email**: support@testrun-manager.com  
**Dokumentacja**: https://docs.testrun-manager.com

---

## Licencja

MIT License - Copyright (c) 2026 ITM Marek Dacz
