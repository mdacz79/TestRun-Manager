# Bugfix - Import CSV nie działał z 12 kolumnami

## Problem
Import przypadków testowych z CSV wyświetlał komunikat "Nie znaleziono przypadków testowych w pliku" mimo że plik zawierał prawidłowe dane.

## Przyczyna
Parser CSV wymagał **13 kolumn** (z kolumną "Data utworzenia"), ale użytkownik eksportował CSV z **12 kolumnami** (bez daty).

### Kod przed naprawą:
```typescript
if (values.length < 13) {
  console.warn('Pominięto nieprawidłowy wiersz:', line);
  return;
}
```

### Struktura CSV użytkownika (12 kolumn):
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
```

### Struktura oczekiwana przez parser (13 kolumn):
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi,Data utworzenia
```

## Rozwiązanie

### 1. Zmiana walidacji liczby kolumn
```typescript
// Przed:
if (values.length < 13) {
  console.warn('Pominięto nieprawidłowy wiersz:', line);
  return;
}

// Po:
if (values.length < 12) {
  console.warn('Pominięto nieprawidłowy wiersz (za mało kolumn):', line);
  return;
}
```

### 2. Data utworzenia jako opcjonalna
```typescript
const [
  testCaseId,
  title,
  description,
  preconditions,
  stepNumber,
  action,
  expectedResult,
  priority,
  status,
  suiteName,
  requirements,
  tags,
  createdAt // opcjonalne - może nie być w CSV
] = values;
```

### 3. Dodanie aliasu API
Dodano `getByProject` jako alias dla `getAll` w `/frontend/src/lib/api.ts`:
```typescript
export const tags = {
  getAll: (projectId: number) => api.get(`/tags/project/${projectId}`),
  getByProject: (projectId: number) => api.get(`/tags/project/${projectId}`), // NOWE
  // ...
};
```

## Obsługiwane formaty CSV

### Format z datą (13 kolumn):
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi,Data utworzenia
PT1-001,Test,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,Logowanie,WYM-001,test,14.05.2026
```

### Format bez daty (12 kolumn):
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-001,Test,Opis,Warunki,1,Akcja,Rezultat,Średni,Szkic,Logowanie,WYM-001,test
```

**Oba formaty są teraz obsługiwane!**

## Walidacja

Parser sprawdza:
1. ✅ Minimum 12 kolumn (data opcjonalna)
2. ✅ ID TC nie może być puste
3. ✅ Tytuł nie może być pusty
4. ✅ Wiersz musi być prawidłowo sparsowany

## Przykład użycia

### CSV użytkownika (12 kolumn):
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-004,fsfddsf44dsf,dsfdsfds,fdsfd,1,sfdsf,dsfdsf,Średni,Szkic,Logowanie,WYM-PT1-002,test
PT1-004,fsfddsf44dsf,dsfdsfds,fdsfd,2,sdfdsf,dsfdsf,Średni,Szkic,Logowanie,WYM-PT1-002,test
PT1-005,test 3,sxaxas,xsaxsaxsax,1,xsax,asxsax,Średni,Zatwierdzony,Logowanie,"WYM-PT1-001, WYM-PT1-002","test, wymaganie"
```

### Rezultat importu:
```
✅ Zaimportowano 2 przypadków testowych
- PT1-004 (2 kroki)
- PT1-005 (1 krok)
```

## Pliki zmienione
- `/frontend/src/utils/csvImport.ts` - zmiana walidacji z 13 na 12 kolumn
- `/frontend/src/lib/api.ts` - dodanie aliasu `getByProject`

## Weryfikacja
1. ✅ CSV z 12 kolumnami - importuje poprawnie
2. ✅ CSV z 13 kolumnami - importuje poprawnie
3. ✅ CSV z mniej niż 12 kolumnami - wyświetla ostrzeżenie
4. ✅ Puste wiersze - są pomijane

## Data naprawy
2026-05-14

## Status
✅ Naprawione - import działa z 12 i 13 kolumnami
