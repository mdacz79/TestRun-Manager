# Feature - Filtrowanie TC przez modal

## Opis
Zmieniono interfejs filtrowania przypadków testowych z inline filtrów na **modal z przyciskiem "Filtruj"**. Użytkownik klika przycisk, ustawia filtry w modalu i zatwierdza przyciskiem "Zastosuj".

## Zmiana UI

### Przed:
```
┌─────────────────────────────────────────────────────────┐
│ [Input tekst] [Select tagi] [Input wymaganie]           │
│                                    [Wyczyść filtry]      │
└─────────────────────────────────────────────────────────┘
```
Filtry widoczne zawsze, zmiany natychmiastowe.

### Po:
```
┌─────────────────────────────────────────────────────────┐
│ [Filtruj]  Aktywne filtry: [Tekst: "login"] [Tagi: 2]  │
│                                    [Wyczyść wszystkie]   │
└─────────────────────────────────────────────────────────┘
```
Kompaktowy widok, filtry w modalu.

## Implementacja

### 1. Nowe stany

```typescript
// Modal
const [showFilterModal, setShowFilterModal] = useState(false);

// Filtry aktywne (zastosowane)
const [filterText, setFilterText] = useState('');
const [filterTags, setFilterTags] = useState<number[]>([]);
const [filterRequirement, setFilterRequirement] = useState('');

// Filtry tymczasowe (w modalu)
const [tempFilterText, setTempFilterText] = useState('');
const [tempFilterTags, setTempFilterTags] = useState<number[]>([]);
const [tempFilterRequirement, setTempFilterRequirement] = useState('');
```

### 2. Funkcje obsługi

```typescript
// Otwórz modal - skopiuj aktualne filtry do tymczasowych
const handleOpenFilterModal = () => {
  setTempFilterText(filterText);
  setTempFilterTags(filterTags);
  setTempFilterRequirement(filterRequirement);
  setShowFilterModal(true);
};

// Zastosuj filtry - skopiuj tymczasowe do aktywnych
const handleApplyFilters = () => {
  setFilterText(tempFilterText);
  setFilterTags(tempFilterTags);
  setFilterRequirement(tempFilterRequirement);
  setShowFilterModal(false);
};

// Wyczyść filtry w modalu
const handleClearFilters = () => {
  setTempFilterText('');
  setTempFilterTags([]);
  setTempFilterRequirement('');
};
```

### 3. Przycisk "Filtruj"

```tsx
<button
  onClick={handleOpenFilterModal}
  className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
>
  <ClipboardList className="h-4 w-4 mr-2" />
  Filtruj
</button>
```

### 4. Wskaźnik aktywnych filtrów

```tsx
{(filterText || filterTags.length > 0 || filterRequirement) && (
  <div className="flex items-center gap-2 text-sm">
    <span className="text-gray-600">Aktywne filtry:</span>
    {filterText && (
      <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded">
        Tekst: "{filterText}"
      </span>
    )}
    {filterTags.length > 0 && (
      <span className="px-2 py-1 bg-green-100 text-green-800 rounded">
        Tagi: {filterTags.length}
      </span>
    )}
    {filterRequirement && (
      <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded">
        Wymaganie: "{filterRequirement}"
      </span>
    )}
    <button onClick={clearAllFilters}>
      Wyczyść wszystkie
    </button>
  </div>
)}
```

### 5. Modal filtrów

```tsx
{showFilterModal && (
  <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
    <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
      <h3>Filtruj przypadki testowe</h3>
      
      {/* Filtry */}
      <input value={tempFilterText} onChange={...} />
      <select multiple value={tempFilterTags} onChange={...} />
      <input value={tempFilterRequirement} onChange={...} />
      
      {/* Przyciski */}
      <button onClick={handleClearFilters}>Wyczyść filtry</button>
      <button onClick={() => setShowFilterModal(false)}>Anuluj</button>
      <button onClick={handleApplyFilters}>Zastosuj</button>
    </div>
  </div>
)}
```

## Przepływ użytkownika

### Krok 1: Kliknij "Filtruj"
```
[Filtruj] ← klik
↓
Modal się otwiera z aktualnymi filtrami
```

### Krok 2: Ustaw filtry w modalu
```
Modal:
- Tekst: "login"
- Tagi: [Backend, API]
- Wymaganie: "WYM-001"
```

### Krok 3: Kliknij "Zastosuj"
```
[Zastosuj] ← klik
↓
Modal się zamyka
Filtry są zastosowane
Lista TC jest przefiltrowana
```

### Krok 4: Zobacz aktywne filtry
```
[Filtruj] Aktywne filtry: [Tekst: "login"] [Tagi: 2] [Wymaganie: "WYM-001"]
```

### Krok 5: Wyczyść filtry (opcjonalnie)
```
[Wyczyść wszystkie] ← klik
↓
Wszystkie filtry usunięte
Lista TC pokazuje wszystko
```

## Przyciski w modalu

### 1. "Wyczyść filtry"
- **Pozycja:** Lewy dolny róg
- **Akcja:** Czyści wszystkie pola w modalu (tymczasowe)
- **Nie zamyka** modala
- **Nie wpływa** na aktywne filtry (dopóki nie klikniesz "Zastosuj")

### 2. "Anuluj"
- **Pozycja:** Prawy dolny róg (pierwszy)
- **Akcja:** Zamyka modal
- **Odrzuca** zmiany (tymczasowe filtry są ignorowane)
- **Zachowuje** aktualne aktywne filtry

### 3. "Zastosuj"
- **Pozycja:** Prawy dolny róg (drugi, niebieski)
- **Akcja:** Zamyka modal
- **Zastosowuje** tymczasowe filtry jako aktywne
- **Filtruje** listę TC

## Wskaźniki aktywnych filtrów

### Filtr tekstowy:
```
[Tekst: "login"]  ← niebieski badge
```

### Filtr tagów:
```
[Tagi: 2]  ← zielony badge
```
Pokazuje liczbę wybranych tagów (nie nazwy).

### Filtr wymagania:
```
[Wymaganie: "WYM-001"]  ← fioletowy badge
```

### Przycisk czyszczenia:
```
[Wyczyść wszystkie]  ← czerwony link
```
Czyści wszystkie aktywne filtry jednocześnie.

## Przykłady użycia

### Scenariusz 1: Ustawienie filtrów

**Akcje:**
1. Kliknij "Filtruj"
2. Wpisz "login" w polu tekstowym
3. Wybierz tagi: Backend, API
4. Wpisz "WYM-001" w polu wymagania
5. Kliknij "Zastosuj"

**Rezultat:**
```
[Filtruj] Aktywne filtry: [Tekst: "login"] [Tagi: 2] [Wymaganie: "WYM-001"]
```
Lista pokazuje tylko TC spełniające wszystkie warunki.

### Scenariusz 2: Modyfikacja filtrów

**Akcje:**
1. Kliknij "Filtruj" (modal pokazuje aktualne filtry)
2. Usuń tekst "login"
3. Dodaj tag "Database"
4. Kliknij "Zastosuj"

**Rezultat:**
```
[Filtruj] Aktywne filtry: [Tagi: 3] [Wymaganie: "WYM-001"]
```
Lista pokazuje TC z 3 tagami i wymaganiem WYM-001.

### Scenariusz 3: Anulowanie zmian

**Akcje:**
1. Kliknij "Filtruj"
2. Zmień filtry
3. Kliknij "Anuluj"

**Rezultat:**
```
Filtry pozostają bez zmian
Modal się zamyka
```

### Scenariusz 4: Czyszczenie w modalu

**Akcje:**
1. Kliknij "Filtruj"
2. Kliknij "Wyczyść filtry" (w modalu)
3. Kliknij "Zastosuj"

**Rezultat:**
```
Wszystkie filtry usunięte
Lista pokazuje wszystkie TC
```

### Scenariusz 5: Szybkie czyszczenie

**Akcje:**
1. Kliknij "Wyczyść wszystkie" (obok aktywnych filtrów)

**Rezultat:**
```
Wszystkie filtry usunięte natychmiast
Bez otwierania modala
```

## Korzyści nowego rozwiązania

### ✅ Czytelność:
- Kompaktowy widok - więcej miejsca na listę TC
- Aktywne filtry widoczne jako badges
- Mniej rozpraszający interfejs

### ✅ Kontrola:
- Filtry nie są stosowane natychmiast
- Użytkownik może przetestować różne kombinacje
- Przycisk "Anuluj" pozwala odrzucić zmiany

### ✅ Przejrzystość:
- Jasno widać które filtry są aktywne
- Łatwe czyszczenie wszystkich filtrów
- Kolorowe badges dla różnych typów filtrów

### ✅ UX:
- Mniej przypadkowych zmian
- Świadome zastosowanie filtrów
- Możliwość eksperymentowania bez wpływu na listę

## Porównanie

| Aspekt | Inline filtry | Modal filtry |
|--------|---------------|--------------|
| Widoczność | Zawsze widoczne | Ukryte w modalu |
| Zastosowanie | Natychmiastowe | Po kliknięciu "Zastosuj" |
| Miejsce | Zajmuje dużo miejsca | Kompaktowy przycisk |
| Anulowanie | Brak | Przycisk "Anuluj" |
| Eksperymentowanie | Trudne (zmienia listę) | Łatwe (nie wpływa) |
| Aktywne filtry | Trzeba sprawdzić pola | Widoczne jako badges |

## Pliki zmienione

- `/frontend/src/pages/TestSpecifications.tsx`:
  - Dodanie stanu `showFilterModal`
  - Dodanie tymczasowych stanów filtrów
  - Funkcje `handleOpenFilterModal`, `handleApplyFilters`, `handleClearFilters`
  - Zamiana inline filtrów na przycisk + wskaźniki
  - Dodanie modala filtrów

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
