# Bugfix - Backend nie zapisywał tagów dla TC

## Problem
Tagi nie były widoczne na liście przypadków testowych mimo że:
- Frontend wysyłał `tag_ids` do backendu
- Formularz pozwalał na wybór tagów
- TagSelector działał poprawnie

## Przyczyna
Backend nie obsługiwał parametru `tag_ids` w endpointach:
- `POST /api/test-specifications` - tworzenie TC
- `PUT /api/test-specifications/:id` - edycja TC

Kod backendu:
```typescript
// Przed - brak tag_ids
const { title, description, ..., requirement_ids } = req.body;
```

Backend zapisywał tylko:
- Dane TC (title, description, etc.)
- Kroki testowe (steps)
- Powiązania z wymaganiami (requirement_ids)

Ale **nie zapisywał tagów** do tabeli `test_specification_tags`.

## Rozwiązanie

### 1. Endpoint POST - dodanie obsługi tagów przy tworzeniu TC

```typescript
// Dodano tag_ids do destructuringu
const { ..., requirement_ids, tag_ids } = req.body;

// Dodano zapisywanie tagów po wymaganiach
if (tag_ids && Array.isArray(tag_ids)) {
  tag_ids.forEach((tagId: number) => {
    db.prepare(`
      INSERT INTO test_specification_tags (test_specification_id, tag_id)
      VALUES (?, ?)
    `).run(specId, tagId);
  });
}
```

### 2. Endpoint PUT - dodanie obsługi tagów przy edycji TC

```typescript
// Dodano tag_ids do destructuringu
const { ..., requirement_ids, tag_ids } = req.body;

// Dodano usuwanie starych i zapisywanie nowych tagów
db.prepare('DELETE FROM test_specification_tags WHERE test_specification_id = ?').run(id);
if (tag_ids && Array.isArray(tag_ids)) {
  tag_ids.forEach((tagId: number) => {
    db.prepare(`
      INSERT INTO test_specification_tags (test_specification_id, tag_id)
      VALUES (?, ?)
    `).run(id, tagId);
  });
}
```

## Przepływ danych

### Tworzenie TC z tagami:
1. Frontend: Użytkownik wybiera tagi w TagSelector
2. Frontend: `selectedTags = [{id: 1, name: 'Backend', ...}, ...]`
3. Frontend: `tag_ids: selectedTags.map(t => t.id)` → `[1, 2, 3]`
4. Backend: Otrzymuje `tag_ids: [1, 2, 3]`
5. Backend: **TERAZ** zapisuje do `test_specification_tags`
6. Backend GET: Zwraca TC z tagami w `enrichedSpecs`
7. Frontend: Wyświetla tagi na liście i w podglądzie

### Edycja TC z tagami:
1. Frontend: Ładuje TC z tagami: `setSelectedTags(spec.tags)`
2. Frontend: Użytkownik modyfikuje tagi
3. Frontend: Wysyła `tag_ids: [1, 3, 5]`
4. Backend: **TERAZ** usuwa stare i zapisuje nowe tagi
5. Backend GET: Zwraca zaktualizowane TC z tagami
6. Frontend: Wyświetla zaktualizowane tagi

## Tabela bazy danych

```sql
CREATE TABLE test_specification_tags (
  test_specification_id INTEGER NOT NULL,
  tag_id INTEGER NOT NULL,
  PRIMARY KEY (test_specification_id, tag_id),
  FOREIGN KEY (test_specification_id) REFERENCES test_specifications(id) ON DELETE CASCADE,
  FOREIGN KEY (tag_id) REFERENCES tags(id) ON DELETE CASCADE
);
```

## Pliki zmienione
- `/backend/src/routes/test-specifications.ts`
  - POST endpoint: dodano obsługę `tag_ids`
  - PUT endpoint: dodano obsługę `tag_ids`

## Weryfikacja

### Test tworzenia TC z tagami:
1. ✅ Utwórz nowy TC
2. ✅ Wybierz tagi w formularzu
3. ✅ Zapisz TC
4. ✅ Sprawdź listę TC - tagi powinny być widoczne
5. ✅ Sprawdź podgląd TC - tagi powinny być widoczne

### Test edycji TC z tagami:
1. ✅ Edytuj istniejący TC
2. ✅ Dodaj/usuń tagi
3. ✅ Zapisz zmiany
4. ✅ Sprawdź listę TC - tagi powinny być zaktualizowane

### Test eksportu CSV:
1. ✅ Wyeksportuj TC do CSV
2. ✅ Sprawdź kolumnę "Tagi" - powinny być wyeksportowane

## Data naprawy
2026-05-14

## Status
✅ Naprawione - backend automatycznie zrestartował się (ts-node-dev)
