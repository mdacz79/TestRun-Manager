# Bugfix - Wyświetlanie tagów w TC

## Problemy
1. **Podwójny label "Tagi"** w formularzu TC
2. **Tagi nie wyświetlają się** na liście TC

## Przyczyny

### Problem 1: Podwójny label
- TagSelector ma wbudowany label "Tagi" (linia 91-93 w TagSelector.tsx)
- W TestSpecifications.tsx dodano zewnętrzny label `<label>Tagi</label>`
- Rezultat: dwa labele jeden pod drugim

### Problem 2: Brak tagów na liście
- `selectedTags` był zdefiniowany jako `number[]` (tablica ID)
- TagSelector oczekuje `any[]` (tablica obiektów tagów)
- W `handleEdit` mapowano tagi na ID: `spec.tags.map((t: any) => t.id)`
- TagSelector nie mógł wyświetlić tagów bo otrzymywał tylko liczby zamiast obiektów

## Rozwiązania

### Naprawa 1: Usunięcie podwójnego labela
```typescript
// Przed:
<div>
  <label className="block text-sm font-medium text-gray-700 mb-2">Tagi</label>
  <TagSelector ... />
</div>

// Po:
<div>
  <TagSelector ... />
</div>
```

### Naprawa 2: Przechowywanie obiektów tagów
```typescript
// Przed:
const [selectedTags, setSelectedTags] = useState<number[]>([]);

// Po:
const [selectedTags, setSelectedTags] = useState<any[]>([]);
```

### Naprawa 3: Ładowanie pełnych obiektów
```typescript
// Przed (handleEdit):
setSelectedTags(spec.tags ? spec.tags.map((t: any) => t.id) : []);

// Po (handleEdit):
setSelectedTags(spec.tags || []);
```

### Naprawa 4: Wysyłanie ID do API
```typescript
// W handleSubmit:
tag_ids: selectedTags.map(t => t.id),  // Konwersja obiektów na ID przed wysłaniem
```

## Architektura danych

### Stan w komponencie:
```typescript
selectedTags: any[]  // Pełne obiekty tagów z {id, name, color}
```

### Wyświetlanie:
```typescript
<TagSelector selectedTags={selectedTags} />  // Otrzymuje obiekty
```

### Wysyłanie do API:
```typescript
tag_ids: selectedTags.map(t => t.id)  // Konwersja na ID
```

### Ładowanie z API:
```typescript
setSelectedTags(spec.tags || [])  // Pełne obiekty z backendu
```

## Pliki zmienione
- `/frontend/src/pages/TestSpecifications.tsx`
  - Usunięto zewnętrzny label
  - Zmieniono typ selectedTags na any[]
  - Zaktualizowano handleEdit
  - Zaktualizowano handleSubmit

## Weryfikacja
1. ✅ Formularz TC - jeden label "Tagi"
2. ✅ Wybrane tagi wyświetlają się w formularzu
3. ✅ Tagi zapisują się przy tworzeniu TC
4. ✅ Tagi ładują się przy edycji TC
5. ✅ Tagi wyświetlają się na liście TC
6. ✅ Tagi wyświetlają się w podglądzie TC

## Data naprawy
2026-05-14

## Status
✅ Naprawione
