# Changelog - Eksport CSV

## 2026-05-14 - v1.1 - Eksport TC z krokami

### ✨ Nowe funkcje:
- **Powielanie TC per krok** - każdy krok przypadku testowego jest teraz w osobnym wierszu CSV
- Nowa kolumna **"Numer kroku"** - numeracja kroków (1, 2, 3, ...)
- Rozdzielone kolumny **"Akcja"** i **"Oczekiwany rezultat"** dla każdego kroku
- Dane TC (ID, Tytuł, Opis, Warunki wstępne, Priorytet, Status, Zestaw, Wymagania, Tagi, Data) są powtarzane dla każdego kroku

### 📊 Format CSV dla TC:
```
ID TC | Tytuł | Opis | Warunki wstępne | Numer kroku | Akcja | Oczekiwany rezultat | Priorytet | Status | Zestaw testowy | Powiązane wymagania | Tagi | Data utworzenia
```

### 💡 Korzyści:
- **Łatwiejsza analiza** - każdy krok można filtrować i sortować osobno
- **Lepsze raportowanie** - możliwość tworzenia raportów per krok
- **Import do narzędzi** - łatwiejszy import do innych systemów testowych
- **Pivot tables** - możliwość tworzenia tabel przestawnych w Excel/Sheets
- **Grupowanie** - łatwe grupowanie po ID TC, numerze kroku, akcji

### 🔄 Przykład:
TC z 3 krokami = 3 wiersze w CSV:
```csv
TC-001,Test logowania,...,1,Otwórz stronę,...
TC-001,Test logowania,...,2,Wprowadź dane,...
TC-001,Test logowania,...,3,Kliknij Zaloguj,...
```

---

## 2026-05-14 - v1.0 - Pierwsze wydanie

### ✨ Funkcje:
- Eksport wszystkich wymagań do CSV
- Eksport pojedynczego wymagania do CSV
- Eksport wszystkich przypadków testowych do CSV
- Eksport pojedynczego przypadku testowego do CSV
- Uwzględnienie zestawów wymagań i testowych
- Uwzględnienie tagów
- Uwzględnienie powiązań wymagania-TC
- BOM dla poprawnego wyświetlania polskich znaków w Excel
- Automatyczne czyszczenie HTML z pól tekstowych
- Escapowanie wartości CSV

### 📋 Kolumny dla wymagań:
1. ID Wymagania
2. Tytuł
3. Opis
4. Priorytet
5. Status
6. Zestaw
7. Tagi
8. Liczba TC
9. Data utworzenia

### 📋 Kolumny dla TC (v1.0):
1. ID TC
2. Tytuł
3. Opis
4. Warunki wstępne
5. Kroki testowe (wszystkie w jednej kolumnie)
6. Oczekiwany rezultat (wszystkie w jednej kolumnie)
7. Priorytet
8. Status
9. Zestaw testowy
10. Powiązane wymagania
11. Tagi
12. Data utworzenia
