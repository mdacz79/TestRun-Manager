# Komponenty do Utworzenia - Moduł Wykonywania Testów

## Pozostałe komponenty do implementacji:

### 1. AddTestCasesModal.tsx
### 2. ExecuteTestModal.tsx  
### 3. TestHistoryModal.tsx
### 4. CreateBugModal.tsx

---

## 1. AddTestCasesModal.tsx

```tsx
import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { testSpecifications } from '../lib/api';

interface AddTestCasesModalProps {
  projectId: number;
  existingCaseIds: number[];
  onClose: () => void;
  onAdd: (caseIds: number[]) => void;
}

export default function AddTestCasesModal({ projectId, existingCaseIds, onClose, onAdd }: AddTestCasesModalProps) {
  const [testCases, setTestCases] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTestCases();
  }, []);

  const loadTestCases = async () => {
    try {
      const res = await testSpecifications.getAll(projectId);
      // Wyklucz już dodane przypadki
      const available = res.data.filter((tc: any) => !existingCaseIds.includes(tc.id));
      setTestCases(available);
    } catch (error) {
      console.error('Error loading test cases:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleCase = (id: number) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSubmit = () => {
    onAdd(selectedIds);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Dodaj przypadki testowe</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[50vh]">
          {loading ? (
            <p>Ładowanie...</p>
          ) : testCases.length === 0 ? (
            <p className="text-gray-500">Brak dostępnych przypadków testowych</p>
          ) : (
            <div className="space-y-2">
              {testCases.map((tc) => (
                <label
                  key={tc.id}
                  className="flex items-start p-3 border rounded hover:bg-gray-50 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(tc.id)}
                    onChange={() => toggleCase(tc.id)}
                    className="mt-1 mr-3"
                  />
                  <div className="flex-1">
                    <div className="font-mono text-sm font-semibold text-blue-600">
                      {tc.test_case_id}
                    </div>
                    <div className="text-sm text-gray-900">{tc.title}</div>
                  </div>
                </label>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 border-t flex justify-between items-center">
          <span className="text-sm text-gray-600">
            Wybrano: {selectedIds.length}
          </span>
          <div className="space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Anuluj
            </button>
            <button
              onClick={handleSubmit}
              disabled={selectedIds.length === 0}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
            >
              Dodaj wybrane
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
```

---

## 2. ExecuteTestModal.tsx

```tsx
import { useState } from 'react';
import { X, CheckCircle, XCircle, MinusCircle, Ban } from 'lucide-react';

interface ExecuteTestModalProps {
  testCase: any;
  execution: any;
  onClose: () => void;
  onComplete: (data: { status: string; bug_id?: number; notes?: string }) => void;
  onCreateBug: () => void;
}

export default function ExecuteTestModal({ testCase, execution, onClose, onComplete, onCreateBug }: ExecuteTestModalProps) {
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [bugId, setBugId] = useState<number | undefined>();

  const handleStatusClick = async (status: string) => {
    setSelectedStatus(status);
    
    if (status === 'FAILED') {
      // Otwórz modal tworzenia błędu
      onCreateBug();
      // Po utworzeniu błędu, bug ID będzie przekazany z rodzica
    }
  };

  const handleComplete = () => {
    if (!selectedStatus) return;
    
    onComplete({
      status: selectedStatus,
      bug_id: bugId,
      notes,
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <div className="font-mono text-sm font-semibold text-blue-600">
                {testCase.test_case_id}
              </div>
              <h2 className="text-xl font-bold mt-1">{testCase.title}</h2>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[50vh] space-y-6">
          {/* Opis */}
          {testCase.description && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Opis</h3>
              <p className="text-sm text-gray-700">{testCase.description}</p>
            </div>
          )}

          {/* Warunki wstępne */}
          {testCase.preconditions && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Warunki wstępne</h3>
              <p className="text-sm text-gray-700">{testCase.preconditions}</p>
            </div>
          )}

          {/* Kroki testowe */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Kroki testowe</h3>
            <div className="space-y-3">
              {testCase.steps?.map((step: any, idx: number) => (
                <div key={idx} className="border rounded-lg p-3 bg-gray-50">
                  <div className="text-xs font-semibold text-gray-500 mb-2">
                    Krok {idx + 1}
                  </div>
                  <div className="text-sm mb-2">
                    <span className="font-medium">Akcja:</span> {step.action}
                  </div>
                  <div className="text-sm">
                    <span className="font-medium">Oczekiwany rezultat:</span> {step.expected_result}
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Wybór statusu */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Wybierz wynik testu</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleStatusClick('PASSED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'PASSED'
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300 hover:border-green-300'
                }`}
              >
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="font-medium">Zaliczony</span>
              </button>

              <button
                onClick={() => handleStatusClick('FAILED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'FAILED'
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-300 hover:border-red-300'
                }`}
              >
                <XCircle className="h-5 w-5 text-red-600" />
                <span className="font-medium">Niezaliczony</span>
              </button>

              <button
                onClick={() => handleStatusClick('SKIPPED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'SKIPPED'
                    ? 'border-gray-500 bg-gray-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <MinusCircle className="h-5 w-5 text-gray-600" />
                <span className="font-medium">Pominięty</span>
              </button>

              <button
                onClick={() => handleStatusClick('BLOCKED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'BLOCKED'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-300 hover:border-orange-300'
                }`}
              >
                <Ban className="h-5 w-5 text-orange-600" />
                <span className="font-medium">Zablokowany</span>
              </button>
            </div>
          </div>

          {/* Notatki */}
          <div>
            <label className="block font-semibold text-gray-900 mb-2">
              Notatki
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Opcjonalne uwagi dotyczące wykonania testu"
            />
          </div>
        </div>

        <div className="p-6 border-t flex justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Anuluj
          </button>
          <button
            onClick={handleComplete}
            disabled={!selectedStatus}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
          >
            Zakończ test
          </button>
        </div>
      </div>
    </div>
  );
}
```

---

## 3. TestHistoryModal.tsx

```tsx
import { useState, useEffect } from 'react';
import { X, CheckCircle, XCircle, MinusCircle, Ban, Clock } from 'lucide-react';
import { testExecutions } from '../lib/api';

interface TestHistoryModalProps {
  testCase: any;
  onClose: () => void;
}

export default function TestHistoryModal({ testCase, onClose }: TestHistoryModalProps) {
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const res = await testExecutions.getHistory(testCase.id);
      setHistory(res.data);
    } catch (error) {
      console.error('Error loading history:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PASSED': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'FAILED': return <XCircle className="h-5 w-5 text-red-600" />;
      case 'SKIPPED': return <MinusCircle className="h-5 w-5 text-gray-600" />;
      case 'BLOCKED': return <Ban className="h-5 w-5 text-orange-600" />;
      case 'IN_PROGRESS': return <Clock className="h-5 w-5 text-blue-600" />;
      default: return null;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'PASSED': return 'Zaliczony';
      case 'FAILED': return 'Niezaliczony';
      case 'SKIPPED': return 'Pominięty';
      case 'BLOCKED': return 'Zablokowany';
      case 'IN_PROGRESS': return 'W trakcie';
      default: return status;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[80vh] overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <div className="font-mono text-sm font-semibold text-blue-600">
                {testCase.test_case_id}
              </div>
              <h2 className="text-xl font-bold mt-1">Historia wykonań</h2>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {loading ? (
            <p>Ładowanie historii...</p>
          ) : history.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Brak historii wykonań</p>
          ) : (
            <div className="space-y-4">
              {history.map((exec) => (
                <div key={exec.id} className="border rounded-lg p-4 bg-gray-50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(exec.status)}
                      <span className="font-semibold text-gray-900">
                        {getStatusLabel(exec.status)}
                      </span>
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(exec.created_at).toLocaleString('pl-PL')}
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-gray-500">👤 Wykonał:</span>
                      <span className="font-medium">{exec.executed_by_name}</span>
                    </div>

                    {exec.test_plan_name && (
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">📋 Plan:</span>
                        <span>{exec.test_plan_name}</span>
                      </div>
                    )}

                    {exec.bug_id && (
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">🐛 Błąd:</span>
                        <span className="font-mono text-red-600">{exec.bug_id}</span>
                        {exec.bug_title && <span>- {exec.bug_title}</span>}
                      </div>
                    )}

                    {exec.notes && (
                      <div className="mt-2 pt-2 border-t">
                        <span className="text-gray-500">📝 Notatki:</span>
                        <p className="mt-1 text-gray-700">{exec.notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 border-t flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            Zamknij
          </button>
        </div>
      </div>
    </div>
  );
}
```

---

## 4. CreateBugModal.tsx

```tsx
import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { bugs, users as usersApi } from '../lib/api';

interface CreateBugModalProps {
  projectId: number;
  onClose: () => void;
  onCreate: (bug: any) => void;
}

export default function CreateBugModal({ projectId, onClose, onCreate }: CreateBugModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [severity, setSeverity] = useState('medium');
  const [assignedTo, setAssignedTo] = useState<number | null>(null);
  const [users, setUsers] = useState<any[]>([]);

  useEffect(() => {
    loadUsers();
  }, []);

  const loadUsers = async () => {
    try {
      const res = await usersApi.getAll();
      setUsers(res.data);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const res = await bugs.create({
        title,
        description,
        severity,
        project_id: projectId,
        assigned_to: assignedTo || undefined,
      });
      onCreate(res.data);
    } catch (error) {
      console.error('Error creating bug:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full p-6">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-bold">Zgłoś błąd</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tytuł błędu *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Krótki opis błędu"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Opis
            </label>
            <textarea
              value={description}
              onChange={(e) => setDescription(e.target.value)}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Szczegółowy opis błędu, kroki do odtworzenia, itp."
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Priorytet
              </label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="low">Niski</option>
                <option value="medium">Średni</option>
                <option value="high">Wysoki</option>
                <option value="critical">Krytyczny</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Przypisz do
              </label>
              <select
                value={assignedTo || ''}
                onChange={(e) => setAssignedTo(e.target.value ? Number(e.target.value) : null)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="">Nie przypisano</option>
                {users.map((user) => (
                  <option key={user.id} value={user.id}>
                    {user.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex justify-end space-x-2 pt-4">
            <button
              type="button"
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Anuluj
            </button>
            <button
              type="submit"
              className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
            >
              Zgłoś błąd
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
```

---

## Instrukcje Implementacji

1. **Utwórz wszystkie 4 pliki** w `/frontend/src/components/`
2. **Zaimportuj brakujące ikony** w ExecuteTestModal jeśli potrzebne
3. **Dodaj route** w App.tsx:
   ```tsx
   <Route path="/test-execution" element={<TestExecution />} />
   ```
4. **Dodaj link w menu** nawigacji
5. **Przetestuj przepływ:**
   - Utworzenie planu
   - Dodanie przypadków
   - Przypisanie użytkowników
   - Wykonanie testu (PASSED)
   - Wykonanie testu (FAILED) z błędem
   - Przeglądanie historii

## Status
✅ Kod gotowy do implementacji
