# TestRun Manager - Logo Design

## Koncepcja Logo

Logo **TestRun Manager** zostało zaprojektowane z myślą o odzwierciedleniu kluczowych funkcji systemu zarządzania testami.

### Elementy Logo

1. **Okrąg z gradientem (niebieski)**
   - Reprezentuje kompletność i profesjonalizm
   - Gradient od jasnego (#3b82f6) do ciemnego (#1d4ed8) niebieskiego symbolizuje postęp i rozwój

2. **Trójkąt "Play" (biały)**
   - Symbolizuje **"Run"** - uruchamianie testów
   - Wskazuje na akcję i dynamikę systemu
   - Pozycjonowany centralnie jako główny element

3. **Checkmark (biały)**
   - Reprezentuje **"Test"** - weryfikację i zatwierdzenie
   - Symbol sukcesu i zaliczonych testów
   - Umieszczony w prawym górnym rogu

4. **Dolna linia (biała)**
   - Symbolizuje **"Manager"** - zarządzanie i organizację
   - Reprezentuje stabilność i strukturę
   - Podkreśla całość kompozycji

### Wersje Logo

#### 1. Logo Główne (Logo.tsx)
- Rozmiar: 32-64px
- Użycie: Nagłówek aplikacji, strona logowania
- Pełna wersja z wszystkimi elementami

#### 2. Logo Kompaktowe (LogoCompact.tsx)
- Rozmiar: 24-32px
- Użycie: Małe ikony, favicon
- Inicjały "TRM" + małe akcenty (play + checkmark)

### Paleta Kolorów

- **Główny niebieski**: #3b82f6 (blue-500)
- **Ciemny niebieski**: #1d4ed8 (blue-700)
- **Biały**: #ffffff (elementy na gradiencie)
- **Przezroczystość**: 0.6-0.9 dla subtelnych akcentów

### Symbolika

Logo łączy trzy kluczowe aspekty systemu:
- ▶️ **Run** - uruchamianie i wykonywanie testów
- ✓ **Test** - weryfikacja i kontrola jakości
- 📊 **Manager** - zarządzanie procesem testowym

---

**Autor**: ITM Marek Dacz  
**Wersja**: 1.0  
**Data**: 2026
