import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import { ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';
import { isAuthenticated } from './lib/auth';
import { ProjectProvider } from './context/ProjectContext';
import Login from './pages/Login';
import Dashboard from './pages/Dashboard';
import Projects from './pages/Projects';
import Tests from './pages/Tests';
import TestDetail from './pages/TestDetail';
import AdminPanel from './pages/AdminPanel';
import Requirements from './pages/Requirements';
import TestSpecifications from './pages/TestSpecifications';
import Defects from './pages/Defects';
import TestExecution from './pages/TestExecution';
import Reports from './pages/Reports';
import StatusDictionaries from './pages/StatusDictionaries';
import Layout from './components/Layout';

function PrivateRoute({ children }: { children: React.ReactNode }) {
  return isAuthenticated() ? <>{children}</> : <Navigate to="/login" />;
}

function App() {
  return (
    <BrowserRouter>
      <ProjectProvider>
        <Routes>
          <Route path="/login" element={<Login />} />
          <Route
            path="/"
            element={
              <PrivateRoute>
                <Layout />
              </PrivateRoute>
            }
          >
            <Route index element={<Dashboard />} />
            <Route path="projects" element={<Projects />} />
            <Route path="tests" element={<Tests />} />
            <Route path="tests/:id" element={<TestDetail />} />
            <Route path="admin" element={<AdminPanel />} />
            <Route path="admin/statuses" element={<StatusDictionaries />} />
            <Route path="requirements" element={<Requirements />} />
            <Route path="test-specifications" element={<TestSpecifications />} />
            <Route path="defects" element={<Defects />} />
            <Route path="test-execution" element={<TestExecution />} />
            <Route path="reports" element={<Reports />} />
          </Route>
        </Routes>
        <ToastContainer
          position="bottom-right"
          autoClose={3000}
          hideProgressBar={false}
          newestOnTop={false}
          closeOnClick
          rtl={false}
          pauseOnFocusLoss
          draggable
          pauseOnHover
          theme="light"
          style={{ width: 'auto' }}
        />
      </ProjectProvider>
    </BrowserRouter>
  );
}

export default App;
