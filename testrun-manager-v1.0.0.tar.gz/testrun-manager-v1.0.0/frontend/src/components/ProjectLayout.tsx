import { Outlet, Link, useLocation } from 'react-router-dom';
import { FileText, ClipboardList, Bug } from 'lucide-react';
import { useProject } from '../context/ProjectContext';

export default function ProjectLayout() {
  const location = useLocation();
  const { selectedProject } = useProject();

  if (!selectedProject) {
    return null;
  }

  const menuItems = [
    { path: '/requirements', icon: FileText, label: 'Wymagania' },
    { path: '/test-specifications', icon: ClipboardList, label: 'Specyfikacja testowa' },
    { path: '/defects', icon: Bug, label: 'Defekty' },
  ];

  return (
    <div className="space-y-6">
      {/* Menu nawigacji modułów */}
      <div className="bg-white shadow rounded-lg">
        <nav className="flex space-x-4 px-6 py-4">
          {menuItems.map((item) => {
            const Icon = item.icon;
            const isActive = location.pathname === item.path;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`inline-flex items-center px-4 py-2 rounded-md text-sm font-medium transition-colors ${
                  isActive
                    ? 'bg-blue-100 text-blue-700'
                    : 'text-gray-600 hover:bg-gray-100 hover:text-gray-900'
                }`}
              >
                <Icon className="h-5 w-5 mr-2" />
                {item.label}
              </Link>
            );
          })}
        </nav>
      </div>

      {/* Zawartość modułu */}
      <Outlet />
    </div>
  );
}
