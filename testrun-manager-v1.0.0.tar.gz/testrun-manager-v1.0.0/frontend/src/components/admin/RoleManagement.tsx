import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2 } from 'lucide-react';
import { roles } from '../../lib/api';
import { PERMISSION_CATEGORIES, getPermissionsByCategory, permissionsToString, permissionsFromString } from '../../config/permissions';

export default function RoleManagement() {
  const [roleList, setRoleList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedRole, setSelectedRole] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    permissions: '',
  });
  const [selectedPermissions, setSelectedPermissions] = useState<string[]>([]);
  const permissionsByCategory = getPermissionsByCategory();

  useEffect(() => {
    loadRoles();
  }, []);

  const loadRoles = async () => {
    try {
      const response = await roles.getAll();
      setRoleList(response.data);
    } catch (error) {
      console.error('Error loading roles:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const permissionsString = permissionsToString(selectedPermissions);
      const dataToSave = {
        ...formData,
        permissions: permissionsString
      };
      
      if (selectedRole) {
        await roles.update(selectedRole.id, dataToSave);
      } else {
        await roles.create(dataToSave);
      }
      setShowModal(false);
      setSelectedRole(null);
      setFormData({ name: '', description: '', permissions: '' });
      setSelectedPermissions([]);
      loadRoles();
    } catch (error) {
      console.error('Error saving role:', error);
      alert('Błąd podczas zapisywania roli');
    }
  };

  const handleEdit = (role: any) => {
    if (role.id <= 4) {
      alert('Nie można edytować domyślnych ról');
      return;
    }
    setSelectedRole(role);
    const perms = permissionsFromString(role.permissions || '');
    setFormData({
      name: role.name,
      description: role.description || '',
      permissions: role.permissions || '',
    });
    setSelectedPermissions(perms);
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (id <= 4) {
      alert('Nie można usunąć domyślnych ról');
      return;
    }
    if (!confirm('Czy na pewno chcesz usunąć tę rolę?')) return;
    try {
      await roles.delete(id);
      loadRoles();
    } catch (error: any) {
      console.error('Error deleting role:', error);
      if (error.response?.data?.error) {
        alert(error.response.data.error);
      } else {
        alert('Błąd podczas usuwania roli');
      }
    }
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Zarządzanie rolami</h2>
        <button
          onClick={() => {
            setSelectedRole(null);
            setFormData({ name: '', description: '', permissions: '' });
            setSelectedPermissions([]);
            setShowModal(true);
          }}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Dodaj rolę
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nazwa roli
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Opis
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Uprawnienia
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Akcje
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {roleList.map((role) => (
              <tr key={role.id} className={role.id <= 4 ? 'bg-gray-50' : ''}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center">
                    <div className="text-sm font-medium text-gray-900">
                      {role.name}
                      {role.id <= 4 && (
                        <span className="ml-2 text-xs text-gray-500">(Domyślna)</span>
                      )}
                    </div>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-500">{role.description}</div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-xs text-gray-500">
                    {role.permissions === 'all' || role.permissions?.includes('admin.full_access') ? (
                      <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded font-medium">
                        🔓 Pełny dostęp
                      </span>
                    ) : role.permissions ? (
                      <div className="flex flex-wrap gap-1">
                        {permissionsFromString(role.permissions).map((permKey: string, idx: number) => {
                          const allPerms = Object.values(permissionsByCategory).flat();
                          const perm = allPerms.find(p => p.key === permKey);
                          return (
                            <span
                              key={idx}
                              className="inline-block px-2 py-1 bg-blue-100 text-blue-800 rounded text-xs"
                              title={perm?.description || permKey}
                            >
                              {perm?.name || permKey}
                            </span>
                          );
                        })}
                      </div>
                    ) : (
                      <span className="text-gray-400 italic">Brak uprawnień</span>
                    )}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                  <button
                    onClick={() => handleEdit(role)}
                    className={`${
                      role.id <= 4
                        ? 'text-gray-400 cursor-not-allowed'
                        : 'text-blue-600 hover:text-blue-900'
                    }`}
                    disabled={role.id <= 4}
                    title={role.id <= 4 ? 'Nie można edytować domyślnych ról' : 'Edytuj'}
                  >
                    <Edit className="h-4 w-4 inline" />
                  </button>
                  <button
                    onClick={() => handleDelete(role.id)}
                    className={`${
                      role.id <= 4
                        ? 'text-gray-400 cursor-not-allowed'
                        : 'text-red-600 hover:text-red-900'
                    }`}
                    disabled={role.id <= 4}
                    title={role.id <= 4 ? 'Nie można usunąć domyślnych ról' : 'Usuń'}
                  >
                    <Trash2 className="h-4 w-4 inline" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal dodawania/edycji roli */}
      {showModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4 pt-4 pb-20">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => setShowModal(false)}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-6xl w-full z-20 my-8">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-6 pt-5 pb-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {selectedRole ? 'Edytuj rolę' : 'Nowa rola'}
                  </h3>
                  <div className="space-y-4">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Nazwa roli</label>
                        <input
                          type="text"
                          required
                          value={formData.name}
                          onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          placeholder="np. Project Manager"
                        />
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Opis</label>
                        <input
                          type="text"
                          value={formData.description}
                          onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                          placeholder="Krótki opis roli..."
                        />
                      </div>
                    </div>
                    
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-3">
                        Uprawnienia
                      </label>
                      <div className="border border-gray-200 rounded-lg overflow-hidden">
                        <div className="max-h-96 overflow-y-auto">
                          <table className="min-w-full divide-y divide-gray-200">
                            <thead className="bg-gray-50 sticky top-0">
                              <tr>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider w-12">
                                  <input
                                    type="checkbox"
                                    checked={selectedPermissions.includes('admin.full_access')}
                                    onChange={(e) => {
                                      if (e.target.checked) {
                                        setSelectedPermissions(['admin.full_access']);
                                      } else {
                                        setSelectedPermissions([]);
                                      }
                                    }}
                                    className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                                  />
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Funkcja
                                </th>
                                <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                  Opis
                                </th>
                              </tr>
                            </thead>
                            <tbody className="bg-white divide-y divide-gray-200">
                              {Object.entries(permissionsByCategory).map(([category, perms]) => (
                                <>
                                  <tr key={category} className="bg-gray-100">
                                    <td colSpan={3} className="px-4 py-2 text-sm font-semibold text-gray-700">
                                      {PERMISSION_CATEGORIES[category as keyof typeof PERMISSION_CATEGORIES]}
                                    </td>
                                  </tr>
                                  {perms.map((permission) => (
                                    <tr key={permission.key} className="hover:bg-gray-50">
                                      <td className="px-4 py-3 whitespace-nowrap">
                                        <input
                                          type="checkbox"
                                          checked={selectedPermissions.includes(permission.key) || selectedPermissions.includes('admin.full_access')}
                                          disabled={selectedPermissions.includes('admin.full_access') && permission.key !== 'admin.full_access'}
                                          onChange={(e) => {
                                            if (e.target.checked) {
                                              setSelectedPermissions([...selectedPermissions, permission.key]);
                                            } else {
                                              setSelectedPermissions(selectedPermissions.filter(p => p !== permission.key));
                                            }
                                          }}
                                          className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded disabled:opacity-50"
                                        />
                                      </td>
                                      <td className="px-4 py-3 text-sm text-gray-900">
                                        {permission.name}
                                      </td>
                                      <td className="px-4 py-3 text-sm text-gray-500">
                                        {permission.description}
                                      </td>
                                    </tr>
                                  ))}
                                </>
                              ))}
                            </tbody>
                          </table>
                        </div>
                      </div>
                      <p className="mt-2 text-xs text-gray-500">
                        Zaznacz checkbox w nagłówku aby przyznać pełny dostęp do systemu
                      </p>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-6 py-3 flex justify-between items-center">
                  <div className="text-sm text-gray-600">
                    Wybrano uprawnień: <span className="font-semibold">{selectedPermissions.length}</span>
                  </div>
                  <div className="flex gap-3">
                    <button
                      type="button"
                      onClick={() => setShowModal(false)}
                      className="inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-sm font-medium text-gray-700 hover:bg-gray-50 focus:outline-none"
                    >
                      Anuluj
                    </button>
                    <button
                      type="submit"
                      className="inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-sm font-medium text-white hover:bg-blue-700 focus:outline-none"
                    >
                      {selectedRole ? 'Zapisz zmiany' : 'Utwórz rolę'}
                    </button>
                  </div>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
