import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Key, FolderOpen, X } from 'lucide-react';
import { users, roles, projects } from '../../lib/api';

export default function UserManagement() {
  const [userList, setUserList] = useState<any[]>([]);
  const [roleList, setRoleList] = useState<any[]>([]);
  const [projectList, setProjectList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showPasswordModal, setShowPasswordModal] = useState(false);
  const [showProjectsModal, setShowProjectsModal] = useState(false);
  const [selectedUser, setSelectedUser] = useState<any>(null);
  const [userProjects, setUserProjects] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    email: '',
    password: '',
    name: '',
    role_id: 4,
    is_active: 1,
  });
  const [newPassword, setNewPassword] = useState('');

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      const [usersRes, rolesRes, projectsRes] = await Promise.all([
        users.getAll(),
        roles.getAll(),
        projects.getAll(),
      ]);
      console.log('Users:', usersRes.data);
      console.log('Roles:', rolesRes.data);
      console.log('Projects:', projectsRes.data);
      setUserList(usersRes.data);
      setRoleList(rolesRes.data);
      setProjectList(projectsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (selectedUser) {
        await users.update(selectedUser.id, {
          email: formData.email,
          name: formData.name,
          role_id: formData.role_id,
          is_active: formData.is_active,
        });
      } else {
        await users.create(formData);
      }
      setShowModal(false);
      setSelectedUser(null);
      setFormData({ email: '', password: '', name: '', role_id: 4, is_active: 1 });
      loadData();
    } catch (error) {
      console.error('Error saving user:', error);
      alert('Błąd podczas zapisywania użytkownika');
    }
  };

  const handleEdit = (user: any) => {
    setSelectedUser(user);
    setFormData({
      email: user.email,
      password: '',
      name: user.name,
      role_id: user.role_id,
      is_active: user.is_active,
    });
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Czy na pewno chcesz usunąć tego użytkownika?')) return;
    try {
      await users.delete(id);
      loadData();
    } catch (error) {
      console.error('Error deleting user:', error);
      alert('Błąd podczas usuwania użytkownika');
    }
  };

  const handleResetPassword = async () => {
    if (!selectedUser || !newPassword) return;
    try {
      await users.resetPassword(selectedUser.id, newPassword);
      setShowPasswordModal(false);
      setSelectedUser(null);
      setNewPassword('');
      alert('Hasło zostało zresetowane');
    } catch (error) {
      console.error('Error resetting password:', error);
      alert('Błąd podczas resetowania hasła');
    }
  };

  const handleShowProjects = async (user: any) => {
    setSelectedUser(user);
    try {
      const response = await users.getProjects(user.id);
      setUserProjects(response.data);
      setShowProjectsModal(true);
    } catch (error) {
      console.error('Error loading user projects:', error);
    }
  };

  const handleAssignProject = async (projectId: number) => {
    if (!selectedUser) return;
    try {
      await users.assignProject(selectedUser.id, projectId);
      const response = await users.getProjects(selectedUser.id);
      setUserProjects(response.data);
      // Odśwież listę użytkowników aby zaktualizować kolumnę projektów
      loadData();
    } catch (error) {
      console.error('Error assigning project:', error);
    }
  };

  const handleUnassignProject = async (projectId: number) => {
    if (!selectedUser) return;
    try {
      await users.unassignProject(selectedUser.id, projectId);
      const response = await users.getProjects(selectedUser.id);
      setUserProjects(response.data);
      // Odśwież listę użytkowników aby zaktualizować kolumnę projektów
      loadData();
    } catch (error) {
      console.error('Error unassigning project:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold text-gray-900">Zarządzanie użytkownikami</h2>
        <button
          onClick={() => {
            setSelectedUser(null);
            setFormData({ email: '', password: '', name: '', role_id: 4, is_active: 1 });
            setShowModal(true);
          }}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Dodaj użytkownika
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Użytkownik
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Email
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Rola
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Przypisane projekty
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Akcje
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {userList.map((user) => (
              <tr key={user.id}>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm font-medium text-gray-900">{user.name}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="text-sm text-gray-500">{user.email}</div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-blue-100 text-blue-800">
                    {user.role_name}
                  </span>
                </td>
                <td className="px-6 py-4">
                  {user.projects && user.projects.length > 0 ? (
                    <div className="flex flex-wrap gap-1">
                      {user.projects.map((project: any) => (
                        <span
                          key={project.id}
                          className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-purple-100 text-purple-800"
                        >
                          {project.name}
                        </span>
                      ))}
                    </div>
                  ) : (
                    <span className="text-xs text-gray-400 italic">Brak przypisanych projektów</span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <span
                    className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      user.is_active
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {user.is_active ? 'Aktywny' : 'Nieaktywny'}
                  </span>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                  <button
                    onClick={() => handleShowProjects(user)}
                    className="text-purple-600 hover:text-purple-900"
                    title="Zarządzaj projektami"
                  >
                    <FolderOpen className="h-4 w-4 inline" />
                  </button>
                  <button
                    onClick={() => handleEdit(user)}
                    className="text-blue-600 hover:text-blue-900"
                    title="Edytuj"
                  >
                    <Edit className="h-4 w-4 inline" />
                  </button>
                  <button
                    onClick={() => {
                      setSelectedUser(user);
                      setShowPasswordModal(true);
                    }}
                    className="text-yellow-600 hover:text-yellow-900"
                    title="Resetuj hasło"
                  >
                    <Key className="h-4 w-4 inline" />
                  </button>
                  <button
                    onClick={() => handleDelete(user.id)}
                    className="text-red-600 hover:text-red-900"
                    title="Usuń"
                  >
                    <Trash2 className="h-4 w-4 inline" />
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal dodawania/edycji użytkownika */}
      {showModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => setShowModal(false)}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-lg w-full z-20">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {selectedUser ? 'Edytuj użytkownika' : 'Nowy użytkownik'}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Imię i nazwisko</label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Email</label>
                      <input
                        type="email"
                        required
                        value={formData.email}
                        onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    {!selectedUser && (
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Hasło</label>
                        <input
                          type="password"
                          required={!selectedUser}
                          value={formData.password}
                          onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        />
                      </div>
                    )}
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Rola</label>
                      <select
                        value={formData.role_id}
                        onChange={(e) => setFormData({ ...formData, role_id: parseInt(e.target.value) })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      >
                        {roleList.map((role) => (
                          <option key={role.id} value={role.id}>
                            {role.name}
                          </option>
                        ))}
                      </select>
                    </div>
                    {selectedUser && (
                      <div>
                        <label className="flex items-center">
                          <input
                            type="checkbox"
                            checked={formData.is_active === 1}
                            onChange={(e) => setFormData({ ...formData, is_active: e.target.checked ? 1 : 0 })}
                            className="h-4 w-4 text-blue-600 focus:ring-blue-500 border-gray-300 rounded"
                          />
                          <span className="ml-2 text-sm text-gray-700">Konto aktywne</span>
                        </label>
                      </div>
                    )}
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {selectedUser ? 'Zapisz' : 'Utwórz'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm"
                  >
                    Anuluj
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal resetowania hasła */}
      {showPasswordModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => setShowPasswordModal(false)}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-md w-full z-20">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Resetuj hasło: {selectedUser?.name}
                </h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700">Nowe hasło</label>
                  <input
                    type="password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                  />
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  onClick={handleResetPassword}
                  className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                >
                  Resetuj hasło
                </button>
                <button
                  onClick={() => setShowPasswordModal(false)}
                  className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm"
                >
                  Anuluj
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal przypisywania projektów */}
      {showProjectsModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => setShowProjectsModal(false)}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-2xl w-full z-20">
              <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                <h3 className="text-lg font-medium text-gray-900 mb-4">
                  Projekty użytkownika: {selectedUser?.name}
                </h3>
                
                <div className="mb-4">
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Przypisane projekty</h4>
                  {userProjects.length === 0 ? (
                    <p className="text-sm text-gray-500">Brak przypisanych projektów</p>
                  ) : (
                    <div className="space-y-2">
                      {userProjects.map((project) => (
                        <div key={project.id} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                          <span className="text-sm">{project.name}</span>
                          <button
                            onClick={() => handleUnassignProject(project.id)}
                            className="text-red-600 hover:text-red-900"
                          >
                            <X className="h-4 w-4" />
                          </button>
                        </div>
                      ))}
                    </div>
                  )}
                </div>

                <div>
                  <h4 className="text-sm font-medium text-gray-700 mb-2">Dostępne projekty</h4>
                  <div className="space-y-2 max-h-60 overflow-y-auto">
                    {projectList
                      .filter((p) => !userProjects.find((up) => up.id === p.id))
                      .map((project) => (
                        <div key={project.id} className="flex items-center justify-between bg-gray-50 p-2 rounded">
                          <span className="text-sm">{project.name}</span>
                          <button
                            onClick={() => handleAssignProject(project.id)}
                            className="text-blue-600 hover:text-blue-900 text-sm"
                          >
                            Przypisz
                          </button>
                        </div>
                      ))}
                  </div>
                </div>
              </div>
              <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                <button
                  onClick={() => setShowProjectsModal(false)}
                  className="w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:w-auto sm:text-sm"
                >
                  Zamknij
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
