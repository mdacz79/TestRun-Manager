import { useState, useEffect } from 'react';
import { X, CheckCircle, XCircle, MinusCircle, Ban, Clock } from 'lucide-react';
import { testExecutions } from '../lib/api';

interface TestHistoryModalProps {
  testCase: any;
  onClose: () => void;
}

export default function TestHistoryModal({ testCase, onClose }: TestHistoryModalProps) {
  const [history, setHistory] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadHistory();
  }, []);

  const loadHistory = async () => {
    try {
      const res = await testExecutions.getHistory(testCase.id);
      setHistory(res.data);
    } catch (error) {
      console.error('Error loading history:', error);
    } finally {
      setLoading(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PASSED': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'FAILED': return <XCircle className="h-5 w-5 text-red-600" />;
      case 'SKIPPED': return <MinusCircle className="h-5 w-5 text-gray-600" />;
      case 'BLOCKED': return <Ban className="h-5 w-5 text-orange-600" />;
      case 'IN_PROGRESS': return <Clock className="h-5 w-5 text-blue-600" />;
      default: return null;
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'PASSED': return 'Zaliczony';
      case 'FAILED': return 'Niezaliczony';
      case 'SKIPPED': return 'Pominięty';
      case 'BLOCKED': return 'Zablokowany';
      case 'IN_PROGRESS': return 'W trakcie';
      default: return status;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[80vh] overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <div className="font-mono text-sm font-semibold text-blue-600">
                {testCase.test_case_id}
              </div>
              <h2 className="text-xl font-bold mt-1">Historia wykonań</h2>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[60vh]">
          {loading ? (
            <p>Ładowanie historii...</p>
          ) : history.length === 0 ? (
            <p className="text-gray-500 text-center py-8">Brak historii wykonań</p>
          ) : (
            <div className="space-y-4">
              {history.map((exec) => (
                <div key={exec.id} className="border rounded-lg p-4 bg-gray-50">
                  <div className="flex items-start justify-between mb-3">
                    <div className="flex items-center gap-2">
                      {getStatusIcon(exec.status)}
                      <span className="font-semibold text-gray-900">
                        {getStatusLabel(exec.status)}
                      </span>
                    </div>
                    <div className="text-sm text-gray-500">
                      {new Date(exec.created_at).toLocaleString('pl-PL')}
                    </div>
                  </div>

                  <div className="space-y-2 text-sm">
                    <div className="flex items-center gap-2">
                      <span className="text-gray-500">👤 Wykonał:</span>
                      <span className="font-medium">{exec.executed_by_name}</span>
                    </div>

                    {exec.test_plan_name && (
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">📋 Plan:</span>
                        <span>{exec.test_plan_name}</span>
                      </div>
                    )}

                    {exec.bug_id && (
                      <div className="flex items-center gap-2">
                        <span className="text-gray-500">🐛 Błąd:</span>
                        <span className="font-mono text-red-600">{exec.bug_id}</span>
                        {exec.bug_title && <span>- {exec.bug_title}</span>}
                      </div>
                    )}

                    {exec.notes && (
                      <div className="mt-2 pt-2 border-t">
                        <span className="text-gray-500">📝 Notatki:</span>
                        <p className="mt-1 text-gray-700">{exec.notes}</p>
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 border-t flex justify-end">
          <button
            onClick={onClose}
            className="px-4 py-2 bg-gray-600 text-white rounded-md hover:bg-gray-700"
          >
            Zamknij
          </button>
        </div>
      </div>
    </div>
  );
}
