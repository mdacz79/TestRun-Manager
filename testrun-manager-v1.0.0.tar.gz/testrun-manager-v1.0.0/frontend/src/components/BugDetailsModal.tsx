import { useState, useEffect } from 'react';
import { X, UserPlus, MessageSquare, Clock, Paperclip, Download, Trash2 } from 'lucide-react';
import { bugs as bugsApi, users as usersApi, statuses as statusesApi } from '../lib/api';
import { usePermissions } from '../hooks/usePermissions';

interface BugDetailsModalProps {
  bug: any;
  onClose: () => void;
  onUpdate: () => void;
}

export default function BugDetailsModal({ bug, onClose, onUpdate }: BugDetailsModalProps) {
  const { can } = usePermissions();
  const [comments, setComments] = useState<any[]>([]);
  const [newComment, setNewComment] = useState('');
  const [showReassign, setShowReassign] = useState(false);
  const [selectedUser, setSelectedUser] = useState<number | null>(null);
  const [reassignComment, setReassignComment] = useState('');
  const [newStatus, setNewStatus] = useState<string>('');
  const [users, setUsers] = useState<any[]>([]);
  const [bugStatuses, setBugStatuses] = useState<any[]>([]);
  const [statusHistory, setStatusHistory] = useState<any[]>([]);
  const [attachments, setAttachments] = useState<any[]>([]);
  const [loading, setLoading] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [activeTab, setActiveTab] = useState<'history' | 'comments' | 'attachments'>('history');

  useEffect(() => {
    loadComments();
    loadUsers();
    loadStatuses();
    loadStatusHistory();
    loadAttachments();
  }, [bug.id]);

  const loadStatuses = async () => {
    try {
      const res = await statusesApi.getBugStatuses();
      setBugStatuses(res.data.filter((s: any) => s.is_active));
    } catch (error) {
      console.error('Error loading statuses:', error);
    }
  };

  const loadStatusHistory = async () => {
    try {
      const res = await bugsApi.getStatusHistory(bug.id);
      setStatusHistory(res.data);
    } catch (error) {
      console.error('Error loading status history:', error);
    }
  };

  const getStatusName = (statusKey: string) => {
    const status = bugStatuses.find(s => s.key === statusKey);
    return status ? status.name : statusKey;
  };

  const loadComments = async () => {
    try {
      const res = await bugsApi.getComments(bug.id);
      setComments(res.data);
    } catch (error) {
      console.error('Error loading comments:', error);
    }
  };

  const loadUsers = async () => {
    try {
      const res = await usersApi.getList();
      setUsers(res.data);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadAttachments = async () => {
    try {
      const res = await bugsApi.getAttachments(bug.id);
      setAttachments(res.data);
    } catch (error) {
      console.error('Error loading attachments:', error);
    }
  };

  const handleFileUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      await bugsApi.uploadAttachment(bug.id, file);
      loadAttachments();
      event.target.value = ''; // Reset input
    } catch (error) {
      console.error('Error uploading file:', error);
      alert('Błąd podczas przesyłania pliku');
    } finally {
      setUploading(false);
    }
  };

  const handleDeleteAttachment = async (attachmentId: number) => {
    if (!confirm('Czy na pewno chcesz usunąć ten załącznik?')) return;
    
    try {
      await bugsApi.deleteAttachment(attachmentId);
      loadAttachments();
    } catch (error) {
      console.error('Error deleting attachment:', error);
      alert('Błąd podczas usuwania załącznika');
    }
  };

  const handleAddComment = async () => {
    if (!newComment.trim()) return;
    
    setLoading(true);
    try {
      await bugsApi.addComment(bug.id, newComment);
      setNewComment('');
      loadComments();
    } catch (error) {
      console.error('Error adding comment:', error);
      alert('Błąd podczas dodawania komentarza');
    } finally {
      setLoading(false);
    }
  };

  const handleChangeStatus = async () => {
    if (!newStatus || newStatus === bug.status) {
      alert('Wybierz nowy status');
      return;
    }

    setLoading(true);
    try {
      await bugsApi.update(bug.id, { status: newStatus });
      
      // Pobierz zaktualizowane dane błędu
      const updatedBug = await bugsApi.getById(bug.id);
      Object.assign(bug, updatedBug.data);
      
      setNewStatus('');
      loadComments();
      loadStatusHistory();
      onUpdate();
    } catch (error) {
      console.error('Error changing status:', error);
      alert('Błąd podczas zmiany statusu');
    } finally {
      setLoading(false);
    }
  };

  const handleReassign = async () => {
    if (!selectedUser) {
      alert('Wybierz użytkownika');
      return;
    }

    setLoading(true);
    try {
      // Przepisz błąd
      await bugsApi.reassign(bug.id, selectedUser, reassignComment || undefined);
      
      // Jeśli zmieniono status, zaktualizuj go
      if (newStatus && newStatus !== bug.status) {
        await bugsApi.update(bug.id, { status: newStatus });
      }
      
      // Pobierz zaktualizowane dane błędu
      const updatedBug = await bugsApi.getById(bug.id);
      
      // Zaktualizuj obiekt bug w komponencie
      Object.assign(bug, updatedBug.data);
      
      setShowReassign(false);
      setReassignComment('');
      setSelectedUser(null);
      setNewStatus('');
      loadComments();
      loadStatusHistory();
      onUpdate();
    } catch (error) {
      console.error('Error reassigning bug:', error);
      alert('Błąd podczas przepisywania');
    } finally {
      setLoading(false);
    }
  };

  const formatDate = (dateString: string) => {
    const date = new Date(dateString);
    return date.toLocaleString('pl-PL', {
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  const renderDescription = (text: string) => {
    if (!text) return null;
    
    const html = text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-blue-600 underline" target="_blank">$1</a>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/^(\d+)\. (.+)$/gm, '<li>$2</li>')
      .replace(/\n/g, '<br/>');
    
    return <div dangerouslySetInnerHTML={{ __html: html }} className="prose prose-sm max-w-none" />;
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-hidden flex flex-col">
        {/* Header */}
        <div className="flex justify-between items-start p-6 border-b">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              {bug.bug_id && (
                <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                  {bug.bug_id}
                </span>
              )}
              <h2 className="text-xl font-bold">{bug.title}</h2>
            </div>
            <div className="flex flex-wrap gap-4 text-sm text-gray-600">
              <span>Status: <span className="font-medium">{getStatusName(bug.status)}</span></span>
              <span>Priorytet: <span className="font-medium">{bug.priority}</span></span>
              <span>Severity: <span className="font-medium">{bug.severity}</span></span>
              {bug.assigned_to_name && (
                <span>Przypisany: <span className="font-medium">{bug.assigned_to_name}</span></span>
              )}
            </div>
            <div className="flex flex-wrap gap-4 text-sm text-gray-500 mt-2">
              {bug.reported_by_name && (
                <span>Zgłosił: <span className="font-medium text-gray-700">{bug.reported_by_name}</span></span>
              )}
              {bug.created_at && (
                <span>Data zgłoszenia: <span className="font-medium text-gray-700">{formatDate(bug.created_at)}</span></span>
              )}
              {bug.updated_at && (
                <span>Ostatnia modyfikacja: <span className="font-medium text-gray-700">{formatDate(bug.updated_at)}</span></span>
              )}
            </div>
          </div>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        {/* Content */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">
          {/* Description */}
          {bug.description && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Opis</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                {renderDescription(bug.description)}
              </div>
            </div>
          )}

          {/* Steps to reproduce */}
          {bug.steps_to_reproduce && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Kroki do reprodukcji</h3>
              <div className="bg-gray-50 rounded-lg p-4">
                {renderDescription(bug.steps_to_reproduce)}
              </div>
            </div>
          )}

          {/* Change Status Section */}
          {can('defects.change_status') && !can('defects.assign') && (
            <div className="border-t pt-6">
              <h3 className="font-semibold text-gray-900 mb-3">Zmień status</h3>
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-3">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nowy status *
                  </label>
                  <select
                    value={newStatus || bug.status}
                    onChange={(e) => setNewStatus(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {bugStatuses.map((status) => (
                      <option key={status.id} value={status.key}>
                        {status.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleChangeStatus}
                    disabled={loading || !newStatus || newStatus === bug.status}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
                  >
                    Zmień status
                  </button>
                  <button
                    onClick={() => setNewStatus('')}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Anuluj
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* Reassign Section */}
          {can('defects.assign') && (
            <div className="border-t pt-6">
              {!showReassign ? (
                <button
                  onClick={() => setShowReassign(true)}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  <UserPlus className="h-4 w-4" />
                  Przepisz błąd
                </button>
              ) : (
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 space-y-3">
                <h3 className="font-semibold text-gray-900">Przepisz błąd</h3>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nowy właściciel *
                  </label>
                  <select
                    value={selectedUser || ''}
                    onChange={(e) => setSelectedUser(Number(e.target.value))}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    <option value="">Wybierz użytkownika</option>
                    {users.map((user) => (
                      <option key={user.id} value={user.id}>
                        {user.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Zmień status (opcjonalnie)
                  </label>
                  <select
                    value={newStatus || bug.status}
                    onChange={(e) => setNewStatus(e.target.value)}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  >
                    {bugStatuses.map((status) => (
                      <option key={status.id} value={status.key}>
                        {status.name}
                      </option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Komentarz (opcjonalnie)
                  </label>
                  <textarea
                    value={reassignComment}
                    onChange={(e) => setReassignComment(e.target.value)}
                    rows={2}
                    className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="Powód przepisania..."
                  />
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={handleReassign}
                    disabled={loading || !selectedUser}
                    className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
                  >
                    Przepisz
                  </button>
                  <button
                    onClick={() => {
                      setShowReassign(false);
                      setReassignComment('');
                      setSelectedUser(null);
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                  >
                    Anuluj
                  </button>
                </div>
              </div>
            )}
            </div>
          )}

          {/* Tabs Section - Historia i Komentarze */}
          <div className="border-t pt-6">
            {/* Tab Headers */}
            <div className="flex border-b border-gray-200 mb-4">
              <button
                onClick={() => setActiveTab('history')}
                className={`flex items-center gap-2 px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'history'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Clock className="h-4 w-4" />
                Historia zmian statusu ({statusHistory.length})
              </button>
              <button
                onClick={() => setActiveTab('comments')}
                className={`flex items-center gap-2 px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'comments'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <MessageSquare className="h-4 w-4" />
                Komentarze ({comments.length})
              </button>
              <button
                onClick={() => setActiveTab('attachments')}
                className={`flex items-center gap-2 px-4 py-2 border-b-2 font-medium text-sm transition-colors ${
                  activeTab === 'attachments'
                    ? 'border-blue-600 text-blue-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                }`}
              >
                <Paperclip className="h-4 w-4" />
                Załączniki ({attachments.length})
              </button>
            </div>

            {/* Tab Content */}
            {activeTab === 'history' && (
              <div className="space-y-2">
                {statusHistory.length > 0 ? (
                  statusHistory.map((history) => (
                    <div key={history.id} className="bg-gray-50 border rounded-lg p-3">
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2 flex-wrap">
                            <span className="font-medium text-gray-900">{history.changed_by_name}</span>
                            <span className="text-sm text-gray-500">zmienił status z</span>
                            <span className="px-2 py-0.5 rounded text-xs font-medium bg-gray-200 text-gray-800">
                              {getStatusName(history.old_status)}
                            </span>
                            <span className="text-sm text-gray-500">na</span>
                            <span className="px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                              {getStatusName(history.new_status)}
                            </span>
                          </div>
                          {history.comment && (
                            <p className="mt-2 text-sm text-gray-700">{history.comment}</p>
                          )}
                        </div>
                        <span className="text-xs text-gray-500 whitespace-nowrap ml-4">
                          {new Date(history.created_at).toLocaleString('pl-PL')}
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <p className="text-sm text-gray-500 text-center py-8">Brak historii zmian statusu</p>
                )}
              </div>
            )}

            {activeTab === 'comments' && (
              <div>
                {/* Add Comment */}
                {can('defects.edit') && (
                  <div className="mb-4">
                    <textarea
                      value={newComment}
                      onChange={(e) => setNewComment(e.target.value)}
                      rows={3}
                      className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="Dodaj komentarz..."
                    />
                    <button
                      onClick={handleAddComment}
                      disabled={loading || !newComment.trim()}
                      className="mt-2 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
                    >
                      Dodaj komentarz
                    </button>
                  </div>
                )}

                {/* Comments List */}
                <div className="space-y-3">
                  {comments.map((comment) => (
                    <div key={comment.id} className={`border rounded-lg p-4 ${
                      comment.is_reassignment ? 'bg-blue-50 border-blue-200' : 'bg-gray-50'
                    }`}>
                      <div className="flex items-start justify-between mb-2">
                        <div className="flex items-center gap-2">
                          <span className="font-medium text-gray-900">{comment.user_name}</span>
                          {comment.is_reassignment === 1 && (
                            <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                              <UserPlus className="h-3 w-3 mr-1" />
                              Przepisanie
                            </span>
                          )}
                        </div>
                        <div className="flex items-center gap-1 text-xs text-gray-500">
                          <Clock className="h-3 w-3" />
                          {formatDate(comment.created_at)}
                        </div>
                      </div>
                      
                      {comment.is_reassignment === 1 && (
                        <div className="text-sm text-blue-800 mb-2">
                          Przepisano z <strong>{comment.old_assignee_name || 'Nieprzypisany'}</strong> na <strong>{comment.new_assignee_name}</strong>
                        </div>
                      )}
                      
                      {comment.comment && (
                        <div className="text-sm text-gray-700 whitespace-pre-wrap">
                          {comment.comment}
                        </div>
                      )}
                    </div>
                  ))}
              
                  {comments.length === 0 && (
                    <div className="text-center py-8 text-gray-500">
                      Brak komentarzy
                    </div>
                  )}
                </div>
              </div>
            )}

            {activeTab === 'attachments' && (
              <div>
                {/* Upload Section */}
                {can('defects.edit') && (
                  <div className="mb-4">
                    <label className="block">
                      <span className="sr-only">Wybierz plik</span>
                      <input
                        type="file"
                        onChange={handleFileUpload}
                        disabled={uploading}
                        className="block w-full text-sm text-gray-500
                          file:mr-4 file:py-2 file:px-4
                          file:rounded-md file:border-0
                          file:text-sm file:font-medium
                          file:bg-blue-50 file:text-blue-700
                          hover:file:bg-blue-100
                          disabled:opacity-50 disabled:cursor-not-allowed"
                      />
                    </label>
                    {uploading && (
                      <p className="mt-2 text-sm text-gray-500">Przesyłanie...</p>
                    )}
                  </div>
                )}

                {/* Attachments List */}
                <div className="space-y-2">
                  {attachments.length > 0 ? (
                    attachments.map((attachment) => (
                      <div key={attachment.id} className="flex items-center justify-between bg-gray-50 border rounded-lg p-3">
                        <div className="flex items-center gap-3 flex-1 min-w-0">
                          <Paperclip className="h-5 w-5 text-gray-400 flex-shrink-0" />
                          <div className="flex-1 min-w-0">
                            <p className="text-sm font-medium text-gray-900 truncate">
                              {attachment.original_filename}
                            </p>
                            <p className="text-xs text-gray-500">
                              {(attachment.file_size / 1024).toFixed(2)} KB • {attachment.uploaded_by_name} • {new Date(attachment.created_at).toLocaleString('pl-PL')}
                            </p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 flex-shrink-0">
                          <a
                            href={bugsApi.downloadAttachment(attachment.id)}
                            download
                            className="p-2 text-blue-600 hover:bg-blue-50 rounded-md transition-colors"
                            title="Pobierz"
                          >
                            <Download className="h-4 w-4" />
                          </a>
                          {can('defects.edit') && (
                            <button
                              onClick={() => handleDeleteAttachment(attachment.id)}
                              className="p-2 text-red-600 hover:bg-red-50 rounded-md transition-colors"
                              title="Usuń"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                        </div>
                      </div>
                    ))
                  ) : (
                    <p className="text-sm text-gray-500 text-center py-8">Brak załączników</p>
                  )}
                </div>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
