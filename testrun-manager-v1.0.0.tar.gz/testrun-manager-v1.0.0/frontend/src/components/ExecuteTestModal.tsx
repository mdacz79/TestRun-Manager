import { useState } from 'react';
import { X, CheckCircle, XCircle, MinusCircle, Ban } from 'lucide-react';

interface ExecuteTestModalProps {
  testCase: any;
  execution: any;
  bugId?: number;
  onClose: () => void;
  onComplete: (data: { status: string; bug_id?: number; notes?: string }) => void;
  onCreateBug: () => void;
}

export default function ExecuteTestModal({ testCase, bugId, onClose, onComplete, onCreateBug }: ExecuteTestModalProps) {
  const [selectedStatus, setSelectedStatus] = useState<string>('');
  const [notes, setNotes] = useState('');
  const [stepStatuses, setStepStatuses] = useState<{ [key: number]: string }>({});

  const handleStepStatusChange = (stepIndex: number, status: string) => {
    setStepStatuses(prev => ({
      ...prev,
      [stepIndex]: status
    }));
  };

  const getStepStatusIcon = (stepIndex: number) => {
    const status = stepStatuses[stepIndex];
    if (!status) return null;
    
    switch (status) {
      case 'PASSED':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'FAILED':
        return <XCircle className="h-4 w-4 text-red-600" />;
      case 'SKIPPED':
        return <MinusCircle className="h-4 w-4 text-gray-600" />;
      default:
        return null;
    }
  };

  const getStepStatusColor = (stepIndex: number) => {
    const status = stepStatuses[stepIndex];
    if (!status) return 'bg-gray-50';
    
    switch (status) {
      case 'PASSED':
        return 'bg-green-50 border-green-200';
      case 'FAILED':
        return 'bg-red-50 border-red-200';
      case 'SKIPPED':
        return 'bg-gray-100 border-gray-300';
      default:
        return 'bg-gray-50';
    }
  };

  const handleStatusClick = async (status: string) => {
    setSelectedStatus(status);
    
    if (status === 'FAILED') {
      // Otwórz modal tworzenia błędu
      onCreateBug();
      // Po utworzeniu błędu, bug ID będzie przekazany z rodzica
    }
  };

  const handleComplete = () => {
    if (!selectedStatus) return;
    
    onComplete({
      status: selectedStatus,
      bug_id: bugId,
      notes,
    });
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-3xl w-full max-h-[90vh] overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <div>
              <div className="font-mono text-sm font-semibold text-blue-600">
                {testCase.test_case_id}
              </div>
              <h2 className="text-xl font-bold mt-1">{testCase.title}</h2>
            </div>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[50vh] space-y-6">
          {/* Opis */}
          {testCase.description && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Opis</h3>
              <p className="text-sm text-gray-700">{testCase.description}</p>
            </div>
          )}

          {/* Warunki wstępne */}
          {testCase.preconditions && (
            <div>
              <h3 className="font-semibold text-gray-900 mb-2">Warunki wstępne</h3>
              <p className="text-sm text-gray-700">{testCase.preconditions}</p>
            </div>
          )}

          {/* Kroki testowe */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Kroki testowe</h3>
            {testCase.steps && testCase.steps.length > 0 ? (
              <div className="space-y-3">
                {testCase.steps.map((step: any, idx: number) => (
                  <div key={idx} className={`border rounded-lg p-3 ${getStepStatusColor(idx)}`}>
                    <div className="flex items-center justify-between mb-2">
                      <div className="text-xs font-semibold text-gray-500">
                        Krok {idx + 1}
                      </div>
                      <div className="flex items-center gap-1">
                        {getStepStatusIcon(idx)}
                        <button
                          onClick={() => handleStepStatusChange(idx, 'PASSED')}
                          className={`p-1 rounded hover:bg-green-100 ${
                            stepStatuses[idx] === 'PASSED' ? 'bg-green-100' : ''
                          }`}
                          title="Zaliczony"
                        >
                          <CheckCircle className="h-4 w-4 text-green-600" />
                        </button>
                        <button
                          onClick={() => handleStepStatusChange(idx, 'FAILED')}
                          className={`p-1 rounded hover:bg-red-100 ${
                            stepStatuses[idx] === 'FAILED' ? 'bg-red-100' : ''
                          }`}
                          title="Niezaliczony"
                        >
                          <XCircle className="h-4 w-4 text-red-600" />
                        </button>
                        <button
                          onClick={() => handleStepStatusChange(idx, 'SKIPPED')}
                          className={`p-1 rounded hover:bg-gray-200 ${
                            stepStatuses[idx] === 'SKIPPED' ? 'bg-gray-200' : ''
                          }`}
                          title="Pominięty"
                        >
                          <MinusCircle className="h-4 w-4 text-gray-600" />
                        </button>
                      </div>
                    </div>
                    <div className="text-sm mb-2">
                      <span className="font-medium">Akcja:</span> {step.action}
                    </div>
                    <div className="text-sm">
                      <span className="font-medium">Oczekiwany rezultat:</span> {step.expected_result}
                    </div>
                  </div>
                ))}
              </div>
            ) : (
              <div className="text-sm text-gray-500 italic p-4 bg-gray-50 rounded-lg">
                Brak zdefiniowanych kroków testowych
              </div>
            )}
          </div>

          {/* Podsumowanie statusów kroków */}
          {testCase.steps && testCase.steps.length > 0 && Object.keys(stepStatuses).length > 0 && (
            <div className="bg-blue-50 border border-blue-200 rounded-lg p-3">
              <div className="text-sm font-medium text-blue-900 mb-2">Podsumowanie kroków:</div>
              <div className="flex gap-4 text-sm">
                <div className="flex items-center gap-1">
                  <CheckCircle className="h-4 w-4 text-green-600" />
                  <span>Zaliczone: {Object.values(stepStatuses).filter(s => s === 'PASSED').length}</span>
                </div>
                <div className="flex items-center gap-1">
                  <XCircle className="h-4 w-4 text-red-600" />
                  <span>Niezaliczone: {Object.values(stepStatuses).filter(s => s === 'FAILED').length}</span>
                </div>
                <div className="flex items-center gap-1">
                  <MinusCircle className="h-4 w-4 text-gray-600" />
                  <span>Pominięte: {Object.values(stepStatuses).filter(s => s === 'SKIPPED').length}</span>
                </div>
              </div>
            </div>
          )}

          {/* Wybór statusu */}
          <div>
            <h3 className="font-semibold text-gray-900 mb-3">Wybierz wynik testu</h3>
            <div className="grid grid-cols-2 gap-3">
              <button
                onClick={() => handleStatusClick('PASSED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'PASSED'
                    ? 'border-green-500 bg-green-50'
                    : 'border-gray-300 hover:border-green-300'
                }`}
              >
                <CheckCircle className="h-5 w-5 text-green-600" />
                <span className="font-medium">Zaliczony</span>
              </button>

              <button
                onClick={() => handleStatusClick('FAILED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'FAILED'
                    ? 'border-red-500 bg-red-50'
                    : 'border-gray-300 hover:border-red-300'
                }`}
              >
                <XCircle className="h-5 w-5 text-red-600" />
                <span className="font-medium">Niezaliczony</span>
              </button>

              <button
                onClick={() => handleStatusClick('SKIPPED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'SKIPPED'
                    ? 'border-gray-500 bg-gray-50'
                    : 'border-gray-300 hover:border-gray-400'
                }`}
              >
                <MinusCircle className="h-5 w-5 text-gray-600" />
                <span className="font-medium">Pominięty</span>
              </button>

              <button
                onClick={() => handleStatusClick('BLOCKED')}
                className={`p-4 border-2 rounded-lg flex items-center justify-center gap-2 transition-colors ${
                  selectedStatus === 'BLOCKED'
                    ? 'border-orange-500 bg-orange-50'
                    : 'border-gray-300 hover:border-orange-300'
                }`}
              >
                <Ban className="h-5 w-5 text-orange-600" />
                <span className="font-medium">Zablokowany</span>
              </button>
            </div>
          </div>

          {/* Notatki */}
          <div>
            <label className="block font-semibold text-gray-900 mb-2">
              Notatki
            </label>
            <textarea
              value={notes}
              onChange={(e) => setNotes(e.target.value)}
              rows={3}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Opcjonalne uwagi dotyczące wykonania testu"
            />
          </div>

          {/* Informacja o zgłoszonym błędzie */}
          {selectedStatus === 'FAILED' && bugId && (
            <div className="bg-green-50 border border-green-200 rounded-lg p-3">
              <div className="flex items-center gap-2 text-green-800">
                <span className="text-lg">✅</span>
                <span className="font-medium">Błąd został zgłoszony (ID: {bugId})</span>
              </div>
            </div>
          )}

          {/* Ostrzeżenie jeśli FAILED bez błędu */}
          {selectedStatus === 'FAILED' && !bugId && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-3">
              <div className="flex items-center gap-2 text-red-800">
                <span className="text-lg">⚠️</span>
                <span className="font-medium">Musisz zgłosić błąd przed zakończeniem testu</span>
              </div>
            </div>
          )}
        </div>

        <div className="p-6 border-t flex justify-end space-x-2">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Anuluj
          </button>
          <button
            onClick={handleComplete}
            disabled={!selectedStatus || (selectedStatus === 'FAILED' && !bugId)}
            className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
          >
            Zakończ test
          </button>
        </div>
      </div>
    </div>
  );
}
