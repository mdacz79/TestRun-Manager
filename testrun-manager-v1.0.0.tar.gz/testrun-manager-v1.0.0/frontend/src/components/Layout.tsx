import { Outlet, Link, useNavigate, useLocation } from 'react-router-dom';
import { LayoutDashboard, LogOut, FolderOpen, Shield, FileText, ClipboardList, Bug, Play, BarChart3 } from 'lucide-react';
import { logout, getUser } from '../lib/auth';
import { useProject } from '../context/ProjectContext';
import { usePermissions } from '../hooks/usePermissions';
import Logo from './Logo';

export default function Layout() {
  const navigate = useNavigate();
  const location = useLocation();
  const user = getUser();
  const { can, isAdmin } = usePermissions();
  const { selectedProject, setSelectedProject } = useProject();

  const handleLogout = () => {
    logout();
    navigate('/login');
  };

  const handleGoToDashboard = () => {
    setSelectedProject(null);
    navigate('/');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      <nav className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between h-16">
            <div className="flex">
              <div className="flex-shrink-0 flex items-center">
                <Logo size={40} />
                <div className="ml-3">
                  <span className="text-xl font-bold text-gray-900">
                    TestRun Manager
                  </span>
                  <span className="ml-2 text-xs text-gray-500 font-normal"></span>
                </div>
              </div>
              <div className="hidden sm:ml-6 sm:flex sm:space-x-8 items-center">
                {can('projects.view') && (
                  <button
                    onClick={handleGoToDashboard}
                    className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  >
                    <LayoutDashboard className="h-4 w-4 mr-2" />
                    Projekty
                  </button>
                )}
                {(isAdmin() || can('admin.manage_users') || can('admin.manage_roles') || can('admin.manage_statuses')) && (
                  <Link
                    to="/admin"
                    className="inline-flex items-center px-1 pt-1 border-b-2 border-transparent text-sm font-medium text-gray-500 hover:text-gray-700 hover:border-gray-300"
                  >
                    <Shield className="h-4 w-4 mr-2" />
                    Admin Panel
                  </Link>
                )}
                {selectedProject && (
                  <>
                    <span className="text-gray-400">/</span>
                    <div className="flex items-center px-3 py-1 bg-blue-50 rounded-md">
                      <FolderOpen className="h-4 w-4 text-blue-600 mr-2" />
                      <span className="text-sm font-medium text-blue-900">
                        {selectedProject.name}
                      </span>
                    </div>
                  </>
                )}
              </div>
            </div>
            <div className="flex items-center">
              <span className="text-sm text-gray-700 mr-4">{user?.name}</span>
              <button
                onClick={handleLogout}
                className="inline-flex items-center px-3 py-2 border border-transparent text-sm font-medium rounded-md text-white bg-red-600 hover:bg-red-700"
              >
                <LogOut className="h-4 w-4 mr-2" />
                Wyloguj
              </button>
            </div>
          </div>
        </div>
      </nav>
      
      {/* Menu modułów projektu */}
      {selectedProject && (
        <div className="bg-white border-b border-gray-200">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <nav className="flex space-x-8" aria-label="Moduły projektu">
              {can('requirements.view') && (
                <Link
                  to="/requirements"
                  className={`inline-flex items-center px-1 py-4 border-b-2 text-sm font-medium ${
                    location.pathname === '/requirements'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <FileText className="h-5 w-5 mr-2" />
                  Wymagania
                </Link>
              )}
              {can('test_specs.view') && (
                <Link
                  to="/test-specifications"
                  className={`inline-flex items-center px-1 py-4 border-b-2 text-sm font-medium ${
                    location.pathname === '/test-specifications'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <ClipboardList className="h-5 w-5 mr-2" />
                  Specyfikacja testowa
                </Link>
              )}
              {can('test_execution.view') && (
                <Link
                  to="/test-execution"
                  className={`inline-flex items-center px-1 py-4 border-b-2 text-sm font-medium ${
                    location.pathname === '/test-execution'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Play className="h-5 w-5 mr-2" />
                  Wykonywanie testów
                </Link>
              )}
              {can('defects.view') && (
                <Link
                  to="/defects"
                  className={`inline-flex items-center px-1 py-4 border-b-2 text-sm font-medium ${
                    location.pathname === '/defects'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <Bug className="h-5 w-5 mr-2" />
                  Defekty
                </Link>
              )}
              {can('reports.view') && (
                <Link
                  to="/reports"
                  className={`inline-flex items-center px-1 py-4 border-b-2 text-sm font-medium ${
                    location.pathname === '/reports'
                      ? 'border-blue-500 text-blue-600'
                      : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
                  }`}
                >
                  <BarChart3 className="h-5 w-5 mr-2" />
                  Raporty
                </Link>
              )}
            </nav>
          </div>
        </div>
      )}
      
      <main className="max-w-7xl mx-auto py-6 sm:px-6 lg:px-8 min-h-[calc(100vh-200px)]">
        <Outlet />
      </main>
      
      {/* Stopka */}
      <footer className="bg-white border-t border-gray-200 mt-auto">
        <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center text-xs text-gray-500">
            <div>
              <span className="font-medium">TestRun Manager</span> <span className="text-gray-400">v1.0</span>
            </div>
            <div>
              Created by <span className="font-medium text-gray-600">ITM Marek Dacz</span> © 2026
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
