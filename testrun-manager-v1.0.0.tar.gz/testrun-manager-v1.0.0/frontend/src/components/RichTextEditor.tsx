import { useState, useRef } from 'react';
import { Bold, Italic, List, ListOrdered, Link as LinkIcon } from 'lucide-react';

interface RichTextEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  rows?: number;
  onImagePaste?: (file: File) => void;
}

export default function RichTextEditor({ value, onChange, placeholder, rows = 4, onImagePaste }: RichTextEditorProps) {
  const [showPreview, setShowPreview] = useState(false);
  const textareaRef = useRef<HTMLTextAreaElement>(null);

  const handlePaste = (e: React.ClipboardEvent<HTMLTextAreaElement>) => {
    const items = e.clipboardData?.items;
    if (!items || !onImagePaste) return;

    for (let i = 0; i < items.length; i++) {
      const item = items[i];
      
      // Sprawdź czy to obrazek
      if (item.type.indexOf('image') !== -1) {
        e.preventDefault();
        const file = item.getAsFile();
        if (file) {
          onImagePaste(file);
          
          // Konwertuj obrazek na base64 i wstaw do tekstu
          const reader = new FileReader();
          reader.onload = (event) => {
            const base64 = event.target?.result as string;
            const textarea = textareaRef.current;
            if (textarea && base64) {
              const start = textarea.selectionStart;
              const imageName = file.name || 'Wklejony obrazek';
              const newText = value.substring(0, start) + 
                            `\n![${imageName}](${base64})\n` + 
                            value.substring(start);
              onChange(newText);
            }
          };
          reader.readAsDataURL(file);
        }
        break;
      }
    }
  };

  const insertMarkdown = (before: string, after: string = '') => {
    const textarea = textareaRef.current;
    if (!textarea) return;

    const start = textarea.selectionStart;
    const end = textarea.selectionEnd;
    const selectedText = value.substring(start, end);
    const newText = value.substring(0, start) + before + selectedText + after + value.substring(end);
    
    onChange(newText);
    
    // Ustaw kursor po wstawieniu
    setTimeout(() => {
      textarea.focus();
      const newCursorPos = start + before.length + selectedText.length;
      textarea.setSelectionRange(newCursorPos, newCursorPos);
    }, 0);
  };

  const formatBold = () => insertMarkdown('**', '**');
  const formatItalic = () => insertMarkdown('*', '*');
  const formatBulletList = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const lineStart = value.lastIndexOf('\n', start - 1) + 1;
    const newText = value.substring(0, lineStart) + '- ' + value.substring(lineStart);
    onChange(newText);
  };
  
  const formatNumberedList = () => {
    const textarea = textareaRef.current;
    if (!textarea) return;
    
    const start = textarea.selectionStart;
    const lineStart = value.lastIndexOf('\n', start - 1) + 1;
    const newText = value.substring(0, lineStart) + '1. ' + value.substring(lineStart);
    onChange(newText);
  };
  
  const formatLink = () => insertMarkdown('[', '](url)');

  const renderPreview = (text: string) => {
    // Prosty parser markdown
    let html = text
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/!\[(.*?)\]\((.*?)\)/g, '<img src="$2" alt="$1" class="max-w-full h-auto rounded border my-2" />')
      .replace(/\[(.*?)\]\((.*?)\)/g, '<a href="$2" class="text-blue-600 underline" target="_blank">$1</a>')
      .replace(/^- (.+)$/gm, '<li>$1</li>')
      .replace(/^(\d+)\. (.+)$/gm, '<li>$2</li>')
      .replace(/\n/g, '<br/>');
    
    // Owijaj listy w <ul> lub <ol>
    html = html.replace(/(<li>.*?<\/li>)/g, (match) => {
      if (match.includes('<li>')) {
        return `<ul class="list-disc list-inside">${match}</ul>`;
      }
      return match;
    });
    
    return html;
  };

  return (
    <div className="border border-gray-300 rounded-md">
      {/* Toolbar */}
      <div className="flex items-center gap-1 p-2 border-b border-gray-300 bg-gray-50">
        <button
          type="button"
          onClick={formatBold}
          className="p-1.5 hover:bg-gray-200 rounded"
          title="Pogrubienie (Ctrl+B)"
        >
          <Bold className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={formatItalic}
          className="p-1.5 hover:bg-gray-200 rounded"
          title="Kursywa (Ctrl+I)"
        >
          <Italic className="h-4 w-4" />
        </button>
        <div className="w-px h-6 bg-gray-300 mx-1"></div>
        <button
          type="button"
          onClick={formatBulletList}
          className="p-1.5 hover:bg-gray-200 rounded"
          title="Lista punktowana"
        >
          <List className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={formatNumberedList}
          className="p-1.5 hover:bg-gray-200 rounded"
          title="Lista numerowana"
        >
          <ListOrdered className="h-4 w-4" />
        </button>
        <div className="w-px h-6 bg-gray-300 mx-1"></div>
        <button
          type="button"
          onClick={formatLink}
          className="p-1.5 hover:bg-gray-200 rounded"
          title="Link"
        >
          <LinkIcon className="h-4 w-4" />
        </button>
        <div className="flex-1"></div>
        <button
          type="button"
          onClick={() => setShowPreview(!showPreview)}
          className={`px-3 py-1 text-xs rounded ${
            showPreview ? 'bg-blue-600 text-white' : 'bg-gray-200 text-gray-700'
          }`}
        >
          {showPreview ? 'Edycja' : 'Podgląd'}
        </button>
      </div>

      {/* Editor / Preview */}
      {showPreview ? (
        <div 
          className="p-3 min-h-[100px] prose prose-sm max-w-none"
          dangerouslySetInnerHTML={{ __html: renderPreview(value) }}
        />
      ) : (
        <textarea
          ref={textareaRef}
          value={value}
          onChange={(e) => onChange(e.target.value)}
          onPaste={handlePaste}
          placeholder={placeholder}
          rows={rows}
          className="w-full p-3 focus:outline-none resize-none"
        />
      )}

      {/* Podpowiedzi */}
      <div className="px-3 py-2 bg-gray-50 border-t border-gray-300 text-xs text-gray-500">
        <span className="font-medium">Formatowanie:</span> **pogrubienie** *kursywa* - lista • 1. numerowana • [link](url)
        {onImagePaste && <span className="ml-2">• <strong>Ctrl+V</strong> aby wkleić obrazek</span>}
      </div>
    </div>
  );
}
