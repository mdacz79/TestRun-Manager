import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { testSpecifications } from '../lib/api';

interface AddTestCasesModalProps {
  projectId: number;
  existingCaseIds: number[];
  onClose: () => void;
  onAdd: (caseIds: number[]) => void;
}

export default function AddTestCasesModal({ projectId, existingCaseIds, onClose, onAdd }: AddTestCasesModalProps) {
  const [testCases, setTestCases] = useState<any[]>([]);
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadTestCases();
  }, []);

  const loadTestCases = async () => {
    try {
      const res = await testSpecifications.getAll(projectId);
      // Wyklucz już dodane przypadki
      const available = res.data.filter((tc: any) => !existingCaseIds.includes(tc.id));
      setTestCases(available);
    } catch (error) {
      console.error('Error loading test cases:', error);
    } finally {
      setLoading(false);
    }
  };

  const toggleCase = (id: number) => {
    setSelectedIds(prev =>
      prev.includes(id) ? prev.filter(i => i !== id) : [...prev, id]
    );
  };

  const handleSubmit = () => {
    onAdd(selectedIds);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[80vh] overflow-hidden">
        <div className="p-6 border-b">
          <div className="flex justify-between items-center">
            <h2 className="text-xl font-bold">Dodaj przypadki testowe</h2>
            <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        <div className="p-6 overflow-y-auto max-h-[50vh]">
          {loading ? (
            <p>Ładowanie...</p>
          ) : testCases.length === 0 ? (
            <p className="text-gray-500">Brak dostępnych przypadków testowych</p>
          ) : (
            <div className="space-y-2">
              {testCases.map((tc) => (
                <label
                  key={tc.id}
                  className="flex items-start p-3 border rounded hover:bg-gray-50 cursor-pointer"
                >
                  <input
                    type="checkbox"
                    checked={selectedIds.includes(tc.id)}
                    onChange={() => toggleCase(tc.id)}
                    className="mt-1 mr-3"
                  />
                  <div className="flex-1">
                    <div className="font-mono text-sm font-semibold text-blue-600">
                      {tc.test_case_id}
                    </div>
                    <div className="text-sm text-gray-900">{tc.title}</div>
                  </div>
                </label>
              ))}
            </div>
          )}
        </div>

        <div className="p-6 border-t flex justify-between items-center">
          <span className="text-sm text-gray-600">
            Wybrano: {selectedIds.length}
          </span>
          <div className="space-x-2">
            <button
              onClick={onClose}
              className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
            >
              Anuluj
            </button>
            <button
              onClick={handleSubmit}
              disabled={selectedIds.length === 0}
              className="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 disabled:bg-gray-400"
            >
              Dodaj wybrane
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
