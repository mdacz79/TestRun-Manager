import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { bugs as bugsApi, users as usersApi, statuses as statusesApi } from '../lib/api';
import RichTextEditor from './RichTextEditor';

interface CreateBugModalProps {
  projectId: number;
  onClose: () => void;
  onCreate: (bug: any) => void;
}

export default function CreateBugModal({ projectId, onClose, onCreate }: CreateBugModalProps) {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [stepsToReproduce, setStepsToReproduce] = useState('');
  const [severity, setSeverity] = useState('medium');
  const [priority, setPriority] = useState('medium');
  const [status] = useState('new');
  const [assignedTo, setAssignedTo] = useState<number | null>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [bugStatuses, setBugStatuses] = useState<any[]>([]);

  useEffect(() => {
    loadUsers();
    loadStatuses();
  }, []);

  const loadUsers = async () => {
    try {
      const res = await usersApi.getList();
      setUsers(res.data);
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const loadStatuses = async () => {
    try {
      const res = await statusesApi.getBugStatuses();
      setBugStatuses(res.data.filter((s: any) => s.is_active));
    } catch (error) {
      console.error('Error loading statuses:', error);
    }
  };

  const getStatusName = (statusKey: string) => {
    const status = bugStatuses.find(s => s.key === statusKey);
    return status ? status.name : statusKey;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      const res = await bugsApi.create({
        title,
        description,
        steps_to_reproduce: stepsToReproduce,
        severity,
        priority,
        status,
        project_id: projectId,
        assigned_to: assignedTo || undefined,
      });
      onCreate(res.data);
    } catch (error) {
      console.error('Error creating bug:', error);
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] flex flex-col overflow-hidden">
        <div className="flex justify-between items-center p-6 pb-4 border-b">
          <h2 className="text-xl font-bold">Zgłoś błąd</h2>
          <button onClick={onClose} className="text-gray-500 hover:text-gray-700">
            <X className="h-6 w-6" />
          </button>
        </div>

        <form id="bug-form" onSubmit={handleSubmit} className="flex-1 overflow-y-auto px-6 py-4 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Tytuł błędu *
            </label>
            <input
              type="text"
              required
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Krótki opis błędu"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Opis
            </label>
            <RichTextEditor
              value={description}
              onChange={setDescription}
              placeholder="Szczegółowy opis błędu..."
              rows={4}
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Kroki do reprodukcji
            </label>
            <RichTextEditor
              value={stepsToReproduce}
              onChange={setStepsToReproduce}
              placeholder="1. Krok pierwszy&#10;2. Krok drugi&#10;3. Oczekiwany rezultat"
              rows={5}
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Priorytet
              </label>
              <select
                value={priority}
                onChange={(e) => setPriority(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="low">Niski</option>
                <option value="medium">Średni</option>
                <option value="high">Wysoki</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Severity
              </label>
              <select
                value={severity}
                onChange={(e) => setSeverity(e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="low">Niski</option>
                <option value="medium">Średni</option>
                <option value="high">Wysoki</option>
                <option value="critical">Krytyczny</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Status
            </label>
            <input
              type="text"
              value={getStatusName('new')}
              disabled
              className="w-full px-3 py-2 border border-gray-300 rounded-md bg-gray-100 text-gray-600 cursor-not-allowed"
            />
            <p className="mt-1 text-xs text-gray-500">Nowe błędy zawsze mają status "Nowy"</p>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Przypisz do
            </label>
            <select
              value={assignedTo || ''}
              onChange={(e) => setAssignedTo(e.target.value ? Number(e.target.value) : null)}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">Nieprzypisany</option>
              {users.map((user) => (
                <option key={user.id} value={user.id}>
                  {user.name}
                </option>
              ))}
            </select>
          </div>
        </form>

        <div className="flex justify-end space-x-2 p-6 pt-4 border-t bg-gray-50">
          <button
            type="button"
            onClick={onClose}
            className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
          >
            Anuluj
          </button>
          <button
            type="submit"
            form="bug-form"
            className="px-4 py-2 bg-red-600 text-white rounded-md hover:bg-red-700"
          >
            Zgłoś błąd
          </button>
        </div>
      </div>
    </div>
  );
}
