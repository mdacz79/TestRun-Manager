interface LogoProps {
  className?: string;
  size?: number;
}

export default function Logo({ className = "", size = 32 }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Tło - gradient okrąg */}
      <defs>
        <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#1d4ed8" />
        </linearGradient>
      </defs>
      
      {/* Okrąg tła */}
      <circle cx="50" cy="50" r="45" fill="url(#logoGradient)" />
      
      {/* Ikona "play" (trójkąt) - symbolizuje "Run" */}
      <path
        d="M 38 30 L 38 70 L 70 50 Z"
        fill="white"
        opacity="0.9"
      />
      
      {/* Checkmark - symbolizuje testy */}
      <path
        d="M 65 35 L 72 42 L 82 25"
        stroke="white"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        opacity="0.85"
      />
      
      {/* Dolna linia - symbolizuje "Manager" */}
      <rect
        x="25"
        y="75"
        width="50"
        height="3"
        rx="1.5"
        fill="white"
        opacity="0.7"
      />
    </svg>
  );
}

export function LogoCompact({ className = "", size = 24 }: LogoProps) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Wersja kompaktowa - tylko inicjały TRM */}
      <defs>
        <linearGradient id="logoGradientCompact" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" stopColor="#3b82f6" />
          <stop offset="100%" stopColor="#1d4ed8" />
        </linearGradient>
      </defs>
      
      <rect width="100" height="100" rx="20" fill="url(#logoGradientCompact)" />
      
      {/* T */}
      <path
        d="M 20 25 L 40 25 M 30 25 L 30 55"
        stroke="white"
        strokeWidth="5"
        strokeLinecap="round"
      />
      
      {/* R */}
      <path
        d="M 50 25 L 50 55 M 50 25 L 60 25 Q 65 25 65 32 Q 65 39 60 39 L 50 39 M 55 39 L 65 55"
        stroke="white"
        strokeWidth="5"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      
      {/* M */}
      <path
        d="M 75 55 L 75 25 L 82.5 40 L 90 25 L 90 55"
        stroke="white"
        strokeWidth="4"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
      />
      
      {/* Play icon - mały akcent */}
      <path
        d="M 35 70 L 35 85 L 47 77.5 Z"
        fill="white"
        opacity="0.6"
      />
      
      {/* Checkmark - mały akcent */}
      <path
        d="M 60 75 L 65 80 L 75 70"
        stroke="white"
        strokeWidth="3"
        strokeLinecap="round"
        strokeLinejoin="round"
        fill="none"
        opacity="0.6"
      />
    </svg>
  );
}
