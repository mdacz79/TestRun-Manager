import { useState, useEffect, useRef } from 'react';
import { Tag, X, Plus } from 'lucide-react';
import { tags as tagsApi } from '../lib/api';

interface TagSelectorProps {
  projectId: number;
  selectedTags: any[];
  onChange: (tags: any[]) => void;
}

export default function TagSelector({ projectId, selectedTags, onChange }: TagSelectorProps) {
  const [availableTags, setAvailableTags] = useState<any[]>([]);
  const [showDropdown, setShowDropdown] = useState(false);
  const [searchTerm, setSearchTerm] = useState('');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [newTagName, setNewTagName] = useState('');
  const [newTagColor, setNewTagColor] = useState('#3B82F6');
  const dropdownRef = useRef<HTMLDivElement>(null);

  const colorPresets = [
    '#3B82F6', '#10B981', '#EF4444', '#F59E0B', '#8B5CF6',
    '#EC4899', '#6366F1', '#F97316', '#14B8A6', '#6B7280',
  ];

  useEffect(() => {
    loadTags();
  }, [projectId]);

  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (dropdownRef.current && !dropdownRef.current.contains(event.target as Node)) {
        setShowDropdown(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  const loadTags = async () => {
    try {
      const response = await tagsApi.getAll(projectId);
      setAvailableTags(response.data);
    } catch (error) {
      console.error('Error loading tags:', error);
    }
  };

  const handleCreateTag = async () => {
    if (!newTagName.trim()) return;

    try {
      const response = await tagsApi.create({
        project_id: projectId,
        name: newTagName.trim(),
        color: newTagColor,
      });
      
      const newTag = response.data;
      setAvailableTags([...availableTags, newTag]);
      onChange([...selectedTags, newTag]);
      setNewTagName('');
      setNewTagColor('#3B82F6');
      setShowCreateModal(false);
      setSearchTerm('');
    } catch (error) {
      console.error('Error creating tag:', error);
    }
  };

  const toggleTag = (tag: any) => {
    const isSelected = selectedTags.some(t => t.id === tag.id);
    if (isSelected) {
      onChange(selectedTags.filter(t => t.id !== tag.id));
    } else {
      onChange([...selectedTags, tag]);
    }
  };

  const removeTag = (tagId: number) => {
    onChange(selectedTags.filter(t => t.id !== tagId));
  };

  const filteredTags = availableTags.filter(tag =>
    tag.name.toLowerCase().includes(searchTerm.toLowerCase()) &&
    !selectedTags.some(t => t.id === tag.id)
  );

  return (
    <div className="relative" ref={dropdownRef}>
      <label className="block text-sm font-medium text-gray-700 mb-1">
        Tagi
      </label>
      
      <div className="flex flex-wrap gap-2 mb-2">
        {selectedTags.map(tag => (
          <span
            key={tag.id}
            className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium text-white"
            style={{ backgroundColor: tag.color }}
          >
            <Tag className="h-3 w-3 mr-1" />
            {tag.name}
            <button
              type="button"
              onClick={() => removeTag(tag.id)}
              className="ml-1 hover:bg-white hover:bg-opacity-20 rounded-full p-0.5"
            >
              <X className="h-3 w-3" />
            </button>
          </span>
        ))}
      </div>

      <div className="relative">
        <input
          type="text"
          value={searchTerm}
          onChange={(e) => {
            setSearchTerm(e.target.value);
            setShowDropdown(true);
          }}
          onFocus={() => setShowDropdown(true)}
          placeholder="Wyszukaj lub dodaj tag..."
          className="w-full border border-gray-300 rounded-lg px-3 py-2 pr-10"
        />
        <Tag className="absolute right-3 top-2.5 h-5 w-5 text-gray-400" />
      </div>

      {showDropdown && (
        <div className="absolute z-10 mt-1 w-full bg-white border border-gray-300 rounded-lg shadow-lg max-h-60 overflow-y-auto">
          {filteredTags.length > 0 ? (
            <div className="py-1">
              {filteredTags.map(tag => (
                <button
                  key={tag.id}
                  type="button"
                  onClick={() => toggleTag(tag)}
                  className="w-full text-left px-3 py-2 hover:bg-gray-100 flex items-center gap-2"
                >
                  <span
                    className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium text-white"
                    style={{ backgroundColor: tag.color }}
                  >
                    <Tag className="h-3 w-3 mr-1" />
                    {tag.name}
                  </span>
                </button>
              ))}
            </div>
          ) : searchTerm ? (
            <div className="py-2 px-3 text-sm text-gray-500">
              Nie znaleziono tagu
            </div>
          ) : (
            <div className="py-2 px-3 text-sm text-gray-500">
              Brak dostępnych tagów
            </div>
          )}
          
          {searchTerm && (
            <button
              type="button"
              onClick={() => {
                setNewTagName(searchTerm);
                setShowCreateModal(true);
                setShowDropdown(false);
              }}
              className="w-full text-left px-3 py-2 border-t border-gray-200 hover:bg-blue-50 flex items-center gap-2 text-blue-600"
            >
              <Plus className="h-4 w-4" />
              Utwórz tag
            </button>
          )}
        </div>
      )}

      {showCreateModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-sm w-full p-6">
            <h3 className="text-lg font-bold mb-4">Utwórz nowy tag</h3>
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nazwa
                </label>
                <input
                  type="text"
                  value={newTagName}
                  onChange={(e) => setNewTagName(e.target.value)}
                  className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  autoFocus
                />
              </div>
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Kolor
                </label>
                <div className="grid grid-cols-5 gap-2">
                  {colorPresets.map(color => (
                    <button
                      key={color}
                      type="button"
                      onClick={() => setNewTagColor(color)}
                      className={`w-full h-10 rounded border-2 ${
                        newTagColor === color ? 'border-gray-900 ring-2 ring-gray-900' : 'border-gray-300'
                      }`}
                      style={{ backgroundColor: color }}
                    />
                  ))}
                </div>
              </div>
              <div className="flex justify-end gap-2 pt-4">
                <button
                  type="button"
                  onClick={() => setShowCreateModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                >
                  Anuluj
                </button>
                <button
                  type="button"
                  onClick={handleCreateTag}
                  className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                >
                  Utwórz
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
