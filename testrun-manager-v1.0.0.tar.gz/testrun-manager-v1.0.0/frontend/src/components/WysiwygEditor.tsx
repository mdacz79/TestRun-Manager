import { useEditor, EditorContent } from '@tiptap/react';
import StarterKit from '@tiptap/starter-kit';
import Image from '@tiptap/extension-image';
import Placeholder from '@tiptap/extension-placeholder';
import { Bold, Italic, List, ListOrdered } from 'lucide-react';
import { useEffect } from 'react';

interface WysiwygEditorProps {
  value: string;
  onChange: (value: string) => void;
  placeholder?: string;
  onImagePaste?: (file: File) => void;
}

export default function WysiwygEditor({ value, onChange, placeholder, onImagePaste }: WysiwygEditorProps) {
  const editor = useEditor({
    extensions: [
      StarterKit,
      Image.configure({
        inline: true,
        allowBase64: true,
      }),
      Placeholder.configure({
        placeholder: placeholder || 'Zacznij pisać...',
      }),
    ],
    content: value,
    onUpdate: ({ editor }) => {
      onChange(editor.getHTML());
    },
    editorProps: {
      handlePaste: (_view, event) => {
        const items = event.clipboardData?.items;
        if (!items || !onImagePaste) return false;

        for (let i = 0; i < items.length; i++) {
          const item = items[i];
          
          if (item.type.indexOf('image') !== -1) {
            event.preventDefault();
            const file = item.getAsFile();
            if (file) {
              onImagePaste(file);
              
              // Konwertuj na base64 i wstaw do edytora
              const reader = new FileReader();
              reader.onload = (e) => {
                const base64 = e.target?.result as string;
                if (base64 && editor) {
                  editor.chain().focus().setImage({ src: base64 }).run();
                }
              };
              reader.readAsDataURL(file);
            }
            return true;
          }
        }
        return false;
      },
    },
  });

  // Aktualizuj zawartość gdy value się zmienia z zewnątrz
  useEffect(() => {
    if (editor && value !== editor.getHTML()) {
      editor.commands.setContent(value);
    }
  }, [value, editor]);

  if (!editor) {
    return null;
  }

  return (
    <div className="border border-gray-300 rounded-md">
      {/* Toolbar */}
      <div className="flex items-center gap-1 p-2 border-b border-gray-300 bg-gray-50">
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBold().run()}
          className={`p-1.5 rounded ${
            editor.isActive('bold') ? 'bg-gray-300' : 'hover:bg-gray-200'
          }`}
          title="Pogrubienie (Ctrl+B)"
        >
          <Bold className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleItalic().run()}
          className={`p-1.5 rounded ${
            editor.isActive('italic') ? 'bg-gray-300' : 'hover:bg-gray-200'
          }`}
          title="Kursywa (Ctrl+I)"
        >
          <Italic className="h-4 w-4" />
        </button>
        <div className="w-px h-6 bg-gray-300 mx-1"></div>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleBulletList().run()}
          className={`p-1.5 rounded ${
            editor.isActive('bulletList') ? 'bg-gray-300' : 'hover:bg-gray-200'
          }`}
          title="Lista punktowana"
        >
          <List className="h-4 w-4" />
        </button>
        <button
          type="button"
          onClick={() => editor.chain().focus().toggleOrderedList().run()}
          className={`p-1.5 rounded ${
            editor.isActive('orderedList') ? 'bg-gray-300' : 'hover:bg-gray-200'
          }`}
          title="Lista numerowana"
        >
          <ListOrdered className="h-4 w-4" />
        </button>
      </div>

      {/* Editor */}
      <div className="p-3 min-h-[100px]">
        <EditorContent 
          editor={editor} 
          className="wysiwyg-editor"
        />
      </div>
      
      <style>{`
        .wysiwyg-editor .ProseMirror {
          outline: none;
          min-height: 80px;
        }
        
        .wysiwyg-editor .ProseMirror p {
          margin: 0.5em 0;
        }
        
        .wysiwyg-editor .ProseMirror p:first-child {
          margin-top: 0;
        }
        
        .wysiwyg-editor .ProseMirror p:last-child {
          margin-bottom: 0;
        }
        
        .wysiwyg-editor .ProseMirror strong {
          font-weight: 600;
        }
        
        .wysiwyg-editor .ProseMirror em {
          font-style: italic;
        }
        
        .wysiwyg-editor .ProseMirror ul,
        .wysiwyg-editor .ProseMirror ol {
          padding-left: 1.5rem;
          margin: 0.5em 0;
        }
        
        .wysiwyg-editor .ProseMirror ul {
          list-style-type: disc;
        }
        
        .wysiwyg-editor .ProseMirror ol {
          list-style-type: decimal;
        }
        
        .wysiwyg-editor .ProseMirror li {
          margin: 0.25em 0;
        }
        
        .wysiwyg-editor .ProseMirror img {
          max-width: 100%;
          height: auto;
          border-radius: 0.375rem;
          border: 1px solid #e5e7eb;
          margin: 0.5rem 0;
        }
        
        .wysiwyg-editor .ProseMirror p.is-editor-empty:first-child::before {
          color: #9ca3af;
          content: attr(data-placeholder);
          float: left;
          height: 0;
          pointer-events: none;
        }
      `}</style>

      {/* Podpowiedzi */}
      <div className="px-3 py-2 bg-gray-50 border-t border-gray-300 text-xs text-gray-500">
        <span className="font-medium">Skróty:</span> Ctrl+B (pogrubienie) • Ctrl+I (kursywa)
        {onImagePaste && <span className="ml-2">• <strong>Ctrl+V</strong> aby wkleić obrazek</span>}
      </div>
    </div>
  );
}
