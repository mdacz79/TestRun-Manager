export interface Permission {
  key: string;
  name: string;
  description: string;
  category: string;
}

export const PERMISSION_CATEGORIES = {
  ADMIN: 'Administracja',
  PROJECTS: 'Projekty',
  REQUIREMENTS: 'Wymagania',
  TEST_SPECS: 'Specyfikacje testowe',
  TEST_EXECUTION: 'Wykonywanie testów',
  DEFECTS: 'Defekty',
  REPORTS: 'Raporty',
};

export const PERMISSIONS: Permission[] = [
  // Administracja
  { key: 'admin.full_access', name: 'Pełny dostęp', description: 'Wszystkie uprawnienia w systemie', category: 'ADMIN' },
  { key: 'admin.manage_users', name: 'Zarządzanie użytkownikami', description: 'Tworzenie, edycja i usuwanie użytkowników', category: 'ADMIN' },
  { key: 'admin.manage_roles', name: 'Zarządzanie rolami', description: 'Tworzenie i edycja ról oraz uprawnień', category: 'ADMIN' },
  { key: 'admin.manage_statuses', name: 'Zarządzanie statusami', description: 'Konfiguracja słowników statusów', category: 'ADMIN' },
  
  // Projekty
  { key: 'projects.view', name: 'Przeglądanie projektów', description: 'Dostęp do listy projektów', category: 'PROJECTS' },
  { key: 'projects.create', name: 'Tworzenie projektów', description: 'Możliwość tworzenia nowych projektów', category: 'PROJECTS' },
  { key: 'projects.edit', name: 'Edycja projektów', description: 'Modyfikacja istniejących projektów', category: 'PROJECTS' },
  { key: 'projects.delete', name: 'Usuwanie projektów', description: 'Usuwanie projektów z systemu', category: 'PROJECTS' },
  
  // Wymagania
  { key: 'requirements.view', name: 'Przeglądanie wymagań', description: 'Dostęp do listy wymagań', category: 'REQUIREMENTS' },
  { key: 'requirements.create', name: 'Tworzenie wymagań', description: 'Dodawanie nowych wymagań', category: 'REQUIREMENTS' },
  { key: 'requirements.edit', name: 'Edycja wymagań', description: 'Modyfikacja istniejących wymagań', category: 'REQUIREMENTS' },
  { key: 'requirements.delete', name: 'Usuwanie wymagań', description: 'Usuwanie wymagań z systemu', category: 'REQUIREMENTS' },
  { key: 'requirements.export', name: 'Eksport wymagań', description: 'Eksport wymagań do CSV', category: 'REQUIREMENTS' },
  
  // Specyfikacje testowe
  { key: 'test_specs.view', name: 'Przeglądanie testów', description: 'Dostęp do specyfikacji testowych', category: 'TEST_SPECS' },
  { key: 'test_specs.create', name: 'Tworzenie testów', description: 'Dodawanie nowych przypadków testowych', category: 'TEST_SPECS' },
  { key: 'test_specs.edit', name: 'Edycja testów', description: 'Modyfikacja specyfikacji testowych', category: 'TEST_SPECS' },
  { key: 'test_specs.delete', name: 'Usuwanie testów', description: 'Usuwanie przypadków testowych', category: 'TEST_SPECS' },
  { key: 'test_specs.export', name: 'Eksport testów', description: 'Eksport testów do CSV', category: 'TEST_SPECS' },
  { key: 'test_specs.import', name: 'Import testów', description: 'Import testów z CSV', category: 'TEST_SPECS' },
  
  // Wykonywanie testów
  { key: 'test_execution.view', name: 'Przeglądanie planów', description: 'Dostęp do planów testowych', category: 'TEST_EXECUTION' },
  { key: 'test_execution.create_plan', name: 'Tworzenie planów', description: 'Tworzenie nowych planów testowych', category: 'TEST_EXECUTION' },
  { key: 'test_execution.edit_plan', name: 'Edycja planów', description: 'Modyfikacja planów testowych', category: 'TEST_EXECUTION' },
  { key: 'test_execution.delete_plan', name: 'Usuwanie planów', description: 'Usuwanie planów testowych', category: 'TEST_EXECUTION' },
  { key: 'test_execution.execute', name: 'Wykonywanie testów', description: 'Uruchamianie i wykonywanie testów', category: 'TEST_EXECUTION' },
  { key: 'test_execution.assign', name: 'Przypisywanie testów', description: 'Przypisywanie testów do użytkowników', category: 'TEST_EXECUTION' },
  
  // Defekty
  { key: 'defects.view', name: 'Przeglądanie defektów', description: 'Dostęp do listy błędów', category: 'DEFECTS' },
  { key: 'defects.create', name: 'Zgłaszanie defektów', description: 'Tworzenie nowych zgłoszeń błędów', category: 'DEFECTS' },
  { key: 'defects.edit', name: 'Edycja defektów', description: 'Modyfikacja zgłoszeń błędów', category: 'DEFECTS' },
  { key: 'defects.delete', name: 'Usuwanie defektów', description: 'Usuwanie zgłoszeń błędów', category: 'DEFECTS' },
  { key: 'defects.assign', name: 'Przypisywanie defektów', description: 'Przypisywanie błędów do użytkowników', category: 'DEFECTS' },
  { key: 'defects.change_status', name: 'Zmiana statusu', description: 'Zmiana statusu błędów', category: 'DEFECTS' },
  
  // Raporty
  { key: 'reports.view', name: 'Przeglądanie raportów', description: 'Dostęp do raportów i statystyk', category: 'REPORTS' },
  { key: 'reports.export', name: 'Eksport raportów', description: 'Eksport raportów do CSV', category: 'REPORTS' },
];

export const getPermissionsByCategory = () => {
  const grouped: { [key: string]: Permission[] } = {};
  
  PERMISSIONS.forEach(permission => {
    if (!grouped[permission.category]) {
      grouped[permission.category] = [];
    }
    grouped[permission.category].push(permission);
  });
  
  return grouped;
};

export const hasPermission = (userPermissions: string[], requiredPermission: string): boolean => {
  if (!userPermissions || userPermissions.length === 0) return false;
  
  // Sprawdź czy użytkownik ma pełny dostęp
  if (userPermissions.includes('admin.full_access') || userPermissions.includes('all')) {
    return true;
  }
  
  // Sprawdź czy użytkownik ma konkretne uprawnienie
  return userPermissions.includes(requiredPermission);
};

export const permissionsToString = (permissions: string[]): string => {
  return permissions.join(',');
};

export const permissionsFromString = (permissionsStr: string): string[] => {
  if (!permissionsStr) return [];
  return permissionsStr.split(',').map(p => p.trim()).filter(p => p.length > 0);
};
