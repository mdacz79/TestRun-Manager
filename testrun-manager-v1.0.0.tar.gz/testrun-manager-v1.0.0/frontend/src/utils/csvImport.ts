// Funkcje importu CSV dla przypadków testowych

interface ParsedTestCase {
  test_case_id: string;
  title: string;
  description: string;
  preconditions: string;
  priority: string;
  status: string;
  suite_name: string;
  requirements: string[];
  tags: string[];
  steps: Array<{ action: string; expected_result: string }>;
}

export const parseTestCasesCSV = (csvContent: string): ParsedTestCase[] => {
  const lines = csvContent.split('\n').filter(line => line.trim());
  
  if (lines.length < 2) {
    throw new Error('Plik CSV jest pusty lub nie zawiera danych');
  }

  // Wykryj separator (przecinek lub średnik)
  const headerLine = lines[0];
  const separator = detectSeparator(headerLine);
  console.log(`Wykryto separator CSV: "${separator}"`);

  // Pomiń nagłówek
  const dataLines = lines.slice(1);
  
  // Grupuj wiersze według ID TC
  const testCasesMap = new Map<string, ParsedTestCase>();
  
  dataLines.forEach(line => {
    const values = parseCSVLine(line, separator);
    
    if (values.length < 12) {
      console.warn('Pominięto nieprawidłowy wiersz (za mało kolumn):', line);
      return;
    }

    const [
      testCaseId,
      title,
      description,
      preconditions,
      stepNumber,
      action,
      expectedResult,
      priority,
      status,
      suiteName,
      requirements,
      tags,
      createdAt // opcjonalne
    ] = values;

    if (!title) {
      console.warn('Pominięto wiersz bez tytułu:', line);
      return;
    }

    // Użyj ID jako klucza, lub tytułu jeśli brak ID (dla grupowania kroków)
    const mapKey = testCaseId || `__no_id__${title}`;

    // Jeśli TC nie istnieje w mapie, utwórz go
    if (!testCasesMap.has(mapKey)) {
      testCasesMap.set(mapKey, {
        test_case_id: testCaseId, // może być puste
        title: title,
        description: description,
        preconditions: preconditions,
        priority: mapPriorityFromPolish(priority),
        status: mapStatusFromPolish(status),
        suite_name: suiteName === 'Bez zestawu' ? '' : suiteName,
        requirements: requirements ? requirements.split(',').map(r => r.trim()).filter(r => r) : [],
        tags: tags ? tags.split(',').map(t => t.trim()).filter(t => t) : [],
        steps: []
      });
    }

    // Dodaj krok jeśli ma akcję i rezultat
    const testCase = testCasesMap.get(mapKey)!;
    if (action && expectedResult) {
      testCase.steps.push({
        action: action,
        expected_result: expectedResult
      });
    }
  });

  return Array.from(testCasesMap.values());
};

// Wykrywanie separatora CSV (przecinek lub średnik)
const detectSeparator = (headerLine: string): string => {
  const commaCount = (headerLine.match(/,/g) || []).length;
  const semicolonCount = (headerLine.match(/;/g) || []).length;
  
  // Wybierz separator który występuje częściej
  if (semicolonCount > commaCount) {
    return ';';
  }
  return ',';
};

// Parsowanie linii CSV z obsługą wartości w cudzysłowach
const parseCSVLine = (line: string, separator: string = ','): string[] => {
  const values: string[] = [];
  let currentValue = '';
  let insideQuotes = false;

  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    const nextChar = line[i + 1];

    if (char === '"') {
      if (insideQuotes && nextChar === '"') {
        // Podwójny cudzysłów wewnątrz wartości
        currentValue += '"';
        i++; // Pomiń następny cudzysłów
      } else {
        // Przełącz stan cudzysłowu
        insideQuotes = !insideQuotes;
      }
    } else if (char === separator && !insideQuotes) {
      // Koniec wartości (separator)
      values.push(currentValue.trim());
      currentValue = '';
    } else {
      currentValue += char;
    }
  }

  // Dodaj ostatnią wartość
  values.push(currentValue.trim());

  return values;
};

// Mapowanie polskich nazw priorytetów na angielskie
const mapPriorityFromPolish = (priority: string): string => {
  const map: { [key: string]: string } = {
    'Wysoki': 'high',
    'Średni': 'medium',
    'Niski': 'low'
  };
  return map[priority] || 'medium';
};

// Mapowanie polskich nazw statusów na angielskie
const mapStatusFromPolish = (status: string): string => {
  const map: { [key: string]: string } = {
    'Szkic': 'draft',
    'Zatwierdzony': 'approved',
    'Odrzucony': 'rejected',
    'Zaliczony': 'passed',
    'Niezaliczony': 'failed',
    'Zablokowany': 'blocked',
    'Niewykonany': 'not-run'
  };
  return map[status] || 'draft';
};

// Funkcja do odczytu pliku CSV
export const readCSVFile = (file: File): Promise<string> => {
  return new Promise((resolve, reject) => {
    const reader = new FileReader();
    
    reader.onload = (e) => {
      const content = e.target?.result as string;
      resolve(content);
    };
    
    reader.onerror = () => {
      reject(new Error('Błąd podczas odczytu pliku'));
    };
    
    reader.readAsText(file, 'UTF-8');
  });
};
