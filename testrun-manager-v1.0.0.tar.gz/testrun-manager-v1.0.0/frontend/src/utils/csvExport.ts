export const exportRequirementsToCSV = (requirements: any[], filename: string = 'wymagania.csv') => {
  // Przygotuj nagłówki
  const headers = [
    'ID Wymagania',
    'Tytuł',
    'Opis',
    'Priorytet',
    'Status',
    'Zestaw',
    'Tagi',
    'Liczba TC',
    'Data utworzenia'
  ];

  // Funkcja do czyszczenia HTML z opisu
  const stripHtml = (html: string) => {
    const tmp = document.createElement('DIV');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  };

  // Funkcja do escapowania wartości CSV
  const escapeCSV = (value: any) => {
    if (value === null || value === undefined) return '';
    const stringValue = String(value);
    // Jeśli zawiera przecinek, cudzysłów lub nową linię, otocz cudzysłowami
    if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
      return `"${stringValue.replace(/"/g, '""')}"`;
    }
    return stringValue;
  };

  // Mapuj priorytety i statusy na polskie nazwy
  const getPriorityLabel = (priority: string) => {
    const map: any = { high: 'Wysoki', medium: 'Średni', low: 'Niski' };
    return map[priority] || priority;
  };

  const getStatusLabel = (status: string) => {
    const map: any = { draft: 'Szkic', approved: 'Zatwierdzony', rejected: 'Odrzucony' };
    return map[status] || status;
  };

  // Przygotuj wiersze danych
  const rows = requirements.map(req => [
    escapeCSV(req.requirement_id || ''),
    escapeCSV(req.title),
    escapeCSV(stripHtml(req.description || '')),
    escapeCSV(getPriorityLabel(req.priority)),
    escapeCSV(getStatusLabel(req.status)),
    escapeCSV(req.group_name || 'Bez zestawu'),
    escapeCSV(req.tags?.map((t: any) => t.name).join(', ') || ''),
    escapeCSV(req.test_case_count || 0),
    escapeCSV(new Date(req.created_at).toLocaleDateString('pl-PL'))
  ]);

  // Połącz nagłówki i wiersze
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');

  // Dodaj BOM dla poprawnego wyświetlania polskich znaków w Excel
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  
  // Utwórz link do pobrania
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportSingleRequirementToCSV = (requirement: any) => {
  const filename = `wymaganie_${requirement.requirement_id || requirement.id}.csv`;
  exportRequirementsToCSV([requirement], filename);
};

export const exportTestSpecificationsToCSV = (testSpecs: any[], filename: string = 'przypadki_testowe.csv') => {
  // Przygotuj nagłówki
  const headers = [
    'ID TC',
    'Tytuł',
    'Opis',
    'Warunki wstępne',
    'Numer kroku',
    'Akcja',
    'Oczekiwany rezultat',
    'Priorytet',
    'Status',
    'Zestaw testowy',
    'Powiązane wymagania',
    'Tagi',
    'Autor',
    'Data utworzenia'
  ];

  // Funkcja do czyszczenia HTML z opisu
  const stripHtml = (html: string) => {
    const tmp = document.createElement('DIV');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
  };

  // Funkcja do escapowania wartości CSV
  const escapeCSV = (value: any) => {
    if (value === null || value === undefined) return '';
    const stringValue = String(value);
    // Jeśli zawiera przecinek, cudzysłów lub nową linię, otocz cudzysłowami
    if (stringValue.includes(',') || stringValue.includes('"') || stringValue.includes('\n')) {
      return `"${stringValue.replace(/"/g, '""')}"`;
    }
    return stringValue;
  };

  // Mapuj priorytety i statusy na polskie nazwy
  const getPriorityLabel = (priority: string) => {
    const map: any = { high: 'Wysoki', medium: 'Średni', low: 'Niski' };
    return map[priority] || priority;
  };

  const getStatusLabel = (status: string) => {
    const map: any = { 
      draft: 'Szkic', 
      approved: 'Zatwierdzony', 
      rejected: 'Odrzucony',
      passed: 'Zaliczony',
      failed: 'Niezaliczony',
      blocked: 'Zablokowany',
      'not-run': 'Niewykonany'
    };
    return map[status] || status;
  };

  // Przygotuj wiersze danych - każdy krok w osobnym wierszu
  const rows: any[] = [];
  
  testSpecs.forEach(spec => {
    // Pobierz kroki z obiektu steps lub sparsuj z test_steps
    const steps = spec.steps || [];
    
    if (steps.length > 0) {
      // Jeśli są kroki, utwórz wiersz dla każdego kroku
      steps.forEach((step: any, index: number) => {
        rows.push([
          escapeCSV(spec.test_case_id || ''),
          escapeCSV(spec.title),
          escapeCSV(stripHtml(spec.description || '')),
          escapeCSV(stripHtml(spec.preconditions || '')),
          escapeCSV(index + 1), // Numer kroku
          escapeCSV(step.action || ''),
          escapeCSV(step.expected_result || ''),
          escapeCSV(getPriorityLabel(spec.priority)),
          escapeCSV(getStatusLabel(spec.status)),
          escapeCSV(spec.suite_name || 'Bez zestawu'),
          escapeCSV(spec.requirements?.map((r: any) => r.requirement_id || r.title).join(', ') || ''),
          escapeCSV(spec.tags?.map((t: any) => t.name).join(', ') || ''),
          escapeCSV(spec.created_by_name || ''),
          escapeCSV(new Date(spec.created_at).toLocaleDateString('pl-PL'))
        ]);
      });
    } else {
      // Jeśli brak kroków, utwórz jeden wiersz bez kroków
      rows.push([
        escapeCSV(spec.test_case_id || ''),
        escapeCSV(spec.title),
        escapeCSV(stripHtml(spec.description || '')),
        escapeCSV(stripHtml(spec.preconditions || '')),
        escapeCSV(''),
        escapeCSV(''),
        escapeCSV(''),
        escapeCSV(getPriorityLabel(spec.priority)),
        escapeCSV(getStatusLabel(spec.status)),
        escapeCSV(spec.suite_name || 'Bez zestawu'),
        escapeCSV(spec.requirements?.map((r: any) => r.requirement_id || r.title).join(', ') || ''),
        escapeCSV(spec.tags?.map((t: any) => t.name).join(', ') || ''),
        escapeCSV(spec.created_by_name || ''),
        escapeCSV(new Date(spec.created_at).toLocaleDateString('pl-PL'))
      ]);
    }
  });

  // Połącz nagłówki i wiersze
  const csvContent = [
    headers.join(','),
    ...rows.map(row => row.join(','))
  ].join('\n');

  // Dodaj BOM dla poprawnego wyświetlania polskich znaków w Excel
  const BOM = '\uFEFF';
  const blob = new Blob([BOM + csvContent], { type: 'text/csv;charset=utf-8;' });
  
  // Utwórz link do pobrania
  const link = document.createElement('a');
  const url = URL.createObjectURL(blob);
  link.setAttribute('href', url);
  link.setAttribute('download', filename);
  link.style.visibility = 'hidden';
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
};

export const exportSingleTestSpecificationToCSV = (testSpec: any) => {
  const filename = `tc_${testSpec.test_case_id || testSpec.id}.csv`;
  exportTestSpecificationsToCSV([testSpec], filename);
};
