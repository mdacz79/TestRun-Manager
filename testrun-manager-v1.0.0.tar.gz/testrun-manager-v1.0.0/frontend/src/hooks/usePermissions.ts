import { useMemo } from 'react';
import { getUser } from '../lib/auth';
import { hasPermission, permissionsFromString } from '../config/permissions';

export const usePermissions = () => {
  const user = getUser();
  
  const userPermissions = useMemo(() => {
    if (!user || !user.role_permissions) return [];
    return permissionsFromString(user.role_permissions);
  }, [user]);

  const can = (permission: string): boolean => {
    return hasPermission(userPermissions, permission);
  };

  const canAny = (permissions: string[]): boolean => {
    return permissions.some(permission => hasPermission(userPermissions, permission));
  };

  const canAll = (permissions: string[]): boolean => {
    return permissions.every(permission => hasPermission(userPermissions, permission));
  };

  const isAdmin = (): boolean => {
    return hasPermission(userPermissions, 'admin.full_access') || 
           userPermissions.includes('all');
  };

  return {
    can,
    canAny,
    canAll,
    isAdmin,
    permissions: userPermissions,
  };
};
