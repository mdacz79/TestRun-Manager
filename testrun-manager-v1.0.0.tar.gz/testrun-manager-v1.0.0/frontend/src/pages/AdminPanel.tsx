import { useState } from 'react';
import { Users, Shield, Tag, Settings } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { usePermissions } from '../hooks/usePermissions';
import UserManagement from '../components/admin/UserManagement';
import RoleManagement from '../components/admin/RoleManagement';
import TagsManagement from './TagsManagement';

export default function AdminPanel() {
  const { can, isAdmin } = usePermissions();
  
  // Ustaw domyślną zakładkę na podstawie uprawnień
  const getDefaultTab = () => {
    if (isAdmin() || can('admin.manage_users')) return 'users';
    if (can('admin.manage_roles')) return 'roles';
    return 'tags';
  };
  
  const [activeTab, setActiveTab] = useState<'users' | 'roles' | 'tags'>(getDefaultTab());
  const navigate = useNavigate();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-start">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Panel Administracyjny</h1>
          <p className="mt-2 text-sm text-gray-600">
            Zarządzanie użytkownikami, rolami i słownikami w systemie
          </p>
        </div>
        {(isAdmin() || can('admin.manage_statuses')) && (
          <button
            onClick={() => navigate('/admin/statuses')}
            className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
          >
            <Settings className="h-4 w-4 mr-2" />
            Słowniki Statusów
          </button>
        )}
      </div>

      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          {(isAdmin() || can('admin.manage_users')) && (
            <button
              onClick={() => setActiveTab('users')}
              className={`${
                activeTab === 'users'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
            >
              <Users className="h-5 w-5 mr-2" />
              Użytkownicy
            </button>
          )}
          {(isAdmin() || can('admin.manage_roles')) && (
            <button
              onClick={() => setActiveTab('roles')}
              className={`${
                activeTab === 'roles'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
            >
              <Shield className="h-5 w-5 mr-2" />
              Role
            </button>
          )}
          {(isAdmin() || can('admin.manage_statuses')) && (
            <button
              onClick={() => setActiveTab('tags')}
              className={`${
                activeTab === 'tags'
                  ? 'border-blue-500 text-blue-600'
                  : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
              } whitespace-nowrap py-4 px-1 border-b-2 font-medium text-sm flex items-center`}
            >
              <Tag className="h-5 w-5 mr-2" />
              Tagi
            </button>
          )}
        </nav>
      </div>

      <div>
        {activeTab === 'users' ? <UserManagement /> : activeTab === 'roles' ? <RoleManagement /> : <TagsManagement />}
      </div>
    </div>
  );
}
