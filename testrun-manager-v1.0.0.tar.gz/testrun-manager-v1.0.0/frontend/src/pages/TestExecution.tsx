import { useState, useEffect } from 'react';
import { toast } from 'react-toastify';
import { Play, Plus, ClipboardList, History, CheckCircle, XCircle, MinusCircle, Ban, Clock, Edit, Trash2, Power, PowerOff } from 'lucide-react';
import { testPlans, testExecutions, users as usersApi } from '../lib/api';
import { useProject } from '../context/ProjectContext';
import { usePermissions } from '../hooks/usePermissions';
import CreateTestPlanModal from '../components/CreateTestPlanModal';
import AddTestCasesModal from '../components/AddTestCasesModal';
import ExecuteTestModal from '../components/ExecuteTestModal';
import TestHistoryModal from '../components/TestHistoryModal';
import CreateBugModal from '../components/CreateBugModal';
import ConfirmDialog from '../components/ConfirmDialog';

export default function TestExecution() {
  const { selectedProject } = useProject();
  const { can } = usePermissions();
  const [plans, setPlans] = useState<any[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [planDetails, setPlanDetails] = useState<any>(null);
  const [users, setUsers] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  
  // Modals
  const [showCreatePlanModal, setShowCreatePlanModal] = useState(false);
  const [showEditPlanModal, setShowEditPlanModal] = useState(false);
  const [showAddCasesModal, setShowAddCasesModal] = useState(false);
  const [showExecuteModal, setShowExecuteModal] = useState(false);
  const [showHistoryModal, setShowHistoryModal] = useState(false);
  const [showBugModal, setShowBugModal] = useState(false);
  const [editingPlan, setEditingPlan] = useState<any>(null);
  
  // Selected items
  const [selectedTestCase, setSelectedTestCase] = useState<any>(null);
  const [currentExecution, setCurrentExecution] = useState<any>(null);
  const [createdBugId, setCreatedBugId] = useState<number | undefined>();
  
  // Confirm dialogs
  const [confirmDialog, setConfirmDialog] = useState<{
    show: boolean;
    title: string;
    message: string;
    onConfirm: () => void;
    variant?: 'danger' | 'warning' | 'info';
  }>({
    show: false,
    title: '',
    message: '',
    onConfirm: () => {},
  });

  useEffect(() => {
    if (selectedProject) {
      loadData();
    }
  }, [selectedProject]);

  const loadData = async () => {
    try {
      setLoading(true);
      const [plansRes, usersRes] = await Promise.all([
        testPlans.getAll(selectedProject!.id),
        usersApi.getList(),
      ]);
      setPlans(plansRes.data);
      setUsers(usersRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
      toast.error('❌ Błąd podczas ładowania danych');
    } finally {
      setLoading(false);
    }
  };

  const loadPlanDetails = async (planId: number) => {
    try {
      const res = await testPlans.getById(planId);
      setPlanDetails(res.data);
      setSelectedPlan(res.data);
    } catch (error) {
      console.error('Error loading plan details:', error);
      toast.error('❌ Błąd podczas ładowania szczegółów planu');
    }
  };

  const handleCreatePlan = async (data: { name: string; description: string; start_date?: string; end_date?: string }) => {
    try {
      await testPlans.create({ ...data, project_id: selectedProject!.id });
      toast.success('✅ Plan testów utworzony');
      setShowCreatePlanModal(false);
      loadData();
    } catch (error) {
      console.error('Error creating plan:', error);
      toast.error('❌ Błąd podczas tworzenia planu');
    }
  };

  const handleAddCases = async (caseIds: number[]) => {
    try {
      for (const caseId of caseIds) {
        await testPlans.addCase(selectedPlan.id, { test_specification_id: caseId });
      }
      toast.success(`✅ Dodano ${caseIds.length} przypadków testowych`);
      setShowAddCasesModal(false);
      loadPlanDetails(selectedPlan.id);
    } catch (error: any) {
      console.error('Error adding cases:', error);
      if (error.response?.data?.error?.includes('already exists')) {
        toast.error('❌ Niektóre przypadki już istnieją w planie');
      } else {
        toast.error('❌ Błąd podczas dodawania przypadków');
      }
    }
  };

  const handleStartTest = async (testCase: any) => {
    try {
      // Jeśli test jest już IN_PROGRESS, pobierz istniejące wykonanie
      if (testCase.status === 'IN_PROGRESS') {
        // Pobierz historię i znajdź ostatnie IN_PROGRESS wykonanie
        const historyRes = await testExecutions.getHistory(testCase.id);
        const inProgressExecution = historyRes.data.find((exec: any) => exec.status === 'IN_PROGRESS');
        
        if (inProgressExecution) {
          setCurrentExecution(inProgressExecution);
          setSelectedTestCase(testCase);
          setShowExecuteModal(true);
          return;
        }
      }
      
      // W przeciwnym razie rozpocznij nowe wykonanie
      const res = await testExecutions.start(testCase.id);
      setCurrentExecution(res.data);
      setSelectedTestCase(testCase);
      setShowExecuteModal(true);
      loadPlanDetails(selectedPlan.id);
    } catch (error) {
      console.error('Error starting test:', error);
      toast.error('❌ Błąd podczas rozpoczynania testu');
    }
  };

  const handleCompleteTest = async (data: { status: string; bug_id?: number; notes?: string }) => {
    try {
      await testExecutions.complete({
        execution_id: currentExecution.id,
        ...data,
      });
      toast.success('✅ Test zakończony');
      setShowExecuteModal(false);
      setCurrentExecution(null);
      setSelectedTestCase(null);
      loadPlanDetails(selectedPlan.id);
    } catch (error) {
      console.error('Error completing test:', error);
      toast.error('❌ Błąd podczas kończenia testu');
    }
  };

  const handleAssignUser = async (caseId: number, userId: number | null) => {
    try {
      await testPlans.assignUser(selectedPlan.id, caseId, userId);
      toast.success('✅ Użytkownik przypisany');
      loadPlanDetails(selectedPlan.id);
    } catch (error) {
      console.error('Error assigning user:', error);
      toast.error('❌ Błąd podczas przypisywania użytkownika');
    }
  };

  const handleEditPlan = (plan: any) => {
    setEditingPlan(plan);
    setShowEditPlanModal(true);
  };

  const handleUpdatePlan = async (data: { name: string; description?: string; start_date?: string; end_date?: string }) => {
    try {
      await testPlans.update(editingPlan.id, data);
      toast.success('✅ Plan testów zaktualizowany');
      setShowEditPlanModal(false);
      setEditingPlan(null);
      loadData();
      if (selectedPlan?.id === editingPlan.id) {
        loadPlanDetails(editingPlan.id);
      }
    } catch (error) {
      console.error('Error updating test plan:', error);
      toast.error('❌ Błąd podczas aktualizacji planu');
    }
  };

  const handleDeletePlan = async (planId: number) => {
    setConfirmDialog({
      show: true,
      title: 'Usunąć plan testów?',
      message: 'Czy na pewno chcesz usunąć ten plan testów? Wszystkie powiązane wykonania testów zostaną utracone.',
      variant: 'danger',
      onConfirm: async () => {
        try {
          await testPlans.delete(planId);
          toast.success('✅ Plan testów usunięty');
          if (selectedPlan?.id === planId) {
            setSelectedPlan(null);
            setPlanDetails(null);
          }
          loadData();
        } catch (error) {
          console.error('Error deleting test plan:', error);
          toast.error('❌ Błąd podczas usuwania planu');
        } finally {
          setConfirmDialog({ ...confirmDialog, show: false });
        }
      }
    });
  };

  const handleToggleActive = async (planId: number, event: React.MouseEvent) => {
    event.stopPropagation();
    try {
      await testPlans.toggleActive(planId);
      toast.success('✅ Status planu zmieniony');
      loadData();
      if (selectedPlan?.id === planId) {
        loadPlanDetails(planId);
      }
    } catch (error) {
      console.error('Error toggling plan active state:', error);
      toast.error('❌ Błąd podczas zmiany statusu planu');
    }
  };

  const handleRemoveCase = async (caseId: number) => {
    setConfirmDialog({
      show: true,
      title: 'Usunąć przypadek testowy z planu?',
      message: 'Czy na pewno chcesz usunąć ten przypadek testowy z planu? Przypadek testowy pozostanie w systemie, ale zostanie usunięty z tego planu.',
      variant: 'warning',
      onConfirm: async () => {
        try {
          await testPlans.removeCase(selectedPlan.id, caseId);
          toast.success('✅ Przypadek testowy usunięty z planu');
          loadPlanDetails(selectedPlan.id);
        } catch (error) {
          console.error('Error removing case:', error);
          toast.error('❌ Błąd podczas usuwania przypadku');
        } finally {
          setConfirmDialog({ ...confirmDialog, show: false });
        }
      }
    });
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'PASSED': return <CheckCircle className="h-5 w-5 text-green-600" />;
      case 'FAILED': return <XCircle className="h-5 w-5 text-red-600" />;
      case 'SKIPPED': return <MinusCircle className="h-5 w-5 text-gray-600" />;
      case 'BLOCKED': return <Ban className="h-5 w-5 text-orange-600" />;
      case 'IN_PROGRESS': return <Clock className="h-5 w-5 text-blue-600" />;
      default: return <ClipboardList className="h-5 w-5 text-gray-400" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'PASSED': return 'bg-green-100 text-green-800';
      case 'FAILED': return 'bg-red-100 text-red-800';
      case 'SKIPPED': return 'bg-gray-100 text-gray-800';
      case 'BLOCKED': return 'bg-orange-100 text-orange-800';
      case 'IN_PROGRESS': return 'bg-blue-100 text-blue-800';
      default: return 'bg-gray-100 text-gray-600';
    }
  };

  const getStatusLabel = (status: string) => {
    switch (status) {
      case 'PASSED': return 'Zaliczony';
      case 'FAILED': return 'Niezaliczony';
      case 'SKIPPED': return 'Pominięty';
      case 'BLOCKED': return 'Zablokowany';
      case 'IN_PROGRESS': return 'W trakcie';
      default: return 'Nie wykonano';
    }
  };

  if (loading) {
    return <div className="p-6">Ładowanie...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Wykonywanie testów</h1>
        {can('test_execution.create_plan') && (
          <button
            onClick={() => setShowCreatePlanModal(true)}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nowy plan testów
          </button>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Lista planów testów */}
        <div className="lg:col-span-1 bg-white shadow rounded-lg p-4">
          <h2 className="text-lg font-semibold mb-4">Plany testów</h2>
          <div className="space-y-2">
            {plans.length === 0 ? (
              <p className="text-sm text-gray-500">Brak planów testów</p>
            ) : (
              plans.map((plan) => (
                <div
                  key={plan.id}
                  className={`p-3 rounded-lg transition-colors ${
                    selectedPlan?.id === plan.id
                      ? 'bg-blue-50 border-2 border-blue-500'
                      : 'bg-gray-50 hover:bg-gray-100 border-2 border-transparent'
                  } ${plan.is_active === 0 ? 'opacity-60' : ''}`}
                >
                  <div 
                    onClick={() => loadPlanDetails(plan.id)}
                    className="cursor-pointer flex-1"
                  >
                    <div className="flex items-center justify-between">
                      <div className="font-medium text-gray-900 flex items-center gap-2">
                        {plan.name}
                        {plan.is_active === 0 && (
                          <span className="text-xs px-2 py-0.5 bg-gray-200 text-gray-600 rounded">
                            Nieaktywny
                          </span>
                        )}
                      </div>
                    </div>
                    <div className="text-xs text-gray-500 mt-1">
                      {plan.test_count} przypadków testowych
                    </div>
                  </div>
                  {(can('test_execution.edit_plan') || can('test_execution.create_plan') || can('test_execution.delete_plan')) && (
                    <div className="flex gap-1 mt-2 pt-2 border-t border-gray-200">
                      {can('test_execution.edit_plan') && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleEditPlan(plan);
                          }}
                          className="flex-1 inline-flex items-center justify-center px-2 py-1 text-xs text-blue-600 hover:bg-blue-50 rounded"
                          title="Edytuj"
                        >
                          <Edit className="h-3 w-3 mr-1" />
                          Edytuj
                        </button>
                      )}
                      {(can('test_execution.create_plan') || can('test_execution.edit_plan')) && (
                        <button
                          onClick={(e) => handleToggleActive(plan.id, e)}
                          className={`flex-1 inline-flex items-center justify-center px-2 py-1 text-xs rounded ${
                            plan.is_active === 1
                              ? 'text-orange-600 hover:bg-orange-50'
                              : 'text-green-600 hover:bg-green-50'
                          }`}
                          title={plan.is_active === 1 ? 'Dezaktywuj' : 'Aktywuj'}
                        >
                          {plan.is_active === 1 ? (
                            <><PowerOff className="h-3 w-3 mr-1" />Dezaktywuj</>
                          ) : (
                            <><Power className="h-3 w-3 mr-1" />Aktywuj</>
                          )}
                        </button>
                      )}
                      {can('test_execution.delete_plan') && (
                        <button
                          onClick={(e) => {
                            e.stopPropagation();
                            handleDeletePlan(plan.id);
                          }}
                          className="flex-1 inline-flex items-center justify-center px-2 py-1 text-xs text-red-600 hover:bg-red-50 rounded"
                          title="Usuń"
                        >
                          <Trash2 className="h-3 w-3 mr-1" />
                          Usuń
                        </button>
                      )}
                    </div>
                  )}
                </div>
              ))
            )}
          </div>
        </div>

        {/* Szczegóły planu i przypadki testowe */}
        <div className="lg:col-span-2 bg-white shadow rounded-lg p-4">
          {!selectedPlan ? (
            <div className="text-center text-gray-500 py-12">
              Wybierz plan testów aby zobaczyć szczegóły
            </div>
          ) : (
            <>
              <div className="flex justify-between items-center mb-4">
                <div>
                  <h2 className="text-lg font-semibold">{planDetails?.name}</h2>
                  <p className="text-sm text-gray-600">{planDetails?.description}</p>
                </div>
                {(can('test_execution.create_plan') || can('test_execution.edit_plan')) && (
                  <button
                    onClick={() => setShowAddCasesModal(true)}
                    className="inline-flex items-center px-3 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                  >
                    <Plus className="h-4 w-4 mr-2" />
                    Dodaj testy
                  </button>
                )}
              </div>

              {/* Lista przypadków testowych */}
              <div className="space-y-2">
                {planDetails?.cases?.length === 0 ? (
                  <p className="text-sm text-gray-500 text-center py-8">
                    Brak przypadków testowych w tym planie
                  </p>
                ) : (
                  planDetails?.cases?.map((testCase: any) => (
                    <div
                      key={testCase.id}
                      className="border rounded-lg p-4 hover:bg-gray-50"
                    >
                      <div className="flex items-start justify-between">
                        <div className="flex-1">
                          <div className="flex items-center gap-2">
                            {getStatusIcon(testCase.status)}
                            <span className="font-mono text-sm font-semibold text-blue-600">
                              {testCase.test_case_id}
                            </span>
                            <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStatusColor(testCase.status)}`}>
                              {getStatusLabel(testCase.status)}
                            </span>
                          </div>
                          <div className="mt-2 text-sm font-medium text-gray-900">
                            {testCase.title}
                          </div>
                          {testCase.assigned_to_name && (
                            <div className="mt-1 text-xs text-gray-500">
                              👤 {testCase.assigned_to_name}
                            </div>
                          )}
                        </div>
                        <div className="flex items-center gap-2">
                          <button
                            onClick={() => {
                              setSelectedTestCase(testCase);
                              setShowHistoryModal(true);
                            }}
                            className="p-2 text-gray-600 hover:text-gray-900"
                            title="Historia"
                          >
                            <History className="h-4 w-4" />
                          </button>
                          {(can('test_execution.create_plan') || can('test_execution.edit_plan')) && (
                            <button
                              onClick={() => handleRemoveCase(testCase.id)}
                              className="p-2 text-red-600 hover:text-red-900 hover:bg-red-50 rounded"
                              title="Usuń z planu"
                            >
                              <Trash2 className="h-4 w-4" />
                            </button>
                          )}
                          {can('test_execution.assign') ? (
                            <select
                              value={testCase.assigned_to || ''}
                              onChange={(e) => handleAssignUser(testCase.id, e.target.value ? Number(e.target.value) : null)}
                              className="text-xs border border-gray-300 rounded px-2 py-1"
                            >
                              <option value="">Nie przypisano</option>
                              {users.map((user) => (
                                <option key={user.id} value={user.id}>
                                  {user.name}
                                </option>
                              ))}
                            </select>
                          ) : (
                            testCase.assigned_to_name && (
                              <span className="text-xs text-gray-600 px-2 py-1">
                                {testCase.assigned_to_name}
                              </span>
                            )
                          )}
                          {can('test_execution.execute') && (
                            planDetails?.is_active === 0 ? (
                              <div className="inline-flex items-center px-3 py-1 bg-gray-300 text-gray-500 rounded text-sm cursor-not-allowed" title="Plan testów jest nieaktywny">
                                <Play className="h-3 w-3 mr-1" />
                                Zablokowany
                              </div>
                            ) : (
                              <button
                                onClick={() => handleStartTest(testCase)}
                                className={`inline-flex items-center px-3 py-1 text-white rounded text-sm ${
                                  testCase.status === 'IN_PROGRESS' 
                                    ? 'bg-blue-600 hover:bg-blue-700' 
                                    : 'bg-green-600 hover:bg-green-700'
                                }`}
                              >
                                <Play className="h-3 w-3 mr-1" />
                                {testCase.status === 'IN_PROGRESS' ? 'Kontynuuj' : 'Wykonaj'}
                              </button>
                            )
                          )}
                        </div>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </>
          )}
        </div>
      </div>

      {/* Modals */}
      {showCreatePlanModal && (
        <CreateTestPlanModal
          onClose={() => setShowCreatePlanModal(false)}
          onCreate={handleCreatePlan}
        />
      )}

      {showEditPlanModal && editingPlan && (
        <CreateTestPlanModal
          onClose={() => {
            setShowEditPlanModal(false);
            setEditingPlan(null);
          }}
          onCreate={handleUpdatePlan}
          initialData={editingPlan}
        />
      )}

      {showAddCasesModal && selectedPlan && (
        <AddTestCasesModal
          projectId={selectedProject!.id}
          existingCaseIds={planDetails?.cases?.map((c: any) => c.test_specification_id) || []}
          onClose={() => setShowAddCasesModal(false)}
          onAdd={handleAddCases}
        />
      )}

      {showExecuteModal && selectedTestCase && currentExecution && (
        <ExecuteTestModal
          testCase={selectedTestCase}
          execution={currentExecution}
          bugId={createdBugId}
          onClose={() => {
            setShowExecuteModal(false);
            setCurrentExecution(null);
            setSelectedTestCase(null);
            setCreatedBugId(undefined);
          }}
          onComplete={handleCompleteTest}
          onCreateBug={() => setShowBugModal(true)}
        />
      )}

      {showHistoryModal && selectedTestCase && (
        <TestHistoryModal
          testCase={selectedTestCase}
          onClose={() => {
            setShowHistoryModal(false);
            setSelectedTestCase(null);
          }}
        />
      )}

      {showBugModal && (
        <CreateBugModal
          projectId={selectedProject!.id}
          onClose={() => setShowBugModal(false)}
          onCreate={(bug: any) => {
            setCreatedBugId(bug.id);
            setShowBugModal(false);
            toast.success(`✅ Błąd ${bug.bug_id} zgłoszony`);
          }}
        />
      )}

      {confirmDialog.show && (
        <ConfirmDialog
          title={confirmDialog.title}
          message={confirmDialog.message}
          variant={confirmDialog.variant}
          confirmText="Potwierdź"
          cancelText="Anuluj"
          onConfirm={confirmDialog.onConfirm}
          onCancel={() => setConfirmDialog({ ...confirmDialog, show: false })}
        />
      )}
    </div>
  );
}
