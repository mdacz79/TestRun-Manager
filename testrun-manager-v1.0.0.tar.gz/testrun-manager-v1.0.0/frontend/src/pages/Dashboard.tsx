import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from 'react-toastify';
import { FolderKanban, Plus, ArrowRight, AlertCircle, Edit, Trash2 } from 'lucide-react';
import { projects, users } from '../lib/api';
import { useProject } from '../context/ProjectContext';
import { getUser } from '../lib/auth';
import { usePermissions } from '../hooks/usePermissions';
import ConfirmDialog from '../components/ConfirmDialog';

export default function Dashboard() {
  const navigate = useNavigate();
  const { setSelectedProject } = useProject();
  const { can } = usePermissions();
  const user = getUser();
  const isAdmin = user?.role_name === 'Administrator';
  const [projectList, setProjectList] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedProject, setSelectedProjectState] = useState<any>(null);
  const [formData, setFormData] = useState({ 
    name: '', 
    tag: '', 
    description: '', 
    project_manager_id: '' 
  });
  const [showDeleteDialog, setShowDeleteDialog] = useState(false);
  const [projectToDelete, setProjectToDelete] = useState<any>(null);

  useEffect(() => {
    // Wyczyść wybrany projekt przy wejściu na Dashboard
    setSelectedProject(null);
    loadProjects();
    
    // Ładuj użytkowników jeśli użytkownik ma uprawnienia do zarządzania projektami
    const userPermissions = user?.role_permissions || '';
    const hasProjectPermissions = 
      isAdmin || 
      userPermissions.includes('projects.create') || 
      userPermissions.includes('projects.edit');
    
    if (hasProjectPermissions) {
      loadUsers();
    }
  }, []);

  const loadProjects = async () => {
    try {
      const response = await projects.getAll();
      setProjectList(response.data);
    } catch (error) {
      console.error('Error loading projects:', error);
    } finally {
      setLoading(false);
    }
  };

  const loadUsers = async () => {
    try {
      const response = await users.getList();
      setUsersList(response.data.filter((u: any) => u.is_active));
    } catch (error) {
      console.error('Error loading users:', error);
    }
  };

  const handleProjectSelect = (project: any) => {
    setSelectedProject(project);
    
    // Przekieruj do pierwszej dostępnej zakładki na podstawie uprawnień
    if (can('requirements.view')) {
      navigate('/requirements');
    } else if (can('test_specs.view')) {
      navigate('/test-specifications');
    } else if (can('test_execution.view')) {
      navigate('/test-execution');
    } else if (can('defects.view')) {
      navigate('/defects');
    } else if (can('reports.view')) {
      navigate('/reports');
    } else {
      // Jeśli użytkownik nie ma dostępu do żadnej zakładki
      toast.error('Brak uprawnień do modułów projektu');
      setSelectedProject(null);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (selectedProject) {
        await projects.update(selectedProject.id, formData);
        toast.success('Projekt został zaktualizowany');
      } else {
        await projects.create(formData);
        toast.success('Projekt został utworzony');
      }
      setShowModal(false);
      setSelectedProjectState(null);
      setFormData({ name: '', tag: '', description: '', project_manager_id: '' });
      loadProjects();
    } catch (error) {
      console.error('Error saving project:', error);
      toast.error('Błąd podczas zapisywania projektu');
    }
  };

  const handleEdit = (project: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedProjectState(project);
    setFormData({
      name: project.name,
      tag: project.tag || '',
      description: project.description || '',
      project_manager_id: project.project_manager_id || '',
    });
    setShowModal(true);
  };

  const handleDelete = (project: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setProjectToDelete(project);
    setShowDeleteDialog(true);
  };

  const confirmDelete = async () => {
    if (!projectToDelete) return;
    
    try {
      await projects.delete(projectToDelete.id);
      toast.success('Projekt został usunięty');
      setShowDeleteDialog(false);
      setProjectToDelete(null);
      loadProjects();
    } catch (error) {
      console.error('Error deleting project:', error);
      toast.error('Błąd podczas usuwania projektu');
    }
  };

  const cancelDelete = () => {
    setShowDeleteDialog(false);
    setProjectToDelete(null);
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Wybierz Projekt</h1>
          <p className="mt-2 text-sm text-gray-600">
            {isAdmin ? 'Zarządzaj projektami i wybierz projekt do pracy' : 'Wybierz projekt, aby zarządzać testami'}
          </p>
        </div>
        {can('projects.create') && (
          <button
            onClick={() => {
              setSelectedProjectState(null);
              setFormData({ name: '', tag: '', description: '', project_manager_id: '' });
              setShowModal(true);
            }}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Nowy projekt
          </button>
        )}
      </div>

      {projectList.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          {isAdmin ? (
            <>
              <FolderKanban className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Brak projektów</h3>
              <p className="mt-1 text-sm text-gray-500">Zacznij od utworzenia nowego projektu.</p>
              <div className="mt-6">
                <button
                  onClick={() => {
                    setSelectedProjectState(null);
                    setFormData({ name: '', tag: '', description: '', project_manager_id: '' });
                    setShowModal(true);
                  }}
                  className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
                >
                  <Plus className="h-4 w-4 mr-2" />
                  Utwórz pierwszy projekt
                </button>
              </div>
            </>
          ) : (
            <>
              <AlertCircle className="mx-auto h-12 w-12 text-yellow-500" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Brak przypisanych projektów</h3>
              <p className="mt-1 text-sm text-gray-500">
                Nie jesteś przypisany do żadnego projektu.
              </p>
              <p className="mt-2 text-sm text-gray-500">
                Skontaktuj się z administratorem, aby uzyskać dostęp do projektów.
              </p>
            </>
          )}
        </div>
      ) : (
        <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {projectList.map((project) => (
            <div
              key={project.id}
              onClick={() => handleProjectSelect(project)}
              className="bg-white overflow-hidden shadow rounded-lg hover:shadow-xl transition-all cursor-pointer border-2 border-transparent hover:border-blue-500"
            >
              <div className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <FolderKanban className="h-8 w-8 text-blue-600" />
                  <div className="flex items-center space-x-2">
                    {can('projects.edit') && (
                      <button
                        onClick={(e) => handleEdit(project, e)}
                        className="p-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded"
                        title="Edytuj projekt"
                      >
                        <Edit className="h-4 w-4" />
                      </button>
                    )}
                    {can('projects.delete') && (
                      <button
                        onClick={(e) => handleDelete(project, e)}
                        className="p-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded"
                        title="Usuń projekt"
                      >
                        <Trash2 className="h-4 w-4" />
                      </button>
                    )}
                    <ArrowRight className="h-5 w-5 text-gray-400" />
                  </div>
                </div>
                <h3 className="text-lg font-semibold text-gray-900 mb-2">
                  {project.name}
                </h3>
                <p className="text-sm text-gray-600 line-clamp-2">
                  {project.description || 'Brak opisu'}
                </p>
                <div className="mt-4 pt-4 border-t border-gray-200 space-y-1">
                  {project.tag && (
                    <p className="text-xs font-semibold text-blue-600">
                      TAG: {project.tag}
                    </p>
                  )}
                  {project.project_manager_name && (
                    <p className="text-xs text-gray-600">
                      <span className="font-medium">PM:</span> {project.project_manager_name}
                    </p>
                  )}
                  <p className="text-xs text-gray-500">
                    Utworzono: {new Date(project.created_at).toLocaleDateString('pl-PL')}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {showModal && (can('projects.create') || can('projects.edit')) && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => {
              setShowModal(false);
              setSelectedProjectState(null);
              setFormData({ name: '', tag: '', description: '', project_manager_id: '' });
            }}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-lg w-full z-20">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {selectedProject ? 'Edytuj projekt' : 'Nowy projekt'}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Nazwa projektu *
                      </label>
                      <input
                        type="text"
                        required
                        value={formData.name}
                        onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="np. Aplikacja mobilna"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        TAG projektu * (max 5 znaków)
                      </label>
                      <input
                        type="text"
                        required
                        maxLength={5}
                        value={formData.tag}
                        onChange={(e) => setFormData({ ...formData, tag: e.target.value.toUpperCase() })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500 uppercase"
                        placeholder="np. MOBIL"
                      />
                      <p className="mt-1 text-xs text-gray-500">TAG będzie używany do generowania identyfikatorów (np. MOBIL-001)</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Opis
                      </label>
                      <textarea
                        value={formData.description}
                        onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                        rows={3}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        placeholder="Krótki opis projektu..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Project Manager *
                      </label>
                      <select
                        required
                        value={formData.project_manager_id}
                        onChange={(e) => setFormData({ ...formData, project_manager_id: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">Wybierz Project Managera</option>
                        {usersList.map((u) => (
                          <option key={u.id} value={u.id}>
                            {u.name} ({u.email}) - {u.role_name}
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {selectedProject ? 'Zapisz zmiany' : 'Utwórz projekt'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowModal(false);
                      setSelectedProjectState(null);
                      setFormData({ name: '', tag: '', description: '', project_manager_id: '' });
                    }}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm"
                  >
                    Anuluj
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Dialog potwierdzenia usunięcia */}
      {showDeleteDialog && projectToDelete && (
        <ConfirmDialog
          title="Usuń projekt"
          message={`Czy na pewno chcesz usunąć projekt "${projectToDelete.name}"?\n\nUWAGA: Zostaną usunięte wszystkie powiązane dane (wymagania, przypadki testowe, defekty).`}
          confirmText="Usuń"
          cancelText="Anuluj"
          onConfirm={confirmDelete}
          onCancel={cancelDelete}
          variant="danger"
        />
      )}
    </div>
  );
}
