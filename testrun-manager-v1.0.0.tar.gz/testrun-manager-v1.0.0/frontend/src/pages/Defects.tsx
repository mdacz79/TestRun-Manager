import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Bug, Eye, Paperclip, X } from 'lucide-react';
import { bugs, testSpecifications, users, statuses } from '../lib/api';
import { useProject } from '../context/ProjectContext';
import WysiwygEditor from '../components/WysiwygEditor';
import BugDetailsModal from '../components/BugDetailsModal';
import ConfirmDialog from '../components/ConfirmDialog';
import { usePermissions } from '../hooks/usePermissions';

export default function Defects() {
  const { selectedProject } = useProject();
  const { can } = usePermissions();
  const [defectsList, setDefectsList] = useState<any[]>([]);
  const [specificationsList, setSpecificationsList] = useState<any[]>([]);
  const [usersList, setUsersList] = useState<any[]>([]);
  const [bugStatuses, setBugStatuses] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [selectedDefect, setSelectedDefect] = useState<any>(null);
  const [showDetailsModal, setShowDetailsModal] = useState(false);
  const [selectedBugForDetails, setSelectedBugForDetails] = useState<any>(null);
  const [showDeleteConfirm, setShowDeleteConfirm] = useState(false);
  const [defectToDelete, setDefectToDelete] = useState<any>(null);
  const [pendingAttachments, setPendingAttachments] = useState<File[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    steps_to_reproduce: '',
    severity: 'medium',
    priority: 'medium',
    status: 'new',
    test_specification_id: '',
    assigned_to: '',
  });

  useEffect(() => {
    if (selectedProject) {
      loadData();
    }
  }, [selectedProject]);

  const loadData = async () => {
    try {
      const [bugsRes, specsRes, usersRes, statusesRes] = await Promise.all([
        bugs.getAll(selectedProject!.id),
        testSpecifications.getAll(selectedProject!.id),
        users.getList(),
        statuses.getBugStatuses(),
      ]);
      
      setDefectsList(bugsRes.data);
      setSpecificationsList(specsRes.data);
      setUsersList(usersRes.data);
      setBugStatuses(statusesRes.data.filter((s: any) => s.is_active));
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        title: formData.title,
        description: formData.description,
        steps_to_reproduce: formData.steps_to_reproduce,
        severity: formData.severity,
        priority: formData.priority,
        status: formData.status,
        project_id: selectedProject!.id,
        test_specification_id: formData.test_specification_id ? Number(formData.test_specification_id) : undefined,
        assigned_to: formData.assigned_to ? Number(formData.assigned_to) : undefined,
      };

      let bugId: number;
      
      if (selectedDefect) {
        await bugs.update(selectedDefect.id, data);
        bugId = selectedDefect.id;
      } else {
        const response = await bugs.create(data);
        console.log('Create response:', response);
        console.log('Response data:', response.data);
        
        // Backend zwraca obiekt w response.data
        if (!response.data || !response.data.id) {
          throw new Error('Nie otrzymano ID defektu z serwera');
        }
        bugId = response.data.id;
      }

      // Prześlij załączniki jeśli są
      if (pendingAttachments.length > 0) {
        for (const file of pendingAttachments) {
          try {
            await bugs.uploadAttachment(bugId, file);
          } catch (error) {
            console.error('Error uploading attachment:', error);
          }
        }
      }

      setShowModal(false);
      setSelectedDefect(null);
      setPendingAttachments([]);
      setFormData({
        title: '',
        description: '',
        steps_to_reproduce: '',
        severity: 'medium',
        priority: 'medium',
        status: 'new',
        test_specification_id: '',
        assigned_to: '',
      });
      loadData();
    } catch (error: any) {
      console.error('Error saving defect:', error);
      const errorMessage = error.response?.data?.error || error.message || 'Nieznany błąd';
      alert(`Błąd podczas zapisywania defektu: ${errorMessage}`);
    }
  };

  const handleEdit = (defect: any) => {
    setSelectedDefect(defect);
    setFormData({
      title: defect.title,
      description: defect.description || '',
      steps_to_reproduce: defect.steps_to_reproduce || '',
      severity: defect.severity,
      priority: defect.priority,
      status: defect.status,
      test_specification_id: defect.test_specification_id || '',
      assigned_to: defect.assigned_to || '',
    });
    setShowModal(true);
  };

  const handleDelete = (defect: any) => {
    setDefectToDelete(defect);
    setShowDeleteConfirm(true);
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (files) {
      setPendingAttachments([...pendingAttachments, ...Array.from(files)]);
      event.target.value = ''; // Reset input
    }
  };

  const handleRemoveFile = (index: number) => {
    setPendingAttachments(pendingAttachments.filter((_, i) => i !== index));
  };

  const confirmDelete = async () => {
    if (!defectToDelete) return;
    
    try {
      await bugs.delete(defectToDelete.id);
      setShowDeleteConfirm(false);
      setDefectToDelete(null);
      loadData();
    } catch (error) {
      console.error('Error deleting bug:', error);
      alert('Błąd podczas usuwania błędu');
    }
  };

  const getStatusName = (statusKey: string) => {
    const status = bugStatuses.find(s => s.key === statusKey);
    return status ? status.name : statusKey;
  };

  const getStatusColor = (statusKey: string) => {
    const status = bugStatuses.find(s => s.key === statusKey);
    if (!status) return 'bg-gray-100 text-gray-800';
    
    // Konwersja hex na tailwind classes (uproszczona wersja)
    const colorMap: Record<string, string> = {
      '#8b5cf6': 'bg-purple-100 text-purple-800',
      '#3b82f6': 'bg-blue-100 text-blue-800',
      '#f59e0b': 'bg-yellow-100 text-yellow-800',
      '#10b981': 'bg-green-100 text-green-800',
      '#6b7280': 'bg-gray-100 text-gray-800',
      '#ef4444': 'bg-red-100 text-red-800',
    };
    
    return colorMap[status.color] || 'bg-gray-100 text-gray-800';
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Defekty</h2>
        {can('defects.create') && (
          <button
            onClick={() => {
              setSelectedDefect(null);
              setPendingAttachments([]);
              setFormData({
                title: '',
                description: '',
                steps_to_reproduce: '',
                severity: 'medium',
                priority: 'medium',
                status: 'new',
                test_specification_id: '',
                assigned_to: '',
              });
              setShowModal(true);
            }}
            className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
          >
            <Plus className="h-4 w-4 mr-2" />
            Zgłoś defekt
          </button>
        )}
      </div>

      {defectsList.length === 0 ? (
        <div className="text-center py-12 bg-white rounded-lg shadow">
          <Bug className="mx-auto h-12 w-12 text-gray-400" />
          <h3 className="mt-2 text-sm font-medium text-gray-900">Brak defektów</h3>
          <p className="mt-1 text-sm text-gray-500">Zgłoś pierwszy defekt w projekcie.</p>
        </div>
      ) : (
        <div className="bg-white shadow overflow-hidden sm:rounded-lg">
          <table className="min-w-full divide-y divide-gray-200">
            <thead className="bg-gray-50">
              <tr>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Tytuł</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Status</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Priorytet</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Zgłosił</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Przypisany</th>
                <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">Ostatnia modyfikacja</th>
                <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">Akcje</th>
              </tr>
            </thead>
            <tbody className="bg-white divide-y divide-gray-200">
              {defectsList.map((defect) => (
                <tr key={defect.id}>
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-2">
                      {defect.bug_id && (
                        <span className="inline-flex items-center px-2 py-0.5 rounded text-xs font-medium bg-blue-100 text-blue-800">
                          {defect.bug_id}
                        </span>
                      )}
                      <div className="text-sm font-medium text-gray-900">{defect.title}</div>
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(defect.status)}`}>
                      {getStatusName(defect.status)}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      defect.priority === 'high' ? 'bg-red-100 text-red-800' : 
                      defect.priority === 'medium' ? 'bg-yellow-100 text-yellow-800' : 
                      'bg-green-100 text-green-800'
                    }`}>
                      {defect.priority === 'high' ? 'Wysoki' : defect.priority === 'medium' ? 'Średni' : 'Niski'}
                    </span>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{defect.reported_by_name || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-900">{defect.assigned_to_name || '-'}</div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap">
                    <div className="text-sm text-gray-500">
                      {defect.updated_at ? new Date(defect.updated_at).toLocaleString('pl-PL', {
                        day: '2-digit',
                        month: '2-digit',
                        year: 'numeric',
                        hour: '2-digit',
                        minute: '2-digit'
                      }) : '-'}
                    </div>
                  </td>
                  <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                    <button 
                      onClick={() => {
                        setSelectedBugForDetails(defect);
                        setShowDetailsModal(true);
                      }} 
                      className="text-green-600 hover:text-green-900"
                      title="Szczegóły i komentarze"
                    >
                      <Eye className="h-4 w-4 inline" />
                    </button>
                    {can('defects.edit') && (
                      <button 
                        onClick={() => handleEdit(defect)} 
                        className="text-blue-600 hover:text-blue-900"
                        title="Edytuj"
                      >
                        <Edit className="h-4 w-4 inline" />
                      </button>
                    )}
                    {can('defects.delete') && (
                      <button 
                        onClick={() => handleDelete(defect)} 
                        className="text-red-600 hover:text-red-900"
                        title="Usuń"
                      >
                        <Trash2 className="h-4 w-4 inline" />
                      </button>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {showModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => setShowModal(false)}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-2xl w-full z-20">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4 max-h-[80vh] overflow-y-auto">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {selectedDefect ? 'Edytuj defekt' : 'Zgłoś nowy defekt'}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Tytuł</label>
                      <input
                        type="text"
                        required
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Opis</label>
                      <WysiwygEditor
                        value={formData.description}
                        onChange={(value) => setFormData({ ...formData, description: value })}
                        placeholder="Szczegółowy opis błędu..."
                        onImagePaste={(file) => {
                          setPendingAttachments([...pendingAttachments, file]);
                        }}
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Kroki do reprodukcji</label>
                      <WysiwygEditor
                        value={formData.steps_to_reproduce}
                        onChange={(value) => setFormData({ ...formData, steps_to_reproduce: value })}
                        placeholder="1. Krok pierwszy, 2. Krok drugi, 3. Oczekiwany rezultat"
                        onImagePaste={(file) => {
                          setPendingAttachments([...pendingAttachments, file]);
                        }}
                      />
                    </div>
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Priorytet</label>
                        <select
                          value={formData.priority}
                          onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="low">Niski</option>
                          <option value="medium">Średni</option>
                          <option value="high">Wysoki</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Severity</label>
                        <select
                          value={formData.severity}
                          onChange={(e) => setFormData({ ...formData, severity: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                        >
                          <option value="low">Niski</option>
                          <option value="medium">Średni</option>
                          <option value="high">Wysoki</option>
                          <option value="critical">Krytyczny</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Status</label>
                      <input
                        type="text"
                        value={getStatusName('new')}
                        disabled
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 bg-gray-100 text-gray-600 cursor-not-allowed"
                      />
                      <p className="mt-1 text-xs text-gray-500">Nowe błędy zawsze mają status "Nowy"</p>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Powiązana specyfikacja</label>
                      <select
                        value={formData.test_specification_id}
                        onChange={(e) => setFormData({ ...formData, test_specification_id: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">Brak</option>
                        {specificationsList.map((spec) => (
                          <option key={spec.id} value={spec.id}>{spec.title}</option>
                        ))}
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Przypisz do</label>
                      <select
                        value={formData.assigned_to}
                        onChange={(e) => setFormData({ ...formData, assigned_to: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                      >
                        <option value="">Nieprzypisany</option>
                        {usersList.map((user) => (
                          <option key={user.id} value={user.id}>{user.name}</option>
                        ))}
                      </select>
                    </div>

                    {/* Załączniki */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Załączniki (opcjonalnie)
                      </label>
                      <div className="space-y-2">
                        {/* Upload button */}
                        <label className="block">
                          <input
                            type="file"
                            onChange={handleFileSelect}
                            multiple
                            className="block w-full text-sm text-gray-500
                              file:mr-4 file:py-2 file:px-4
                              file:rounded-md file:border-0
                              file:text-sm file:font-medium
                              file:bg-blue-50 file:text-blue-700
                              hover:file:bg-blue-100
                              cursor-pointer"
                          />
                        </label>
                        
                        {/* Lista wybranych plików */}
                        {pendingAttachments.length > 0 && (
                          <div className="space-y-1">
                            {pendingAttachments.map((file, index) => (
                              <div key={index} className="flex items-center justify-between bg-gray-50 border rounded-md p-2">
                                <div className="flex items-center gap-2 flex-1 min-w-0">
                                  <Paperclip className="h-4 w-4 text-gray-400 flex-shrink-0" />
                                  <span className="text-sm text-gray-700 truncate">
                                    {file.name}
                                  </span>
                                  <span className="text-xs text-gray-500 flex-shrink-0">
                                    ({(file.size / 1024).toFixed(2)} KB)
                                  </span>
                                </div>
                                <button
                                  type="button"
                                  onClick={() => handleRemoveFile(index)}
                                  className="p-1 text-red-600 hover:bg-red-50 rounded transition-colors flex-shrink-0"
                                  title="Usuń"
                                >
                                  <X className="h-4 w-4" />
                                </button>
                              </div>
                            ))}
                          </div>
                        )}
                        
                        <p className="text-xs text-gray-500">
                          Możesz dodać wiele plików (zrzuty ekranu, CSV, dokumenty). Maksymalny rozmiar: 10MB na plik.
                        </p>
                      </div>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {selectedDefect ? 'Zapisz' : 'Zgłoś'}
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowModal(false)}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm"
                  >
                    Anuluj
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Bug Details Modal */}
      {showDetailsModal && selectedBugForDetails && (
        <BugDetailsModal
          bug={selectedBugForDetails}
          onClose={() => {
            setShowDetailsModal(false);
            setSelectedBugForDetails(null);
          }}
          onUpdate={() => {
            loadData();
          }}
        />
      )}

      {/* Delete Confirmation Dialog */}
      {showDeleteConfirm && defectToDelete && (
        <ConfirmDialog
          title="Usuwanie defektu"
          message={`Czy na pewno chcesz usunąć defekt "${defectToDelete.bug_id || defectToDelete.title}"?`}
          confirmText="Usuń"
          cancelText="Anuluj"
          variant="danger"
          onConfirm={confirmDelete}
          onCancel={() => {
            setShowDeleteConfirm(false);
            setDefectToDelete(null);
          }}
        />
      )}
    </div>
  );
}
