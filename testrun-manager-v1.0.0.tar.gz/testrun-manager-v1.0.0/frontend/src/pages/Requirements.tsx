import { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { Plus, Edit, Trash2, FileText, X, FolderOpen, ChevronDown, ChevronRight, Eye, Download } from 'lucide-react';
import ReactQuill, { Quill } from 'react-quill';
import 'react-quill/dist/quill.snow.css';
import ImageResize from 'quill-image-resize-module-react';
import '../styles/quill-custom.css';
import { requirements, requirementGroups, tags as tagsApi } from '../lib/api';
import { useProject } from '../context/ProjectContext';
import TagSelector from '../components/TagSelector';
import { exportRequirementsToCSV, exportSingleRequirementToCSV } from '../utils/csvExport';
import { usePermissions } from '../hooks/usePermissions';

// Register modules
Quill.register('modules/imageResize', ImageResize);

export default function Requirements() {
  const { selectedProject } = useProject();
  const { can } = usePermissions();
  const [searchParams, setSearchParams] = useSearchParams();
  const quillRef = useRef<any>(null);
  const [requirementsList, setRequirementsList] = useState<any[]>([]);
  const [groupsList, setGroupsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showGroupModal, setShowGroupModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [selectedRequirement, setSelectedRequirement] = useState<any>(null);
  const [selectedGroup, setSelectedGroup] = useState<any>(null);
  const [viewRequirement, setViewRequirement] = useState<any>(null);
  const [expandedGroups, setExpandedGroups] = useState<Set<number>>(new Set());
  const [draggedRequirement, setDraggedRequirement] = useState<any>(null);
  const [dragOverGroup, setDragOverGroup] = useState<number | null>(null);
  const [selectedTags, setSelectedTags] = useState<any[]>([]);
  
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    priority: 'medium',
    status: 'draft',
    requirement_group_id: '',
  });

  const [groupFormData, setGroupFormData] = useState({
    name: '',
    description: '',
    parent_id: null as number | null,
  });

  const toggleGroup = (groupId: number) => {
    const newExpanded = new Set(expandedGroups);
    if (newExpanded.has(groupId)) {
      newExpanded.delete(groupId);
    } else {
      newExpanded.add(groupId);
    }
    setExpandedGroups(newExpanded);
  };

  const insertTable = () => {
    if (quillRef.current) {
      try {
        const quill = quillRef.current.getEditor();
        const range = quill.getSelection();
        if (range) {
          // Wstaw prostą HTML tabelkę 3x3
          const tableHTML = `
            <table style="border-collapse: collapse; width: 100%; border: 1px solid #ddd;">
              <tbody>
                <tr>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                </tr>
                <tr>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                </tr>
                <tr>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                  <td style="border: 1px solid #ddd; padding: 8px;"><br></td>
                </tr>
              </tbody>
            </table>
            <p><br></p>
          `;
          quill.clipboard.dangerouslyPasteHTML(range.index, tableHTML);
          toast.success('Tabelka została wstawiona');
        }
      } catch (error) {
        console.error('Error inserting table:', error);
        toast.error('Nie udało się wstawić tabelki');
      }
    }
  };

  useEffect(() => {
    if (selectedProject) {
      loadData();
    }
  }, [selectedProject]);

  // Automatyczne otwarcie modalu gdy jest parametr id w URL
  useEffect(() => {
    const reqId = searchParams.get('id');
    if (reqId && requirementsList.length > 0) {
      const req = requirementsList.find((r: any) => r.id === parseInt(reqId));
      if (req) {
        handleView(req);
        // Usuń parametr z URL po otwarciu
        setSearchParams({});
      }
    }
  }, [searchParams, requirementsList]);

  const loadData = async () => {
    try {
      const [reqResponse, groupsResponse] = await Promise.all([
        requirements.getAll(selectedProject!.id),
        requirementGroups.getAll(selectedProject!.id),
      ]);
      setRequirementsList(reqResponse.data);
      setGroupsList(groupsResponse.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        requirement_group_id: formData.requirement_group_id || null,
        project_id: selectedProject!.id,
      };
      
      let requirementId;
      if (selectedRequirement) {
        await requirements.update(selectedRequirement.id, data);
        requirementId = selectedRequirement.id;
        toast.success('✅ Wymaganie zostało zaktualizowane');
      } else {
        const response = await requirements.create(data);
        requirementId = response.data.id;
        toast.success('✅ Wymaganie zostało utworzone');
      }
      
      // Zapisz tagi
      await tagsApi.assignToRequirement(requirementId, selectedTags.map(t => t.id));
      
      resetForm();
      loadData();
    } catch (error) {
      console.error('Error saving requirement:', error);
      toast.error('❌ Błąd podczas zapisywania wymagania');
    }
  };

  const handleGroupSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (selectedGroup) {
        await requirementGroups.update(selectedGroup.id, groupFormData);
        toast.success('✅ Zestaw wymagań został zaktualizowany');
      } else {
        await requirementGroups.create({ ...groupFormData, project_id: selectedProject!.id });
        toast.success('✅ Zestaw wymagań został utworzony');
      }
      setShowGroupModal(false);
      setSelectedGroup(null);
      setGroupFormData({ name: '', description: '', parent_id: null });
      await loadData();
    } catch (error) {
      console.error('Error saving group:', error);
      toast.error('❌ Błąd podczas zapisywania zestawu');
    }
  };

  const handleEditGroup = (group: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedGroup(group);
    setGroupFormData({
      name: group.name,
      description: group.description || '',
      parent_id: group.parent_id || null,
    });
    setShowGroupModal(true);
  };

  const handleAddSubGroup = (parentGroup: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedGroup(null);
    setGroupFormData({
      name: '',
      description: '',
      parent_id: parentGroup.id,
    });
    setShowGroupModal(true);
  };

  const handleDeleteGroup = async (group: any, e: React.MouseEvent) => {
    e.stopPropagation();
    
    const groupReqs = getRequirementsByGroup(group.id);
    
    if (groupReqs.length > 0) {
      const deleteReqs = window.confirm(
        `Zestaw "${group.name}" zawiera ${groupReqs.length} wymagań.\n\nCzy chcesz usunąć zestaw razem z wymaganiami?\n\nKliknij OK aby usunąć wszystko, lub Anuluj aby zachować wymagania.`
      );
      
      if (deleteReqs === null) return;
      
      try {
        await requirementGroups.delete(group.id, deleteReqs);
        toast.success('✅ Zestaw został usunięty');
        await loadData();
      } catch (error) {
        console.error('Error deleting group:', error);
        toast.error('❌ Błąd podczas usuwania zestawu');
      }
    } else {
      if (window.confirm(`Czy na pewno chcesz usunąć zestaw "${group.name}"?`)) {
        try {
          await requirementGroups.delete(group.id, false);
          toast.success('✅ Zestaw został usunięty');
          await loadData();
        } catch (error) {
          console.error('Error deleting group:', error);
          toast.error('❌ Błąd podczas usuwania zestawu');
        }
      }
    }
  };

  const resetForm = () => {
    setShowModal(false);
    setSelectedRequirement(null);
    setFormData({
      title: '',
      description: '',
      priority: 'medium',
      status: 'draft',
      requirement_group_id: '',
    });
    setSelectedTags([]);
  };

  const handleAddRequirementToGroup = (group: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setFormData({
      title: '',
      description: '',
      priority: 'medium',
      status: 'draft',
      requirement_group_id: group.id,
    });
    setSelectedRequirement(null);
    setShowModal(true);
  };

  const handleEdit = (requirement: any) => {
    setSelectedRequirement(requirement);
    setFormData({
      title: requirement.title,
      description: requirement.description || '',
      priority: requirement.priority,
      status: requirement.status,
      requirement_group_id: requirement.requirement_group_id || '',
    });
    setSelectedTags(requirement.tags || []);
    setShowModal(true);
  };

  const handleView = (requirement: any) => {
    setViewRequirement(requirement);
    setShowViewModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Czy na pewno chcesz usunąć to wymaganie?')) return;
    try {
      await requirements.delete(id);
      toast.success('✅ Wymaganie zostało usunięte');
      loadData();
    } catch (error) {
      console.error('Error deleting requirement:', error);
      toast.error('❌ Błąd podczas usuwania wymagania');
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getRequirementsByGroup = (groupId: number | null) => {
    return requirementsList.filter(req => 
      (groupId === null && !req.requirement_group_id) || 
      (req.requirement_group_id === groupId)
    );
  };

  const getChildGroups = (parentId: number | null) => {
    return groupsList.filter(g => g.parent_id === parentId);
  };

  const getRootGroups = () => {
    return groupsList.filter(g => !g.parent_id);
  };

  const handleDragStart = (e: React.DragEvent, requirement: any) => {
    setDraggedRequirement(requirement);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, groupId: number | null) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverGroup(groupId);
  };

  const handleDragLeave = () => {
    setDragOverGroup(null);
  };

  const handleDrop = async (e: React.DragEvent, targetGroupId: number | null) => {
    e.preventDefault();
    
    if (!draggedRequirement) return;
    
    if (draggedRequirement.requirement_group_id === targetGroupId) {
      setDraggedRequirement(null);
      setDragOverGroup(null);
      return;
    }

    try {
      await requirements.update(draggedRequirement.id, {
        ...draggedRequirement,
        requirement_group_id: targetGroupId
      });

      await loadData();
      setDraggedRequirement(null);
      setDragOverGroup(null);
      toast.success('✅ Wymaganie zostało przeniesione');
    } catch (error) {
      console.error('Error moving requirement:', error);
      toast.error('❌ Błąd podczas przenoszenia wymagania');
    }
  };

  const renderGroup = (group: any, depth: number = 0): JSX.Element => {
    const groupReqs = getRequirementsByGroup(group.id);
    const childGroups = getChildGroups(group.id);
    const isExpanded = expandedGroups.has(group.id);
    const paddingLeft = depth * 24;

    return (
      <div key={group.id}>
        <div 
          className={`flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer border-b ${
            dragOverGroup === group.id ? 'bg-blue-100 border-blue-400' : ''
          }`}
          style={{ paddingLeft: `${16 + paddingLeft}px` }}
          onClick={() => toggleGroup(group.id)}
          onDragOver={(e) => handleDragOver(e, group.id)}
          onDragLeave={handleDragLeave}
          onDrop={(e) => handleDrop(e, group.id)}
        >
          <div className="flex items-center flex-1">
            {isExpanded ? (
              <ChevronDown className="h-5 w-5 text-gray-400 mr-2" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-400 mr-2" />
            )}
            <FolderOpen className="h-5 w-5 text-blue-600 mr-3" />
            <div>
              <div className="text-sm font-medium text-gray-900">{group.name}</div>
              <div className="text-xs text-gray-500">
                {childGroups.length > 0 && `${childGroups.length} podzestawów, `}
                {groupReqs.length} wymagań
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {can('requirements.create') && (
              <button
                onClick={(e) => handleAddRequirementToGroup(group, e)}
                className="p-1 text-purple-600 hover:text-purple-800 hover:bg-purple-50 rounded"
                title="Dodaj wymaganie"
              >
                <FileText className="h-4 w-4" />
              </button>
            )}
            {can('requirements.create') && (
              <button
                onClick={(e) => handleAddSubGroup(group, e)}
                className="p-1 text-green-600 hover:text-green-800 hover:bg-green-50 rounded"
                title="Dodaj podzestaw"
              >
                <Plus className="h-4 w-4" />
              </button>
            )}
            {can('requirements.edit') && (
              <button
                onClick={(e) => handleEditGroup(group, e)}
                className="p-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded"
                title="Edytuj zestaw"
              >
                <Edit className="h-4 w-4" />
              </button>
            )}
            {can('requirements.delete') && (
              <button
                onClick={(e) => handleDeleteGroup(group, e)}
                className="p-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded"
                title="Usuń zestaw"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>

        {isExpanded && (
          <div className="bg-gray-50">
            {groupReqs.length > 0 && (
              <table className="min-w-full">
                <thead className="bg-gray-100">
                  <tr>
                    <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ paddingLeft: '48px', paddingRight: '24px' }}>Tytuł</th>
                    <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '80px', paddingLeft: '24px', paddingRight: '24px' }}>TC</th>
                    <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>Priorytet</th>
                    <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>Status</th>
                    <th className="py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>Akcje</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-gray-200">
                  {groupReqs.map((req) => (
                    <tr 
                      key={req.id} 
                      className="hover:bg-gray-100 cursor-move"
                      draggable
                      onDragStart={(e) => handleDragStart(e, req)}
                    >
                      <td className="py-3" style={{ paddingLeft: '48px', paddingRight: '24px' }}>
                        <div style={{ paddingLeft: `${paddingLeft}px` }}>
                          <div className="flex items-center gap-2 mb-1">
                            {req.requirement_id && (
                              <span className="text-xs font-mono font-semibold text-green-600 bg-green-50 px-2 py-1 rounded">
                                {req.requirement_id}
                              </span>
                            )}
                            <div className="text-sm font-medium text-gray-900">{req.title}</div>
                          </div>
                          {req.tags && req.tags.length > 0 && (
                            <div className="flex flex-wrap gap-1 mt-1">
                              {req.tags.map((tag: any) => (
                                <span
                                  key={tag.id}
                                  className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium text-white"
                                  style={{ backgroundColor: tag.color }}
                                >
                                  {tag.name}
                                </span>
                              ))}
                            </div>
                          )}
                        </div>
                      </td>
                      <td className="py-3 whitespace-nowrap text-sm text-gray-500" style={{ width: '80px', paddingLeft: '24px', paddingRight: '24px' }}>
                        {req.test_case_count || 0}
                      </td>
                      <td className="py-3 whitespace-nowrap" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(req.priority)}`}>
                          {req.priority === 'high' ? 'Wysoki' : req.priority === 'medium' ? 'Średni' : 'Niski'}
                        </span>
                      </td>
                      <td className="py-3 whitespace-nowrap" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>
                        <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(req.status)}`}>
                          {req.status === 'draft' ? 'Szkic' : req.status === 'approved' ? 'Zatwierdzony' : 'Odrzucony'}
                        </span>
                      </td>
                      <td className="py-3 whitespace-nowrap text-right text-sm font-medium space-x-2" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>
                        <button onClick={() => handleView(req)} className="text-gray-600 hover:text-gray-900" title="Podgląd">
                          <Eye className="h-4 w-4 inline" />
                        </button>
                        {can('requirements.export') && (
                          <button 
                            onClick={() => {
                              exportSingleRequirementToCSV(req);
                              toast.success('✅ Wymaganie wyeksportowane do CSV');
                            }} 
                            className="text-green-600 hover:text-green-900" 
                            title="Eksportuj CSV"
                          >
                            <Download className="h-4 w-4 inline" />
                          </button>
                        )}
                        {can('requirements.edit') && (
                          <button onClick={() => handleEdit(req)} className="text-blue-600 hover:text-blue-900" title="Edytuj">
                            <Edit className="h-4 w-4 inline" />
                          </button>
                        )}
                        {can('requirements.delete') && (
                          <button onClick={() => handleDelete(req.id)} className="text-red-600 hover:text-red-900" title="Usuń">
                            <Trash2 className="h-4 w-4 inline" />
                          </button>
                        )}
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            )}
            
            {childGroups.map(childGroup => renderGroup(childGroup, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  if (!selectedProject) {
    return (
      <div className="text-center py-12">
        <FileText className="mx-auto h-12 w-12 text-gray-400" />
        <h3 className="mt-2 text-sm font-medium text-gray-900">Brak wybranego projektu</h3>
        <p className="mt-1 text-sm text-gray-500">Wybierz projekt z dashboardu</p>
      </div>
    );
  }

  const unassignedReqs = getRequirementsByGroup(null);
  const rootGroups = getRootGroups();

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-2xl font-bold text-gray-900">Wymagania</h1>
          <p className="text-gray-600">Projekt: {selectedProject.name}</p>
        </div>
        <div className="space-x-2">
          {can('requirements.export') && (
            <button
              onClick={() => {
                exportRequirementsToCSV(requirementsList, `wymagania_${selectedProject.name}_${new Date().toISOString().split('T')[0]}.csv`);
                toast.success('✅ Wymagania wyeksportowane do CSV');
              }}
              className="bg-gray-600 text-white px-4 py-2 rounded-lg hover:bg-gray-700 inline-flex items-center"
              disabled={requirementsList.length === 0}
            >
              <Download className="h-5 w-5 mr-2" />
              Eksportuj CSV
            </button>
          )}
          {can('requirements.create') && (
            <button
              onClick={() => setShowGroupModal(true)}
              className="bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 inline-flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Nowy zestaw
            </button>
          )}
          {can('requirements.create') && (
            <button
              onClick={() => setShowModal(true)}
              className="bg-blue-600 text-white px-4 py-2 rounded-lg hover:bg-blue-700 inline-flex items-center"
            >
              <Plus className="h-5 w-5 mr-2" />
              Nowe wymaganie
            </button>
          )}
        </div>
      </div>

      {rootGroups.map(group => (
        <div key={group.id} className="bg-white shadow rounded-lg overflow-hidden">
          {renderGroup(group, 0)}
        </div>
      ))}

      {unassignedReqs.length > 0 && (() => {
        const isExpanded = expandedGroups.has(0);
        return (
          <div className="bg-white shadow rounded-lg overflow-hidden">
            <div 
              className={`flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer border-b ${
                dragOverGroup === null ? 'bg-blue-100 border-blue-400' : ''
              }`}
              onClick={() => toggleGroup(0)}
              onDragOver={(e) => handleDragOver(e, null)}
              onDragLeave={handleDragLeave}
              onDrop={(e) => handleDrop(e, null)}
            >
              <div className="flex items-center flex-1">
                {isExpanded ? (
                  <ChevronDown className="h-5 w-5 text-gray-400 mr-2" />
                ) : (
                  <ChevronRight className="h-5 w-5 text-gray-400 mr-2" />
                )}
                <FileText className="h-5 w-5 text-gray-600 mr-3" />
                <div>
                  <div className="text-sm font-medium text-gray-900">Bez zestawu</div>
                  <div className="text-xs text-gray-500">{unassignedReqs.length} wymagań</div>
                </div>
              </div>
            </div>
            
            {isExpanded && (
              <div className="bg-gray-50">
                <table className="min-w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ paddingLeft: '48px', paddingRight: '24px' }}>Tytuł</th>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '80px', paddingLeft: '24px', paddingRight: '24px' }}>TC</th>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>Priorytet</th>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>Status</th>
                      <th className="py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>Akcje</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {unassignedReqs.map((req) => (
                      <tr 
                        key={req.id} 
                        className="hover:bg-gray-100 cursor-move"
                        draggable
                        onDragStart={(e) => handleDragStart(e, req)}
                      >
                        <td className="py-3" style={{ paddingLeft: '48px', paddingRight: '24px' }}>
                          <div>
                            <div className="flex items-center gap-2 mb-1">
                              {req.requirement_id && (
                                <span className="text-xs font-mono font-semibold text-green-600 bg-green-50 px-2 py-1 rounded">
                                  {req.requirement_id}
                                </span>
                              )}
                              <div className="text-sm font-medium text-gray-900">{req.title}</div>
                            </div>
                            {req.tags && req.tags.length > 0 && (
                              <div className="flex flex-wrap gap-1 mt-1">
                                {req.tags.map((tag: any) => (
                                  <span
                                    key={tag.id}
                                    className="inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium text-white"
                                    style={{ backgroundColor: tag.color }}
                                  >
                                    {tag.name}
                                  </span>
                                ))}
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="py-3 whitespace-nowrap text-sm text-gray-500" style={{ width: '80px', paddingLeft: '24px', paddingRight: '24px' }}>
                          {req.test_case_count || 0}
                        </td>
                        <td className="py-3 whitespace-nowrap" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(req.priority)}`}>
                            {req.priority === 'high' ? 'Wysoki' : req.priority === 'medium' ? 'Średni' : 'Niski'}
                          </span>
                        </td>
                        <td className="py-3 whitespace-nowrap" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(req.status)}`}>
                            {req.status === 'draft' ? 'Szkic' : req.status === 'approved' ? 'Zatwierdzony' : 'Odrzucony'}
                          </span>
                        </td>
                        <td className="py-3 whitespace-nowrap text-right text-sm font-medium space-x-2" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>
                          <button onClick={() => handleView(req)} className="text-gray-600 hover:text-gray-900" title="Podgląd">
                            <Eye className="h-4 w-4 inline" />
                          </button>
                          <button 
                            onClick={() => {
                              exportSingleRequirementToCSV(req);
                              toast.success('✅ Wymaganie wyeksportowane do CSV');
                            }} 
                            className="text-green-600 hover:text-green-900" 
                            title="Eksportuj CSV"
                          >
                            <Download className="h-4 w-4 inline" />
                          </button>
                          <button onClick={() => handleEdit(req)} className="text-blue-600 hover:text-blue-900" title="Edytuj">
                            <Edit className="h-4 w-4 inline" />
                          </button>
                          <button onClick={() => handleDelete(req.id)} className="text-red-600 hover:text-red-900" title="Usuń">
                            <Trash2 className="h-4 w-4 inline" />
                          </button>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
          </div>
        );
      })()}

      {/* Modal wymagania */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">
                  {selectedRequirement ? 'Edytuj wymaganie' : 'Nowe wymaganie'}
                </h2>
                <button onClick={resetForm} className="text-gray-500 hover:text-gray-700">
                  <X className="h-6 w-6" />
                </button>
              </div>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tytuł *
                  </label>
                  <input
                    type="text"
                    required
                    value={formData.title}
                    onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Opis
                  </label>
                  <div className="mb-2">
                    <button
                      type="button"
                      onClick={insertTable}
                      className="inline-flex items-center px-3 py-1 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                    >
                      <FileText className="h-4 w-4 mr-1" />
                      Wstaw tabelkę (3x3)
                    </button>
                  </div>
                  <ReactQuill
                    ref={quillRef}
                    value={formData.description}
                    onChange={(value) => setFormData({ ...formData, description: value })}
                    modules={{
                      toolbar: [
                        [{ 'header': [1, 2, 3, false] }],
                        ['bold', 'italic', 'underline', 'strike'],
                        [{ 'list': 'ordered'}, { 'list': 'bullet' }],
                        [{ 'color': [] }, { 'background': [] }],
                        ['link', 'image'],
                        ['clean']
                      ],
                      imageResize: {
                        parchment: Quill.import('parchment'),
                        modules: ['Resize', 'DisplaySize']
                      }
                    }}
                    theme="snow"
                    className="bg-white"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Zestaw wymagań
                  </label>
                  <select
                    value={formData.requirement_group_id}
                    onChange={(e) => setFormData({ ...formData, requirement_group_id: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  >
                    <option value="">Bez zestawu</option>
                    {groupsList.map(group => (
                      <option key={group.id} value={group.id}>{group.name}</option>
                    ))}
                  </select>
                </div>
                {selectedProject && (
                  <TagSelector
                    projectId={selectedProject.id}
                    selectedTags={selectedTags}
                    onChange={setSelectedTags}
                  />
                )}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Priorytet
                    </label>
                    <select
                      value={formData.priority}
                      onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    >
                      <option value="low">Niski</option>
                      <option value="medium">Średni</option>
                      <option value="high">Wysoki</option>
                    </select>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <select
                      value={formData.status}
                      onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                      className="w-full border border-gray-300 rounded-lg px-3 py-2"
                    >
                      <option value="draft">Szkic</option>
                      <option value="approved">Zatwierdzony</option>
                      <option value="rejected">Odrzucony</option>
                    </select>
                  </div>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <button
                    type="button"
                    onClick={resetForm}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Anuluj
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                  >
                    {selectedRequirement ? 'Zapisz' : 'Utwórz'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal zestawu */}
      {showGroupModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">
                  {selectedGroup ? 'Edytuj zestaw' : 'Nowy zestaw wymagań'}
                </h2>
                <button
                  onClick={() => {
                    setShowGroupModal(false);
                    setSelectedGroup(null);
                    setGroupFormData({ name: '', description: '', parent_id: null });
                  }}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-6 w-6" />
                </button>
              </div>
              <form onSubmit={handleGroupSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nazwa zestawu *
                  </label>
                  <input
                    type="text"
                    required
                    value={groupFormData.name}
                    onChange={(e) => setGroupFormData({ ...groupFormData, name: e.target.value })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Opis
                  </label>
                  <textarea
                    value={groupFormData.description}
                    onChange={(e) => setGroupFormData({ ...groupFormData, description: e.target.value })}
                    rows={3}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Nadrzędny zestaw
                  </label>
                  <select
                    value={groupFormData.parent_id || ''}
                    onChange={(e) => setGroupFormData({ ...groupFormData, parent_id: e.target.value ? parseInt(e.target.value) : null })}
                    className="w-full border border-gray-300 rounded-lg px-3 py-2"
                  >
                    <option value="">Brak (zestaw główny)</option>
                    {groupsList
                      .filter(g => !selectedGroup || g.id !== selectedGroup.id)
                      .map(group => (
                        <option key={group.id} value={group.id}>{group.name}</option>
                      ))}
                  </select>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <button
                    type="button"
                    onClick={() => {
                      setShowGroupModal(false);
                      setSelectedGroup(null);
                      setGroupFormData({ name: '', description: '', parent_id: null });
                    }}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Anuluj
                  </button>
                  <button
                    type="submit"
                    className="px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700"
                  >
                    {selectedGroup ? 'Zapisz' : 'Utwórz'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal podglądu wymagania */}
      {showViewModal && viewRequirement && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-center mb-4">
                <h2 className="text-xl font-bold">Podgląd wymagania</h2>
                <button onClick={() => setShowViewModal(false)} className="text-gray-500 hover:text-gray-700">
                  <X className="h-6 w-6" />
                </button>
              </div>
              <div className="space-y-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    ID Wymagania
                  </label>
                  <div className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
                    {viewRequirement.requirement_id || 'Brak ID'}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tytuł
                  </label>
                  <div className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
                    {viewRequirement.title}
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Opis
                  </label>
                  <div 
                    className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg min-h-[100px] prose prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: viewRequirement.description || '<p class="text-gray-500">Brak opisu</p>' }}
                  />
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Zestaw wymagań
                  </label>
                  <div className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
                    {viewRequirement.group_name || 'Bez zestawu'}
                  </div>
                </div>
                {viewRequirement.tags && viewRequirement.tags.length > 0 && (
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Tagi
                    </label>
                    <div className="bg-gray-50 px-3 py-2 rounded-lg">
                      <div className="flex flex-wrap gap-2">
                        {viewRequirement.tags.map((tag: any) => (
                          <span
                            key={tag.id}
                            className="inline-flex items-center px-3 py-1 rounded-full text-sm font-medium text-white"
                            style={{ backgroundColor: tag.color }}
                          >
                            {tag.name}
                          </span>
                        ))}
                      </div>
                    </div>
                  </div>
                )}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Priorytet
                    </label>
                    <div className="text-sm bg-gray-50 px-3 py-2 rounded-lg">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(viewRequirement.priority)}`}>
                        {viewRequirement.priority === 'high' ? 'Wysoki' : viewRequirement.priority === 'medium' ? 'Średni' : 'Niski'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <div className="text-sm bg-gray-50 px-3 py-2 rounded-lg">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(viewRequirement.status)}`}>
                        {viewRequirement.status === 'draft' ? 'Szkic' : viewRequirement.status === 'approved' ? 'Zatwierdzony' : 'Odrzucony'}
                      </span>
                    </div>
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Liczba przypadków testowych
                  </label>
                  <div className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg">
                    {viewRequirement.test_case_count || 0}
                  </div>
                </div>
                <div className="flex justify-end space-x-2 pt-4">
                  <button
                    onClick={() => setShowViewModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Zamknij
                  </button>
                  {can('requirements.edit') && (
                    <button
                      onClick={() => {
                        setShowViewModal(false);
                        handleEdit(viewRequirement);
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      Edytuj
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
