import { useState, useEffect } from 'react';
import { Plus, Edit, Trash2, Save, X, Settings } from 'lucide-react';
import { statuses } from '../lib/api';

export default function StatusDictionaries() {
  const [activeTab, setActiveTab] = useState<'test' | 'bug'>('test');
  const [testStatuses, setTestStatuses] = useState<any[]>([]);
  const [bugStatuses, setBugStatuses] = useState<any[]>([]);
  const [showModal, setShowModal] = useState(false);
  const [editingStatus, setEditingStatus] = useState<any>(null);
  const [formData, setFormData] = useState({
    name: '',
    key: '',
    color: '#3b82f6',
    description: '',
    display_order: 999
  });

  useEffect(() => {
    loadStatuses();
  }, []);

  const loadStatuses = async () => {
    try {
      const [testRes, bugRes] = await Promise.all([
        statuses.getTestExecutionStatuses(),
        statuses.getBugStatuses()
      ]);
      setTestStatuses(testRes.data);
      setBugStatuses(bugRes.data);
    } catch (error) {
      console.error('Error loading statuses:', error);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      if (editingStatus) {
        // Update
        const updateData = {
          ...formData,
          is_active: editingStatus.is_active
        };
        
        if (activeTab === 'test') {
          await statuses.updateTestExecutionStatus(editingStatus.id, updateData);
        } else {
          await statuses.updateBugStatus(editingStatus.id, updateData);
        }
      } else {
        // Create
        if (activeTab === 'test') {
          await statuses.createTestExecutionStatus(formData);
        } else {
          await statuses.createBugStatus(formData);
        }
      }
      
      setShowModal(false);
      setEditingStatus(null);
      setFormData({
        name: '',
        key: '',
        color: '#3b82f6',
        description: '',
        display_order: 999
      });
      loadStatuses();
    } catch (error) {
      console.error('Error saving status:', error);
      alert('Błąd podczas zapisywania statusu');
    }
  };

  const handleEdit = (status: any) => {
    setEditingStatus(status);
    setFormData({
      name: status.name,
      key: status.key,
      color: status.color,
      description: status.description || '',
      display_order: status.display_order
    });
    setShowModal(true);
  };

  const handleDelete = async (status: any) => {
    if (status.is_system) {
      alert('Nie można usunąć statusu systemowego');
      return;
    }

    if (!confirm(`Czy na pewno chcesz usunąć status "${status.name}"?`)) return;

    try {
      if (activeTab === 'test') {
        await statuses.deleteTestExecutionStatus(status.id);
      } else {
        await statuses.deleteBugStatus(status.id);
      }
      loadStatuses();
    } catch (error) {
      console.error('Error deleting status:', error);
      alert('Błąd podczas usuwania statusu');
    }
  };

  const handleToggleActive = async (status: any) => {
    try {
      const updateData = {
        ...status,
        is_active: status.is_active ? 0 : 1
      };

      if (activeTab === 'test') {
        await statuses.updateTestExecutionStatus(status.id, updateData);
      } else {
        await statuses.updateBugStatus(status.id, updateData);
      }
      loadStatuses();
    } catch (error) {
      console.error('Error toggling status:', error);
      alert('Błąd podczas zmiany statusu');
    }
  };

  const currentStatuses = activeTab === 'test' ? testStatuses : bugStatuses;

  return (
    <div className="p-6">
      <div className="mb-6">
        <h1 className="text-2xl font-bold text-gray-900 flex items-center gap-2">
          <Settings className="h-7 w-7" />
          Słowniki Statusów
        </h1>
        <p className="text-gray-600 mt-1">
          Zarządzaj statusami wykonania testów i błędów
        </p>
      </div>

      {/* Tabs */}
      <div className="mb-6 border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('test')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'test'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Statusy Wykonania Testów
          </button>
          <button
            onClick={() => setActiveTab('bug')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'bug'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            Statusy Błędów
          </button>
        </nav>
      </div>

      {/* Add Button */}
      <div className="mb-4">
        <button
          onClick={() => {
            setEditingStatus(null);
            setFormData({
              name: '',
              key: '',
              color: '#3b82f6',
              description: '',
              display_order: 999
            });
            setShowModal(true);
          }}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
        >
          <Plus className="h-4 w-4 mr-2" />
          Dodaj Status
        </button>
      </div>

      {/* Statuses Table */}
      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Kolejność
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Nazwa
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Klucz
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Kolor
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Opis
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Typ
              </th>
              <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                Status
              </th>
              <th className="px-6 py-3 text-right text-xs font-medium text-gray-500 uppercase tracking-wider">
                Akcje
              </th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {currentStatuses.map((status) => (
              <tr key={status.id}>
                <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                  {status.display_order}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-3 h-3 rounded-full"
                      style={{ backgroundColor: status.color }}
                    />
                    <span className="text-sm font-medium text-gray-900">{status.name}</span>
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <code className="text-xs bg-gray-100 px-2 py-1 rounded">{status.key}</code>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <div className="flex items-center gap-2">
                    <div
                      className="w-8 h-8 rounded border"
                      style={{ backgroundColor: status.color }}
                    />
                    <span className="text-xs text-gray-500">{status.color}</span>
                  </div>
                </td>
                <td className="px-6 py-4">
                  <div className="text-sm text-gray-500 max-w-xs truncate">
                    {status.description || '-'}
                  </div>
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  {status.is_system ? (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-purple-100 text-purple-800">
                      Systemowy
                    </span>
                  ) : (
                    <span className="px-2 inline-flex text-xs leading-5 font-semibold rounded-full bg-gray-100 text-gray-800">
                      Niestandardowy
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 whitespace-nowrap">
                  <button
                    onClick={() => handleToggleActive(status)}
                    className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${
                      status.is_active
                        ? 'bg-green-100 text-green-800'
                        : 'bg-red-100 text-red-800'
                    }`}
                  >
                    {status.is_active ? 'Aktywny' : 'Nieaktywny'}
                  </button>
                </td>
                <td className="px-6 py-4 whitespace-nowrap text-right text-sm font-medium space-x-2">
                  <button
                    onClick={() => handleEdit(status)}
                    className="text-blue-600 hover:text-blue-900"
                    title="Edytuj"
                  >
                    <Edit className="h-4 w-4 inline" />
                  </button>
                  {!status.is_system && (
                    <button
                      onClick={() => handleDelete(status)}
                      className="text-red-600 hover:text-red-900"
                      title="Usuń"
                    >
                      <Trash2 className="h-4 w-4 inline" />
                    </button>
                  )}
                </td>
              </tr>
            ))}
          </tbody>
        </table>

        {currentStatuses.length === 0 && (
          <div className="text-center py-12">
            <p className="text-gray-500">Brak statusów</p>
          </div>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-md w-full">
            <div className="flex justify-between items-center p-6 border-b">
              <h2 className="text-xl font-bold">
                {editingStatus ? 'Edytuj Status' : 'Nowy Status'}
              </h2>
              <button onClick={() => setShowModal(false)} className="text-gray-500 hover:text-gray-700">
                <X className="h-6 w-6" />
              </button>
            </div>

            <form onSubmit={handleSubmit} className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Nazwa *
                </label>
                <input
                  type="text"
                  required
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="np. W trakcie przeglądu"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Klucz *
                </label>
                <input
                  type="text"
                  required
                  value={formData.key}
                  onChange={(e) => setFormData({ ...formData, key: e.target.value.toLowerCase().replace(/\s+/g, '_') })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="np. in_review"
                />
                <p className="text-xs text-gray-500 mt-1">Unikalny identyfikator (bez spacji, małe litery)</p>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kolor *
                </label>
                <div className="flex gap-2">
                  <input
                    type="color"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="w-16 h-10 border border-gray-300 rounded cursor-pointer"
                  />
                  <input
                    type="text"
                    value={formData.color}
                    onChange={(e) => setFormData({ ...formData, color: e.target.value })}
                    className="flex-1 px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                    placeholder="#3b82f6"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Opis
                </label>
                <textarea
                  value={formData.description}
                  onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                  rows={2}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  placeholder="Opcjonalny opis statusu"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Kolejność wyświetlania
                </label>
                <input
                  type="number"
                  value={formData.display_order}
                  onChange={(e) => setFormData({ ...formData, display_order: parseInt(e.target.value) })}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              <div className="flex gap-2 pt-4">
                <button
                  type="submit"
                  className="flex-1 inline-flex justify-center items-center px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700"
                >
                  <Save className="h-4 w-4 mr-2" />
                  {editingStatus ? 'Zapisz' : 'Utwórz'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="px-4 py-2 border border-gray-300 rounded-md text-gray-700 hover:bg-gray-50"
                >
                  Anuluj
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
