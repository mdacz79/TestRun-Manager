import { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { toast } from 'react-toastify';
import { BarChart3, PieChart, FileText, Download, TrendingUp, CheckCircle, XCircle, Clock, AlertCircle, Link as LinkIcon, ExternalLink } from 'lucide-react';
import { PieChart as RechartsPieChart, Pie, Cell, ResponsiveContainer, Legend, Tooltip, LineChart, Line, XAxis, YAxis, CartesianGrid } from 'recharts';
import { useProject } from '../context/ProjectContext';
import { testPlans, bugs as bugsApi, requirements as requirementsApi, testSpecifications as testSpecsApi } from '../lib/api';
import { usePermissions } from '../hooks/usePermissions';

// Kolory dla wykresów
const PRIORITY_COLORS: { [key: string]: string } = {
  'Krytyczny': '#dc2626',
  'Critical': '#dc2626',
  'krytyczny': '#dc2626',
  'critical': '#dc2626',
  'Wysoki': '#ef4444',
  'High': '#ef4444',
  'wysoki': '#ef4444',
  'high': '#ef4444',
  'Średni': '#f59e0b',
  'Medium': '#f59e0b',
  'średni': '#f59e0b',
  'medium': '#f59e0b',
  'Niski': '#10b981',
  'Low': '#10b981',
  'niski': '#10b981',
  'low': '#10b981'
};

// Tłumaczenia statusów
const translateStatus = (status: string): string => {
  const translations: { [key: string]: string } = {
    'new': 'Nowy',
    'in_progress': 'W trakcie',
    'resolved': 'Rozwiązany',
    'closed': 'Zamknięty',
    'rejected': 'Odrzucony',
    'reopened': 'Ponownie otwarty',
    'New': 'Nowy',
    'In Progress': 'W trakcie',
    'Resolved': 'Rozwiązany',
    'Closed': 'Zamknięty',
    'Rejected': 'Odrzucony',
    'Reopened': 'Ponownie otwarty'
  };
  return translations[status] || status;
};

export default function Reports() {
  const { selectedProject } = useProject();
  const { can } = usePermissions();
  const [loading, setLoading] = useState(true);
  const [activeTab, setActiveTab] = useState<'test-execution' | 'defects' | 'coverage'>('test-execution');
  
  // Dane raportów
  const [testExecutionStats, setTestExecutionStats] = useState<any>(null);
  const [defectStats, setDefectStats] = useState<any>(null);
  const [plans, setPlans] = useState<any[]>([]);
  const [selectedPlan, setSelectedPlan] = useState<any>(null);
  const [burndownData, setBurndownData] = useState<any>(null);
  
  // Dane macierzy pokrycia
  const [requirements, setRequirements] = useState<any[]>([]);
  const [testSpecs, setTestSpecs] = useState<any[]>([]);
  const [coverageMatrix, setCoverageMatrix] = useState<any>(null);

  useEffect(() => {
    if (selectedProject) {
      loadReportData();
    }
  }, [selectedProject]);

  const loadReportData = async () => {
    try {
      setLoading(true);
      
      // Pobierz plany testów
      const plansRes = await testPlans.getAll(selectedProject!.id);
      setPlans(plansRes.data);
      
      // Pobierz błędy
      const bugsRes = await bugsApi.getAll(selectedProject!.id);
      
      // Oblicz statystyki błędów
      const bugs = bugsRes.data;
      
      // Filtruj defekty otwarte (nie zamknięte)
      const openBugs = bugs.filter((bug: any) => 
        bug.status !== 'Zamknięty' && 
        bug.status !== 'Closed' && 
        bug.status !== 'Rozwiązany' &&
        bug.status !== 'Resolved'
      );
      
      const closedBugs = bugs.filter((bug: any) => 
        bug.status === 'Zamknięty' || 
        bug.status === 'Closed' || 
        bug.status === 'Rozwiązany' ||
        bug.status === 'Resolved'
      );
      
      // Oblicz KPI
      // 1. MTTR (Mean Time To Repair) - średni czas naprawy w dniach
      const mttr = closedBugs.length > 0 
        ? closedBugs.reduce((sum: number, bug: any) => {
            const created = new Date(bug.created_at);
            const updated = new Date(bug.updated_at);
            const days = Math.floor((updated.getTime() - created.getTime()) / (1000 * 60 * 60 * 24));
            return sum + days;
          }, 0) / closedBugs.length
        : 0;
      
      // 2. Defect Density - defekty na 1000 linii kodu (zakładamy 10000 LOC dla projektu)
      const estimatedLOC = 10000;
      const defectDensity = (bugs.length / estimatedLOC) * 1000;
      
      // 3. DRE (Defect Removal Efficiency) - zakładamy że 95% defektów wykryto przed produkcją
      const defectsInProduction = bugs.filter((b: any) => b.environment === 'Production' || b.environment === 'Produkcja').length;
      const dre = bugs.length > 0 ? ((bugs.length - defectsInProduction) / bugs.length) * 100 : 100;
      
      // 4. Reopen Rate - wskaźnik ponownego otwarcia
      const reopenedBugs = bugs.filter((b: any) => b.reopen_count && b.reopen_count > 0).length;
      const reopenRate = closedBugs.length > 0 ? (reopenedBugs / closedBugs.length) * 100 : 0;
      
      // 5. Defect Leakage - defekty wykryte w produkcji
      const defectLeakage = bugs.length > 0 ? (defectsInProduction / bugs.length) * 100 : 0;
      
      // 6. Trend defektów (ostatnie 7 dni)
      const last7Days = Array.from({ length: 7 }, (_, i) => {
        const date = new Date();
        date.setDate(date.getDate() - (6 - i));
        return date.toISOString().split('T')[0];
      });
      
      const defectTrend = last7Days.map(date => {
        const count = bugs.filter((b: any) => b.created_at?.startsWith(date)).length;
        return { date, count };
      });
      
      const defectStats = {
        total: bugs.length,
        openTotal: openBugs.length,
        closedTotal: closedBugs.length,
        byStatus: bugs.reduce((acc: any, bug: any) => {
          acc[bug.status] = (acc[bug.status] || 0) + 1;
          return acc;
        }, {}),
        bySeverity: bugs.reduce((acc: any, bug: any) => {
          acc[bug.severity] = (acc[bug.severity] || 0) + 1;
          return acc;
        }, {}),
        byPriority: bugs.reduce((acc: any, bug: any) => {
          acc[bug.priority] = (acc[bug.priority] || 0) + 1;
          return acc;
        }, {}),
        openByPriority: openBugs.reduce((acc: any, bug: any) => {
          acc[bug.priority] = (acc[bug.priority] || 0) + 1;
          return acc;
        }, {}),
        kpi: {
          mttr: mttr.toFixed(1),
          defectDensity: defectDensity.toFixed(2),
          dre: dre.toFixed(1),
          reopenRate: reopenRate.toFixed(1),
          defectLeakage: defectLeakage.toFixed(1),
          criticalOpen: openBugs.filter((b: any) => b.priority === 'Krytyczny' || b.priority === 'Critical' || b.priority === 'Wysoki' || b.priority === 'High').length
        },
        trend: defectTrend
      };
      
      setDefectStats(defectStats);
      
      // Pobierz wymagania i specyfikacje testowe dla macierzy pokrycia
      const [requirementsRes, testSpecsRes] = await Promise.all([
        requirementsApi.getAll(selectedProject!.id),
        testSpecsApi.getAll(selectedProject!.id)
      ]);
      
      setRequirements(requirementsRes.data);
      setTestSpecs(testSpecsRes.data);
      
      // Buduj macierz pokrycia
      buildCoverageMatrix(requirementsRes.data, testSpecsRes.data);
      
    } catch (error) {
      console.error('Error loading report data:', error);
      toast.error('❌ Błąd podczas ładowania danych raportu');
    } finally {
      setLoading(false);
    }
  };

  const buildCoverageMatrix = (reqs: any[], specs: any[]) => {
    // Mapa: requirement_id -> lista test_case_id
    const matrix: any = {};
    
    console.log('Building coverage matrix with specs:', specs);
    
    specs.forEach((spec: any) => {
      if (spec.requirements && Array.isArray(spec.requirements)) {
        spec.requirements.forEach((req: any) => {
          // requirements to tablica obiektów {id, requirement_id, title}
          const reqId = req.id;
          if (!matrix[reqId]) {
            matrix[reqId] = [];
          }
          matrix[reqId].push({
            test_case_id: spec.test_case_id,
            title: spec.title,
            id: spec.id
          });
        });
      }
    });
    
    console.log('Coverage matrix built:', matrix);
    
    // Statystyki
    const totalRequirements = reqs.length;
    const coveredRequirements = Object.keys(matrix).length;
    const coveragePercentage = totalRequirements > 0 
      ? ((coveredRequirements / totalRequirements) * 100).toFixed(1)
      : '0';
    
    const totalTests = specs.length;
    const linkedTests = specs.filter((s: any) => s.requirements && s.requirements.length > 0).length;
    
    setCoverageMatrix({
      matrix,
      stats: {
        totalRequirements,
        coveredRequirements,
        uncoveredRequirements: totalRequirements - coveredRequirements,
        coveragePercentage,
        totalTests,
        linkedTests,
        unlinkedTests: totalTests - linkedTests
      }
    });
  };

  const loadPlanStats = async (planId: number) => {
    try {
      const planRes = await testPlans.getById(planId);
      const plan = planRes.data;
      setSelectedPlan(plan);
      
      // Oblicz statystyki wykonania testów
      const cases = plan.cases || [];
      const stats = {
        total: cases.length,
        passed: cases.filter((c: any) => c.status === 'PASSED').length,
        failed: cases.filter((c: any) => c.status === 'FAILED').length,
        blocked: cases.filter((c: any) => c.status === 'BLOCKED').length,
        skipped: cases.filter((c: any) => c.status === 'SKIPPED').length,
        inProgress: cases.filter((c: any) => c.status === 'IN_PROGRESS').length,
        notRun: cases.filter((c: any) => c.status === 'NOT_RUN').length,
      };
      
      const executed = stats.total - stats.notRun;
      const passRate = executed > 0 ? ((stats.passed / executed) * 100).toFixed(1) : '0';
      
      setTestExecutionStats({ ...stats, executed, passRate });
      
      // Pobierz dane burndown
      if (plan.start_date && plan.end_date) {
        const burndownRes = await testPlans.getBurndown(planId);
        setBurndownData(burndownRes.data);
      } else {
        setBurndownData(null);
      }
    } catch (error) {
      console.error('Error loading plan stats:', error);
      toast.error('❌ Błąd podczas ładowania statystyk planu');
    }
  };

  const exportToCSV = (data: any[], filename: string) => {
    if (data.length === 0) {
      toast.warning('⚠️ Brak danych do eksportu');
      return;
    }
    
    const headers = Object.keys(data[0]);
    const csvContent = [
      headers.join(','),
      ...data.map(row => headers.map(header => `"${row[header] || ''}"`).join(','))
    ].join('\n');
    
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement('a');
    link.href = URL.createObjectURL(blob);
    link.download = `${filename}_${new Date().toISOString().split('T')[0]}.csv`;
    link.click();
    
    toast.success('✅ Raport wyeksportowany');
  };

  const exportTestExecutionReport = () => {
    if (!selectedPlan) {
      toast.warning('⚠️ Wybierz plan testów');
      return;
    }
    
    const data = selectedPlan.cases.map((c: any) => ({
      'ID przypadku': c.test_case_id,
      'Tytuł': c.title,
      'Status': c.status,
      'Przypisany do': c.assigned_to_name || 'Nie przypisano',
      'Liczba wykonań': c.execution_count
    }));
    
    exportToCSV(data, `raport_wykonania_${selectedPlan.name.replace(/\s/g, '_')}`);
  };

  const exportDefectsReport = () => {
    if (!defectStats) return;
    
    const data = Object.entries(defectStats.byStatus).map(([status, count]) => ({
      'Status': status,
      'Liczba': count
    }));
    
    exportToCSV(data, 'raport_defektow');
  };

  const exportCoverageReport = () => {
    if (!coverageMatrix) return;
    
    const data = requirements.map((req: any) => {
      const tests = coverageMatrix.matrix[req.id] || [];
      return {
        'ID wymagania': req.requirement_id,
        'Tytuł wymagania': req.title,
        'Liczba testów': tests.length,
        'Testy': tests.map((t: any) => t.test_case_id).join(', ') || 'Brak pokrycia'
      };
    });
    
    exportToCSV(data, 'macierz_pokrycia');
  };

  if (loading) {
    return <div className="p-6">Ładowanie...</div>;
  }

  return (
    <div className="p-6 space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-2xl font-bold text-gray-900">Raporty</h1>
      </div>

      {/* Zakładki */}
      <div className="border-b border-gray-200">
        <nav className="-mb-px flex space-x-8">
          <button
            onClick={() => setActiveTab('test-execution')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'test-execution'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <BarChart3 className="h-5 w-5 inline mr-2" />
            Wykonanie testów
          </button>
          <button
            onClick={() => setActiveTab('defects')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'defects'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <PieChart className="h-5 w-5 inline mr-2" />
            Defekty
          </button>
          <button
            onClick={() => setActiveTab('coverage')}
            className={`py-4 px-1 border-b-2 font-medium text-sm ${
              activeTab === 'coverage'
                ? 'border-blue-500 text-blue-600'
                : 'border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-300'
            }`}
          >
            <TrendingUp className="h-5 w-5 inline mr-2" />
            Pokrycie testami
          </button>
        </nav>
      </div>

      {/* Raport wykonania testów */}
      {activeTab === 'test-execution' && (
        <div className="space-y-6">
          <div className="bg-white shadow rounded-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Wybierz plan testów</h2>
              {selectedPlan && (
                <button
                  onClick={exportTestExecutionReport}
                  className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
                >
                  <Download className="h-4 w-4 mr-2" />
                  Eksportuj CSV
                </button>
              )}
            </div>
            
            <select
              value={selectedPlan?.id || ''}
              onChange={(e) => e.target.value && loadPlanStats(Number(e.target.value))}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
            >
              <option value="">-- Wybierz plan testów --</option>
              {plans.map((plan) => (
                <option key={plan.id} value={plan.id}>
                  {plan.name} ({plan.test_count} przypadków) - {plan.is_active === 1 ? '✓ Aktywny' : '✗ Nieaktywny'}
                </option>
              ))}
            </select>
          </div>

          {testExecutionStats && selectedPlan && (
            <>
              {/* Statystyki ogólne */}
              <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-blue-100 rounded-md p-3">
                      <FileText className="h-6 w-6 text-blue-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Wszystkie testy</p>
                      <p className="text-2xl font-semibold text-gray-900">{testExecutionStats.total}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-green-100 rounded-md p-3">
                      <CheckCircle className="h-6 w-6 text-green-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Zaliczone</p>
                      <p className="text-2xl font-semibold text-gray-900">{testExecutionStats.passed}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-red-100 rounded-md p-3">
                      <XCircle className="h-6 w-6 text-red-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Niezaliczone</p>
                      <p className="text-2xl font-semibold text-gray-900">{testExecutionStats.failed}</p>
                    </div>
                  </div>
                </div>

                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex items-center">
                    <div className="flex-shrink-0 bg-purple-100 rounded-md p-3">
                      <TrendingUp className="h-6 w-6 text-purple-600" />
                    </div>
                    <div className="ml-4">
                      <p className="text-sm font-medium text-gray-500">Wskaźnik zaliczenia</p>
                      <p className="text-2xl font-semibold text-gray-900">{testExecutionStats.passRate}%</p>
                    </div>
                  </div>
                </div>
              </div>

              {/* Wykres kołowy - rozkład według statusów */}
              <div className="bg-white shadow rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Rozkład testów według statusów</h3>
                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  {/* Wykres kołowy */}
                  <div className="flex items-center justify-center">
                    <ResponsiveContainer width="100%" height={350}>
                      <RechartsPieChart>
                        <Pie
                          data={[
                            { name: 'Zaliczone', value: testExecutionStats.passed, color: '#10b981' },
                            { name: 'Niezaliczone', value: testExecutionStats.failed, color: '#ef4444' },
                            { name: 'W trakcie', value: testExecutionStats.inProgress, color: '#3b82f6' },
                            { name: 'Zablokowane', value: testExecutionStats.blocked, color: '#f59e0b' },
                            { name: 'Pominięte', value: testExecutionStats.skipped, color: '#6b7280' },
                            { name: 'Nie wykonano', value: testExecutionStats.notRun, color: '#9ca3af' }
                          ].filter(item => item.value > 0)}
                          cx="50%"
                          cy="50%"
                          labelLine={false}
                          label={({ name, percent }) => `${name}: ${((percent || 0) * 100).toFixed(0)}%`}
                          outerRadius={120}
                          dataKey="value"
                        >
                          {[
                            { name: 'Zaliczone', value: testExecutionStats.passed, color: '#10b981' },
                            { name: 'Niezaliczone', value: testExecutionStats.failed, color: '#ef4444' },
                            { name: 'W trakcie', value: testExecutionStats.inProgress, color: '#3b82f6' },
                            { name: 'Zablokowane', value: testExecutionStats.blocked, color: '#f59e0b' },
                            { name: 'Pominięte', value: testExecutionStats.skipped, color: '#6b7280' },
                            { name: 'Nie wykonano', value: testExecutionStats.notRun, color: '#9ca3af' }
                          ].filter(item => item.value > 0).map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip />
                        <Legend />
                      </RechartsPieChart>
                    </ResponsiveContainer>
                  </div>

                  {/* Statystyki tekstowe */}
                  <div className="flex flex-col justify-center space-y-3">
                    <div className="flex items-center justify-between p-3 bg-green-50 rounded border border-green-200">
                      <div className="flex items-center">
                        <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                        <span className="font-medium text-gray-900">Zaliczone</span>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-green-600">{testExecutionStats.passed}</span>
                        <span className="text-sm ml-2 text-gray-600">
                          ({testExecutionStats.total > 0 ? ((testExecutionStats.passed / testExecutionStats.total) * 100).toFixed(1) : 0}%)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-red-50 rounded border border-red-200">
                      <div className="flex items-center">
                        <XCircle className="h-5 w-5 text-red-600 mr-3" />
                        <span className="font-medium text-gray-900">Niezaliczone</span>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-red-600">{testExecutionStats.failed}</span>
                        <span className="text-sm ml-2 text-gray-600">
                          ({testExecutionStats.total > 0 ? ((testExecutionStats.failed / testExecutionStats.total) * 100).toFixed(1) : 0}%)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-blue-50 rounded border border-blue-200">
                      <div className="flex items-center">
                        <Clock className="h-5 w-5 text-blue-600 mr-3" />
                        <span className="font-medium text-gray-900">W trakcie</span>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-blue-600">{testExecutionStats.inProgress}</span>
                        <span className="text-sm ml-2 text-gray-600">
                          ({testExecutionStats.total > 0 ? ((testExecutionStats.inProgress / testExecutionStats.total) * 100).toFixed(1) : 0}%)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-orange-50 rounded border border-orange-200">
                      <div className="flex items-center">
                        <AlertCircle className="h-5 w-5 text-orange-600 mr-3" />
                        <span className="font-medium text-gray-900">Zablokowane</span>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-orange-600">{testExecutionStats.blocked}</span>
                        <span className="text-sm ml-2 text-gray-600">
                          ({testExecutionStats.total > 0 ? ((testExecutionStats.blocked / testExecutionStats.total) * 100).toFixed(1) : 0}%)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-50 rounded border border-gray-200">
                      <div className="flex items-center">
                        <span className="h-5 w-5 text-gray-600 mr-3">⊘</span>
                        <span className="font-medium text-gray-900">Pominięte</span>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-gray-600">{testExecutionStats.skipped}</span>
                        <span className="text-sm ml-2 text-gray-600">
                          ({testExecutionStats.total > 0 ? ((testExecutionStats.skipped / testExecutionStats.total) * 100).toFixed(1) : 0}%)
                        </span>
                      </div>
                    </div>

                    <div className="flex items-center justify-between p-3 bg-gray-100 rounded border border-gray-300">
                      <div className="flex items-center">
                        <span className="h-5 w-5 text-gray-400 mr-3">○</span>
                        <span className="font-medium text-gray-900">Nie wykonano</span>
                      </div>
                      <div className="text-right">
                        <span className="text-lg font-bold text-gray-400">{testExecutionStats.notRun}</span>
                        <span className="text-sm ml-2 text-gray-600">
                          ({testExecutionStats.total > 0 ? ((testExecutionStats.notRun / testExecutionStats.total) * 100).toFixed(1) : 0}%)
                        </span>
                      </div>
                    </div>
                  </div>
                </div>
              </div>

              {/* Szczegółowe statystyki */}
              <div className="bg-white shadow rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Szczegółowy podział statusów</h3>
                <div className="space-y-3">
                  <div className="flex items-center justify-between p-3 bg-green-50 rounded">
                    <div className="flex items-center">
                      <CheckCircle className="h-5 w-5 text-green-600 mr-3" />
                      <span className="font-medium text-gray-900">Zaliczone (PASSED)</span>
                    </div>
                    <span className="text-lg font-semibold text-green-600">{testExecutionStats.passed}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-red-50 rounded">
                    <div className="flex items-center">
                      <XCircle className="h-5 w-5 text-red-600 mr-3" />
                      <span className="font-medium text-gray-900">Niezaliczone (FAILED)</span>
                    </div>
                    <span className="text-lg font-semibold text-red-600">{testExecutionStats.failed}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-blue-50 rounded">
                    <div className="flex items-center">
                      <Clock className="h-5 w-5 text-blue-600 mr-3" />
                      <span className="font-medium text-gray-900">W trakcie (IN_PROGRESS)</span>
                    </div>
                    <span className="text-lg font-semibold text-blue-600">{testExecutionStats.inProgress}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-orange-50 rounded">
                    <div className="flex items-center">
                      <AlertCircle className="h-5 w-5 text-orange-600 mr-3" />
                      <span className="font-medium text-gray-900">Zablokowane (BLOCKED)</span>
                    </div>
                    <span className="text-lg font-semibold text-orange-600">{testExecutionStats.blocked}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-50 rounded">
                    <div className="flex items-center">
                      <span className="h-5 w-5 text-gray-600 mr-3">⊘</span>
                      <span className="font-medium text-gray-900">Pominięte (SKIPPED)</span>
                    </div>
                    <span className="text-lg font-semibold text-gray-600">{testExecutionStats.skipped}</span>
                  </div>
                  
                  <div className="flex items-center justify-between p-3 bg-gray-100 rounded">
                    <div className="flex items-center">
                      <span className="h-5 w-5 text-gray-400 mr-3">○</span>
                      <span className="font-medium text-gray-900">Nie wykonano (NOT_RUN)</span>
                    </div>
                    <span className="text-lg font-semibold text-gray-400">{testExecutionStats.notRun}</span>
                  </div>
                </div>
              </div>

              {/* Wykres Burndown */}
              {burndownData && burndownData.burndown && burndownData.burndown.length > 0 && (
                <div className="bg-white shadow rounded-lg p-6">
                  <div className="flex justify-between items-start mb-4">
                    <div>
                      <h3 className="text-lg font-semibold">Postęp testów: idealny vs rzeczywisty (Passed/Failed/Uruchomione)</h3>
                      <p className="text-sm text-gray-600 mt-1">
                        Porównanie postępu wykonania testów. Linia niebieska to cel (idealny plan), 
                        pomarańczowa to wszystkie uruchomione testy, zielona to zaliczone (Passed), czerwona to niezaliczone (Failed).
                      </p>
                    </div>
                    
                    {/* Dodatkowe informacje - kompaktowe kafelki */}
                    <div className="flex gap-3">
                      {burndownData.plan.test_completion_date && (
                        <div className="bg-purple-50 rounded-lg px-4 py-2 border border-purple-200">
                          <p className="text-xs font-medium text-gray-600">Data realizacji TC</p>
                          <p className="text-base font-semibold text-purple-600">
                            {new Date(burndownData.plan.test_completion_date).toLocaleDateString('pl-PL')}
                          </p>
                          <p className="text-xs text-gray-500">{burndownData.plan.working_days || 0} dni roboczych</p>
                        </div>
                      )}
                      {burndownData.plan.daily_tests_target > 0 && (
                        <div className="bg-indigo-50 rounded-lg px-4 py-2 border border-indigo-200">
                          <p className="text-xs font-medium text-gray-600">Tempo dzienne</p>
                          <p className="text-base font-semibold text-indigo-600">
                            {burndownData.plan.daily_tests_target} testów/dzień
                          </p>
                          <p className="text-xs text-gray-500">Wymagane tempo</p>
                        </div>
                      )}
                    </div>
                  </div>
                  <ResponsiveContainer width="100%" height={400}>
                    <LineChart data={burndownData.burndown}>
                      <CartesianGrid strokeDasharray="3 3" />
                      <XAxis 
                        dataKey="date" 
                        tick={{ fontSize: 11 }}
                        angle={-45}
                        textAnchor="end"
                        height={80}
                        tickFormatter={(value) => new Date(value).toLocaleDateString('pl-PL', { day: '2-digit', month: '2-digit' })}
                      />
                      <YAxis 
                        label={{ value: 'Liczba testów', angle: -90, position: 'insideLeft' }}
                      />
                      <Tooltip 
                        labelFormatter={(value) => new Date(value).toLocaleDateString('pl-PL')}
                        formatter={(value: any, name: string | number | undefined) => {
                          const nameStr = String(name || '');
                          if (nameStr === 'target') return [value, 'Cel (idealny)'];
                          if (nameStr === 'executed') return [value, 'Uruchomione'];
                          if (nameStr === 'passed') return [value, 'Passed'];
                          if (nameStr === 'failed') return [value, 'Failed'];
                          return [value, nameStr];
                        }}
                      />
                      <Legend 
                        formatter={(value) => {
                          if (value === 'target') return 'Cel (idealny)';
                          if (value === 'executed') return 'Uruchomione (wszystkie)';
                          if (value === 'passed') return 'Passed';
                          if (value === 'failed') return 'Failed';
                          return value;
                        }}
                      />
                      {/* Cel - niebieski */}
                      <Line 
                        type="monotone" 
                        dataKey="target" 
                        stroke="#3b82f6" 
                        strokeWidth={2}
                        dot={{ fill: '#3b82f6', r: 3 }}
                        name="target"
                      />
                      {/* Uruchomione - pomarańczowy */}
                      <Line 
                        type="monotone" 
                        dataKey="executed" 
                        stroke="#f97316" 
                        strokeWidth={2}
                        dot={{ fill: '#f97316', r: 3 }}
                        name="executed"
                        connectNulls={false}
                      />
                      {/* Passed - zielony */}
                      <Line 
                        type="monotone" 
                        dataKey="passed" 
                        stroke="#22c55e" 
                        strokeWidth={2}
                        dot={{ fill: '#22c55e', r: 3 }}
                        name="passed"
                        connectNulls={false}
                      />
                      {/* Failed - czerwony */}
                      <Line 
                        type="monotone" 
                        dataKey="failed" 
                        stroke="#ef4444" 
                        strokeWidth={2}
                        dot={{ fill: '#ef4444', r: 3 }}
                        name="failed"
                        connectNulls={false}
                      />
                    </LineChart>
                  </ResponsiveContainer>
                  
                  {/* Analiza postępu */}
                  <div className="mt-4 grid grid-cols-1 md:grid-cols-4 gap-4">
                    <div className="bg-blue-50 rounded-lg p-4 border border-blue-200">
                      <p className="text-sm font-medium text-gray-600">Cel (plan)</p>
                      <p className="text-lg font-semibold text-blue-600">
                        {burndownData.plan.total_tests} testów
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {new Date(burndownData.plan.start_date).toLocaleDateString('pl-PL')} - {new Date(burndownData.plan.end_date).toLocaleDateString('pl-PL')}
                      </p>
                    </div>
                    <div className="bg-orange-50 rounded-lg p-4 border border-orange-200">
                      <p className="text-sm font-medium text-gray-600">Uruchomione</p>
                      <p className="text-lg font-semibold text-orange-600">
                        {(() => {
                          const lastExecuted = burndownData.burndown.filter((d: any) => d.executed !== undefined).pop();
                          return lastExecuted?.executed || 0;
                        })()} testów
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {burndownData.plan.total_tests > 0 
                          ? `${((((() => {
                              const lastExecuted = burndownData.burndown.filter((d: any) => d.executed !== undefined).pop();
                              return lastExecuted?.executed || 0;
                            })()) / burndownData.plan.total_tests) * 100).toFixed(1)}%`
                          : '0%'}
                      </p>
                    </div>
                    <div className="bg-green-50 rounded-lg p-4 border border-green-200">
                      <p className="text-sm font-medium text-gray-600">Passed</p>
                      <p className="text-lg font-semibold text-green-600">
                        {(() => {
                          const lastPassed = burndownData.burndown.filter((d: any) => d.passed !== undefined).pop();
                          return lastPassed?.passed || 0;
                        })()} testów
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {burndownData.plan.total_tests > 0 
                          ? `${((((() => {
                              const lastPassed = burndownData.burndown.filter((d: any) => d.passed !== undefined).pop();
                              return lastPassed?.passed || 0;
                            })()) / burndownData.plan.total_tests) * 100).toFixed(1)}%`
                          : '0%'}
                      </p>
                    </div>
                    <div className="bg-red-50 rounded-lg p-4 border border-red-200">
                      <p className="text-sm font-medium text-gray-600">Failed</p>
                      <p className="text-lg font-semibold text-red-600">
                        {(() => {
                          const lastFailed = burndownData.burndown.filter((d: any) => d.failed !== undefined).pop();
                          return lastFailed?.failed || 0;
                        })()} testów
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {burndownData.plan.total_tests > 0 
                          ? `${((((() => {
                              const lastFailed = burndownData.burndown.filter((d: any) => d.failed !== undefined).pop();
                              return lastFailed?.failed || 0;
                            })()) / burndownData.plan.total_tests) * 100).toFixed(1)}%`
                          : '0%'}
                      </p>
                    </div>
                  </div>
                </div>
              )}

              {/* Informacje o planie */}
              <div className="bg-white shadow rounded-lg p-6">
                <h3 className="text-lg font-semibold mb-4">Informacje o planie</h3>
                <dl className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Nazwa planu</dt>
                    <dd className="mt-1 text-sm text-gray-900">{selectedPlan.name}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Opis</dt>
                    <dd className="mt-1 text-sm text-gray-900">{selectedPlan.description || 'Brak opisu'}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Data rozpoczęcia</dt>
                    <dd className="mt-1 text-sm text-gray-900">{selectedPlan.start_date || 'Nie określono'}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Data zakończenia</dt>
                    <dd className="mt-1 text-sm text-gray-900">{selectedPlan.end_date || 'Nie określono'}</dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Status</dt>
                    <dd className="mt-1 text-sm text-gray-900">
                      {selectedPlan.is_active === 1 ? (
                        <span className="px-2 py-1 bg-green-100 text-green-800 rounded text-xs">Aktywny</span>
                      ) : (
                        <span className="px-2 py-1 bg-gray-100 text-gray-800 rounded text-xs">Nieaktywny</span>
                      )}
                    </dd>
                  </div>
                  <div>
                    <dt className="text-sm font-medium text-gray-500">Utworzony przez</dt>
                    <dd className="mt-1 text-sm text-gray-900">{selectedPlan.created_by_name}</dd>
                  </div>
                </dl>
              </div>
            </>
          )}
        </div>
      )}

      {/* Raport defektów */}
      {activeTab === 'defects' && defectStats && (
        <div className="space-y-6">
          {/* KPI - Kluczowe Wskaźniki */}
          <div className="bg-gradient-to-r from-blue-50 to-indigo-50 rounded-lg p-6 border border-blue-200">
            <h2 className="text-xl font-bold text-gray-900 mb-4">📊 Kluczowe Wskaźniki KPI</h2>
            
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {/* Średni czas naprawy */}
              <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Średni czas naprawy</span>
                  <Clock className="h-5 w-5 text-blue-500" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{defectStats.kpi.mttr}</div>
                <div className="text-xs text-gray-500 mt-1">dni</div>
                <div className="mt-2">
                  <div className={`text-xs font-medium ${parseFloat(defectStats.kpi.mttr) <= 2 ? 'text-green-600' : 'text-red-600'}`}>
                    Cel: ≤ 2 dni {parseFloat(defectStats.kpi.mttr) <= 2 ? '✓' : '✗'}
                  </div>
                </div>
              </div>

              {/* Gęstość defektów */}
              <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Gęstość defektów</span>
                  <BarChart3 className="h-5 w-5 text-purple-500" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{defectStats.kpi.defectDensity}</div>
                <div className="text-xs text-gray-500 mt-1">defektów / 1000 linii kodu</div>
                <div className="mt-2">
                  <div className={`text-xs font-medium ${parseFloat(defectStats.kpi.defectDensity) <= 10 ? 'text-green-600' : 'text-orange-600'}`}>
                    Cel: ≤ 10 {parseFloat(defectStats.kpi.defectDensity) <= 10 ? '✓' : '⚠'}
                  </div>
                </div>
              </div>

              {/* Efektywność usuwania */}
              <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Efektywność usuwania</span>
                  <CheckCircle className="h-5 w-5 text-green-500" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{defectStats.kpi.dre}%</div>
                <div className="text-xs text-gray-500 mt-1">przed produkcją</div>
                <div className="mt-2">
                  <div className={`text-xs font-medium ${parseFloat(defectStats.kpi.dre) >= 95 ? 'text-green-600' : 'text-red-600'}`}>
                    Cel: ≥ 95% {parseFloat(defectStats.kpi.dre) >= 95 ? '✓' : '✗'}
                  </div>
                </div>
              </div>

              {/* Wskaźnik ponownego otwarcia */}
              <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Ponowne otwarcia</span>
                  <AlertCircle className="h-5 w-5 text-orange-500" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{defectStats.kpi.reopenRate}%</div>
                <div className="text-xs text-gray-500 mt-1">defektów</div>
                <div className="mt-2">
                  <div className={`text-xs font-medium ${parseFloat(defectStats.kpi.reopenRate) <= 10 ? 'text-green-600' : 'text-red-600'}`}>
                    Cel: ≤ 10% {parseFloat(defectStats.kpi.reopenRate) <= 10 ? '✓' : '✗'}
                  </div>
                </div>
              </div>

              {/* Wyciek do produkcji */}
              <div className="bg-white rounded-lg p-4 shadow-sm border border-gray-200">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Wyciek do produkcji</span>
                  <XCircle className="h-5 w-5 text-red-500" />
                </div>
                <div className="text-3xl font-bold text-gray-900">{defectStats.kpi.defectLeakage}%</div>
                <div className="text-xs text-gray-500 mt-1">defektów</div>
                <div className="mt-2">
                  <div className={`text-xs font-medium ${parseFloat(defectStats.kpi.defectLeakage) <= 5 ? 'text-green-600' : 'text-red-600'}`}>
                    Cel: ≤ 5% {parseFloat(defectStats.kpi.defectLeakage) <= 5 ? '✓' : '✗'}
                  </div>
                </div>
              </div>

              {/* Critical Open */}
              <div className={`bg-white rounded-lg p-4 shadow-sm border ${defectStats.kpi.criticalOpen === 0 ? 'border-green-200' : 'border-red-200'}`}>
                <div className="flex items-center justify-between mb-2">
                  <span className="text-sm font-medium text-gray-600">Krytyczne Otwarte</span>
                  {defectStats.kpi.criticalOpen === 0 ? (
                    <CheckCircle className="h-5 w-5 text-green-600" />
                  ) : (
                    <AlertCircle className="h-5 w-5 text-red-600" />
                  )}
                </div>
                <div className={`text-3xl font-bold ${defectStats.kpi.criticalOpen === 0 ? 'text-green-600' : 'text-red-600'}`}>
                  {defectStats.kpi.criticalOpen}
                </div>
                <div className="text-xs text-gray-500 mt-1">wysokiego priorytetu</div>
                <div className="mt-2">
                  <div className={`text-xs font-medium ${defectStats.kpi.criticalOpen === 0 ? 'text-green-600' : 'text-red-600'}`}>
                    {defectStats.kpi.criticalOpen === 0 ? '✓ Brak krytycznych' : '! Wymaga uwagi'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Trend defektów - wykres liniowy */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Trend defektów (ostatnie 7 dni)</h3>
            <ResponsiveContainer width="100%" height={250}>
              <LineChart data={defectStats.trend}>
                <CartesianGrid strokeDasharray="3 3" />
                <XAxis 
                  dataKey="date" 
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => new Date(value).toLocaleDateString('pl-PL', { day: '2-digit', month: '2-digit' })}
                />
                <YAxis />
                <Tooltip 
                  labelFormatter={(value) => new Date(value).toLocaleDateString('pl-PL')}
                  formatter={(value: any) => [value, 'Defekty']}
                />
                <Line 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#3b82f6" 
                  strokeWidth={2}
                  dot={{ fill: '#3b82f6', r: 4 }}
                  activeDot={{ r: 6 }}
                />
              </LineChart>
            </ResponsiveContainer>
          </div>

          <div className="bg-white shadow rounded-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Statystyki defektów</h2>
              <button
                onClick={exportDefectsReport}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Download className="h-4 w-4 mr-2" />
                Eksportuj CSV
              </button>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              {/* Statystyki ogólne */}
              <div className="bg-blue-50 rounded-lg p-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-2">Wszystkie defekty</p>
                  <p className="text-4xl font-bold text-blue-600">{defectStats.total}</p>
                </div>
              </div>

              {/* Podział według statusu */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Według statusu</h3>
                <div className="space-y-2">
                  {Object.entries(defectStats.byStatus).map(([status, count]: [string, any]) => (
                    <div key={status} className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">{translateStatus(status)}</span>
                      <span className="text-sm font-semibold text-gray-900">{count}</span>
                    </div>
                  ))}
                </div>
              </div>

              {/* Podział według priorytetu */}
              <div className="bg-white border border-gray-200 rounded-lg p-6">
                <h3 className="text-sm font-semibold text-gray-700 mb-3">Według priorytetu</h3>
                <div className="space-y-2">
                  {Object.entries(defectStats.byPriority).map(([priority, count]: [string, any]) => (
                    <div key={priority} className="flex justify-between items-center">
                      <span className="text-sm text-gray-600">{priority}</span>
                      <span className="text-sm font-semibold text-gray-900">{count}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>

          {/* Podział według severity */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Według ważności (Severity)</h3>
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              {Object.entries(defectStats.bySeverity).map(([severity, count]: [string, any]) => (
                <div key={severity} className="bg-gray-50 rounded-lg p-4 text-center">
                  <p className="text-sm font-medium text-gray-500 mb-1">{severity}</p>
                  <p className="text-2xl font-bold text-gray-900">{count}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Wykres kołowy - Defekty otwarte według priorytetu */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Defekty otwarte według priorytetu</h3>
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Wykres */}
              <div className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={300}>
                  <RechartsPieChart>
                    <Pie
                      data={Object.entries(defectStats.openByPriority).map(([priority, count]) => {
                        console.log('Priority:', priority, 'Color:', PRIORITY_COLORS[priority]);
                        return {
                          name: priority,
                          value: count
                        };
                      })}
                      cx="50%"
                      cy="50%"
                      labelLine={false}
                      label={({ name, percent }) => `${name}: ${((percent || 0) * 100).toFixed(0)}%`}
                      outerRadius={100}
                      dataKey="value"
                    >
                      {Object.entries(defectStats.openByPriority).map(([priority], index) => {
                        const color = PRIORITY_COLORS[priority] || '#6b7280';
                        console.log(`Cell ${index}: ${priority} -> ${color}`);
                        return (
                          <Cell 
                            key={`cell-${index}`} 
                            fill={color}
                          />
                        );
                      })}
                    </Pie>
                    <Tooltip />
                    <Legend />
                  </RechartsPieChart>
                </ResponsiveContainer>
              </div>

              {/* Statystyki tekstowe */}
              <div className="flex flex-col justify-center space-y-3">
                <div className="bg-gray-50 rounded-lg p-4">
                  <p className="text-sm font-medium text-gray-500 mb-2">Wszystkie defekty otwarte</p>
                  <p className="text-3xl font-bold text-blue-600">{defectStats.openTotal}</p>
                </div>
                
                <div className="space-y-2">
                  {Object.entries(defectStats.openByPriority)
                    .sort(([, a]: [string, any], [, b]: [string, any]) => b - a)
                    .map(([priority, count]: [string, any]) => {
                      const COLORS: { [key: string]: string } = {
                        'Wysoki': 'bg-red-100 text-red-800 border-red-200',
                        'High': 'bg-red-100 text-red-800 border-red-200',
                        'Średni': 'bg-amber-100 text-amber-800 border-amber-200',
                        'Medium': 'bg-amber-100 text-amber-800 border-amber-200',
                        'Niski': 'bg-green-100 text-green-800 border-green-200',
                        'Low': 'bg-green-100 text-green-800 border-green-200',
                        'Krytyczny': 'bg-red-200 text-red-900 border-red-300',
                        'Critical': 'bg-red-200 text-red-900 border-red-300'
                      };
                      const percentage = defectStats.openTotal > 0 
                        ? ((count / defectStats.openTotal) * 100).toFixed(1)
                        : '0';
                      
                      return (
                        <div 
                          key={priority} 
                          className={`flex justify-between items-center p-3 rounded-lg border ${COLORS[priority] || 'bg-gray-100 text-gray-800 border-gray-200'}`}
                        >
                          <span className="font-medium">{priority}</span>
                          <div className="text-right">
                            <span className="text-lg font-bold">{count}</span>
                            <span className="text-sm ml-2">({percentage}%)</span>
                          </div>
                        </div>
                      );
                    })}
                </div>
              </div>
            </div>
          </div>

          {/* Tabela KPI - Szczegółowe dane */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Tabela KPI - Szczegółowe dane</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Wskaźnik
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Wartość bieżąca
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Cel
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Opis
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Średni czas naprawy
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {defectStats.kpi.mttr} dni
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ≤ 2 dni
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {parseFloat(defectStats.kpi.mttr) <= 2 ? (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          ✓ Osiągnięty
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          ✗ Nieosiągnięty
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      Średni czas naprawy defektu
                    </td>
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Gęstość defektów
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {defectStats.kpi.defectDensity} / 1000 linii
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ≤ 10 / 1000 linii
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {parseFloat(defectStats.kpi.defectDensity) <= 10 ? (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          ✓ Osiągnięty
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-orange-100 text-orange-800">
                          ⚠ Do poprawy
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      Gęstość defektów na 1000 linii kodu
                    </td>
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Efektywność usuwania
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {defectStats.kpi.dre}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ≥ 95%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {parseFloat(defectStats.kpi.dre) >= 95 ? (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          ✓ Osiągnięty
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          ✗ Nieosiągnięty
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      Efektywność usuwania defektów przed produkcją
                    </td>
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Ponowne otwarcia
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {defectStats.kpi.reopenRate}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ≤ 10%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {parseFloat(defectStats.kpi.reopenRate) <= 10 ? (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          ✓ Osiągnięty
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          ✗ Nieosiągnięty
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      Wskaźnik ponownego otwarcia defektów
                    </td>
                  </tr>
                  
                  <tr>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Wyciek do produkcji
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {defectStats.kpi.defectLeakage}%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      ≤ 5%
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {parseFloat(defectStats.kpi.defectLeakage) <= 5 ? (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          ✓ Osiągnięty
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          ✗ Nieosiągnięty
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      Defekty wykryte w produkcji
                    </td>
                  </tr>
                  
                  <tr className={defectStats.kpi.criticalOpen === 0 ? 'bg-green-50' : 'bg-red-50'}>
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      Krytyczne Otwarte
                    </td>
                    <td className={`px-6 py-4 whitespace-nowrap text-sm font-bold ${defectStats.kpi.criticalOpen === 0 ? 'text-green-600' : 'text-red-600'}`}>
                      {defectStats.kpi.criticalOpen}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      0
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      {defectStats.kpi.criticalOpen === 0 ? (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-green-100 text-green-800">
                          ✓ Brak
                        </span>
                      ) : (
                        <span className="px-2 py-1 text-xs font-semibold rounded-full bg-red-100 text-red-800">
                          ! Wymaga uwagi
                        </span>
                      )}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-500">
                      Defekty wysokiego/krytycznego priorytetu
                    </td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Raport pokrycia testami */}
      {activeTab === 'coverage' && coverageMatrix && (
        <div className="space-y-6">
          {/* Nagłówek z przyciskiem eksportu */}
          <div className="bg-white shadow rounded-lg p-6">
            <div className="flex justify-between items-center mb-4">
              <h2 className="text-lg font-semibold">Macierz pokrycia testami</h2>
              <button
                onClick={exportCoverageReport}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
              >
                <Download className="h-4 w-4 mr-2" />
                Eksportuj CSV
              </button>
            </div>
            
            {/* Statystyki ogólne */}
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="bg-blue-50 rounded-lg p-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-2">Wszystkie wymagania</p>
                  <p className="text-4xl font-bold text-blue-600">{coverageMatrix.stats.totalRequirements}</p>
                </div>
              </div>
              
              <div className="bg-green-50 rounded-lg p-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-2">Pokryte testami</p>
                  <p className="text-4xl font-bold text-green-600">{coverageMatrix.stats.coveredRequirements}</p>
                </div>
              </div>
              
              <div className="bg-red-50 rounded-lg p-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-2">Bez pokrycia</p>
                  <p className="text-4xl font-bold text-red-600">{coverageMatrix.stats.uncoveredRequirements}</p>
                </div>
              </div>
              
              <div className="bg-purple-50 rounded-lg p-6">
                <div className="text-center">
                  <p className="text-sm font-medium text-gray-500 mb-2">Pokrycie</p>
                  <p className="text-4xl font-bold text-purple-600">{coverageMatrix.stats.coveragePercentage}%</p>
                </div>
              </div>
            </div>
          </div>

          {/* Statystyki testów */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Statystyki testów</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-gray-50 rounded-lg p-4">
                <p className="text-sm font-medium text-gray-500 mb-1">Wszystkie testy</p>
                <p className="text-2xl font-bold text-gray-900">{coverageMatrix.stats.totalTests}</p>
              </div>
              <div className="bg-green-50 rounded-lg p-4">
                <p className="text-sm font-medium text-gray-500 mb-1">Powiązane z wymaganiami</p>
                <p className="text-2xl font-bold text-green-600">{coverageMatrix.stats.linkedTests}</p>
              </div>
              <div className="bg-orange-50 rounded-lg p-4">
                <p className="text-sm font-medium text-gray-500 mb-1">Bez powiązań</p>
                <p className="text-2xl font-bold text-orange-600">{coverageMatrix.stats.unlinkedTests}</p>
              </div>
            </div>
          </div>

          {/* Macierz pokrycia */}
          <div className="bg-white shadow rounded-lg p-6">
            <h3 className="text-lg font-semibold mb-4">Szczegółowa macierz pokrycia</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      ID Wymagania
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Tytuł wymagania
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Liczba testów
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Przypadki testowe
                    </th>
                    <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                      Status
                    </th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {requirements.map((req: any) => {
                    const tests = coverageMatrix.matrix[req.id] || [];
                    const hasCoverage = tests.length > 0;
                    
                    return (
                      <tr key={req.id} className={hasCoverage ? '' : 'bg-red-50'}>
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium">
                          {can('requirements.view') ? (
                            <Link 
                              to={`/requirements?id=${req.id}`}
                              className="text-blue-600 hover:text-blue-800 hover:underline inline-flex items-center gap-1"
                              title="Otwórz wymaganie"
                            >
                              {req.requirement_id}
                              <ExternalLink className="h-3 w-3" />
                            </Link>
                          ) : (
                            <span className="text-gray-900">{req.requirement_id}</span>
                          )}
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {req.title}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${
                            hasCoverage 
                              ? 'bg-green-100 text-green-800' 
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {tests.length}
                          </span>
                        </td>
                        <td className="px-6 py-4 text-sm text-gray-900">
                          {hasCoverage ? (
                            <div className="flex flex-wrap gap-1">
                              {tests.map((test: any) => (
                                can('test_specs.view') ? (
                                  <Link
                                    key={test.id}
                                    to={`/test-specifications?id=${test.id}`}
                                    className="inline-flex items-center px-2 py-1 rounded text-xs bg-blue-100 text-blue-800 hover:bg-blue-200 transition-colors cursor-pointer"
                                    title={`${test.title} - Kliknij aby otworzyć`}
                                  >
                                    <LinkIcon className="h-3 w-3 mr-1" />
                                    {test.test_case_id}
                                  </Link>
                                ) : (
                                  <span
                                    key={test.id}
                                    className="inline-flex items-center px-2 py-1 rounded text-xs bg-gray-100 text-gray-800"
                                    title={test.title}
                                  >
                                    <LinkIcon className="h-3 w-3 mr-1" />
                                    {test.test_case_id}
                                  </span>
                                )
                              ))}
                            </div>
                          ) : (
                            <span className="text-gray-400 italic">Brak pokrycia</span>
                          )}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm">
                          {hasCoverage ? (
                            <span className="inline-flex items-center text-green-600">
                              <CheckCircle className="h-4 w-4 mr-1" />
                              Pokryte
                            </span>
                          ) : (
                            <span className="inline-flex items-center text-red-600">
                              <XCircle className="h-4 w-4 mr-1" />
                              Brak pokrycia
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Wymagania bez pokrycia */}
          {coverageMatrix.stats.uncoveredRequirements > 0 && (
            <div className="bg-red-50 border border-red-200 rounded-lg p-6">
              <div className="flex items-start">
                <AlertCircle className="h-6 w-6 text-red-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-lg font-semibold text-red-900 mb-2">
                    Uwaga: {coverageMatrix.stats.uncoveredRequirements} wymagań bez pokrycia testami
                  </h3>
                  <p className="text-sm text-red-700">
                    Następujące wymagania nie mają przypisanych przypadków testowych:
                  </p>
                  <ul className="mt-2 space-y-1">
                    {requirements
                      .filter((req: any) => !coverageMatrix.matrix[req.id] || coverageMatrix.matrix[req.id].length === 0)
                      .map((req: any) => (
                        <li key={req.id} className="text-sm text-red-800">
                          • {can('requirements.view') ? (
                            <Link 
                              to={`/requirements?id=${req.id}`}
                              className="font-medium hover:underline inline-flex items-center gap-1"
                              title="Kliknij aby otworzyć wymaganie"
                            >
                              {req.requirement_id}
                              <ExternalLink className="h-3 w-3" />
                            </Link>
                          ) : (
                            <span className="font-medium">{req.requirement_id}</span>
                          )}: {req.title}
                        </li>
                      ))
                    }
                  </ul>
                </div>
              </div>
            </div>
          )}

          {/* Testy bez powiązań */}
          {coverageMatrix.stats.unlinkedTests > 0 && (
            <div className="bg-orange-50 border border-orange-200 rounded-lg p-6">
              <div className="flex items-start">
                <AlertCircle className="h-6 w-6 text-orange-600 mt-0.5 mr-3" />
                <div>
                  <h3 className="text-lg font-semibold text-orange-900 mb-2">
                    Informacja: {coverageMatrix.stats.unlinkedTests} testów bez powiązań z wymaganiami
                  </h3>
                  <p className="text-sm text-orange-700">
                    Następujące przypadki testowe nie są powiązane z żadnym wymaganiem:
                  </p>
                  <ul className="mt-2 space-y-1">
                    {testSpecs
                      .filter((spec: any) => !spec.requirements || spec.requirements.length === 0)
                      .slice(0, 10)
                      .map((spec: any) => (
                        <li key={spec.id} className="text-sm text-orange-800">
                          • {can('test_specs.view') ? (
                            <Link 
                              to={`/test-specifications?id=${spec.id}`}
                              className="font-medium hover:underline inline-flex items-center gap-1"
                              title="Kliknij aby otworzyć test"
                            >
                              {spec.test_case_id}
                              <ExternalLink className="h-3 w-3" />
                            </Link>
                          ) : (
                            <span className="font-medium">{spec.test_case_id}</span>
                          )}: {spec.title}
                        </li>
                      ))
                    }
                    {testSpecs.filter((spec: any) => !spec.requirements || spec.requirements.length === 0).length > 10 && (
                      <li className="text-sm text-orange-800 italic">
                        ... i {testSpecs.filter((spec: any) => !spec.requirements || spec.requirements.length === 0).length - 10} więcej
                      </li>
                    )}
                  </ul>
                </div>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}
