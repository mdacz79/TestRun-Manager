import { useState, useEffect, useRef } from 'react';
import { useSearchParams } from 'react-router-dom';
import { toast } from 'react-toastify';
import { usePermissions } from '../hooks/usePermissions';
import { Plus, Edit, Trash2, ClipboardList, X, FolderOpen, ChevronDown, ChevronRight, FileText, Eye, Download, Upload } from 'lucide-react';
import { testSpecifications, requirements, testSuites, tags as tagsApi } from '../lib/api';
import { useProject } from '../context/ProjectContext';
import { exportTestSpecificationsToCSV, exportSingleTestSpecificationToCSV } from '../utils/csvExport';
import { parseTestCasesCSV, readCSVFile } from '../utils/csvImport';
import TagSelector from '../components/TagSelector';
import WysiwygEditor from '../components/WysiwygEditor';
import { getUser } from '../lib/auth';

export default function TestSpecifications() {
  const { selectedProject } = useProject();
  const { can } = usePermissions();
  const [searchParams, setSearchParams] = useSearchParams();
  const [specificationsList, setSpecificationsList] = useState<any[]>([]);
  const [requirementsList, setRequirementsList] = useState<any[]>([]);
  const [suitesList, setSuitesList] = useState<any[]>([]);
  const [tagsList, setTagsList] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [showSuiteModal, setShowSuiteModal] = useState(false);
  const [showViewModal, setShowViewModal] = useState(false);
  const [showFilterModal, setShowFilterModal] = useState(false);
  const [showMetadata, setShowMetadata] = useState(false);
  const [selectedSpec, setSelectedSpec] = useState<any>(null);
  const [viewSpec, setViewSpec] = useState<any>(null);
  const [steps, setSteps] = useState<Array<{action: string, expected_result: string}>>([]);
  const [editingStepIndex, setEditingStepIndex] = useState<number | null>(null);
  const [currentStep, setCurrentStep] = useState<{action: string, expected_result: string}>({ action: '', expected_result: '' });
  const [selectedRequirements, setSelectedRequirements] = useState<number[]>([]);
  const [selectedTags, setSelectedTags] = useState<any[]>([]);
  const [formData, setFormData] = useState({
    title: '',
    description: '',
    preconditions: '',
    priority: 'medium',
    status: 'draft',
    test_suite_id: '',
  });
  const [suiteFormData, setSuiteFormData] = useState({
    name: '',
    description: '',
    parent_id: null as number | null,
  });
  const [selectedSuite, setSelectedSuite] = useState<any>(null);
  const [expandedSuites, setExpandedSuites] = useState<Set<number>>(new Set());
  const [draggedSpec, setDraggedSpec] = useState<any>(null);
  const [dragOverSuite, setDragOverSuite] = useState<number | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  
  // Filtry - aktywne
  const [filterText, setFilterText] = useState('');
  const [filterTags, setFilterTags] = useState<number[]>([]);
  const [filterRequirement, setFilterRequirement] = useState('');
  
  // Filtry - tymczasowe (w modalu)
  const [tempFilterText, setTempFilterText] = useState('');
  const [tempFilterTags, setTempFilterTags] = useState<number[]>([]);
  const [tempFilterRequirement, setTempFilterRequirement] = useState('');

  const toggleSuite = (suiteId: number) => {
    const newExpanded = new Set(expandedSuites);
    if (newExpanded.has(suiteId)) {
      newExpanded.delete(suiteId);
    } else {
      newExpanded.add(suiteId);
    }
    setExpandedSuites(newExpanded);
  };

  const getSpecsBySuite = (suiteId: number | null) => {
    const specsInSuite = specificationsList.filter(spec => 
      suiteId === null ? !spec.test_suite_id : spec.test_suite_id === suiteId
    );
    return filterSpecifications(specsInSuite);
  };

  const getChildSuites = (parentId: number | null) => {
    return suitesList.filter(suite => 
      parentId === null ? !suite.parent_id : suite.parent_id === parentId
    );
  };

  const getSuiteDepth = (suiteId: number): number => {
    const suite = suitesList.find(s => s.id === suiteId);
    if (!suite || !suite.parent_id) return 0;
    return 1 + getSuiteDepth(suite.parent_id);
  };

  useEffect(() => {
    if (selectedProject) {
      loadData();
    }
  }, [selectedProject]);

  // Automatyczne otwarcie modalu gdy jest parametr id w URL
  useEffect(() => {
    const specId = searchParams.get('id');
    if (specId && specificationsList.length > 0) {
      const spec = specificationsList.find((s: any) => s.id === parseInt(specId));
      if (spec) {
        handleView(spec);
        // Usuń parametr z URL po otwarciu
        setSearchParams({});
      }
    }
  }, [searchParams, specificationsList]);

  const loadData = async () => {
    try {
      const [specsRes, reqsRes, suitesRes, tagsRes] = await Promise.all([
        testSpecifications.getAll(selectedProject!.id),
        requirements.getAll(selectedProject!.id),
        testSuites.getAll(selectedProject!.id),
        tagsApi.getByProject(selectedProject!.id),
      ]);
      setSpecificationsList(specsRes.data);
      setRequirementsList(reqsRes.data);
      setSuitesList(suitesRes.data);
      setTagsList(tagsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const data = {
        ...formData,
        test_suite_id: formData.test_suite_id || null,
        project_id: selectedProject!.id,
        steps: steps.filter(s => s.action && s.expected_result),
        requirement_ids: selectedRequirements,
        tag_ids: selectedTags.map(t => t.id),
      };
      
      if (selectedSpec) {
        await testSpecifications.update(selectedSpec.id, data);
        toast.success('✅ Przypadek testowy został zaktualizowany');
      } else {
        await testSpecifications.create(data);
        toast.success('✅ Przypadek testowy został utworzony');
      }
      resetForm();
      loadData();
    } catch (error) {
      console.error('Error saving specification:', error);
      toast.error('❌ Błąd podczas zapisywania przypadku testowego');
    }
  };

  const handleSuiteSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (selectedSuite) {
        await testSuites.update(selectedSuite.id, suiteFormData);
        toast.success('✅ Zestaw testowy został zaktualizowany');
      } else {
        await testSuites.create({ ...suiteFormData, project_id: selectedProject!.id });
        toast.success('✅ Zestaw testowy został utworzony');
      }
      setShowSuiteModal(false);
      setSelectedSuite(null);
      setSuiteFormData({ name: '', description: '', parent_id: null });
      await loadData();
    } catch (error) {
      console.error('Error saving suite:', error);
      toast.error('❌ Błąd podczas zapisywania zestawu');
    }
  };

  const handleEditSuite = (suite: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedSuite(suite);
    setSuiteFormData({
      name: suite.name,
      description: suite.description || '',
      parent_id: suite.parent_id || null,
    });
    setShowSuiteModal(true);
  };

  const handleAddSubSuite = (parentSuite: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedSuite(null);
    setSuiteFormData({
      name: '',
      description: '',
      parent_id: parentSuite.id,
    });
    setShowSuiteModal(true);
  };

  const handleDeleteSuite = async (suite: any, e: React.MouseEvent) => {
    e.stopPropagation();
    const suiteSpecs = getSpecsBySuite(suite.id);
    
    if (suiteSpecs.length > 0) {
      const deleteTests = window.confirm(
        `Zestaw "${suite.name}" zawiera ${suiteSpecs.length} przypadków testowych.\n\nCzy chcesz usunąć zestaw razem z przypadkami testowymi?\n\nKliknij OK aby usunąć wszystko, lub Anuluj aby zachować przypadki testowe.`
      );
      
      if (deleteTests === null) return;
      
      try {
        await testSuites.delete(suite.id, deleteTests);
        toast.success('✅ Zestaw został usunięty');
        await loadData();
      } catch (error) {
        console.error('Error deleting suite:', error);
        toast.error('❌ Błąd podczas usuwania zestawu');
      }
    } else {
      if (window.confirm(`Czy na pewno chcesz usunąć zestaw "${suite.name}"?`)) {
        try {
          await testSuites.delete(suite.id, false);
          toast.success('✅ Zestaw został usunięty');
          await loadData();
        } catch (error) {
          console.error('Error deleting suite:', error);
          toast.error('❌ Błąd podczas usuwania zestawu');
        }
      }
    }
  };

  const handleView = (spec: any) => {
    setViewSpec(spec);
    setShowViewModal(true);
    setShowMetadata(false); // Zwinięty panel metadanych przy otwieraniu
  };

  const resetForm = () => {
    setShowModal(false);
    setSelectedSpec(null);
    setFormData({
      title: '',
      description: '',
      preconditions: '',
      priority: 'medium',
      status: 'draft',
      test_suite_id: '',
    });
    setSteps([{ action: '', expected_result: '' }]);
    setSelectedRequirements([]);
    setSelectedTags([]);
  };

  const handleAddTestCaseToSuite = (suite: any, e: React.MouseEvent) => {
    e.stopPropagation();
    setFormData({
      title: '',
      description: '',
      preconditions: '',
      priority: 'medium',
      status: 'draft',
      test_suite_id: suite.id,
    });
    setSteps([]);
    setCurrentStep({ action: '', expected_result: '' });
    setEditingStepIndex(null);
    setSelectedRequirements([]);
    setSelectedSpec(null);
    setShowModal(true);
  };

  const handleEdit = (spec: any) => {
    setSelectedSpec(spec);
    setFormData({
      title: spec.title,
      description: spec.description || '',
      preconditions: spec.preconditions || '',
      priority: spec.priority,
      status: spec.status,
      test_suite_id: spec.test_suite_id || '',
    });
    setSteps(spec.steps && spec.steps.length > 0 ? spec.steps : []);
    setCurrentStep({ action: '', expected_result: '' });
    setEditingStepIndex(null);
    setSelectedRequirements(spec.requirements ? spec.requirements.map((r: any) => r.id) : []);
    setSelectedTags(spec.tags || []);
    setShowModal(true);
  };

  const saveStep = () => {
    if (!currentStep.action.trim() || !currentStep.expected_result.trim()) {
      toast.error('Wypełnij akcję i oczekiwany rezultat');
      return;
    }

    if (editingStepIndex !== null) {
      // Edycja istniejącego kroku
      const updatedSteps = [...steps];
      updatedSteps[editingStepIndex] = currentStep;
      setSteps(updatedSteps);
      setEditingStepIndex(null);
    } else {
      // Dodanie nowego kroku
      setSteps([...steps, currentStep]);
    }
    
    // Reset formularza
    setCurrentStep({ action: '', expected_result: '' });
  };

  const editStep = (index: number) => {
    setCurrentStep(steps[index]);
    setEditingStepIndex(index);
  };

  const cancelEditStep = () => {
    setCurrentStep({ action: '', expected_result: '' });
    setEditingStepIndex(null);
  };

  const removeStep = (index: number) => {
    setSteps(steps.filter((_, i) => i !== index));
  };

  const toggleRequirement = (reqId: number) => {
    if (selectedRequirements.includes(reqId)) {
      setSelectedRequirements(selectedRequirements.filter(id => id !== reqId));
    } else {
      setSelectedRequirements([...selectedRequirements, reqId]);
    }
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Czy na pewno chcesz usunąć tę specyfikację?')) return;
    try {
      await testSpecifications.delete(id);
      toast.success('✅ Przypadek testowy został usunięty');
      loadData();
    } catch (error) {
      console.error('Error deleting specification:', error);
      toast.error('❌ Błąd podczas usuwania przypadku testowego');
    }
  };

  const handleImportCSV = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    try {
      toast.info('📥 Importowanie przypadków testowych...');
      
      // Odczytaj plik CSV
      const csvContent = await readCSVFile(file);
      
      // Parsuj CSV
      const parsedTestCases = parseTestCasesCSV(csvContent);
      
      if (parsedTestCases.length === 0) {
        toast.warning('⚠️ Nie znaleziono przypadków testowych w pliku');
        return;
      }

      // Pobierz wszystkie tagi projektu
      const projectTagsRes = await tagsApi.getByProject(selectedProject!.id);
      const projectTags = projectTagsRes.data;

      // Pobierz wszystkie wymagania projektu
      const projectReqs = requirementsList;

      // Pobierz wszystkie zestawy testowe
      const projectSuites = suitesList;

      let created = 0;
      let updated = 0;
      let errors = 0;
      let createdSuites = 0;

      for (const tc of parsedTestCases) {
        try {
          // Znajdź lub utwórz zestaw testowy
          let suiteId = null;
          if (tc.suite_name) {
            let suite = projectSuites.find(s => s.name === tc.suite_name);
            if (!suite) {
              // Utwórz nowy zestaw testowy
              const newSuiteRes = await testSuites.create({
                name: tc.suite_name,
                description: `Automatycznie utworzony podczas importu CSV`,
                project_id: selectedProject!.id,
                parent_id: null
              });
              suite = newSuiteRes.data;
              projectSuites.push(suite);
              createdSuites++;
              console.log(`Utworzono nowy zestaw testowy: ${tc.suite_name}`);
            }
            suiteId = suite?.id || null;
          }

          // Znajdź wymagania po ID
          // Jeśli brak wymagań w CSV -> pusta tablica
          // Jeśli wymaganie nie istnieje -> pomijane (filtrowane)
          const requirementIds = tc.requirements.length > 0
            ? tc.requirements
                .map(reqId => {
                  const req = projectReqs.find(r => r.requirement_id === reqId);
                  return req?.id;
                })
                .filter(id => id !== undefined)
            : []; // Pusta tablica jeśli brak wymagań w CSV

          // Znajdź lub utwórz tagi
          const tagIds: number[] = [];
          const colorPalette = [
            '#3B82F6', '#10B981', '#EF4444', '#F59E0B', '#8B5CF6',
            '#EC4899', '#6366F1', '#F97316', '#14B8A6', '#6B7280'
          ];
          for (const tagName of tc.tags) {
            let tag = projectTags.find((t: any) => t.name === tagName);
            if (!tag) {
              // Utwórz nowy tag z losowym kolorem
              const randomColor = colorPalette[Math.floor(Math.random() * colorPalette.length)];
              const newTagRes = await tagsApi.create({
                name: tagName,
                color: randomColor,
                project_id: selectedProject!.id
              });
              tag = newTagRes.data;
              projectTags.push(tag);
            }
            tagIds.push(tag.id);
          }

          const tcData = {
            title: tc.title,
            description: tc.description,
            preconditions: tc.preconditions,
            priority: tc.priority,
            status: tc.status,
            test_suite_id: suiteId,
            project_id: selectedProject!.id,
            steps: tc.steps,
            requirement_ids: requirementIds,
            tag_ids: tagIds
          };

          // Sprawdź czy TC o tym ID już istnieje
          const existingTC = tc.test_case_id 
            ? specificationsList.find(s => s.test_case_id === tc.test_case_id)
            : null;

          if (existingTC) {
            // Scenariusz 1: ID istnieje -> aktualizuj
            await testSpecifications.update(existingTC.id, tcData);
            updated++;
            console.log(`Zaktualizowano TC ${tc.test_case_id}`);
          } else {
            // Scenariusz 2 i 3: Utwórz nowy TC
            // Backend automatycznie wygeneruje ID jeśli nie podano
            await testSpecifications.create(tcData);
            created++;
            console.log(`Utworzono TC ${tc.test_case_id || '(nowe ID)'}`);
          }

        } catch (error) {
          console.error(`Błąd importu TC ${tc.test_case_id || '(brak ID)'}:`, error);
          errors++;
        }
      }

      // Odśwież dane
      await loadData();

      // Pokaż podsumowanie
      if (created > 0) {
        toast.success(`✅ Utworzono ${created} nowych przypadków testowych`);
      }
      if (updated > 0) {
        toast.info(`🔄 Zaktualizowano ${updated} istniejących przypadków testowych`);
      }
      if (createdSuites > 0) {
        toast.success(`📁 Utworzono ${createdSuites} nowych zestawów testowych`);
      }
      if (errors > 0) {
        toast.error(`❌ Błędy podczas importu: ${errors}`);
      }
      if (created === 0 && updated === 0 && errors === 0) {
        toast.warning('⚠️ Nie zaimportowano żadnych przypadków testowych');
      }

    } catch (error) {
      console.error('Import error:', error);
      toast.error('❌ Błąd podczas importowania pliku CSV');
    } finally {
      // Wyczyść input
      if (fileInputRef.current) {
        fileInputRef.current.value = '';
      }
    }
  };

  // Funkcja filtrowania TC
  const filterSpecifications = (specs: any[]): any[] => {
    return specs.filter(spec => {
      // Filtr tekstowy (ID, tytuł, opis)
      if (filterText) {
        const searchText = filterText.toLowerCase();
        const matchesText = 
          spec.test_case_id?.toLowerCase().includes(searchText) ||
          spec.title?.toLowerCase().includes(searchText) ||
          spec.description?.toLowerCase().includes(searchText);
        if (!matchesText) return false;
      }

      // Filtr po tagach (TC musi mieć WSZYSTKIE wybrane tagi)
      if (filterTags.length > 0) {
        const specTagIds = spec.tags?.map((t: any) => t.id) || [];
        const hasAllTags = filterTags.every(tagId => specTagIds.includes(tagId));
        if (!hasAllTags) return false;
      }

      // Filtr po ID wymagania
      if (filterRequirement) {
        const searchReq = filterRequirement.toLowerCase();
        const hasRequirement = spec.requirements?.some((req: any) => 
          req.requirement_id?.toLowerCase().includes(searchReq)
        );
        if (!hasRequirement) return false;
      }

      return true;
    });
  };

  // Funkcje obsługi modala filtrów
  const handleOpenFilterModal = () => {
    // Skopiuj aktualne filtry do tymczasowych
    setTempFilterText(filterText);
    setTempFilterTags(filterTags);
    setTempFilterRequirement(filterRequirement);
    setShowFilterModal(true);
  };

  const handleApplyFilters = () => {
    // Zastosuj tymczasowe filtry jako aktywne
    setFilterText(tempFilterText);
    setFilterTags(tempFilterTags);
    setFilterRequirement(tempFilterRequirement);
    setShowFilterModal(false);
  };

  const handleClearFilters = () => {
    setTempFilterText('');
    setTempFilterTags([]);
    setTempFilterRequirement('');
  };

  const handleDragStart = (e: React.DragEvent, spec: any) => {
    setDraggedSpec(spec);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent, suiteId: number | null) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
    setDragOverSuite(suiteId);
  };

  const handleDragLeave = () => {
    setDragOverSuite(null);
  };

  const handleDrop = async (e: React.DragEvent, targetSuiteId: number | null) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (!draggedSpec) return;

    try {
      // Pobierz wszystkie specyfikacje w docelowym zestawie
      const targetSpecs = specificationsList.filter(s => 
        (targetSuiteId === null && !s.test_suite_id) || 
        (s.test_suite_id === targetSuiteId)
      );
      
      // Ustaw nową kolejność
      const newOrder = targetSpecs.length;
      
      await testSpecifications.reorder(draggedSpec.id, {
        test_suite_id: targetSuiteId,
        display_order: newOrder
      });

      await loadData();
      setDraggedSpec(null);
      setDragOverSuite(null);
    } catch (error) {
      console.error('Error moving specification:', error);
      toast.error('❌ Błąd podczas przenoszenia przypadku testowego');
    }
  };

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case 'high': return 'bg-red-100 text-red-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'low': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'draft': return 'bg-gray-100 text-gray-800';
      case 'approved': return 'bg-green-100 text-green-800';
      case 'rejected': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const renderSuite = (suite: any, depth: number = 0): JSX.Element => {
    const suiteSpecs = getSpecsBySuite(suite.id);
    const childSuites = getChildSuites(suite.id);
    const isExpanded = expandedSuites.has(suite.id);
    const paddingLeft = depth * 24;

    return (
      <div key={suite.id}>
        {/* Nagłówek zestawu */}
        <div 
          className={`flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer border-b ${
            dragOverSuite === suite.id ? 'bg-blue-100 border-blue-400' : ''
          }`}
          style={{ paddingLeft: `${16 + paddingLeft}px` }}
          onClick={() => toggleSuite(suite.id)}
          onDragOver={(e) => handleDragOver(e, suite.id)}
          onDragLeave={handleDragLeave}
          onDrop={(e) => handleDrop(e, suite.id)}
        >
          <div className="flex items-center flex-1">
            {isExpanded ? (
              <ChevronDown className="h-5 w-5 text-gray-400 mr-2" />
            ) : (
              <ChevronRight className="h-5 w-5 text-gray-400 mr-2" />
            )}
            <FolderOpen className="h-5 w-5 text-blue-600 mr-3" />
            <div>
              <div className="text-sm font-medium text-gray-900">{suite.name}</div>
              <div className="text-xs text-gray-500">
                {childSuites.length > 0 && `${childSuites.length} podzestawów, `}
                {suiteSpecs.length} przypadków
              </div>
            </div>
          </div>
          <div className="flex items-center space-x-2">
            {can('test_specs.create') && (
              <button
                onClick={(e) => handleAddTestCaseToSuite(suite, e)}
                className="p-1 text-purple-600 hover:text-purple-800 hover:bg-purple-50 rounded"
                title="Dodaj przypadek testowy"
              >
                <FileText className="h-4 w-4" />
              </button>
            )}
            {can('test_specs.create') && (
              <button
                onClick={(e) => handleAddSubSuite(suite, e)}
                className="p-1 text-green-600 hover:text-green-800 hover:bg-green-50 rounded"
                title="Dodaj podzestaw"
              >
                <Plus className="h-4 w-4" />
              </button>
            )}
            {can('test_specs.edit') && (
              <button
                onClick={(e) => handleEditSuite(suite, e)}
                className="p-1 text-blue-600 hover:text-blue-800 hover:bg-blue-50 rounded"
                title="Edytuj zestaw"
              >
                <Edit className="h-4 w-4" />
              </button>
            )}
            {can('test_specs.delete') && (
              <button
                onClick={(e) => handleDeleteSuite(suite, e)}
                className="p-1 text-red-600 hover:text-red-800 hover:bg-red-50 rounded"
                title="Usuń zestaw"
              >
                <Trash2 className="h-4 w-4" />
              </button>
            )}
          </div>
        </div>
        
        {/* Zawartość rozwinięta */}
        {isExpanded && (
          <>
            {/* Podzestawy */}
            {childSuites.map(childSuite => renderSuite(childSuite, depth + 1))}
            
            {/* Przypadki testowe */}
            {suiteSpecs.length > 0 && (
              <div className="bg-gray-50">
                <table className="min-w-full">
                  <thead className="bg-gray-100">
                    <tr>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ paddingLeft: '48px', paddingRight: '24px' }}>Tytuł</th>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '100px', paddingLeft: '24px', paddingRight: '24px' }}>Kroki</th>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>Priorytet</th>
                      <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>Status</th>
                      <th className="py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>Akcje</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-gray-200">
                    {suiteSpecs.map((spec) => (
                      <tr 
                        key={spec.id} 
                        className="hover:bg-gray-100 cursor-move"
                        draggable
                        onDragStart={(e) => handleDragStart(e, spec)}
                      >
                        <td className="py-3" style={{ paddingLeft: '48px', paddingRight: '24px' }}>
                          <div className="flex items-center gap-2" style={{ paddingLeft: `${paddingLeft}px` }}>
                            {spec.test_case_id && (
                              <span className="text-xs font-mono font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                                {spec.test_case_id}
                              </span>
                            )}
                            <div className="text-sm font-medium text-gray-900">{spec.title}</div>
                          </div>
                          {spec.requirements && spec.requirements.length > 0 && (
                            <div className="flex items-center gap-1 mt-1 flex-wrap" style={{ paddingLeft: `${paddingLeft}px` }}>
                              <span className="text-xs text-gray-500">Wymagania:</span>
                              {spec.requirements.map((r: any, idx: number) => (
                                <span key={idx} className="text-xs font-mono font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded">
                                  {r.requirement_id || r.title}
                                </span>
                              ))}
                            </div>
                          )}
                          {spec.tags && spec.tags.length > 0 && (
                            <div className="flex items-center gap-1 mt-1 flex-wrap" style={{ paddingLeft: `${paddingLeft}px` }}>
                              <span className="text-xs text-gray-500">Tagi:</span>
                              {spec.tags.map((tag: any) => (
                                <span 
                                  key={tag.id} 
                                  className="text-xs px-2 py-0.5 rounded"
                                  style={{ 
                                    backgroundColor: `${tag.color}20`,
                                    color: tag.color,
                                    border: `1px solid ${tag.color}40`
                                  }}
                                >
                                  {tag.name}
                                </span>
                              ))}
                            </div>
                          )}
                          {spec.created_by_name && (
                            <div className="flex items-center gap-1 mt-1" style={{ paddingLeft: `${paddingLeft}px` }}>
                              <span className="text-xs text-gray-500">Autor:</span>
                              <span className="text-xs text-gray-700 font-medium">{spec.created_by_name}</span>
                            </div>
                          )}
                        </td>
                        <td className="py-3 whitespace-nowrap text-sm text-gray-500" style={{ width: '100px', paddingLeft: '24px', paddingRight: '24px' }}>
                          {spec.steps?.length || 0} kroków
                        </td>
                        <td className="py-3 whitespace-nowrap" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(spec.priority)}`}>
                            {spec.priority === 'high' ? 'Wysoki' : spec.priority === 'medium' ? 'Średni' : 'Niski'}
                          </span>
                        </td>
                        <td className="py-3 whitespace-nowrap" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>
                          <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(spec.status)}`}>
                            {spec.status === 'draft' ? 'Szkic' : spec.status === 'approved' ? 'Zatwierdzony' : 'Odrzucony'}
                          </span>
                        </td>
                        <td className="py-3 whitespace-nowrap text-right text-sm font-medium space-x-2" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>
                          <button onClick={() => handleView(spec)} className="text-gray-600 hover:text-gray-900" title="Podgląd">
                            <Eye className="h-4 w-4 inline" />
                          </button>
                          {can('test_specs.export') && (
                            <button 
                              onClick={() => {
                                exportSingleTestSpecificationToCSV(spec);
                                toast.success('✅ Przypadek testowy wyeksportowany do CSV');
                              }} 
                              className="text-green-600 hover:text-green-900" 
                              title="Eksportuj CSV"
                            >
                              <Download className="h-4 w-4 inline" />
                            </button>
                          )}
                          {can('test_specs.edit') && (
                            <button onClick={() => handleEdit(spec)} className="text-blue-600 hover:text-blue-900" title="Edytuj">
                              <Edit className="h-4 w-4 inline" />
                            </button>
                          )}
                          {can('test_specs.delete') && (
                            <button onClick={() => handleDelete(spec.id)} className="text-red-600 hover:text-red-900" title="Usuń">
                              <Trash2 className="h-4 w-4 inline" />
                            </button>
                          )}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}
            
            {childSuites.length === 0 && suiteSpecs.length === 0 && (
              <div className="px-12 py-6 text-sm text-gray-500 bg-gray-50" style={{ paddingLeft: `${48 + paddingLeft}px` }}>
                Brak podzestawów i przypadków testowych
              </div>
            )}
          </>
        )}
      </div>
    );
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  return (
    <div className="space-y-4">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold text-gray-900">Specyfikacja testowa</h2>
        <div className="space-x-2">
          {can('test_specs.export') && (
            <button
              onClick={() => {
                exportTestSpecificationsToCSV(specificationsList, `tc_${selectedProject?.name}_${new Date().toISOString().split('T')[0]}.csv`);
                toast.success('✅ Przypadki testowe wyeksportowane do CSV');
              }}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-white bg-gray-600 hover:bg-gray-700"
              disabled={specificationsList.length === 0}
            >
              <Download className="h-4 w-4 mr-2" />
              Eksportuj CSV
            </button>
          )}
          {can('test_specs.import') && (
            <>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
              >
                <Upload className="h-4 w-4 mr-2" />
                Importuj CSV
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept=".csv"
                onChange={handleImportCSV}
                className="hidden"
              />
            </>
          )}
          {can('test_specs.create') && (
            <button
              onClick={() => {
                setSelectedSuite(null);
                setSuiteFormData({ name: '', description: '', parent_id: null });
                setShowSuiteModal(true);
              }}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <FolderOpen className="h-4 w-4 mr-2" />
              Nowy zestaw
            </button>
          )}
          {can('test_specs.create') && (
            <button
              onClick={() => {
                setSelectedSpec(null);
                setFormData({
                  title: '',
                  description: '',
                  preconditions: '',
                  priority: 'medium',
                  status: 'draft',
                  test_suite_id: '',
                });
                setSteps([]);
                setCurrentStep({ action: '', expected_result: '' });
                setEditingStepIndex(null);
                setSelectedRequirements([]);
                setSelectedTags([]);
                setShowModal(true);
              }}
              className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-blue-600 hover:bg-blue-700"
            >
              <Plus className="h-4 w-4 mr-2" />
              Dodaj przypadek
            </button>
          )}
        </div>
      </div>

      {/* Przycisk filtrowania */}
      <div className="bg-white shadow rounded-lg p-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-3">
            <button
              onClick={handleOpenFilterModal}
              className="inline-flex items-center px-4 py-2 border border-gray-300 rounded-md shadow-sm text-sm font-medium text-gray-700 bg-white hover:bg-gray-50"
            >
              <ClipboardList className="h-4 w-4 mr-2" />
              Filtruj
            </button>
            
            {/* Wskaźnik aktywnych filtrów */}
            {(filterText || filterTags.length > 0 || filterRequirement) && (
              <div className="flex items-center gap-2 text-sm">
                <span className="text-gray-600">Aktywne filtry:</span>
                {filterText && (
                  <span className="px-2 py-1 bg-blue-100 text-blue-800 rounded">
                    Tekst: "{filterText}"
                  </span>
                )}
                {filterTags.length > 0 && (
                  <span className="px-2 py-1 bg-green-100 text-green-800 rounded">
                    Tagi: {filterTags.length}
                  </span>
                )}
                {filterRequirement && (
                  <span className="px-2 py-1 bg-purple-100 text-purple-800 rounded">
                    Wymaganie: "{filterRequirement}"
                  </span>
                )}
                <button
                  onClick={() => {
                    setFilterText('');
                    setFilterTags([]);
                    setFilterRequirement('');
                  }}
                  className="text-red-600 hover:text-red-800 text-xs underline"
                >
                  Wyczyść wszystkie
                </button>
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Struktura katalogowa - zestawy i przypadki */}
      <div className="space-y-3">
        {/* Zestawy główne (bez parent_id) */}
        {getChildSuites(null).map((suite) => (
          <div key={suite.id} className="bg-white shadow rounded-lg overflow-hidden">
            {renderSuite(suite, 0)}
          </div>
        ))}
        
        {/* Przypadki bez zestawu */}
        {(() => {
          const unassignedSpecs = getSpecsBySuite(null);
          if (unassignedSpecs.length > 0) {
            const isExpanded = expandedSuites.has(0);
            return (
              <div className="bg-white shadow rounded-lg overflow-hidden">
                <div 
                  className={`flex items-center justify-between p-4 hover:bg-gray-50 cursor-pointer border-b ${
                    dragOverSuite === null ? 'bg-blue-100 border-blue-400' : ''
                  }`}
                  onClick={() => toggleSuite(0)}
                  onDragOver={(e) => handleDragOver(e, null)}
                  onDragLeave={handleDragLeave}
                  onDrop={(e) => handleDrop(e, null)}
                >
                  <div className="flex items-center flex-1">
                    {isExpanded ? (
                      <ChevronDown className="h-5 w-5 text-gray-400 mr-2" />
                    ) : (
                      <ChevronRight className="h-5 w-5 text-gray-400 mr-2" />
                    )}
                    <ClipboardList className="h-5 w-5 text-gray-600 mr-3" />
                    <div>
                      <div className="text-sm font-medium text-gray-900">Bez zestawu</div>
                      <div className="text-xs text-gray-500">{unassignedSpecs.length} przypadków</div>
                    </div>
                  </div>
                </div>
                
                {isExpanded && (
                  <div className="bg-gray-50">
                    <table className="min-w-full">
                      <thead className="bg-gray-100">
                        <tr>
                          <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ paddingLeft: '48px', paddingRight: '24px' }}>Tytuł</th>
                          <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '100px', paddingLeft: '24px', paddingRight: '24px' }}>Kroki</th>
                          <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>Priorytet</th>
                          <th className="py-2 text-left text-xs font-medium text-gray-500 uppercase" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>Status</th>
                          <th className="py-2 text-right text-xs font-medium text-gray-500 uppercase" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>Akcje</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-gray-200">
                        {unassignedSpecs.map((spec) => (
                          <tr 
                            key={spec.id} 
                            className="hover:bg-gray-100 cursor-move"
                            draggable
                            onDragStart={(e) => handleDragStart(e, spec)}
                          >
                            <td className="py-3" style={{ paddingLeft: '48px', paddingRight: '24px' }}>
                              <div className="flex items-center gap-2">
                                {spec.test_case_id && (
                                  <span className="text-xs font-mono font-semibold text-blue-600 bg-blue-50 px-2 py-1 rounded">
                                    {spec.test_case_id}
                                  </span>
                                )}
                                <div className="text-sm font-medium text-gray-900">{spec.title}</div>
                              </div>
                              {spec.requirements && spec.requirements.length > 0 && (
                                <div className="flex items-center gap-1 mt-1 flex-wrap">
                                  <span className="text-xs text-gray-500">Wymagania:</span>
                                  {spec.requirements.map((r: any, idx: number) => (
                                    <span key={idx} className="text-xs font-mono font-semibold text-green-600 bg-green-50 px-2 py-0.5 rounded">
                                      {r.requirement_id || r.title}
                                    </span>
                                  ))}
                                </div>
                              )}
                              {spec.tags && spec.tags.length > 0 && (
                                <div className="flex items-center gap-1 mt-1 flex-wrap">
                                  <span className="text-xs text-gray-500">Tagi:</span>
                                  {spec.tags.map((tag: any) => (
                                    <span 
                                      key={tag.id} 
                                      className="text-xs px-2 py-0.5 rounded"
                                      style={{ 
                                        backgroundColor: `${tag.color}20`,
                                        color: tag.color,
                                        border: `1px solid ${tag.color}40`
                                      }}
                                    >
                                      {tag.name}
                                    </span>
                                  ))}
                                </div>
                              )}
                            </td>
                            <td className="py-3 whitespace-nowrap text-sm text-gray-500" style={{ width: '100px', paddingLeft: '24px', paddingRight: '24px' }}>
                              {spec.steps?.length || 0} kroków
                            </td>
                            <td className="py-3 whitespace-nowrap" style={{ width: '120px', paddingLeft: '24px', paddingRight: '24px' }}>
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(spec.priority)}`}>
                                {spec.priority === 'high' ? 'Wysoki' : spec.priority === 'medium' ? 'Średni' : 'Niski'}
                              </span>
                            </td>
                            <td className="py-3 whitespace-nowrap" style={{ width: '140px', paddingLeft: '24px', paddingRight: '24px' }}>
                              <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(spec.status)}`}>
                                {spec.status === 'draft' ? 'Szkic' : spec.status === 'approved' ? 'Zatwierdzony' : 'Odrzucony'}
                              </span>
                            </td>
                            <td className="py-3 whitespace-nowrap text-right text-sm font-medium space-x-2" style={{ width: '160px', paddingLeft: '24px', paddingRight: '24px' }}>
                              <button onClick={() => handleView(spec)} className="text-gray-600 hover:text-gray-900" title="Podgląd">
                                <Eye className="h-4 w-4 inline" />
                              </button>
                              <button 
                                onClick={() => {
                                  exportSingleTestSpecificationToCSV(spec);
                                  toast.success('✅ Przypadek testowy wyeksportowany do CSV');
                                }} 
                                className="text-green-600 hover:text-green-900" 
                                title="Eksportuj CSV"
                              >
                                <Download className="h-4 w-4 inline" />
                              </button>
                              <button onClick={() => handleEdit(spec)} className="text-blue-600 hover:text-blue-900" title="Edytuj">
                                <Edit className="h-4 w-4 inline" />
                              </button>
                              <button onClick={() => handleDelete(spec.id)} className="text-red-600 hover:text-red-900" title="Usuń">
                                <Trash2 className="h-4 w-4 inline" />
                              </button>
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                )}
              </div>
            );
          }
          return null;
        })()}
        
        {/* Pusty stan */}
        {suitesList.length === 0 && specificationsList.length === 0 && (
          <div className="bg-white shadow rounded-lg">
            <div className="text-center py-12">
              <ClipboardList className="mx-auto h-12 w-12 text-gray-400" />
              <h3 className="mt-2 text-sm font-medium text-gray-900">Brak przypadków testowych</h3>
              <p className="mt-1 text-sm text-gray-500">Zacznij od utworzenia zestawu lub dodania przypadku testowego.</p>
            </div>
          </div>
        )}
      </div>

      {/* Modal przypadku testowego */}
      {showModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={resetForm}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-4xl w-full z-20">
              <form onSubmit={handleSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 max-h-[85vh] overflow-y-auto">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {selectedSpec ? 'Edytuj przypadek testowy' : 'Nowy przypadek testowy'}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Tytuł *</label>
                      <input
                        type="text"
                        required
                        value={formData.title}
                        onChange={(e) => setFormData({ ...formData, title: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:ring-blue-500 focus:border-blue-500"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Opis</label>
                      <WysiwygEditor
                        value={formData.description}
                        onChange={(value) => setFormData({ ...formData, description: value })}
                        placeholder="Szczegółowy opis przypadku testowego..."
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-1">Warunki wstępne</label>
                      <WysiwygEditor
                        value={formData.preconditions}
                        onChange={(value) => setFormData({ ...formData, preconditions: value })}
                        placeholder="Warunki które muszą być spełnione przed testem..."
                      />
                    </div>

                    {/* Kroki testowe */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Kroki testowe</label>
                      
                      {/* Lista zapisanych kroków */}
                      {steps.map((step, index) => (
                        <div key={index} className="border rounded-md p-3 mb-2 bg-white">
                          <div className="flex justify-between items-center mb-2">
                            <span className="text-sm font-medium text-gray-700">Krok {index + 1}</span>
                            <div className="flex gap-2">
                              <button
                                type="button"
                                onClick={() => editStep(index)}
                                className="text-blue-600 hover:text-blue-800 text-sm"
                              >
                                <Edit className="h-4 w-4" />
                              </button>
                              <button
                                type="button"
                                onClick={() => removeStep(index)}
                                className="text-red-600 hover:text-red-800"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                          <div className="space-y-2 text-sm">
                            <div>
                              <span className="font-medium text-gray-600">Akcja:</span>
                              <div 
                                className="prose prose-sm max-w-none mt-1"
                                dangerouslySetInnerHTML={{ __html: step.action }}
                              />
                            </div>
                            <div>
                              <span className="font-medium text-gray-600">Oczekiwany rezultat:</span>
                              <div 
                                className="prose prose-sm max-w-none mt-1"
                                dangerouslySetInnerHTML={{ __html: step.expected_result }}
                              />
                            </div>
                          </div>
                        </div>
                      ))}

                      {/* Formularz dodawania/edycji kroku */}
                      <div className="border-2 border-dashed border-blue-300 rounded-md p-3 bg-blue-50">
                        <div className="flex justify-between items-center mb-2">
                          <span className="text-sm font-medium text-gray-700">
                            {editingStepIndex !== null ? `Edycja kroku ${editingStepIndex + 1}` : 'Nowy krok'}
                          </span>
                          {editingStepIndex !== null && (
                            <button
                              type="button"
                              onClick={cancelEditStep}
                              className="text-gray-600 hover:text-gray-800 text-sm"
                            >
                              Anuluj
                            </button>
                          )}
                        </div>
                        <div className="space-y-2">
                          <div>
                            <label className="block text-xs text-gray-600 mb-1">Akcja</label>
                            <WysiwygEditor
                              value={currentStep.action}
                              onChange={(value) => setCurrentStep({ ...currentStep, action: value })}
                              placeholder="Co należy zrobić?"
                            />
                          </div>
                          <div>
                            <label className="block text-xs text-gray-600 mb-1">Oczekiwany rezultat</label>
                            <WysiwygEditor
                              value={currentStep.expected_result}
                              onChange={(value) => setCurrentStep({ ...currentStep, expected_result: value })}
                              placeholder="Co powinno się stać?"
                            />
                          </div>
                          <button
                            type="button"
                            onClick={saveStep}
                            className="w-full py-2 px-4 bg-blue-600 text-white rounded-md text-sm hover:bg-blue-700"
                          >
                            {editingStepIndex !== null ? 'Zapisz zmiany' : 'Dodaj krok'}
                          </button>
                        </div>
                      </div>
                    </div>

                    {/* Wymagania */}
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">Powiązane wymagania</label>
                      <div className="border rounded-md p-3 max-h-40 overflow-y-auto">
                        {requirementsList.length === 0 ? (
                          <p className="text-sm text-gray-500">Brak wymagań</p>
                        ) : (
                          requirementsList.map((req) => (
                            <label key={req.id} className="flex items-center py-1">
                              <input
                                type="checkbox"
                                checked={selectedRequirements.includes(req.id)}
                                onChange={() => toggleRequirement(req.id)}
                                className="mr-2"
                              />
                              <span className="text-sm">{req.title}</span>
                            </label>
                          ))
                        )}
                      </div>
                    </div>

                    <div className="grid grid-cols-3 gap-4">
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Zestaw testowy</label>
                        <select
                          value={formData.test_suite_id}
                          onChange={(e) => setFormData({ ...formData, test_suite_id: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                        >
                          <option value="">Brak</option>
                          {suitesList.map((suite) => (
                            <option key={suite.id} value={suite.id}>{suite.name}</option>
                          ))}
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Priorytet</label>
                        <select
                          value={formData.priority}
                          onChange={(e) => setFormData({ ...formData, priority: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                        >
                          <option value="low">Niski</option>
                          <option value="medium">Średni</option>
                          <option value="high">Wysoki</option>
                        </select>
                      </div>
                      <div>
                        <label className="block text-sm font-medium text-gray-700">Status</label>
                        <select
                          value={formData.status}
                          onChange={(e) => setFormData({ ...formData, status: e.target.value })}
                          className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                        >
                          <option value="draft">Szkic</option>
                          <option value="approved">Zatwierdzony</option>
                          <option value="rejected">Odrzucony</option>
                        </select>
                      </div>
                    </div>
                    <div>
                      <TagSelector
                        projectId={selectedProject!.id}
                        selectedTags={selectedTags}
                        onChange={setSelectedTags}
                      />
                    </div>
                    
                    {/* Informacja o autorze */}
                    <div className="bg-blue-50 border border-blue-200 rounded-md p-3">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-blue-900">
                          {selectedSpec ? 'Autor:' : 'Zostaniesz autorem tego przypadku testowego:'}
                        </span>
                        <span className="text-sm text-blue-700 font-semibold">
                          {selectedSpec?.created_by_name || getUser()?.name || 'Nieznany'}
                        </span>
                      </div>
                      {!selectedSpec && (
                        <p className="text-xs text-blue-600 mt-1">
                          Twoje imię i nazwisko zostanie automatycznie przypisane jako autor.
                        </p>
                      )}
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {selectedSpec ? 'Zapisz' : 'Utwórz'}
                  </button>
                  <button
                    type="button"
                    onClick={resetForm}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 sm:mt-0 sm:w-auto sm:text-sm"
                  >
                    Anuluj
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal zestawu testowego */}
      {showSuiteModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => {
              setShowSuiteModal(false);
              setSelectedSuite(null);
              setSuiteFormData({ name: '', description: '', parent_id: null });
            }}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-lg w-full z-20">
              <form onSubmit={handleSuiteSubmit}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    {selectedSuite ? 'Edytuj zestaw testowy' : 'Nowy zestaw testowy'}
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Nazwa *</label>
                      <input
                        type="text"
                        required
                        value={suiteFormData.name}
                        onChange={(e) => setSuiteFormData({ ...suiteFormData, name: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Opis</label>
                      <textarea
                        value={suiteFormData.description}
                        onChange={(e) => setSuiteFormData({ ...suiteFormData, description: e.target.value })}
                        rows={3}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                      />
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">Zestaw nadrzędny</label>
                      <select
                        value={suiteFormData.parent_id || ''}
                        onChange={(e) => setSuiteFormData({ ...suiteFormData, parent_id: e.target.value ? parseInt(e.target.value) : null })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3"
                      >
                        <option value="">Brak (zestaw główny)</option>
                        {suitesList
                          .filter(s => !selectedSuite || s.id !== selectedSuite.id)
                          .map(suite => (
                            <option key={suite.id} value={suite.id}>
                              {'  '.repeat(getSuiteDepth(suite.id))}
                              {suite.name}
                            </option>
                          ))}
                      </select>
                      <p className="mt-1 text-xs text-gray-500">Wybierz zestaw nadrzędny, aby utworzyć podzestaw</p>
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-blue-600 text-base font-medium text-white hover:bg-blue-700 sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    {selectedSuite ? 'Zapisz' : 'Utwórz'}
                  </button>
                  <button
                    type="button"
                    onClick={() => {
                      setShowSuiteModal(false);
                      setSelectedSuite(null);
                      setSuiteFormData({ name: '', description: '', parent_id: null });
                    }}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 sm:mt-0 sm:w-auto sm:text-sm"
                  >
                    Anuluj
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}

      {/* Modal podglądu przypadku testowego */}
      {showViewModal && viewSpec && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center p-4 z-50">
          <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6">
              <div className="flex justify-between items-start mb-4">
                <div className="flex-1 pr-4">
                  <h2 className="text-xl font-bold text-gray-900">
                    {viewSpec.test_case_id || 'Brak ID'}: {viewSpec.title}
                  </h2>
                </div>
                <button onClick={() => setShowViewModal(false)} className="text-gray-500 hover:text-gray-700 flex-shrink-0">
                  <X className="h-6 w-6" />
                </button>
              </div>
              <div className="space-y-4">
                {/* 1. Warunki wstępne */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Warunki wstępne
                  </label>
                  <div 
                    className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg min-h-[60px] prose prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: viewSpec.preconditions || 'Brak warunków wstępnych' }}
                  />
                </div>

                {/* 2. Opis */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Opis
                  </label>
                  <div 
                    className="text-sm text-gray-900 bg-gray-50 px-3 py-2 rounded-lg min-h-[60px] prose prose-sm max-w-none"
                    dangerouslySetInnerHTML={{ __html: viewSpec.description || 'Brak opisu' }}
                  />
                </div>

                {/* 3. Kroki testowe */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Kroki testowe
                  </label>
                  <div className="bg-gray-50 rounded-lg p-3">
                    {viewSpec.steps && viewSpec.steps.length > 0 ? (
                      <div className="space-y-3">
                        {viewSpec.steps.map((step: any, idx: number) => (
                          <div key={idx} className="bg-white p-3 rounded border border-gray-200">
                            <div className="text-xs font-semibold text-gray-500 mb-1">Krok {idx + 1}</div>
                            <div className="text-sm mb-2">
                              <span className="font-medium">Akcja:</span>
                              <div 
                                className="inline prose prose-sm max-w-none ml-1"
                                dangerouslySetInnerHTML={{ __html: step.action }}
                              />
                            </div>
                            <div className="text-sm">
                              <span className="font-medium">Oczekiwany rezultat:</span>
                              <div 
                                className="inline prose prose-sm max-w-none ml-1"
                                dangerouslySetInnerHTML={{ __html: step.expected_result }}
                              />
                            </div>
                          </div>
                        ))}
                      </div>
                    ) : (
                      <span className="text-sm text-gray-500">Brak kroków testowych</span>
                    )}
                  </div>
                </div>

                {/* 4. Priorytet i Status */}
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Priorytet
                    </label>
                    <div className="text-sm bg-gray-50 px-3 py-2 rounded-lg">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getPriorityColor(viewSpec.priority)}`}>
                        {viewSpec.priority === 'high' ? 'Wysoki' : viewSpec.priority === 'medium' ? 'Średni' : 'Niski'}
                      </span>
                    </div>
                  </div>
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Status
                    </label>
                    <div className="text-sm bg-gray-50 px-3 py-2 rounded-lg">
                      <span className={`px-2 inline-flex text-xs leading-5 font-semibold rounded-full ${getStatusColor(viewSpec.status)}`}>
                        {viewSpec.status === 'draft' ? 'Szkic' : viewSpec.status === 'approved' ? 'Zatwierdzony' : 'Odrzucony'}
                      </span>
                    </div>
                  </div>
                </div>

                {/* 5. Tagi */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Tagi
                  </label>
                  <div className="text-sm bg-gray-50 px-3 py-2 rounded-lg min-h-[40px]">
                    {viewSpec.tags && viewSpec.tags.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {viewSpec.tags.map((tag: any) => (
                          <span 
                            key={tag.id} 
                            className="text-xs px-2 py-1 rounded font-medium"
                            style={{ 
                              backgroundColor: `${tag.color}20`,
                              color: tag.color,
                              border: `1px solid ${tag.color}40`
                            }}
                          >
                            {tag.name}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-500">Brak tagów</span>
                    )}
                  </div>
                </div>

                {/* 6. Powiązane wymagania */}
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">
                    Powiązane wymagania
                  </label>
                  <div className="text-sm bg-gray-50 px-3 py-2 rounded-lg min-h-[40px]">
                    {viewSpec.requirements && viewSpec.requirements.length > 0 ? (
                      <div className="flex flex-wrap gap-2">
                        {viewSpec.requirements.map((r: any, idx: number) => (
                          <span key={idx} className="text-xs font-mono font-semibold text-green-600 bg-green-50 px-2 py-1 rounded">
                            {r.requirement_id || r.title}
                          </span>
                        ))}
                      </div>
                    ) : (
                      <span className="text-gray-500">Brak powiązanych wymagań</span>
                    )}
                  </div>
                </div>

                {/* Panel metadanych - rozwijany */}
                <div className="border-t border-gray-200 pt-4">
                  <button
                    onClick={() => setShowMetadata(!showMetadata)}
                    className="flex items-center gap-2 text-sm text-gray-600 hover:text-gray-900 transition-colors"
                  >
                    <span className="text-lg">ℹ️</span>
                    <span className="font-medium">Informacje o utworzeniu i modyfikacji</span>
                    <span className="text-xs">
                      {showMetadata ? '▼' : '▶'}
                    </span>
                  </button>
                  
                  {showMetadata && (
                    <div className="mt-3 bg-gray-50 rounded-lg p-4 space-y-3">
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <div className="text-xs font-medium text-gray-500 mb-1">👤 Autor</div>
                          <div className="text-sm font-semibold text-gray-900">
                            {viewSpec.created_by_name || 'Nieznany autor'}
                          </div>
                        </div>
                        <div>
                          <div className="text-xs font-medium text-gray-500 mb-1">📅 Data utworzenia</div>
                          <div className="text-sm text-gray-900">
                            {viewSpec.created_at ? new Date(viewSpec.created_at).toLocaleDateString('pl-PL', { 
                              year: 'numeric', 
                              month: 'long', 
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            }) : 'Brak danych'}
                          </div>
                        </div>
                      </div>
                      {viewSpec.updated_at && viewSpec.updated_at !== viewSpec.created_at && (
                        <div>
                          <div className="text-xs font-medium text-gray-500 mb-1">🔄 Ostatnia modyfikacja</div>
                          <div className="text-sm text-gray-900">
                            {new Date(viewSpec.updated_at).toLocaleDateString('pl-PL', { 
                              year: 'numeric', 
                              month: 'long', 
                              day: 'numeric',
                              hour: '2-digit',
                              minute: '2-digit'
                            })}
                          </div>
                        </div>
                      )}
                    </div>
                  )}
                </div>

                <div className="flex justify-end space-x-2 pt-4">
                  <button
                    onClick={() => setShowViewModal(false)}
                    className="px-4 py-2 border border-gray-300 rounded-lg hover:bg-gray-50"
                  >
                    Zamknij
                  </button>
                  {can('test_specs.edit') && (
                    <button
                      onClick={() => {
                        setShowViewModal(false);
                        handleEdit(viewSpec);
                      }}
                      className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700"
                    >
                      Edytuj
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Modal filtrów */}
      {showFilterModal && (
        <div className="fixed inset-0 bg-gray-600 bg-opacity-50 overflow-y-auto h-full w-full z-50">
          <div className="relative top-20 mx-auto p-5 border w-full max-w-2xl shadow-lg rounded-md bg-white">
            <div className="flex justify-between items-center mb-4">
              <h3 className="text-lg font-medium text-gray-900">Filtruj przypadki testowe</h3>
              <button
                onClick={() => setShowFilterModal(false)}
                className="text-gray-400 hover:text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
            </div>

            <div className="space-y-4">
              {/* Filtr tekstowy */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Szukaj w ID, tytule lub opisie
                </label>
                <input
                  type="text"
                  value={tempFilterText}
                  onChange={(e) => setTempFilterText(e.target.value)}
                  placeholder="Wpisz tekst do wyszukania..."
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>

              {/* Filtr po tagach */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Filtruj po tagach (TC musi mieć wszystkie wybrane)
                </label>
                <select
                  multiple
                  value={tempFilterTags.map(String)}
                  onChange={(e) => {
                    const selected = Array.from(e.target.selectedOptions, option => Number(option.value));
                    setTempFilterTags(selected);
                  }}
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                  size={5}
                >
                  {tagsList.map(tag => (
                    <option key={tag.id} value={tag.id}>
                      {tag.name}
                    </option>
                  ))}
                </select>
                <p className="text-xs text-gray-500 mt-1">Ctrl+klik aby wybrać wiele tagów</p>
              </div>

              {/* Filtr po ID wymagania */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  ID wymagania
                </label>
                <input
                  type="text"
                  value={tempFilterRequirement}
                  onChange={(e) => setTempFilterRequirement(e.target.value)}
                  placeholder="np. WYM-001"
                  className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                />
              </div>
            </div>

            {/* Przyciski */}
            <div className="mt-6 flex justify-between">
              <button
                onClick={handleClearFilters}
                className="px-4 py-2 text-sm text-gray-700 bg-gray-100 hover:bg-gray-200 rounded-md"
              >
                Wyczyść filtry
              </button>
              <div className="space-x-2">
                <button
                  onClick={() => setShowFilterModal(false)}
                  className="px-4 py-2 text-sm text-gray-700 bg-white border border-gray-300 hover:bg-gray-50 rounded-md"
                >
                  Anuluj
                </button>
                <button
                  onClick={handleApplyFilters}
                  className="px-4 py-2 text-sm text-white bg-blue-600 hover:bg-blue-700 rounded-md"
                >
                  Zastosuj
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
