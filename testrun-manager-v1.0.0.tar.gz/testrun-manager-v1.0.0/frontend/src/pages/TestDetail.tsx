import { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { ArrowLeft, CheckCircle, XCircle, Home } from 'lucide-react';
import { tests, testRuns } from '../lib/api';
import { useProject } from '../context/ProjectContext';

export default function TestDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { selectedProject } = useProject();
  const [test, setTest] = useState<any>(null);
  const [runs, setRuns] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showRunModal, setShowRunModal] = useState(false);
  const [runData, setRunData] = useState({ result: 'passed', notes: '' });

  useEffect(() => {
    loadData();
  }, [id]);

  const loadData = async () => {
    try {
      const [testRes, runsRes] = await Promise.all([
        tests.getOne(Number(id)),
        testRuns.getAll(Number(id)),
      ]);
      setTest(testRes.data);
      setRuns(runsRes.data);
    } catch (error) {
      console.error('Error loading data:', error);
    } finally {
      setLoading(false);
    }
  };

  const handleRunTest = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await testRuns.create({
        test_case_id: Number(id),
        result: runData.result,
        notes: runData.notes,
      });
      setShowRunModal(false);
      setRunData({ result: 'passed', notes: '' });
      loadData();
    } catch (error) {
      console.error('Error running test:', error);
    }
  };

  if (loading) {
    return <div className="text-center py-12">Ładowanie...</div>;
  }

  if (!test) {
    return <div className="text-center py-12">Test nie znaleziony</div>;
  }

  return (
    <div className="space-y-6">
      <div className="mb-4">
        <nav className="flex items-center space-x-2 text-sm text-gray-500">
          <button
            onClick={() => navigate('/')}
            className="flex items-center hover:text-gray-700"
          >
            <Home className="h-4 w-4 mr-1" />
            Projekty
          </button>
          <span>/</span>
          <button
            onClick={() => navigate('/tests')}
            className="hover:text-gray-700"
          >
            {selectedProject?.name || 'Projekt'}
          </button>
          <span>/</span>
          <span className="text-gray-900 font-medium">{test.title}</span>
        </nav>
      </div>

      <div className="flex items-center justify-between">
        <button
          onClick={() => navigate('/tests')}
          className="inline-flex items-center text-sm text-gray-500 hover:text-gray-700"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Powrót do listy testów
        </button>
        <button
          onClick={() => setShowRunModal(true)}
          className="inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-green-600 hover:bg-green-700"
        >
          Wykonaj test
        </button>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            {test.title}
          </h3>
          <p className="mt-1 max-w-2xl text-sm text-gray-500">
            {test.project_name}
          </p>
        </div>
        <div className="border-t border-gray-200 px-4 py-5 sm:px-6">
          <dl className="grid grid-cols-1 gap-x-4 gap-y-8 sm:grid-cols-2">
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500">Priorytet</dt>
              <dd className="mt-1 text-sm text-gray-900 capitalize">{test.priority}</dd>
            </div>
            <div className="sm:col-span-1">
              <dt className="text-sm font-medium text-gray-500">Status</dt>
              <dd className="mt-1 text-sm text-gray-900 capitalize">{test.status}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-sm font-medium text-gray-500">Opis</dt>
              <dd className="mt-1 text-sm text-gray-900">{test.description || 'Brak opisu'}</dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-sm font-medium text-gray-500">Kroki</dt>
              <dd className="mt-1 text-sm text-gray-900 whitespace-pre-wrap">
                {test.steps || 'Brak kroków'}
              </dd>
            </div>
            <div className="sm:col-span-2">
              <dt className="text-sm font-medium text-gray-500">Oczekiwany rezultat</dt>
              <dd className="mt-1 text-sm text-gray-900">
                {test.expected_result || 'Brak opisu'}
              </dd>
            </div>
          </dl>
        </div>
      </div>

      <div className="bg-white shadow overflow-hidden sm:rounded-lg">
        <div className="px-4 py-5 sm:px-6">
          <h3 className="text-lg leading-6 font-medium text-gray-900">
            Historia wykonań
          </h3>
        </div>
        <div className="border-t border-gray-200">
          <ul className="divide-y divide-gray-200">
            {runs.map((run) => (
              <li key={run.id} className="px-4 py-4 sm:px-6">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    {run.result === 'passed' ? (
                      <CheckCircle className="h-5 w-5 text-green-500 mr-3" />
                    ) : (
                      <XCircle className="h-5 w-5 text-red-500 mr-3" />
                    )}
                    <div>
                      <p className="text-sm font-medium text-gray-900">
                        {run.result === 'passed' ? 'Zaliczony' : 'Niezaliczony'}
                      </p>
                      <p className="text-sm text-gray-500">
                        {new Date(run.executed_at).toLocaleString('pl-PL')}
                      </p>
                    </div>
                  </div>
                  {run.notes && (
                    <p className="text-sm text-gray-500">{run.notes}</p>
                  )}
                </div>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {showRunModal && (
        <div className="fixed z-10 inset-0 overflow-y-auto">
          <div className="flex items-center justify-center min-h-screen px-4">
            <div className="fixed inset-0 bg-gray-500 bg-opacity-75" onClick={() => setShowRunModal(false)}></div>
            <div className="bg-white rounded-lg overflow-hidden shadow-xl transform transition-all max-w-lg w-full z-20">
              <form onSubmit={handleRunTest}>
                <div className="bg-white px-4 pt-5 pb-4 sm:p-6 sm:pb-4">
                  <h3 className="text-lg font-medium text-gray-900 mb-4">
                    Wykonaj test
                  </h3>
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Rezultat
                      </label>
                      <select
                        value={runData.result}
                        onChange={(e) => setRunData({ ...runData, result: e.target.value })}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                      >
                        <option value="passed">Zaliczony</option>
                        <option value="failed">Niezaliczony</option>
                      </select>
                    </div>
                    <div>
                      <label className="block text-sm font-medium text-gray-700">
                        Notatki
                      </label>
                      <textarea
                        value={runData.notes}
                        onChange={(e) => setRunData({ ...runData, notes: e.target.value })}
                        rows={3}
                        className="mt-1 block w-full border border-gray-300 rounded-md shadow-sm py-2 px-3 focus:outline-none focus:ring-green-500 focus:border-green-500"
                        placeholder="Opcjonalne notatki..."
                      />
                    </div>
                  </div>
                </div>
                <div className="bg-gray-50 px-4 py-3 sm:px-6 sm:flex sm:flex-row-reverse">
                  <button
                    type="submit"
                    className="w-full inline-flex justify-center rounded-md border border-transparent shadow-sm px-4 py-2 bg-green-600 text-base font-medium text-white hover:bg-green-700 focus:outline-none sm:ml-3 sm:w-auto sm:text-sm"
                  >
                    Zapisz
                  </button>
                  <button
                    type="button"
                    onClick={() => setShowRunModal(false)}
                    className="mt-3 w-full inline-flex justify-center rounded-md border border-gray-300 shadow-sm px-4 py-2 bg-white text-base font-medium text-gray-700 hover:bg-gray-50 focus:outline-none sm:mt-0 sm:w-auto sm:text-sm"
                  >
                    Anuluj
                  </button>
                </div>
              </form>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
