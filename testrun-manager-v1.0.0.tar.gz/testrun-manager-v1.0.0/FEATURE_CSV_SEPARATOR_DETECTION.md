# Feature - Automatyczne wykrywanie separatora CSV (przecinek lub średnik)

## Opis
Parser CSV automatycznie wykrywa separator używany w pliku:
- **Przecinek (`,`)** - standard międzynarodowy
- **Średnik (`;`)** - standard europejski (Excel w Polsce)

## Problem

### Przed:
Parser obsługiwał tylko **przecinek** jako separator:
```csv
ID TC,Tytuł,Opis,...  ← działa
```

Ale nie działał ze **średnikiem**:
```csv
ID TC;Tytuł;Opis;...  ← nie działa
```

**Efekt:** Pliki CSV eksportowane z polskiego Excela nie były importowane.

## Rozwiązanie

### 1. Funkcja wykrywania separatora

```typescript
const detectSeparator = (headerLine: string): string => {
  const commaCount = (headerLine.match(/,/g) || []).length;
  const semicolonCount = (headerLine.match(/;/g) || []).length;
  
  // Wybierz separator który występuje częściej
  if (semicolonCount > commaCount) {
    return ';';
  }
  return ',';
};
```

**Logika:**
- Zlicz przecinki w nagłówku
- Zlicz średniki w nagłówku
- Wybierz ten który występuje częściej

### 2. Modyfikacja parsera

```typescript
// Wykryj separator z nagłówka
const headerLine = lines[0];
const separator = detectSeparator(headerLine);
console.log(`Wykryto separator CSV: "${separator}"`);

// Użyj wykrytego separatora
dataLines.forEach(line => {
  const values = parseCSVLine(line, separator);
  // ...
});
```

### 3. Parsowanie z separatorem

```typescript
const parseCSVLine = (line: string, separator: string = ','): string[] => {
  // ...
  if (char === separator && !insideQuotes) {
    // Koniec wartości
    values.push(currentValue.trim());
    currentValue = '';
  }
  // ...
};
```

**Dodatkowo:** Dodano `.trim()` aby usunąć białe znaki z wartości.

## Obsługiwane formaty

### Format 1: Przecinek (międzynarodowy)
```csv
ID TC,Tytuł,Opis,Warunki wstępne,Numer kroku,Akcja,Oczekiwany rezultat,Priorytet,Status,Zestaw testowy,Powiązane wymagania,Tagi
PT1-001,Test 1,Opis,Warunki,1,Akcja,Rezultat,Wysoki,Szkic,Logowanie,WYM-001,Backend
```

**Wykrycie:** 11 przecinków w nagłówku → separator = `,`

### Format 2: Średnik (europejski)
```csv
ID TC;Tytuł;Opis;Warunki wstępne;Numer kroku;Akcja;Oczekiwany rezultat;Priorytet;Status;Zestaw testowy;Powiązane wymagania;Tagi
PT1-001;Test 1;Opis;Warunki;1;Akcja;Rezultat;Wysoki;Szkic;Logowanie;WYM-001;Backend
```

**Wykrycie:** 11 średników w nagłówku → separator = `;`

### Format 3: Mix (przecinki w wartościach)
```csv
ID TC;Tytuł;Opis;Warunki wstępne;Numer kroku;Akcja;Oczekiwany rezultat;Priorytet;Status;Zestaw testowy;Powiązane wymagania;Tagi
PT1-001;Test 1;Opis, długi;Warunki;1;Akcja;Rezultat;Wysoki;Szkic;Logowanie;WYM-001, WYM-002;Backend, API
```

**Wykrycie:** 11 średników > 3 przecinki → separator = `;`

## Przykład z Twojego pliku

### Twój CSV:
```csv
ID TC;Tytuł;Opis;Warunki wstępne;Numer kroku;Akcja;Oczekiwany rezultat;Priorytet;Status;Zestaw testowy;Powiązane wymagania;Tagi
PT1-004;fsfddsf44dsf;dsfdsfds;fdsfd;1;sfdsf;dsfdsf;Średni;Szkic;Admin;WYM-PT1-002;test
PT1-004;fsfddsf44dsf;dsfdsfds;fdsfd;2;sdfdsf;dsfdsf;Średni;Szkic;Admin;WYM-PT1-002;test
PT1-005;test 3;sxaxas;xsaxsaxsax;1;xsax;asxsax;Średni;Zatwierdzony;Logowanie;WYM-PT1-001, WYM-PT1-002;test, wymaganie
;Test 20;Sadsadsad das d sad są;Ddasdsadsad sadsad;1;tftftf;tftftf;Średni;Szkic;Strona główna;;Test, rap
```

### Wykrywanie:
```
Nagłówek: "ID TC;Tytuł;Opis;..."
Przecinki: 0
Średniki: 11
Wykryto separator: ";"
```

### Parsowanie:
```javascript
// Wiersz 1
"PT1-004;fsfddsf44dsf;dsfdsfds;fdsfd;1;sfdsf;dsfdsf;Średni;Szkic;Admin;WYM-PT1-002;test"
↓ split po ";"
["PT1-004", "fsfddsf44dsf", "dsfdsfds", "fdsfd", "1", "sfdsf", "dsfdsf", "Średni", "Szkic", "Admin", "WYM-PT1-002", "test"]
```

### Rezultat importu:
```
✅ Utworzono 3 nowych przypadków testowych
📁 Utworzono 2 nowych zestawów testowych (Admin, Strona główna)
```

**TC:**
- PT1-004 (2 kroki) → zestaw "Admin"
- PT1-005 (2 kroki) → zestaw "Logowanie"
- Test 20 (2 kroki) → zestaw "Strona główna", brak ID (automatyczne)

## Obsługa wartości z przecinkami/średnikami

### Wartości w cudzysłowach:
```csv
ID TC;Tytuł;Powiązane wymagania
PT1-001;Test;"WYM-001, WYM-002"
```

**Parsowanie:**
- Separator: `;`
- Wartość w cudzysłowach: `"WYM-001, WYM-002"`
- Przecinek wewnątrz cudzysłowów jest **ignorowany**
- Rezultat: `["PT1-001", "Test", "WYM-001, WYM-002"]`

## Kompatybilność z Excel

### Excel w Polsce:
- Domyślny separator: **średnik (`;`)**
- Eksport "Zapisz jako CSV" → używa średnika
- Teraz **działa automatycznie**! ✅

### Excel międzynarodowy:
- Domyślny separator: **przecinek (`,`)**
- Eksport "Save as CSV" → używa przecinka
- Nadal **działa**! ✅

## Debugowanie

### Log w konsoli:
```javascript
console.log(`Wykryto separator CSV: "${separator}"`);
```

**W przeglądarce (F12 → Console):**
```
Wykryto separator CSV: ";"
```

### Sprawdzanie w kodzie:
```typescript
// Przed parsowaniem
const headerLine = lines[0];
console.log('Nagłówek:', headerLine);
console.log('Przecinki:', (headerLine.match(/,/g) || []).length);
console.log('Średniki:', (headerLine.match(/;/g) || []).length);
```

## Dodatkowe ulepszenia

### Trim wartości:
```typescript
values.push(currentValue.trim());
```

**Korzyść:** Usuwa białe znaki przed i po wartości:
```
"  PT1-001  " → "PT1-001"
"  Test  " → "Test"
```

## Pliki zmienione

- `/frontend/src/utils/csvImport.ts`:
  - Funkcja `detectSeparator` - wykrywanie separatora
  - Modyfikacja `parseTestCasesCSV` - użycie wykrytego separatora
  - Modyfikacja `parseCSVLine` - parametr separator, trim wartości

## Testowanie

### Test 1: CSV z przecinkiem
```csv
ID TC,Tytuł,Opis
PT1-001,Test,Opis
```
✅ Wykryto: `,` → Import działa

### Test 2: CSV ze średnikiem
```csv
ID TC;Tytuł;Opis
PT1-001;Test;Opis
```
✅ Wykryto: `;` → Import działa

### Test 3: CSV z przecinkami w wartościach
```csv
ID TC;Tytuł;Powiązane wymagania
PT1-001;Test;"WYM-001, WYM-002"
```
✅ Wykryto: `;` → Import działa, przecinki w cudzysłowach ignorowane

## Korzyści

✅ **Uniwersalność** - działa z CSV z Excela (PL i EN)
✅ **Automatyzacja** - nie trzeba ręcznie konwertować separatorów
✅ **Kompatybilność** - obsługa obu standardów (`,` i `;`)
✅ **Debugowanie** - log w konsoli pokazuje wykryty separator
✅ **Czystość** - trim usuwa białe znaki z wartości

## Data implementacji
2026-05-14

## Status
✅ Zaimplementowane i gotowe do użycia
