import axios from 'axios';

const API_URL = 'http://localhost:3000/api';

const api = axios.create({
  baseURL: API_URL,
});

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

export const auth = {
  login: (email: string, password: string) =>
    api.post('/auth/login', { email, password }),
  register: (email: string, password: string, name: string) =>
    api.post('/auth/register', { email, password, name }),
};

export const projects = {
  getAll: () => api.get('/projects'),
  create: (data: { name: string; description: string }) =>
    api.post('/projects', data),
  update: (id: number, data: { name: string; description: string }) =>
    api.put(`/projects/${id}`, data),
  delete: (id: number) => api.delete(`/projects/${id}`),
};

export const tests = {
  getAll: (projectId?: number) =>
    api.get('/tests', { params: { project_id: projectId } }),
  getOne: (id: number) => api.get(`/tests/${id}`),
  create: (data: any) => api.post('/tests', data),
  update: (id: number, data: any) => api.put(`/tests/${id}`, data),
  delete: (id: number) => api.delete(`/tests/${id}`),
};

export const testRuns = {
  getAll: (testCaseId?: number) =>
    api.get('/test-runs', { params: { test_case_id: testCaseId } }),
  create: (data: { test_case_id: number; result: string; notes: string }) =>
    api.post('/test-runs', data),
};

export const statistics = {
  get: () => api.get('/statistics'),
};

export const users = {
  getAll: () => api.get('/users'), // Wymaga uprawnień admina
  getList: () => api.get('/users/list'), // Dostępne dla wszystkich zalogowanych
  create: (data: { email: string; password: string; name: string; role_id: number }) =>
    api.post('/users', data),
  update: (id: number, data: { email: string; name: string; role_id: number; is_active: number }) =>
    api.put(`/users/${id}`, data),
  delete: (id: number) => api.delete(`/users/${id}`),
  resetPassword: (id: number, new_password: string) =>
    api.post(`/users/${id}/reset-password`, { new_password }),
  getProjects: (id: number) => api.get(`/users/${id}/projects`),
  assignProject: (id: number, project_id: number) =>
    api.post(`/users/${id}/projects`, { project_id }),
  unassignProject: (id: number, projectId: number) =>
    api.delete(`/users/${id}/projects/${projectId}`),
};

export const roles = {
  getAll: () => api.get('/roles'),
  create: (data: { name: string; description: string; permissions: string }) =>
    api.post('/roles', data),
  update: (id: number, data: { name: string; description: string; permissions: string }) =>
    api.put(`/roles/${id}`, data),
  delete: (id: number) => api.delete(`/roles/${id}`),
};

export const requirements = {
  getAll: (projectId: number) => api.get(`/requirements?project_id=${projectId}`),
  getById: (id: number) => api.get(`/requirements/${id}`),
  create: (data: any) => api.post('/requirements', data),
  update: (id: number, data: any) => api.put(`/requirements/${id}`, data),
  delete: (id: number) => api.delete(`/requirements/${id}`),
};

export const testSpecifications = {
  getAll: (projectId: number) => api.get(`/test-specifications?project_id=${projectId}`),
  getById: (id: number) => api.get(`/test-specifications/${id}`),
  create: (data: any) => api.post('/test-specifications', data),
  update: (id: number, data: any) => api.put(`/test-specifications/${id}`, data),
  reorder: (id: number, data: { test_suite_id: number | null; display_order: number }) => 
    api.patch(`/test-specifications/${id}/reorder`, data),
  delete: (id: number) => api.delete(`/test-specifications/${id}`),
};

export const testSuites = {
  getAll: (projectId: number) => api.get(`/test-suites?project_id=${projectId}`),
  create: (data: any) => api.post('/test-suites', data),
  update: (id: number, data: any) => api.put(`/test-suites/${id}`, data),
  delete: (id: number, deleteTests: boolean) => api.delete(`/test-suites/${id}?deleteTests=${deleteTests}`),
};

export const requirementGroups = {
  getAll: (projectId: number) => api.get(`/requirement-groups?project_id=${projectId}`),
  create: (data: any) => api.post('/requirement-groups', data),
  update: (id: number, data: any) => api.put(`/requirement-groups/${id}`, data),
  delete: (id: number, deleteRequirements: boolean) => api.delete(`/requirement-groups/${id}?deleteRequirements=${deleteRequirements}`),
};

export const defects = {
  getAll: (projectId: number) => api.get(`/defects?project_id=${projectId}`),
  getById: (id: number) => api.get(`/defects/${id}`),
  create: (data: any) => api.post('/defects', data),
  update: (id: number, data: any) => api.put(`/defects/${id}`, data),
  delete: (id: number) => api.delete(`/defects/${id}`),
};

export const tags = {
  getAllGlobal: () => api.get('/tags'),
  getAll: (projectId: number) => api.get(`/tags/project/${projectId}`),
  getByProject: (projectId: number) => api.get(`/tags/project/${projectId}`),
  create: (data: { name: string; color: string; project_id?: number; description?: string }) => api.post('/tags', data),
  update: (id: number, data: { name: string; color: string; description?: string }) => api.put(`/tags/${id}`, data),
  delete: (id: number) => api.delete(`/tags/${id}`),
  assignToRequirement: (requirementId: number, tagIds: number[]) => api.post(`/tags/requirement/${requirementId}`, { tag_ids: tagIds }),
  assignToTestSpec: (specId: number, tagIds: number[]) => api.post(`/tags/test-specification/${specId}`, { tag_ids: tagIds }),
};

export const testPlans = {
  getAll: (projectId: number) => api.get(`/test-plans?project_id=${projectId}`),
  getById: (id: number) => api.get(`/test-plans/${id}`),
  getBurndown: (id: number) => api.get(`/test-plans/${id}/burndown`),
  create: (data: { name: string; description?: string; project_id: number; start_date?: string; end_date?: string; test_completion_date?: string }) => api.post('/test-plans', data),
  update: (id: number, data: { name: string; description?: string; start_date?: string; end_date?: string; test_completion_date?: string }) => api.put(`/test-plans/${id}`, data),
  delete: (id: number) => api.delete(`/test-plans/${id}`),
  toggleActive: (id: number) => api.patch(`/test-plans/${id}/toggle-active`),
  addCase: (planId: number, data: { test_specification_id: number; assigned_to?: number }) => 
    api.post(`/test-plans/${planId}/cases`, data),
  removeCase: (planId: number, caseId: number) => api.delete(`/test-plans/${planId}/cases/${caseId}`),
  assignUser: (planId: number, caseId: number, userId: number | null) => 
    api.put(`/test-plans/${planId}/cases/${caseId}/assign`, { assigned_to: userId }),
};

export const testExecutions = {
  start: (testPlanCaseId: number) => api.post('/test-executions/start', { test_plan_case_id: testPlanCaseId }),
  complete: (data: { execution_id: number; status: string; bug_id?: number; notes?: string }) => 
    api.post('/test-executions/complete', data),
  getHistory: (testPlanCaseId: number) => api.get(`/test-executions/history/${testPlanCaseId}`),
  getPlanExecutions: (planId: number) => api.get(`/test-executions/plan/${planId}`),
};

export const bugs = {
  getAll: (projectId: number) => api.get(`/bugs?project_id=${projectId}`),
  getById: (id: number) => api.get(`/bugs/${id}`),
  create: (data: { title: string; description?: string; steps_to_reproduce?: string; severity?: string; priority?: string; status?: string; project_id: number; assigned_to?: number; test_specification_id?: number }) => 
    api.post('/bugs', data),
  update: (id: number, data: { title?: string; description?: string; steps_to_reproduce?: string; severity?: string; priority?: string; status?: string; assigned_to?: number }) => 
    api.put(`/bugs/${id}`, data),
  delete: (id: number) => api.delete(`/bugs/${id}`),
  getComments: (bugId: number) => api.get(`/bugs/${bugId}/comments`),
  addComment: (bugId: number, comment: string) => api.post(`/bugs/${bugId}/comments`, { comment }),
  reassign: (bugId: number, newAssigneeId: number, comment?: string) => 
    api.post(`/bugs/${bugId}/reassign`, { new_assignee_id: newAssigneeId, comment }),
  getStatusHistory: (bugId: number) => api.get(`/bugs/${bugId}/status-history`),
  getAttachments: (bugId: number) => api.get(`/bugs/${bugId}/attachments`),
  uploadAttachment: (bugId: number, file: File) => {
    const formData = new FormData();
    formData.append('file', file);
    return api.post(`/bugs/${bugId}/attachments`, formData, {
      headers: { 'Content-Type': 'multipart/form-data' }
    });
  },
  downloadAttachment: (attachmentId: number) => `${API_URL}/bugs/attachments/${attachmentId}/download`,
  deleteAttachment: (attachmentId: number) => api.delete(`/bugs/attachments/${attachmentId}`),
};

export const statuses = {
  // Test Execution Statuses
  getTestExecutionStatuses: () => api.get('/statuses/test-execution'),
  getTestExecutionStatusesForProject: (projectId: number) => api.get(`/statuses/test-execution/project/${projectId}`),
  createTestExecutionStatus: (data: { name: string; key: string; color: string; description?: string; display_order?: number }) =>
    api.post('/statuses/test-execution', data),
  updateTestExecutionStatus: (id: number, data: { name: string; key: string; color: string; description?: string; is_active: boolean; display_order: number }) =>
    api.put(`/statuses/test-execution/${id}`, data),
  deleteTestExecutionStatus: (id: number) => api.delete(`/statuses/test-execution/${id}`),
  toggleTestExecutionStatusForProject: (projectId: number, statusId: number, isEnabled: boolean) =>
    api.post(`/statuses/test-execution/project/${projectId}/toggle/${statusId}`, { is_enabled: isEnabled }),
  
  // Bug Statuses
  getBugStatuses: () => api.get('/statuses/bug'),
  getBugStatusesForProject: (projectId: number) => api.get(`/statuses/bug/project/${projectId}`),
  createBugStatus: (data: { name: string; key: string; color: string; description?: string; display_order?: number }) =>
    api.post('/statuses/bug', data),
  updateBugStatus: (id: number, data: { name: string; key: string; color: string; description?: string; is_active: boolean; display_order: number }) =>
    api.put(`/statuses/bug/${id}`, data),
  deleteBugStatus: (id: number) => api.delete(`/statuses/bug/${id}`),
  toggleBugStatusForProject: (projectId: number, statusId: number, isEnabled: boolean) =>
    api.post(`/statuses/bug/project/${projectId}/toggle/${statusId}`, { is_enabled: isEnabled }),
};

export default api;
