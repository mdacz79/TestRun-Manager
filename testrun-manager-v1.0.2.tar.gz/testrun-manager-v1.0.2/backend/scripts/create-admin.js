#!/usr/bin/env node

/**
 * Skrypt do tworzenia użytkownika administratora
 * Użycie: node create-admin.js <email> <password> <name>
 */

const bcrypt = require('bcryptjs');
const initSqlJs = require('sql.js');
const fs = require('fs');
const path = require('path');

// Argumenty z linii komend
const [,, email, password, name] = process.argv;

if (!email || !password || !name) {
  console.error('❌ Błąd: Wymagane wszystkie parametry');
  console.log('Użycie: node create-admin.js <email> <password> <name>');
  console.log('Przykład: node create-admin.js admin@example.com Admin123! "Administrator"');
  process.exit(1);
}

// Ścieżka do bazy danych
const dbPath = path.join(__dirname, '..', 'database.db');

async function createAdmin() {
  try {
    // Sprawdź czy baza danych istnieje
    if (!fs.existsSync(dbPath)) {
      console.error('❌ Baza danych nie istnieje. Uruchom backend aby zainicjalizować bazę.');
      process.exit(1);
    }

    // Inicjalizuj sql.js
    const SQL = await initSqlJs();
    
    // Wczytaj bazę danych
    const buffer = fs.readFileSync(dbPath);
    const db = new SQL.Database(buffer);
    
    // Sprawdź czy użytkownik już istnieje
    const existingUserResult = db.exec('SELECT id FROM users WHERE email = ?', [email]);
    if (existingUserResult && existingUserResult[0] && existingUserResult[0].values.length > 0) {
      console.log('ℹ Użytkownik z tym emailem już istnieje');
      db.close();
      process.exit(0);
    }
    
    // Sprawdź liczbę użytkowników
    const userCountResult = db.exec('SELECT COUNT(*) as count FROM users');
    const userCount = userCountResult && userCountResult[0] ? userCountResult[0].values[0][0] : 0;
    const isFirstUser = userCount === 0;
    
    // Hashuj hasło
    const hashedPassword = bcrypt.hashSync(password, 10);
    
    // Utwórz użytkownika z rolą Administrator (role_id = 1)
    db.run(
      'INSERT INTO users (email, password, name, role_id, is_active) VALUES (?, ?, ?, ?, ?)',
      [email, hashedPassword, name, 1, 1]
    );
    
    // Zapisz bazę danych
    const data = db.export();
    fs.writeFileSync(dbPath, data);
    
    console.log('✓ Użytkownik administratora został utworzony pomyślnie!');
    console.log(`  - Email: ${email}`);
    console.log(`  - Imię: ${name}`);
    console.log(`  - Rola: Administrator`);
    
    if (!isFirstUser) {
      console.log('\n⚠️  Uwaga: To nie jest pierwszy użytkownik w systemie.');
      console.log('   Został utworzony z rolą Administrator na podstawie tego skryptu.');
    }
    
    db.close();
    process.exit(0);
  } catch (error) {
    console.error('❌ Błąd podczas tworzenia użytkownika:', error.message);
    console.error(error);
    process.exit(1);
  }
}

createAdmin();
