# TestRun Manager v1.0 - Automatyczny skrypt instalacyjny dla Windows
# Autor: ITM Marek Dacz
# Data: 2026

# Wymagaj uprawnień administratora
#Requires -RunAsAdministrator

# Ustaw kodowanie na UTF-8
[Console]::OutputEncoding = [System.Text.Encoding]::UTF8
$OutputEncoding = [System.Text.Encoding]::UTF8

Write-Host "==================================" -ForegroundColor Cyan
Write-Host "TestRun Manager v1.0 - Instalacja" -ForegroundColor Cyan
Write-Host "Autor: ITM Marek Dacz" -ForegroundColor Cyan
Write-Host "==================================" -ForegroundColor Cyan
Write-Host ""

# Funkcje pomocnicze
function Print-Success {
    param([string]$Message)
    Write-Host "✓ $Message" -ForegroundColor Green
}

function Print-Error {
    param([string]$Message)
    Write-Host "✗ $Message" -ForegroundColor Red
}

function Print-Info {
    param([string]$Message)
    Write-Host "ℹ $Message" -ForegroundColor Yellow
}

# Sprawdź Node.js
Write-Host "Krok 1: Sprawdzanie wymagań systemowych..." -ForegroundColor Cyan

try {
    $nodeVersion = node --version
    $nodeMajor = [int]($nodeVersion -replace 'v(\d+)\..*', '$1')
    
    if ($nodeMajor -lt 18) {
        Print-Error "Node.js w wersji 18+ jest wymagany. Aktualna wersja: $nodeVersion"
        Print-Info "Pobierz Node.js z https://nodejs.org/"
        exit 1
    }
    
    Print-Success "Node.js $nodeVersion - OK"
} catch {
    Print-Error "Node.js nie jest zainstalowany"
    Print-Info "Pobierz Node.js z https://nodejs.org/"
    exit 1
}

try {
    $npmVersion = npm --version
    Print-Success "npm $npmVersion - OK"
} catch {
    Print-Error "npm nie jest zainstalowany"
    exit 1
}

Write-Host ""
Write-Host "Krok 2: Konfiguracja instalacji..." -ForegroundColor Cyan

# Zapytaj o katalog instalacji
$defaultInstallDir = "C:\testrun-manager"
$installDir = Read-Host "Katalog instalacji [$defaultInstallDir]"
if ([string]::IsNullOrWhiteSpace($installDir)) {
    $installDir = $defaultInstallDir
}

# Zapytaj o port backendu
$defaultPort = "3000"
$backendPort = Read-Host "Port backendu [$defaultPort]"
if ([string]::IsNullOrWhiteSpace($backendPort)) {
    $backendPort = $defaultPort
}

# Zapytaj o domenę
$defaultDomain = "localhost"
$domain = Read-Host "Domena (przyklad: testrun.example.com) [$defaultDomain]"
if ([string]::IsNullOrWhiteSpace($domain)) {
    $domain = $defaultDomain
}

# Zapytaj czy zainstalować jako usługę
$installService = Read-Host "Czy zainstalować backend jako usługę Windows? (y/n) [y]"
if ([string]::IsNullOrWhiteSpace($installService)) {
    $installService = "y"
}

# Zapytaj o dane administratora
Write-Host ""
Write-Host "Konfiguracja konta administratora:" -ForegroundColor Cyan
$adminEmail = Read-Host "Email administratora [admin@example.com]"
if ([string]::IsNullOrWhiteSpace($adminEmail)) {
    $adminEmail = "admin@example.com"
}

$adminPassword = Read-Host "Haslo administratora (min. 6 znakow)" -AsSecureString
$adminPasswordPlain = [Runtime.InteropServices.Marshal]::PtrToStringAuto([Runtime.InteropServices.Marshal]::SecureStringToBSTR($adminPassword))
if ([string]::IsNullOrWhiteSpace($adminPasswordPlain) -or $adminPasswordPlain.Length -lt 6) {
    $adminPasswordPlain = "Admin123!"
    Print-Info "Uzyto domyslnego hasla: Admin123!"
}

$adminName = Read-Host "Imie i nazwisko administratora [Administrator]"
if ([string]::IsNullOrWhiteSpace($adminName)) {
    $adminName = "Administrator"
}

Write-Host ""
Write-Host "Krok 3: Tworzenie katalogow..." -ForegroundColor Cyan

# Utwórz katalog instalacji
if (-not (Test-Path $installDir)) {
    New-Item -ItemType Directory -Path $installDir -Force | Out-Null
    Print-Success "Utworzono katalog: $installDir"
} else {
    Print-Info "Katalog już istnieje: $installDir"
}

# Skopiuj pliki
Write-Host ""
Write-Host "Krok 4: Kopiowanie plików..." -ForegroundColor Cyan

$scriptDir = Split-Path -Parent $MyInvocation.MyCommand.Path

if ($scriptDir -ne $installDir) {
    Copy-Item -Path "$scriptDir\*" -Destination $installDir -Recurse -Force
    Print-Success "Pliki skopiowane do $installDir"
}

Set-Location $installDir

Write-Host ""
Write-Host "Krok 5: Instalacja zależności backendu..." -ForegroundColor Cyan

Set-Location "$installDir\backend"
npm install --production
Print-Success "Zależności backendu zainstalowane"

Write-Host ""
Write-Host "Krok 6: Budowanie frontendu..." -ForegroundColor Cyan

Set-Location "$installDir\frontend"
npm install
npm run build
Print-Success "Frontend zbudowany"

Write-Host ""
Write-Host "Krok 7: Konfiguracja środowiska..." -ForegroundColor Cyan

# Generuj losowy JWT secret
$jwtSecret = -join ((65..90) + (97..122) + (48..57) | Get-Random -Count 32 | ForEach-Object {[char]$_})

# Utwórz plik .env
$envContent = @"
# TestRun Manager - Konfiguracja środowiska
# Wygenerowano automatycznie: $(Get-Date)

# Port backendu
PORT=$backendPort

# JWT Secret (wygenerowany automatycznie)
JWT_SECRET=$jwtSecret

# CORS Origin
CORS_ORIGIN=http://$domain

# Database path
DB_PATH=./database.db

# Environment
NODE_ENV=production
"@

Set-Content -Path "$installDir\backend\.env" -Value $envContent
Print-Success "Plik .env utworzony"

# Buduj backend TypeScript
Write-Host ""
Write-Host "Krok 8: Budowanie backendu..." -ForegroundColor Cyan

Set-Location "$installDir\backend"
npm run build
Print-Success "Backend zbudowany"

# Instalacja jako usługa Windows
if ($installService -eq "y") {
    Write-Host ""
    Write-Host "Krok 9: Instalacja jako usługa Windows..." -ForegroundColor Cyan
    
    # Instalacja node-windows
    npm install -g node-windows
    
    # Utwórz skrypt usługi
    $serviceScript = @"
var Service = require('node-windows').Service;

var svc = new Service({
  name: 'TestRun Manager Backend',
  description: 'TestRun Manager Backend Service v1.0',
  script: '$installDir\\backend\\dist\\server.js',
  nodeOptions: [
    '--harmony',
    '--max_old_space_size=4096'
  ],
  env: {
    name: 'NODE_ENV',
    value: 'production'
  }
});

svc.on('install', function(){
  console.log('Service installed successfully');
  svc.start();
});

svc.on('alreadyinstalled', function(){
  console.log('Service already installed');
});

svc.on('start', function(){
  console.log('Service started');
});

svc.install();
"@
    
    Set-Content -Path "$installDir\backend\install-service.js" -Value $serviceScript
    
    # Uruchom instalację usługi
    node "$installDir\backend\install-service.js"
    
    Print-Success "Backend zainstalowany jako usługa Windows"
    Print-Info "Usługa zostanie uruchomiona automatycznie przy starcie systemu"
    
    # Poczekaj aż usługa się uruchomi
    Start-Sleep -Seconds 5
    
    # Utwórz użytkownika administratora
    Write-Host ""
    Write-Host "Tworzenie konta administratora..." -ForegroundColor Cyan
    try {
        node "$installDir\backend\scripts\create-admin.js" $adminEmail $adminPasswordPlain $adminName
        if ($LASTEXITCODE -eq 0) {
            Print-Success "Konto administratora utworzone"
        } else {
            Print-Info "Nie udalo sie utworzyc konta administratora automatycznie"
            Print-Info "Mozesz je utworzyc recznie po instalacji przez interfejs rejestracji"
        }
    } catch {
        Print-Info "Nie udalo sie utworzyc konta administratora automatycznie"
        Print-Info "Mozesz je utworzyc recznie po instalacji przez interfejs rejestracji"
    }
}

# Konfiguracja Windows Firewall
Write-Host ""
Write-Host "Krok 10: Konfiguracja Windows Firewall..." -ForegroundColor Cyan

try {
    New-NetFirewallRule -DisplayName "TestRun Manager Backend" -Direction Inbound -Protocol TCP -LocalPort $backendPort -Action Allow -ErrorAction SilentlyContinue
    Print-Success "Reguła firewall dodana dla portu $backendPort"
} catch {
    Print-Info "Nie można dodać reguły firewall - może już istnieć"
}

# Utwórz skrypt uruchamiający (dla trybu development)
$startScript = @"
@echo off
echo Starting TestRun Manager Backend...
cd /d "$installDir\backend"
node dist\server.js
pause
"@

Set-Content -Path "$installDir\start-backend.bat" -Value $startScript
Print-Success "Utworzono skrypt uruchamiający: start-backend.bat"

# Podsumowanie
Write-Host ""
Write-Host "==================================" -ForegroundColor Green
Write-Host "Instalacja zakonczona pomyslnie!" -ForegroundColor Green
Write-Host "==================================" -ForegroundColor Green
Write-Host ""
Write-Host "Szczegoly instalacji:" -ForegroundColor Cyan
Write-Host "  - Katalog: $($installDir)"
Write-Host "  - Backend port: $($backendPort)"
Write-Host "  - Domena: $($domain)"
Write-Host "  - Frontend: http://$($domain)"
Write-Host "  - Backend API: http://$($domain):$($backendPort)/api"
Write-Host ""
Write-Host "Konto administratora:" -ForegroundColor Cyan
Write-Host "  - Email: $($adminEmail)"
Write-Host "  - Haslo: $($adminPasswordPlain)"
Write-Host "  - Rola: Administrator"
Write-Host ""
Write-Host "Nastepne kroki:" -ForegroundColor Yellow
Write-Host "  1. Otworz przegladarke: http://$($domain):$($backendPort)"
Write-Host "  2. Zaloguj sie uzywajac powyzszych danych"
Write-Host "  3. Zmien haslo administratora w Panelu Administracyjnym"
Write-Host "  4. Zacznij korzystac z TestRun Manager!"
Write-Host ""

if ($installService -eq "y") {
    Write-Host "Przydatne komendy:" -ForegroundColor Cyan
    Write-Host "  - Status uslugi: Get-Service 'TestRun Manager Backend'"
    Write-Host "  - Start uslugi: Start-Service 'TestRun Manager Backend'"
    Write-Host "  - Stop uslugi: Stop-Service 'TestRun Manager Backend'"
    Write-Host "  - Restart uslugi: Restart-Service 'TestRun Manager Backend'"
} else {
    Write-Host "Uruchamianie backendu:" -ForegroundColor Cyan
    Write-Host "  - Uruchom: $($installDir)\start-backend.bat"
    Write-Host "  - Lub: cd $($installDir)\backend && node dist\server.js"
}

Write-Host ""
Write-Host "Dokumentacja: $($installDir)\INSTALLATION.md" -ForegroundColor Cyan
Write-Host ""
Write-Host "Autor: ITM Marek Dacz" -ForegroundColor Gray
Write-Host "Wersja: 1.0" -ForegroundColor Gray
Write-Host "==================================" -ForegroundColor Cyan
